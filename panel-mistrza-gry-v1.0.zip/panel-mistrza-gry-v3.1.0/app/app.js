/* Panel D&D — wspólne rzeczy „aplikacyjne”: service worker, instalacja, tryb okna aplikacji */
(function () {
    const standalone = () => matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: window-controls-overlay)').matches || navigator.standalone === true;
    document.documentElement.classList.toggle('is-app', standalone());
    if ('serviceWorker' in navigator && window.isSecureContext) {
        addEventListener('load', () => navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {}));
    }
    let deferred = null;
    addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; document.documentElement.classList.add('can-install'); dispatchEvent(new Event('pmg-install-ready')); });
    addEventListener('appinstalled', () => { deferred = null; document.documentElement.classList.remove('can-install'); document.documentElement.classList.add('is-app'); });
    const ua = navigator.userAgent;
    window.PanelApp = {
        standalone,
        canPrompt: () => !!deferred,
        ios: /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1),
        android: /Android/i.test(ua),
        async install() {
            if (!deferred) return false;
            deferred.prompt();
            const r = await deferred.userChoice.catch(() => null);
            deferred = null; document.documentElement.classList.remove('can-install');
            return r?.outcome === 'accepted';
        }
    };
})();
