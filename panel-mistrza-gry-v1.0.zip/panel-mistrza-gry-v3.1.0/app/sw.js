/* Panel D&D — service worker aplikacji (MG i gracz).
   Zawsze pobiera najnowsze pliki z serwera (nic nie trzyma na stałe, żeby aktualizacje
   działały od razu). Gdy serwer jest nieosiągalny, pokazuje stronę „Brak połączenia ze stołem”. */
const CACHE = 'pmg-offline-v1';
const OFFLINE = '/app/offline.html';
self.addEventListener('install', (e) => {
    e.waitUntil(caches.open(CACHE).then(c => c.addAll([OFFLINE, '/app/mg-192.png', '/app/gracz-192.png'])).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
    e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
    const req = e.request;
    if (req.method !== 'GET' || req.mode !== 'navigate') return;      // API, SSE i pliki idą prosto do serwera
    e.respondWith(fetch(req).catch(() => caches.match(OFFLINE)));
});
