# Third-party notices · Informacje o licencjach

## System Reference Document 5.1

This work includes material taken from the System Reference Document 5.1 ("SRD 5.1") by Wizards of the Coast LLC and available at https://dnd.wizards.com/resources/systems-reference-document. The SRD 5.1 is licensed under the Creative Commons Attribution 4.0 International License available at https://creativecommons.org/licenses/by/4.0/legalcode.

Polish translations and summaries of SRD material in this project are adaptations of the SRD 5.1 under the same license.

Rules data is loaded at runtime from the open D&D 5e SRD API (https://www.dnd5eapi.co, https://github.com/5e-bits/5e-srd-api).

*Dungeons & Dragons* and *D&D* are trademarks of Wizards of the Coast LLC. This is an unofficial fan project, not affiliated with, endorsed or sponsored by Wizards of the Coast.

## Bundled code (`js/dice-box.bundle.js`, `assets/dice-box/`)

- **@3d-dice/dice-box** — MIT License — https://github.com/3d-dice/dice-box
- **Babylon.js** — Apache License 2.0 — https://github.com/BabylonJS/Babylon.js
- **ammo.js** (physics, via dice-box) — zlib License — https://github.com/kripken/ammo.js

## Loaded from CDNs at runtime

- **Font Awesome Free 6** — icons CC BY 4.0, fonts SIL OFL 1.1, code MIT — https://fontawesome.com/license/free
- **QRCode.js** (davidshimjs) — MIT License — https://github.com/davidshimjs/qrcodejs
- **Google Fonts**: Cinzel, Outfit, Pirata One, Alegreya Sans, Caveat, IM Fell English — SIL Open Font License 1.1 — https://fonts.google.com

## Images

`assets/pergamin.jpg`, the textures in `img/` and `assets/oak_table_texture_*.jpg`, and the app icons in `app/` are part of this project and covered by the project license.
