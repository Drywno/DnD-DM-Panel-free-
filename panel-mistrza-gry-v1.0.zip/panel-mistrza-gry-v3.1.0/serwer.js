// ============================================================
//  Panel Mistrza Gry — serwer (bez dodatkowych pakietów, wystarczy Node.js 18+)
//
//  Na własnym komputerze: uruchamiany ikoną „Panel Mistrza Gry” (MG wchodzi bez hasła).
//  Dla graczy w domu: w panelu „Gracze” → „Udostępnij w sieci domowej”.
//  Na serwerze w internecie: zobacz plik SERWER.md (zmienne PANEL_*).
//
//  - serwuje panel MG (/) i widok gracza (/gracz),
//  - trzyma wspólny stan danych i rozsyła zmiany na żywo (SSE),
//  - zapisuje automatyczne kopie do folderu „kopie”.
// ============================================================
if (+String(process.versions.node).split('.')[0] < 18) {
    console.error(`Panel Mistrza Gry potrzebuje Node.js 18 lub nowszego (masz ${process.versions.node}). Pobierz wersję LTS: https://nodejs.org\n` +
        `The Game Master Panel needs Node.js 18 or newer (you have ${process.versions.node}). Get the LTS version: https://nodejs.org`);
    process.exit(1);
}
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { exec, spawn } = require('child_process');
const vm = require('vm');
const zlib = require('zlib');

const ROOT = __dirname;

// ---------- język komunikatów w konsoli: PANEL_LANG=pl|en, domyślnie wg języka systemu ----------
(() => {
    let lang = String(process.env.PANEL_LANG || '').toLowerCase();
    if (lang !== 'pl' && lang !== 'en') { let loc = ''; try { loc = Intl.DateTimeFormat().resolvedOptions().locale || ''; } catch (e) {} lang = /^pl/i.test(loc || process.env.LANG || '') ? 'pl' : 'en'; }
    if (lang !== 'en') return;
    let D = null;
    try { const w = {}; vm.runInNewContext(fs.readFileSync(path.join(ROOT, 'js', 'i18n-en.js'), 'utf8'), { window: w }); D = w.I18N_EN; } catch (e) { return; }
    const ex = new Map(Object.entries(D.e)), pats = D.p.map(([rx, en]) => [new RegExp(rx), en]);
    const tr = (s) => {
        if (typeof s !== 'string' || !/[A-Za-ząćęłńóśźż]/.test(s)) return s;
        return s.split('\n').map((line) => {
            const lead = line.match(/^\s*/)[0], core = line.trim();
            if (!core) return line;
            let t = ex.get(core);
            if (t == null) for (const [rx, en] of pats) { const m = rx.exec(core); if (m) { t = en.replace(/\{(\d+)\}/g, (x, k) => m[+k] ?? ''); break; } }
            if (t == null) { const m = /^(.*\S)(\s+)(\S+)$/.exec(core); const k = m && m[1].replace(/\s+/g, ' '); if (k && ex.has(k)) t = ex.get(k) + '  ' + m[3]; }
            return t == null ? line : lead + t;
        }).join('\n');
    };
    for (const k of ['log', 'warn', 'error', 'info']) { const o = console[k].bind(console); console[k] = (...a) => o(...a.map(tr)); }
})();
const AUTO = process.argv.includes('--auto');   // uruchomiony z ikony: bez okna, sam się wyłącza
const IDLE_LIMIT = 15 * 60 * 1000;
let lastSeen = Date.now();

// ---------- ustawienia ----------
const env = process.env;
const TRYB = env.PANEL_TRYB === 'serwer' ? 'serwer' : 'lokalny';   // „serwer”: brak automatycznego logowania MG z tego komputera
const PORT = +(env.PANEL_PORT || 8080);
const BASE = env.PANEL_DANE ? path.resolve(env.PANEL_DANE) : ROOT;
const DATA_DIR = path.join(BASE, 'dane');
const BACKUP_DIR = path.join(BASE, 'kopie');
const PUBLIC_URL = (env.PANEL_URL || '').replace(/\/+$/, '');
const TRUST_PROXY = env.PANEL_ZAUFAJ_PROXY === '1' || TRYB === 'serwer';
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(BACKUP_DIR, { recursive: true });

const kopie = require('./serwer/kopie.js')(BACKUP_DIR);
const konta = require('./serwer/konta.js')(DATA_DIR, kopie.writeAtomic);
const stan = require('./serwer/stan.js')(kopie, DATA_DIR);
const gracz = require('./serwer/gracz.js')(ROOT);

const SETTINGS_FILE = path.join(DATA_DIR, 'ustawienia.json');
let settings = {};
try { settings = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); } catch (e) { settings = {}; }
const saveSettings = () => kopie.writeAtomic(SETTINGS_FILE, JSON.stringify(settings, null, 2));
if (env.PANEL_HASLO_MG && /^zmien-mnie/i.test(env.PANEL_HASLO_MG)) {
    console.error('PANEL_HASLO_MG ma wartość przykładową z docker-compose.yml — ustaw własne, długie hasło Mistrza Gry.\n' +
        'PANEL_HASLO_MG still has the example value from docker-compose.yml — set your own long Game Master password.');
    process.exit(1);
}
if (env.PANEL_HASLO_MG) { try { if (!konta.checkDm(env.PANEL_HASLO_MG)) konta.setDmPassword(env.PANEL_HASLO_MG, { force: true }); } catch (e) { console.error(e.message); } }
const hostNow = () => env.PANEL_HOST || (settings.siec ? '0.0.0.0' : '127.0.0.1');
const URL_ = `http://localhost:${PORT}/`;

const MIME = {
    '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8', '.wasm': 'application/wasm', '.png': 'image/png', '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon',
    '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
    '.webmanifest': 'application/manifest+json; charset=utf-8'
};
const STATIC_DIRS = ['js', 'css', 'assets', 'img', 'fonts', 'app'];

function openBrowser() {
    const cmd = process.platform === 'win32' ? `start "" "${URL_}"` : process.platform === 'darwin' ? `open "${URL_}"` : `xdg-open "${URL_}"`;
    exec(cmd, () => {});
}
// adresy tego komputera w sieci — najpierw prawdziwe Wi‑Fi / Ethernet, na końcu wirtualne (VPN, maszyny wirtualne)
const VIRTUAL = /vmware|virtualbox|vbox|vethernet|hyper-v|wsl|docker|radmin|hamachi|zerotier|tailscale|wireguard|openvpn|tap|tun|loopback|bluetooth|npcap|vpn/i;
const REAL = /wi-?fi|wlan|wireless|ethernet|^eth|^en\d|^wl|połączenie|lan/i;
function lanInfo() {
    const out = [];
    Object.entries(os.networkInterfaces()).forEach(([name, list]) => (list || []).forEach(a => {
        if (a.family !== 'IPv4' && a.family !== 4) return;
        if (a.internal) return;
        const ip = a.address;
        const priv = /^192\.168\./.test(ip) || /^10\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip);
        let rank = 0;
        if (VIRTUAL.test(name)) rank += 20;
        if (/^26\./.test(ip) || /^25\./.test(ip)) rank += 10;          // Radmin / Hamachi
        if (/^169\.254\./.test(ip)) rank += 30;                        // brak adresu z routera
        if (!priv) rank += 5;
        if (!REAL.test(name)) rank += 2;
        if (/^192\.168\.(56|44|113|137|99)\./.test(ip) && !REAL.test(name)) rank += 5;  // typowe sieci maszyn wirtualnych
        out.push({ ip, name, rank, virtual: rank >= 10 });
    }));
    return out.sort((x, y) => x.rank - y.rank);
}
const lanAddresses = () => lanInfo().map(a => a.ip);

// ---------- bezpieczny adres (https) — potrzebny telefonom, żeby dało się „zainstalować” aplikację gracza ----------
// Telefony instalują aplikacje (PWA) tylko z adresów https. W sieci domowej używamy darmowej usługi local-ip.sh:
// nazwa 192-168-1-10.local-ip.sh wskazuje na 192.168.1.10, a do nazw *.local-ip.sh jest publiczny certyfikat
// Let's Encrypt. Certyfikat pobieramy raz i odświeżamy przed wygaśnięciem. Wyłączenie: PANEL_HTTPS=0.
const HTTPS_ON = env.PANEL_HTTPS !== '0' && TRYB !== 'serwer';
const HTTPS_PORT = +(env.PANEL_HTTPS_PORT || (PORT === 8080 ? 8443 : PORT + 1));
const TLS_DIR = path.join(DATA_DIR, 'tls');
let tlsCert = null, httpsServer = null, httpsHost = null, tlsFetching = null;
const secureHost = (ip) => `${String(ip).replace(/\./g, '-')}.local-ip.sh`;
const secureUrl = (ip) => `https://${secureHost(ip)}:${HTTPS_PORT}`;
function loadTls() {
    try {
        const cert = fs.readFileSync(path.join(TLS_DIR, 'local-ip.pem'), 'utf8'), key = fs.readFileSync(path.join(TLS_DIR, 'local-ip.key'), 'utf8');
        const validTo = Date.parse(new crypto.X509Certificate(cert).validTo);
        if (validTo > Date.now()) tlsCert = { cert, key, validTo };
    } catch (e) {}
    return !!tlsCert;
}
const tlsFresh = () => !!tlsCert && tlsCert.validTo - Date.now() > 20 * 86400e3;
async function fetchTls() {
    if (typeof fetch !== 'function') return false;
    const get = async (u) => { const r = await fetch(u, { signal: AbortSignal.timeout(15000), cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); };
    try {
        const [cert, key] = await Promise.all([get('https://local-ip.sh/server.pem'), get('https://local-ip.sh/server.key')]);
        const x = new crypto.X509Certificate(cert);
        if (!x.checkPrivateKey(crypto.createPrivateKey(key))) throw new Error('klucz nie pasuje do certyfikatu');
        if (!/local-ip\.sh/.test(x.subjectAltName || x.subject)) throw new Error('nieoczekiwany certyfikat');
        fs.mkdirSync(TLS_DIR, { recursive: true });
        kopie.writeAtomic(path.join(TLS_DIR, 'local-ip.pem'), cert);
        kopie.writeAtomic(path.join(TLS_DIR, 'local-ip.key'), key);
        tlsCert = { cert, key, validTo: Date.parse(x.validTo) };
        if (httpsServer) { try { httpsServer.setSecureContext({ cert, key }); } catch (e) {} }
        return true;
    } catch (e) { console.log('  (https dla telefonów niedostępne: ' + e.message + ')'); return false; }
}
async function ensureHttps() {
    if (!HTTPS_ON || currentHost === '127.0.0.1') { stopHttps(); return; }
    if (!tlsCert) loadTls();
    if (!tlsFresh()) { tlsFetching = tlsFetching || fetchTls().finally(() => { tlsFetching = null; }); await tlsFetching; }
    startHttps();
}
function startHttps() {
    const h = currentHost;
    if (!HTTPS_ON || !tlsCert || h === '127.0.0.1') { stopHttps(); return; }
    if (httpsServer && httpsHost === h) return;
    stopHttps();
    const srv = https.createServer({ cert: tlsCert.cert, key: tlsCert.key }, handler);
    srv.on('error', (e) => {
        try { srv.close(); } catch (er) {}
        if (httpsServer === srv) { httpsServer = null; httpsHost = null; }
        // poprzednia wersja serwera jeszcze zwalnia port — spróbuj ponownie
        if (e.code === 'EADDRINUSE' && (startHttps.tries = (startHttps.tries || 0) + 1) < 30) { setTimeout(startHttps, 1000); return; }
        console.log('  (https dla telefonów: ' + e.message + ')');
    });
    srv.listen(HTTPS_PORT, h, () => {
        startHttps.tries = 0;
        setTimeout(httpsSelfTest, 500);
        httpsServer = srv; httpsHost = h;
        lanAddresses().slice(0, 2).forEach(a => console.log(`  Aplikacja na telefon (https): ${secureUrl(a)}/gracz`));
    });
}
// samosprawdzenie: czy nazwa *.local-ip.sh rozwiązuje się w tej sieci (router może blokować) i czy https odpowiada
let httpsDiag = null, diagRunning = null;
async function httpsSelfTest() {
    if (diagRunning) return diagRunning;
    diagRunning = (async () => {
        const ip = lanAddresses()[0]; if (!ip || !httpsServer) { httpsDiag = null; return; }
        const host = secureHost(ip), d = { host, ip, at: Date.now(), dns: null, resolved: null, conn: null };
        try {
            const r = await Promise.race([require('dns').promises.lookup(host, { family: 4 }), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 6000))]);
            d.resolved = r.address; d.dns = r.address === ip ? 'ok' : 'inny-adres';
        } catch (e) { d.dns = 'blokada'; d.dnsErr = e.code || e.message; }
        d.conn = await new Promise((done) => {
            const req = https.get({ host: ip, port: HTTPS_PORT, path: '/api/ping', servername: host, timeout: 5000, headers: { Host: `${host}:${HTTPS_PORT}` } }, (res) => { res.resume(); done(res.statusCode === 200 ? 'ok' : 'http ' + res.statusCode); });
            req.on('timeout', () => { req.destroy(); done('timeout'); });
            req.on('error', (e) => done(e.code || e.message));
        });
        httpsDiag = d;
        console.log(`  Test https dla telefonów: nazwa ${host} → ${d.dns === 'ok' ? 'OK' : 'NIE DZIAŁA (' + (d.dnsErr || d.resolved) + ')'}, połączenie ${d.conn}`);
    })().finally(() => { diagRunning = null; });
    return diagRunning;
}
setInterval(() => { if (httpsServer) httpsSelfTest(); }, 10 * 60e3);
function stopHttps() {
    if (!httpsServer) return;
    const old = httpsServer; httpsServer = null; httpsHost = null;
    try { old.close(); if (old.closeAllConnections) old.closeAllConnections(); } catch (e) {}
}
// adres IP, przez który przyszło zapytanie (do zbudowania bezpiecznego adresu dla tego samego telefonu)
function requestIp(req) {
    const host = String(req.headers.host || '').replace(/:\d+$/, '');
    const m = host.match(/^(\d+)-(\d+)-(\d+)-(\d+)\.local-ip\.sh$/);
    if (m) return m.slice(1).join('.');
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host) && host !== '127.0.0.1') return host;
    return lanAddresses()[0] || null;
}

// ---------- pomocnicze ----------
function sendJSON(res, code, obj, headers = {}) {
    res.writeHead(code, { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store', ...headers });
    res.end(JSON.stringify(obj));
}
const fail = (res, code, msg) => sendJSON(res, code, { ok: false, error: msg });
function readBody(req, cb, limit = 60e6) {
    const chunks = []; let n = 0, tooBig = false;
    req.on('data', c => { n += c.length; if (n > limit) { tooBig = true; req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!tooBig) cb(Buffer.concat(chunks).toString('utf8')); });
}
function readJSON(req, res, cb, limit) {
    readBody(req, (body) => {
        let j; try { j = JSON.parse(body || '{}'); } catch (e) { fail(res, 400, 'Niepoprawne dane.'); return; }
        try { cb(j, body); } catch (e) { fail(res, 400, e.message || 'Błąd.'); }
    }, limit);
}
function cookies(req) {
    const out = {};
    String(req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
    return out;
}
function clientIp(req) {
    if (TRUST_PROXY && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
    return req.socket.remoteAddress || '';
}
function isLoopback(req) {
    if (TRYB === 'serwer' || req.headers['x-forwarded-for'] || req.headers['forwarded']) return false;
    const a = req.socket.remoteAddress || '';
    return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}
function isSecure(req) {
    if (TRUST_PROXY && String(req.headers['x-forwarded-proto'] || '').startsWith('https')) return true;
    return !!req.socket.encrypted;
}
function who(req) {
    const tok = cookies(req).pmg;
    const s = konta.session(tok);
    if (s) {
        if (s.rola === 'gracz') { const g = konta.get(s.pid); if (g) return { rola: 'gracz', pid: g.id, g, token: tok }; }
        else return { rola: 'mg', token: tok };
    }
    if (isLoopback(req)) return { rola: 'mg', local: true };
    return null;
}
// sesje zamknięte, bo ktoś wszedł na to samo konto gdzie indziej — żeby stare okno wiedziało, czemu je wylogowano
const bumped = new Map();
const wasBumped = (req) => { const t = cookies(req).pmg; if (!t || !bumped.has(t)) return false; if (Date.now() - bumped.get(t) > 7 * 86400000) { bumped.delete(t); return false; } return true; };
function setSession(req, res, rola, pid) {
    // jedno konto gracza = jedno urządzenie: nowe logowanie zamyka poprzednie sesje i wyrzuca otwarte okna
    if (rola === 'gracz' && pid) { konta.dropFor(pid).forEach(t => bumped.set(t, Date.now())); kickPlayer(pid); }
    const t = konta.create(rola, pid, { ip: clientIp(req), ua: req.headers['user-agent'] });
    // MG: ciasteczko tylko dla tej strony (Strict) i krótsze niż u graczy
    const cookie = rola === 'mg' ? `SameSite=Strict; Max-Age=${konta.MG_DAYS * 86400}` : `SameSite=Lax; Max-Age=${60 * 86400}`;
    res.setHeader('Set-Cookie', `pmg=${t}; Path=/; HttpOnly; ${cookie}${isSecure(req) ? '; Secure' : ''}`);
    return t;
}
const redirect = (res, to) => { res.writeHead(302, { Location: to, 'Cache-Control': 'no-store' }); res.end(); };

// prosta blokada zgadywania haseł i kodów
const attempts = new Map();
function limited(req) {
    const ip = clientIp(req), now = Date.now();
    const a = attempts.get(ip) || { n: 0, t: now };
    if (now - a.t > 15 * 60000) { a.n = 0; a.t = now; }
    attempts.set(ip, a);
    return a.n >= 12;
}
const failedAttempt = (req) => { const a = attempts.get(clientIp(req)); if (a) a.n++; };
// hasło MG: osobna, ostrzejsza blokada — po 5 błędach przerwa rośnie (5 min → 15 min → 1 h → 6 h),
// a przy wielu próbach z różnych adresów logowanie MG z sieci wstrzymuje się na kwadrans
const dmFails = new Map();
let dmGlobal = { n: 0, t: Date.now(), until: 0 };
const DM_STEPS = [5, 15, 60, 360];
function dmLocked(req) {
    const now = Date.now();
    if (dmGlobal.until > now) return Math.ceil((dmGlobal.until - now) / 60000);
    const a = dmFails.get(clientIp(req));
    return a && a.until > now ? Math.ceil((a.until - now) / 60000) : 0;
}
function dmFailed(req) {
    const ip = clientIp(req), now = Date.now();
    const a = dmFails.get(ip) || { n: 0, strikes: 0, until: 0, t: now };
    if (now - a.t > 24 * 3600000) { a.n = 0; a.strikes = 0; }
    a.t = now; a.n++;
    if (a.n >= 5) { a.until = now + DM_STEPS[Math.min(a.strikes, DM_STEPS.length - 1)] * 60000; a.strikes++; a.n = 0; }
    dmFails.set(ip, a);
    if (now - dmGlobal.t > 3600000) dmGlobal = { n: 0, t: now, until: 0 };
    if (++dmGlobal.n >= 30) { dmGlobal.until = now + 15 * 60000; dmGlobal.n = 0; }
    addLog({ kto: 'Panel', rola: 'sys', typ: 'sys', tylkoMG: true, tekst: `nieudana próba logowania jako Mistrz Gry z adresu ${ip || 'nieznanego'}${a.until > now ? ` — blokada na ${DM_STEPS[Math.max(0, a.strikes - 1)]} min` : ''}` });
}
const dmOk = (req) => dmFails.delete(clientIp(req));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ---------- dziennik stołu i „pokaż graczom” ----------
const LOG_FILE = path.join(DATA_DIR, 'dziennik.json');

// ---------- tłumaczenia (bestiariusz, magia, cechy): wspólna pamięć na dysku ----------
// Każdy tekst tłumaczymy tylko raz — potem MG i gracze dostają go od razu z pliku, także po restarcie.
const TR_FILE = path.join(DATA_DIR, 'tlumaczenia.json');
const tr = new Map();
try { Object.entries(JSON.parse(fs.readFileSync(TR_FILE, 'utf8'))).forEach(([k, v]) => tr.set(k, v)); } catch (e) {}
let trTimer = null;
const trSave = () => { clearTimeout(trTimer); trTimer = setTimeout(() => { try { kopie.writeAtomic(TR_FILE, JSON.stringify(Object.fromEntries(tr))); } catch (e) {} }, 2000); };
async function googleTr(text) {
    // długie teksty dzielimy na akapity, żeby adres nie był za długi
    if (text.length > 3500) {
        const parts = text.split(/(\n+)/);
        const out = [];
        for (const part of parts) out.push(/^\n+$/.test(part) || !part.trim() ? part : await googleTr(part));
        return out.join('');
    }
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=pl&dt=t&q=${encodeURIComponent(text)}`;
    const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    return (j[0] || []).map(x => x[0]).join('');
}
const trPending = new Map();
async function translateMany(list) {
    const out = new Array(list.length);
    const todo = [];
    list.forEach((t, i) => { if (tr.has(t)) out[i] = tr.get(t); else todo.push(i); });
    let next = 0;
    const worker = async () => {
        while (next < todo.length) {
            const i = todo[next++], t = list[i];
            try {
                if (!trPending.has(t)) trPending.set(t, googleTr(t).finally(() => trPending.delete(t)));
                const v = await trPending.get(t);
                if (v) { tr.set(t, v); out[i] = v; } else out[i] = null;
            } catch (e) { out[i] = null; }
        }
    };
    await Promise.all(Array.from({ length: Math.min(8, todo.length) }, worker));
    if (todo.length) trSave();
    return out;
}
let log = [];
try { log = JSON.parse(fs.readFileSync(LOG_FILE, 'utf8')) || []; } catch (e) { log = []; }
let logTimer = null;
const saveLog = () => { clearTimeout(logTimer); logTimer = setTimeout(() => { try { kopie.writeAtomic(LOG_FILE, JSON.stringify(log.slice(-300))); } catch (e) {} }, 1500); };
const LIVE_FILE = path.join(DATA_DIR, 'pokaz.json');
// muzyka i nastrój: co gra u wszystkich + nagrania wgrane przez MG
const MOOD_FILE = path.join(DATA_DIR, 'nastroj.json');
// tablica karczmy (menu, nocleg, plotka) — ostatnia pokazana graczom, żeby mogli do niej wrócić
const BOARD_FILE = path.join(DATA_DIR, 'tablica.json');
let tablica = null;
try { tablica = JSON.parse(fs.readFileSync(BOARD_FILE, 'utf8')); } catch (e) { tablica = null; }
function cleanBoard(b) {
    if (!b || typeof b !== 'object') return null;
    const rows = (a) => (Array.isArray(a) ? a : []).slice(0, 8).map(r => (Array.isArray(r) ? r : []).slice(0, 3).map(x => String(x ?? '').slice(0, 90)));
    return { dishes: rows(b.dishes), drinks: rows(b.drinks), room: rows(b.room), rumor: String(b.rumor || '').slice(0, 500), t: Date.now() };
}
const AUDIO_DIR = path.join(DATA_DIR, 'audio');
const AUDIO_LIST = path.join(AUDIO_DIR, 'lista.json');
const AUDIO_TYPES = { 'audio/mpeg': 'mp3', 'audio/mp3': 'mp3', 'audio/ogg': 'ogg', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/webm': 'webm', 'audio/mp4': 'm4a', 'audio/x-m4a': 'm4a', 'audio/aac': 'aac', 'audio/flac': 'flac' };
const AUDIO_MIME = { mp3: 'audio/mpeg', ogg: 'audio/ogg', wav: 'audio/wav', webm: 'audio/webm', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac' };
fs.mkdirSync(AUDIO_DIR, { recursive: true });
let mood = null;
try { mood = JSON.parse(fs.readFileSync(MOOD_FILE, 'utf8')); if (!mood || mood.kind !== 'plik') mood = null; } catch (e) { mood = null; }
const audioList = () => { try { return JSON.parse(fs.readFileSync(AUDIO_LIST, 'utf8')) || []; } catch (e) { return []; } };
const saveAudioList = (l) => kopie.writeAtomic(AUDIO_LIST, JSON.stringify(l, null, 1));
let live = null;
try { live = JSON.parse(fs.readFileSync(LIVE_FILE, 'utf8')); } catch (e) { live = null; }
// mapa, na której MG prowadzi teraz grę (gracze mogą za nią podążać)
const SCENA_FILE = path.join(DATA_DIR, 'scena.json');
let scena = null;
const pingAt = new Map();
try { scena = JSON.parse(fs.readFileSync(SCENA_FILE, 'utf8')); } catch (e) { scena = null; }

// obrazek postaci (jeśli gracz albo MG go wgrał) — do kropek w dzienniku
function charAv(g) {
    if (!g?.charId) return null;
    try { const c = JSON.parse(stan.data[`dnd5e_dm_characters_${g.campaignId}`] || '[]').find(x => x.id === g.charId); return c && c.portrait ? `${g.campaignId}|${c.id}|${c.portraitV || 1}` : null; } catch (e) { return null; }
}
function charName(g) {
    if (!g?.charId) return null;
    try { return (JSON.parse(stan.data[`dnd5e_dm_characters_${g.campaignId}`] || '[]').find(c => c.id === g.charId) || {}).name || null; } catch (e) { return null; }
}
// każdy przy stole ma swój kolor (ten sam w czacie, w dzienniku i przy wskazywaniu na mapie)
const SEAT_COLORS = ['#e05a4a', '#4a9de0', '#3fbf6f', '#b07ad8', '#e8a23a', '#2ec4b6', '#e05aa0', '#c08a5a'];
function colorOf(rola, pid) {
    if (rola === 'mg') return '#e9c46a';
    if (rola === 'sys') return '#9b8869';
    const idx = konta.list().findIndex(g => g.id === pid);
    return SEAT_COLORS[Math.max(0, idx) % SEAT_COLORS.length];
}
const withColor = (e) => e.kolor ? e : { ...e, kolor: colorOf(e.rola, e.pid) };
// kto widzi wpis: MG wszystko; gracz — wpisy jawne, własne i prywatne skierowane do niego
const canSee = (e, rola, pid) => rola === 'mg' || (!e.tylkoMG && !e.dla) || (!!pid && (e.pid === pid || e.dla === pid));
function addLog(entry) {
    const e = withColor({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), t: Date.now(), ...entry });
    log.push(e); if (log.length > 300) log = log.slice(-300);
    saveLog();
    clients.forEach(c => { if (canSee(e, c.rola, c.pid)) send(c, 'log', e); });
    return e;
}

// ---------- połączenia na żywo (SSE) ----------
const clients = new Set();
function send(c, event, data) { try { c.res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch (e) {} }
function online() {
    const pids = new Set(), out = { mg: false, gracze: [] };
    clients.forEach(c => { if (c.rola === 'mg') out.mg = true; else if (c.pid) pids.add(c.pid); });
    out.gracze = konta.list().filter(g => pids.has(g.id)).map(g => ({ id: g.id, name: g.name, charId: g.charId, postac: charName(g) }));
    return out;
}
let onlineTimer = null;
function announceOnline() { clearTimeout(onlineTimer); onlineTimer = setTimeout(() => { const o = online(); clients.forEach(c => send(c, 'online', o)); }, 200); }
let stanTimer = null;
function notifyPlayers() {
    clearTimeout(stanTimer);
    stanTimer = setTimeout(() => clients.forEach(c => { if (c.rola === 'gracz') send(c, 'stan', { version: stan.version }); }), 250);
}
function notifyDM(keys, origin, exceptKlient) {
    if (!keys.length) return;
    const payload = { version: stan.version, keys: stan.values(keys), origin };
    clients.forEach(c => { if (c.rola === 'mg' && c.klient !== exceptKlient) send(c, 'ops', payload); });
}
setInterval(() => clients.forEach(c => { try { c.res.write(': ping\n\n'); } catch (e) {} }), 25000);

function playerView(g) {
    return { ...gracz.view(stan.data, g, { version: stan.version, live, scena, online: online().gracze, players: konta.list() }), tablica };
}

// ---------- API ----------
function api(req, res, url, me) {
    const p = url.pathname, M = req.method;
    const q = url.searchParams;
    const isMG = me?.rola === 'mg';

    // zabezpieczenie przed wysyłaniem formularzy z obcych stron
    if (M === 'POST' && req.headers['x-panel'] !== '1') return fail(res, 403, 'Brak nagłówka panelu.');

    if (p === '/api/wersja') return sendJSON(res, 200, { ok: true, stale: codeSig() !== START_SIG, start: START_TIME });
    if (p === '/api/bezpieczny') {
        const ip = requestIp(req), on = !!(httpsServer && tlsCert && ip);
        const out = { ok: true, https: on, secure: isSecure(req), url: on ? secureUrl(ip) : null, test: httpsDiag };
        if (on && me?.rola === 'gracz' && me.g?.kod) out.gracz = `${secureUrl(ip)}/gracz?kod=${encodeURIComponent(me.g.kod)}`;
        return sendJSON(res, 200, out);
    }
    if (p === '/api/ping') { res.writeHead(200, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Private-Network': 'true' }); res.end('ok'); return; }

    // ---- logowanie ----
    if (p === '/api/login' && M === 'POST') {
        if (limited(req)) return fail(res, 429, 'Za dużo prób. Spróbuj za kilkanaście minut.');
        return readJSON(req, res, (j) => {
            if (j.kod) {
                const g = konta.byCode(j.kod);
                if (!g) { failedAttempt(req); return fail(res, 401, 'Nieprawidłowy kod gracza.'); }
                setSession(req, res, 'gracz', g.id);
                return sendJSON(res, 200, { ok: true, rola: 'gracz', dokad: '/gracz' });
            }
            if (!konta.hasDm()) return fail(res, 401, 'Mistrz Gry nie ustawił jeszcze hasła. Zaloguj się na komputerze z panelem.');
            const lock = dmLocked(req);
            if (lock) return fail(res, 429, `Logowanie Mistrza Gry jest chwilowo zablokowane po kilku błędnych hasłach. Spróbuj za ${lock} min.`);
            if (!konta.checkDm(j.haslo || '')) {
                dmFailed(req);
                // celowe opóźnienie: zgadywanie haseł staje się bardzo wolne
                return sleep(900 + Math.random() * 600).then(() => fail(res, 401, dmLocked(req) ? `Nieprawidłowe hasło. Zbyt wiele prób — spróbuj za ${dmLocked(req)} min.` : 'Nieprawidłowe hasło.'));
            }
            dmOk(req);
            setSession(req, res, 'mg');
            addLog({ kto: 'Panel', rola: 'sys', typ: 'sys', tylkoMG: true, tekst: `Mistrz Gry zalogował się z adresu ${clientIp(req) || 'nieznanego'}` });
            sendJSON(res, 200, { ok: true, rola: 'mg', dokad: '/' });
        }, 1e5);
    }
    if (p === '/api/logout' && M === 'POST') {
        if (me?.token) konta.drop(me.token);
        res.setHeader('Set-Cookie', 'pmg=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
        return sendJSON(res, 200, { ok: true });
    }
    if (p === '/api/ja') {
        if (!me) return sendJSON(res, 200, { ok: true, rola: null, haslo: konta.hasDm(), sesja: wasBumped(req) || undefined });
        return sendJSON(res, 200, { ok: true, rola: me.rola, lokalny: !!me.local, gracz: me.g ? { id: me.g.id, name: me.g.name, charId: me.g.charId, kod: me.g.kod } : null });
    }

    if (!me) return sendJSON(res, 401, { ok: false, error: wasBumped(req) ? 'Na to konto zalogowano się na innym urządzeniu.' : 'Zaloguj się.', sesja: wasBumped(req) || undefined });

    // ---- obrazki postaci (z karty; MG podaje kampanię, gracz widzi tylko swoją) ----
    // ---- muzyka: lista nagrań i odtwarzanie (MG i gracze) ----
    if (p === '/api/audio' && M === 'GET') return sendJSON(res, 200, { ok: true, pliki: audioList(), nastroj: mood });
    if (p === '/api/audio/plik' && M === 'GET') {
        const it = audioList().find(x => x.id === q.get('id'));
        const file = it && path.join(AUDIO_DIR, it.plik);
        if (!it || !/^[a-z0-9]+\.[a-z0-9]{2,5}$/.test(it.plik) || !fs.existsSync(file)) return fail(res, 404, 'Nie ma takiego nagrania.');
        const size = fs.statSync(file).size, type = AUDIO_MIME[it.plik.split('.').pop()] || 'application/octet-stream';
        const range = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
        if (range) {
            const start = range[1] ? +range[1] : Math.max(0, size - (+range[2] || 0)), end = range[1] && range[2] ? Math.min(+range[2], size - 1) : size - 1;
            if (start >= size || start > end) { res.writeHead(416, { 'Content-Range': `bytes */${size}` }); return res.end(); }
            res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${start}-${end}/${size}`, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Cache-Control': 'private, max-age=86400' });
            return fs.createReadStream(file, { start, end }).pipe(res);
        }
        res.writeHead(200, { 'Content-Type': type, 'Content-Length': size, 'Accept-Ranges': 'bytes', 'Cache-Control': 'private, max-age=86400' });
        return fs.createReadStream(file).pipe(res);
    }
    // własna mapa świata kampanii (obraz trzymany w danych atlasu) — osobno, żeby nie wysyłać go w każdym widoku gracza
    if (p === '/api/mapa-swiata' && M === 'GET') {
        const kamp = isMG ? String(q.get('k') || '') : me.g?.campaignId;
        let url = null;
        try { url = ((JSON.parse(stan.data[`dnd5e_dm_atlas_${kamp}`] || '{}') || {}).world || {}).url || null; } catch (e) { url = null; }
        const m = url && /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(url);
        if (!m) return fail(res, 404, 'Brak obrazka.');
        res.writeHead(200, { 'Content-Type': m[1], 'Cache-Control': q.get('v') ? 'private, max-age=31536000, immutable' : 'private, max-age=30' });
        res.end(Buffer.from(m[2], 'base64'));
        return;
    }
    if (p === '/api/portret' && M === 'GET') {
        const kamp = isMG ? String(q.get('k') || '') : me.g?.campaignId;
        let url = null;
        try { url = (JSON.parse(stan.data[`dnd5e_dm_characters_${kamp}`] || '[]').find(c => c.id === q.get('c')) || {}).portrait || null; } catch (e) { url = null; }
        const m = url && /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(url);
        if (!m) return fail(res, 404, 'Brak obrazka.');
        res.writeHead(200, { 'Content-Type': m[1], 'Cache-Control': q.get('v') ? 'private, max-age=31536000, immutable' : 'private, max-age=30' });
        res.end(Buffer.from(m[2], 'base64'));
        return;
    }

    // ---- na żywo ----
    if (p === '/api/events') {
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
        res.write(`retry: 3000\n\n`);
        const c = { res, rola: me.rola, pid: me.pid || null, token: me.token || null, klient: q.get('klient') || '' };
        clients.add(c);
        send(c, 'hello', { version: stan.version, rola: me.rola, online: online() });
        if (me.rola === 'gracz' && live) send(c, 'live', live);
        if (me.rola === 'gracz' && scena) send(c, 'scena', scena);
        if (mood) send(c, 'nastroj', mood);
        announceOnline();
        req.on('close', () => { clients.delete(c); announceOnline(); });
        return;
    }

    // ---- dziennik stołu ----
    if (p === '/api/tlumacz' && M === 'POST') {
        if (!me) return fail(res, 401, 'Zaloguj się.');
        return readJSON(req, res, async (j) => {
            const list = (Array.isArray(j.teksty) ? j.teksty : []).slice(0, 80).map(t => String(t ?? '').slice(0, 20000));
            if (typeof fetch !== 'function') return sendJSON(res, 200, { ok: true, wyniki: list.map(t => tr.get(t) ?? null) });
            try { sendJSON(res, 200, { ok: true, wyniki: await translateMany(list) }); } catch (e) { fail(res, 500, e.message); }
        }, 2e6);
    }
    if (p === '/api/dziennik' && M === 'GET') {
        return sendJSON(res, 200, { ok: true, wpisy: log.filter(e => canSee(e, me.rola, me.pid)).slice(-120).map(withColor) });
    }
    if (p === '/api/dziennik' && M === 'POST') {
        return readJSON(req, res, (j) => {
            const kto = isMG ? 'Mistrz Gry' : me.g.name, postac = isMG ? null : charName(me.g);
            const av = isMG ? null : charAv(me.g);
            const base = { kto, postac, rola: me.rola, pid: me.pid || null, ...(av ? { av } : {}) };
            // wiadomość prywatna: gracz → MG albo MG → wybrany gracz
            if (j.szept) {
                if (isMG) {
                    const g = konta.get(String(j.dla || ''));
                    if (!g) return fail(res, 400, 'Wybierz gracza, do którego piszesz.');
                    Object.assign(base, { szept: true, dla: g.id, dlaKto: charName(g) || g.name });
                } else Object.assign(base, { szept: true, dla: 'mg', dlaKto: 'Mistrz Gry', tylkoMG: true });
            }
            if (j.typ === 'rzut') {
                const r = gracz.roll(j.wyr, j.tryb, Array.isArray(j.kosci) ? j.kosci : null);
                const e = addLog({ tylkoMG: isMG && !!j.ukryty && !base.szept, ...base, typ: 'rzut', opis: String(j.opis || '').slice(0, 80), rzut: r });
                return sendJSON(res, 200, { ok: true, wpis: e });
            }
            const tekst = String(j.tekst || '').trim().slice(0, 600);
            if (!tekst) return fail(res, 400, 'Pusta wiadomość.');
            sendJSON(res, 200, { ok: true, wpis: addLog({ ...base, typ: 'wiad', tekst }) });
        }, 1e5);
    }

    // ---- pingi na mapie (MG i gracze): krótki znak „tutaj!” widoczny u wszystkich ----
    if (p === '/api/wskaz' && M === 'POST') {
        return readJSON(req, res, (j) => {
            const key = isMG ? 'mg' : me.pid, now = Date.now();
            if (now - (pingAt.get(key) || 0) < 350) return sendJSON(res, 200, { ok: true });
            pingAt.set(key, now);
            const num = (v) => { const n = Number(v); if (!Number.isFinite(n)) throw new Error('Złe miejsce.'); return Math.max(0, Math.min(100, Math.round(n * 100) / 100)); };
            let x, y;
            try { x = num(j.x); y = num(j.y); } catch (e) { return fail(res, 400, e.message); }
            const idx = isMG ? -1 : konta.list().findIndex(g => g.id === me.pid);
            const ping = { id: now.toString(36) + Math.random().toString(36).slice(2, 5), mapId: String(j.mapId || '').slice(0, 80), levelId: j.levelId ? String(j.levelId).slice(0, 80) : null, x, y,
                kto: isMG ? 'Mistrz Gry' : (charName(me.g) || me.g.name), rola: me.rola, pid: me.pid || null, color: isMG ? '#e9c46a' : SEAT_COLORS[Math.max(0, idx) % SEAT_COLORS.length] };
            clients.forEach(c => send(c, 'ping', ping));
            sendJSON(res, 200, { ok: true, ping });
        }, 1e4);
    }

    // ---- widok i akcje gracza ----
    if (p === '/api/gracz/stan') {
        const g = isMG ? konta.get(q.get('jako') || '') : me.g;
        if (!g) return fail(res, 404, 'Nie ma takiego gracza.');
        return sendJSON(res, 200, { ok: true, ...playerView(g), podglad: isMG });
    }
    if (p === '/api/gracz/akcja' && M === 'POST') {
        if (me.rola !== 'gracz') return fail(res, 403, 'To akcja gracza.');
        return readJSON(req, res, (j) => {
            const op = gracz.buildOp(me.g, j);
            const r = stan.playerOp(op);
            notifyDM(r.keys, { gracz: me.g.name, typ: j.typ }, null);
            notifyPlayers();
            if (op.meta?.log) addLog({ kto: me.g.name, postac: charName(me.g), rola: 'gracz', pid: me.pid || null, typ: 'wiad', tekst: op.meta.log, zadanie: true });
            sendJSON(res, 200, { ok: true, version: r.version });
        }, 2e6);
    }

    if (!isMG) return fail(res, 403, 'Tylko dla Mistrza Gry.');

    // ---- dane MG ----
    if (p === '/api/sync') {
        if (M === 'POST') {
            return readJSON(req, res, (j, raw) => {
                const legacy = !('base' in j || 'set' in j || 'full' in j);
                let r;
                if (legacy) { const keys = stan.replaceAll(kopie.parseBackup(raw)); r = { version: stan.version, keys, merged: {} }; }
                else r = stan.dmPush(j);
                const all = [...new Set([...(r.keys || []), ...Object.keys(r.merged || {})])];
                notifyDM(all, 'mg', req.headers['x-klient'] || null);
                notifyPlayers();
                stan.persistNow();
                sendJSON(res, 200, { ok: true, version: r.version, merged: r.merged || {}, t: Date.now(), stats: kopie.statsOf(stan.data) });
            });
        }
        res.writeHead(200, { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store', 'X-Wersja': String(stan.version) });
        return res.end(JSON.stringify(stan.data));
    }
    if (p === '/api/sync/patch' && M === 'POST') {
        return readJSON(req, res, (j) => {
            const r = stan.dmPush({ base: stan.version, set: j.set || {}, del: j.del || [] });
            notifyDM(r.keys, 'mg', req.headers['x-klient'] || null); notifyPlayers();
            stan.persistNow();
            sendJSON(res, 200, { ok: true, version: r.version });
        });
    }
    if (p === '/api/status') {
        const e = fs.existsSync(path.join(BACKUP_DIR, 'autokopia.json')) ? kopie.indexEntry('autokopia.json') : null;
        return sendJSON(res, 200, { ok: true, dir: BACKUP_DIR, last: kopie.lastSync || e?.t || null, stats: kopie.statsOf(stan.data), version: 3, stanWersja: stan.version });
    }
    if (p === '/api/backups') {
        stan.persistNow();
        try { return sendJSON(res, 200, { ok: true, dir: BACKUP_DIR, items: kopie.listBackups() }); } catch (e) { return fail(res, 500, e.message); }
    }
    if (p === '/api/backups/file') {
        const rel = q.get('f') || '', file = path.join(BACKUP_DIR, rel);
        if (!kopie.SAFE_REL.test(rel) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
        const headers = { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store' };
        if (q.get('dl')) headers['Content-Disposition'] = `attachment; filename="panel_${path.basename(rel)}"`;
        res.writeHead(200, headers);
        return fs.createReadStream(file).pipe(res);
    }
    if (p === '/api/backups/snapshot' && M === 'POST') {
        return readBody(req, (body) => {
            try { sendJSON(res, 200, { ok: true, item: kopie.saveManual(body, q.get('name') || '') }); } catch (e) { fail(res, 400, e.message); }
        });
    }

    // ---- gracze i udostępnianie ----
    if (p === '/api/online' && M === 'GET') {
        const on = online();
        return sendJSON(res, 200, {
            ok: true, tryb: TRYB, host: hostNow(), port: PORT, siec: hostNow() !== '127.0.0.1', siecZmienna: !env.PANEL_HOST, url: PUBLIC_URL,
            adresy: lanAddresses(), adresyInfo: lanInfo(), nasluch: server.address() ? server.address().address : null, hasDm: konta.hasDm(),
            https: httpsServer && tlsCert ? { port: HTTPS_PORT, hosty: lanAddresses().map(secureHost), test: httpsDiag } : null, lokalny: !!me.local, max: konta.max, online: on,
            gracze: konta.list().map(g => ({ ...g, online: on.gracze.some(x => x.id === g.id), postac: charName(g) })), live
        });
    }
    if (p === '/api/online/haslo' && M === 'POST') {
        return readJSON(req, res, (j) => {
            if (konta.hasDm() && !me.local) {
                const lock = dmLocked(req);
                if (lock) return fail(res, 429, `Zbyt wiele błędnych haseł — spróbuj za ${lock} min.`);
                if (!konta.checkDm(j.stare || '')) { dmFailed(req); return fail(res, 401, 'Obecne hasło się nie zgadza.'); }
            }
            konta.setDmPassword(j.haslo);
            if (!me.local) setSession(req, res, 'mg');
            sendJSON(res, 200, { ok: true });
        }, 1e5);
    }
    // urządzenia zalogowane jako MG + wylogowanie wszystkich pozostałych
    if (p === '/api/online/mg-sesje' && M === 'GET') {
        return sendJSON(res, 200, { ok: true, sesje: konta.mgSessions().map(x => ({ ip: x.ip, ua: x.ua, od: x.od, ostatnio: x.ostatnio, to: x.t === me.token })) });
    }
    if (p === '/api/online/mg-wyloguj' && M === 'POST') {
        return readJSON(req, res, () => {
            const n = konta.dropMgExcept(me.token || null);
            clients.forEach(c => { if (c.rola === 'mg' && c.token && c.token !== me.token) { try { c.res.end(); } catch (e) {} clients.delete(c); } });
            sendJSON(res, 200, { ok: true, n });
        }, 1e5);
    }
    if (p === '/api/online/siec' && M === 'POST') {
        return readJSON(req, res, (j) => {
            if (env.PANEL_HOST) return fail(res, 400, 'Adres serwera ustawiono w konfiguracji (PANEL_HOST).');
            if (j.wlacz && !konta.hasDm()) return fail(res, 400, 'Najpierw ustaw hasło Mistrza Gry.');
            settings.siec = !!j.wlacz; saveSettings();
            sendJSON(res, 200, { ok: true, siec: settings.siec, adresy: lanAddresses(), adresyInfo: lanInfo() });
            setTimeout(relisten, 150);
        }, 1e4);
    }
    if (p === '/api/online/gracz' && M === 'POST') {
        return readJSON(req, res, (j) => { const g = konta.upsert(j); announceOnline(); notifyPlayers(); sendJSON(res, 200, { ok: true, gracz: g }); }, 1e5);
    }
    if (p === '/api/online/gracz/kod' && M === 'POST') {
        return readJSON(req, res, (j) => { const g = konta.regen(j.id); closeClients(j.id); sendJSON(res, 200, { ok: true, gracz: g }); }, 1e4);
    }
    if (p === '/api/online/gracz/usun' && M === 'POST') {
        return readJSON(req, res, (j) => { konta.remove(j.id); closeClients(j.id); announceOnline(); sendJSON(res, 200, { ok: true }); }, 1e4);
    }
    if (p === '/api/online/max' && M === 'POST') {
        return readJSON(req, res, (j) => { konta.setMax(j.max); sendJSON(res, 200, { ok: true, max: konta.max }); }, 1e4);
    }
    if (p === '/api/online/scena' && M === 'POST') {
        return readJSON(req, res, (j) => {
            const nowy = { mapId: j.mapId ? String(j.mapId).slice(0, 80) : null, levelId: j.levelId ? String(j.levelId).slice(0, 80) : null, lead: j.lead !== false, t: Date.now() };
            const same = scena && scena.mapId === nowy.mapId && scena.levelId === nowy.levelId && scena.lead === nowy.lead;
            scena = nowy;
            if (!same) {
                try { kopie.writeAtomic(SCENA_FILE, JSON.stringify(scena)); } catch (e) {}
                clients.forEach(c => { if (c.rola === 'gracz') send(c, 'scena', scena); });
            }
            sendJSON(res, 200, { ok: true, scena });
        }, 1e4);
    }
    // ---- muzyka i nastrój (tylko MG) ----
    if (p === '/api/nastroj' && M === 'POST') {
        return readJSON(req, res, (j) => {
            if (j.stop) mood = null;
            else {
                const kind = 'plik', id = String(j.id || '').slice(0, 40);
                if (!audioList().some(x => x.id === id)) return fail(res, 404, 'Nie ma takiego nagrania.');
                const same = mood && mood.kind === kind && mood.id === id;
                mood = { kind, id, name: kind === 'plik' ? (audioList().find(x => x.id === id) || {}).nazwa || '' : '', vol: Math.max(0, Math.min(1, +j.vol || 0.8)), loop: j.loop !== false, t: same && j.onlyVol ? mood.t : Date.now() };
            }
            try { kopie.writeAtomic(MOOD_FILE, JSON.stringify(mood)); } catch (e) {}
            clients.forEach(c => send(c, 'nastroj', mood || { kind: 'stop', t: Date.now() }));
            sendJSON(res, 200, { ok: true, nastroj: mood });
        });
    }
    if (p === '/api/audio' && M === 'POST') {
        const ext = AUDIO_TYPES[String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase()];
        if (!ext) return fail(res, 415, 'To nie jest plik dźwiękowy (mp3, ogg, wav, m4a…).');
        const LIMIT = 40 * 1024 * 1024, chunks = []; let size = 0, over = false;
        req.on('data', (d) => { size += d.length; if (size > LIMIT) { over = true; req.destroy(); return; } chunks.push(d); });
        req.on('end', () => {
            if (over) return;
            const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6), plik = `${id}.${ext}`;
            try { fs.writeFileSync(path.join(AUDIO_DIR, plik), Buffer.concat(chunks)); } catch (e) { return fail(res, 500, 'Nie udało się zapisać nagrania.'); }
            const nazwa = String(q.get('nazwa') || 'Nagranie').replace(/\.[a-z0-9]{2,5}$/i, '').slice(0, 80);
            const l = audioList(); l.push({ id, plik, nazwa, rozmiar: size, t: Date.now() }); saveAudioList(l);
            sendJSON(res, 200, { ok: true, plik: l[l.length - 1] });
        });
        req.on('close', () => { if (over) { try { fail(res, 413, 'Plik jest za duży (maks. 40 MB).'); } catch (e) {} } });
        return;
    }
    if (p === '/api/audio/usun' && M === 'POST') {
        return readJSON(req, res, (j) => {
            const l = audioList(), it = l.find(x => x.id === j.id);
            if (!it) return fail(res, 404, 'Nie ma takiego nagrania.');
            try { fs.unlinkSync(path.join(AUDIO_DIR, it.plik)); } catch (e) {}
            saveAudioList(l.filter(x => x !== it));
            if (mood && mood.kind === 'plik' && mood.id === it.id) { mood = null; try { kopie.writeAtomic(MOOD_FILE, 'null'); } catch (e) {} clients.forEach(c => send(c, 'nastroj', { kind: 'stop', t: Date.now() })); }
            sendJSON(res, 200, { ok: true });
        });
    }
    if (p === '/api/online/live' && M === 'POST') {
        return readJSON(req, res, (j) => {
            if (j.clear) live = null;
            else live = { id: Date.now().toString(36), t: Date.now(), kind: String(j.kind || 'tekst').slice(0, 20), title: String(j.title || '').slice(0, 160),
                text: String(j.text || '').slice(0, 8000), url: j.url ? String(j.url).slice(0, 8e6) : null, mapId: j.mapId || null, levelId: j.levelId || null };
            if (live && live.kind === 'tablica') {
                live.board = cleanBoard(j.board);
                if (live.board) { tablica = live.board; try { kopie.writeAtomic(BOARD_FILE, JSON.stringify(tablica)); } catch (e) {} }
            }
            try { kopie.writeAtomic(LIVE_FILE, JSON.stringify(live)); } catch (e) {}
            clients.forEach(c => send(c, 'live', live || { clear: true }));
            if (live && live.kind !== 'mapa') addLog({ kto: 'Mistrz Gry', rola: 'mg', typ: 'sys', tekst: live.kind === 'obraz' ? `pokazuje obraz${live.title ? `: ${live.title}` : ''}` : live.kind === 'tablica' ? 'wywiesza nowe menu na tablicy karczmy' : `czyta: ${live.title || 'tekst dla graczy'}` });
            sendJSON(res, 200, { ok: true, live });
        }, 1e7);
    }
    fail(res, 404, 'Nie ma takiego adresu.');
}
function kickPlayer(pid) {
    let n = 0;
    clients.forEach(c => { if (c.rola === 'gracz' && c.pid === pid) { n++; send(c, 'wylogowano', { powod: 'inne-urzadzenie' }); setTimeout(() => { try { c.res.end(); } catch (e) {} }, 150); clients.delete(c); } });
    if (n) { const g = konta.get(pid); addLog({ kto: g?.name || 'Gracz', rola: 'sys', typ: 'sys', tylkoMG: true, tekst: 'zalogował(a) się na innym urządzeniu — poprzednie zostało rozłączone' }); setTimeout(announceOnline, 200); }
}
function closeClients(pid) { clients.forEach(c => { if (c.pid === pid) { try { c.res.end(); } catch (e) {} clients.delete(c); } }); }

// ---------- pliki ----------
// pliki panelu: kompresja gzip (raz liczona i trzymana w pamięci), ETag + 304 gdy przeglądarka ma aktualną kopię,
// a pliki z numerem wersji (?v=…) — w pamięci przeglądarki na stałe (nowa wersja = nowy adres)
const GZIP_EXT = new Set(['.html', '.js', '.css', '.json', '.svg', '.txt', '.webmanifest', '.wasm', '.ico']);
const gzCache = new Map();
function serveFile(res, file, headers = {}, req = null) {
    fs.stat(file, (err, st) => {
        if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Nie znaleziono'); return; }
        const ext = path.extname(file).toLowerCase();
        const etag = `"${st.size.toString(36)}-${Math.round(st.mtimeMs).toString(36)}"`;
        const versioned = !!(req && /[?&]v=/.test(req.url || ''));
        const base = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': versioned ? 'public, max-age=31536000, immutable' : 'no-cache', ETag: etag, Vary: 'Accept-Encoding', ...headers };
        if (req && req.headers['if-none-match'] === etag) { res.writeHead(304, base); res.end(); return; }
        const gz = req && GZIP_EXT.has(ext) && st.size > 1024 && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
        if (!gz) { res.writeHead(200, { ...base, 'Content-Length': st.size }); fs.createReadStream(file).pipe(res); return; }
        const key = file + etag;
        let buf = gzCache.get(key);
        if (!buf) {
            try { buf = zlib.gzipSync(fs.readFileSync(file), { level: 6 }); } catch (e) { res.writeHead(200, base); fs.createReadStream(file).pipe(res); return; }
            for (const k of gzCache.keys()) if (k.startsWith(file + '"')) gzCache.delete(k);   // stara wersja tego pliku
            gzCache.set(key, buf);
        }
        res.writeHead(200, { ...base, 'Content-Encoding': 'gzip', 'Content-Length': buf.length });
        res.end(buf);
    });
}
const PAGE_HEADERS = { 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'same-origin', 'X-Content-Type-Options': 'nosniff' };

const handler = (req, res) => {
    let url;
    try { url = new URL(req.url, 'http://x'); } catch (e) { res.writeHead(400); res.end(); return; }
    let p;
    try { p = decodeURIComponent(url.pathname); } catch (e) { res.writeHead(400); res.end(); return; }
    lastSeen = Date.now();
    const me = who(req);

    if (p.startsWith('/api/')) return api(req, res, url, me);

    if (p === '/' || p === '/index.html') {
        if (me?.rola === 'mg') return serveFile(res, path.join(ROOT, 'index.html'), PAGE_HEADERS, req);
        return redirect(res, me?.rola === 'gracz' ? '/gracz' : '/logowanie');
    }
    if (p === '/gracz' || p === '/gracz/' || p === '/player.html') {
        const kod = url.searchParams.get('kod');
        if (kod) {
            if (limited(req)) return redirect(res, '/logowanie?blad=limit');
            const g = konta.byCode(kod);
            if (!g) { failedAttempt(req); return redirect(res, '/logowanie?blad=kod'); }
            if (!(me?.rola === 'gracz' && me.pid === g.id)) setSession(req, res, 'gracz', g.id);
            return redirect(res, '/gracz');
        }
        if (!me) return redirect(res, wasBumped(req) ? '/logowanie?blad=sesja' : '/logowanie');
        return serveFile(res, path.join(ROOT, 'player.html'), PAGE_HEADERS, req);
    }
    if (p === '/logowanie' || p === '/logowanie.html') return serveFile(res, path.join(ROOT, 'logowanie.html'), PAGE_HEADERS, req);
    if (p === '/app/gracz.webmanifest') {
        let m = {}; try { m = JSON.parse(fs.readFileSync(path.join(ROOT, 'app', 'gracz.webmanifest'), 'utf8')); } catch (e) {}
        if (me?.rola === 'gracz' && me.g?.kod) m.start_url = `/gracz?kod=${encodeURIComponent(me.g.kod)}`;
        res.writeHead(200, { 'Content-Type': 'application/manifest+json; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(JSON.stringify(m));
    }
    // pakiet kampanii jest opcjonalny — bez niego panel dostaje pusty skrypt zamiast błędu 404
    if (p === '/assets/kampania/pakiet.js' && !fs.existsSync(path.join(ROOT, 'assets', 'kampania', 'pakiet.js'))) {
        res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache' });
        return res.end('/* brak pakietu kampanii */');
    }
    if (p === '/favicon.ico') return serveFile(res, path.join(ROOT, 'app', 'mg.ico'), {}, req);
    // aplikacja (PWA): service worker musi leżeć w katalogu głównym, żeby obejmował cały panel
    if (p === '/sw.js') return serveFile(res, path.join(ROOT, 'app', 'sw.js'), { 'Service-Worker-Allowed': '/', 'Cache-Control': 'no-cache' }, req);

    // tylko foldery z wyglądem panelu — nigdy dane, kopie ani pliki serwera
    const rel = path.normalize(p).replace(/^[/\\]+/, '');
    const top = rel.split(/[/\\]/)[0];
    if (!STATIC_DIRS.includes(top) || rel.split(/[/\\]/).some(s => s.startsWith('.'))) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Nie znaleziono'); return; }
    const file = path.join(ROOT, rel);
    if (!file.startsWith(ROOT + path.sep)) { res.writeHead(403); res.end(); return; }
    serveFile(res, file, {}, req);
};

// ---------- samoczynny restart po wgraniu nowych plików serwera ----------
const START_TIME = Date.now();
function codeFiles() {
    let extra = [];
    try { extra = fs.readdirSync(path.join(ROOT, 'serwer')).filter(f => f.endsWith('.js')).map(f => path.join(ROOT, 'serwer', f)); } catch (e) {}
    return [path.join(ROOT, 'serwer.js'), ...extra];
}
const codeSig = () => codeFiles().map(f => { try { const s = fs.statSync(f); return `${f}:${s.size}:${Math.round(s.mtimeMs)}`; } catch (e) { return `${f}:-`; } }).join('|');
const START_SIG = codeSig();
let changedAt = 0, badSig = '', restarting = false;
function selfRestart() {
    if (restarting) return;
    // nie restartuj na uszkodzonym pliku (np. w trakcie kopiowania)
    for (const f of codeFiles()) {
        try { new vm.Script(fs.readFileSync(f, 'utf8'), { filename: f }); }
        catch (e) { badSig = codeSig(); console.error('  Nowe pliki serwera mają błąd — zostaję przy starej wersji:', e.message); return; }
    }
    restarting = true;
    console.log('  Wykryto nową wersję plików — uruchamiam serwer ponownie…');
    stopHttps();
    try { stan.persistNow(); } catch (e) {}
    try { konta.flush(); } catch (e) {}
    try { kopie.writeAtomic(LOG_FILE, JSON.stringify(log.slice(-300))); } catch (e) {}
    try { if (trTimer) { clearTimeout(trTimer); kopie.writeAtomic(TR_FILE, JSON.stringify(Object.fromEntries(tr))); } } catch (e) {}
    const args = process.argv.slice(1);
    if (!args.includes('--auto')) args.push('--auto');
    try {
        const child = spawn(process.execPath, args, { cwd: process.cwd(), env: { ...process.env, PANEL_RESTART: '1', PANEL_BEZ_PRZEGLADARKI: '1' }, detached: true, stdio: 'ignore', windowsHide: true });
        child.unref();
    } catch (e) { console.error('  Restart nieudany:', e.message); restarting = false; return; }
    clients.forEach(c => { try { c.res.end(); } catch (e) {} });
    try { server.close(); if (server.closeAllConnections) server.closeAllConnections(); } catch (e) {}
    setTimeout(() => process.exit(0), 400);
}
setInterval(() => {
    const sig = codeSig();
    if (sig === START_SIG || sig === badSig) { changedAt = 0; return; }
    if (!changedAt) { changedAt = Date.now(); return; }
    if (Date.now() - changedAt > 2500) selfRestart();
}, 2000);

// ---------- start ----------
let server = http.createServer(handler);
let currentHost = hostNow();
function listen() {
    server.listen(PORT, currentHost, () => {
        console.log('');
        console.log('  Panel Mistrza Gry działa:  ' + (PUBLIC_URL || URL_));
        if (currentHost !== '127.0.0.1') lanAddresses().forEach(a => console.log(`  Dla graczy w sieci:        http://${a}:${PORT}/gracz`));
        console.log('  Dane i kopie:              ' + BASE);
        console.log('');
        ensureHttps();
    });
}
// zmiana „tylko ten komputer” ↔ „sieć domowa” bez wyłączania panelu
let relistening = false;
function relisten() {
    const h = hostNow();
    if (h === currentHost || relistening) return;
    relistening = true;
    const old = server;
    const go = (tries = 0) => {
        const srv = http.createServer(handler);
        srv.once('error', (e) => {
            if (e.code === 'EADDRINUSE' && tries < 20) { setTimeout(() => go(tries + 1), 250); return; }
            console.error('Nie udało się przełączyć dostępu z sieci:', e.message);
            // wróć do poprzedniego adresu, żeby panel dalej działał
            const back = http.createServer(handler); back.on('error', onError);
            back.listen(PORT, currentHost, () => { server = back; relistening = false; });
        });
        srv.listen(PORT, h, () => {
            srv.on('error', onError);
            server = srv; currentHost = h; relistening = false;
            ensureHttps();
            console.log(h === '127.0.0.1' ? '  Dostęp z sieci zamknięty.' : `  Stół otwarty w sieci: ${lanAddresses().map(a => `http://${a}:${PORT}/gracz`).join('  ')}`);
        });
    };
    // najpierw całkowicie zwolnij port (Windows nie pozwala nasłuchiwać dwa razy na tym samym porcie)
    clients.forEach(c => { try { c.res.end(); } catch (e) {} });
    clients.clear();
    let started = false;
    const start = () => { if (!started) { started = true; go(); } };
    old.close(start);
    if (old.closeAllConnections) old.closeAllConnections();
    setTimeout(start, 1500);   // starsze Node: nie czekaj w nieskończoność na otwarte połączenia
}
function onError(e) {
    if (relistening) return;
    if (e.code === 'EADDRINUSE' && env.PANEL_RESTART && (onError.tries = (onError.tries || 0) + 1) < 60) {
        // poprzednia wersja jeszcze zwalnia port
        setTimeout(() => { try { server.close(); } catch (er) {} server = http.createServer(handler); server.on('error', onError); listen(); }, 250);
        return;
    }
    if (e.code === 'EADDRINUSE') {
        console.log(`Panel już działa (port ${PORT} zajęty) — otwieram go w przeglądarce.`);
        if (!AUTO && TRYB !== 'serwer') openBrowser();
        setTimeout(() => process.exit(0), 1500);
    } else console.error(e);
}
server.on('error', onError);
listen();
setInterval(() => { if (HTTPS_ON && currentHost !== '127.0.0.1' && !tlsFresh()) ensureHttps(); }, 12 * 3600e3);
if (AUTO) {
    // panel otwarty z ikony: wyłącz się sam, gdy nikt go nie używa (także żaden gracz)
    setInterval(() => { if (!clients.size && Date.now() - lastSeen > IDLE_LIMIT) shutdown(); }, 60 * 1000);
} else if (TRYB !== 'serwer' && !env.PANEL_BEZ_PRZEGLADARKI) {
    console.log('  Zostaw to okno otwarte podczas gry. Zamknij je, aby wyłączyć panel.');
    openBrowser();
}
function shutdown() {
    try { stan.persistNow(); } catch (e) {}
    try { konta.flush(); } catch (e) {}
    try { kopie.writeAtomic(LOG_FILE, JSON.stringify(log.slice(-300))); } catch (e) {}
    try { if (trTimer) { clearTimeout(trTimer); kopie.writeAtomic(TR_FILE, JSON.stringify(Object.fromEntries(tr))); } } catch (e) {}
    process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
