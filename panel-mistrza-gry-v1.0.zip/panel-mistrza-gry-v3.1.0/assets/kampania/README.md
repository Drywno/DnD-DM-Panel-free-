# Pakiet kampanii · Campaign pack (optional)

The panel works without this folder's script. A campaign pack lets you ship your own built-in maps, sample locations and NPCs with **your** copy of the panel. `pakiet.js` is listed in `.gitignore`, so it never ends up in the public repository.

Panel działa bez tego pliku. Pakiet kampanii pozwala dołączyć do **Twojej** kopii panelu własne mapy, przykładowe lokacje i NPC. Plik `pakiet.js` jest w `.gitignore`, więc nie trafia do publicznego repozytorium.

Create `assets/kampania/pakiet.js` / Utwórz `assets/kampania/pakiet.js`:

```js
window.PANEL_PAKIET = {
    // campaign id the sample world and NPCs are added to automatically (optional)
    kampania: 'my-campaign-id',
    nazwa: 'My campaign',
    // built-in maps: "world" replaces the default parchment, the rest are local maps.
    // anchor = name of the location that leads to that map
    mapy: {
        world: { name: 'World map', url: 'assets/my-world.jpg' },
        city:  { name: 'Capital',   url: 'assets/my-city.jpg', anchor: 'Capital' }
    },
    // gets the current location list, returns a new list or null when nothing changed
    lokacje(locs) {
        if (locs.some(l => l.name === 'Capital')) return null;
        return locs.concat([
            { id: StorageManager.generateId(), name: 'Capital', type: 'capital', x: 50, y: 50, mapType: 'world', description: '' }
        ]);
    },
    // sample NPCs (only the ones missing by name are added)
    npc() {
        return [{ id: StorageManager.generateId(), name: 'Innkeeper', race: 'Human', role: 'Innkeeper', disposition: 'friendly', location: 'Capital', description: '' }];
    },
    znacznikNpc: 'Innkeeper'
};
```

Put the map images in `assets/` (also ignored by git when named `*_map_*.jpg`, or add them to `.gitignore` yourself).
