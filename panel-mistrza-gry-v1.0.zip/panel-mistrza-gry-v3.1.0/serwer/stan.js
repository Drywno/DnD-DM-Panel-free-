// ============================================================
//  Wspólny stan danych panelu (to, co MG ma w przeglądarce),
//  numer wersji, dziennik zmian graczy i zapis na dysk (autokopia).
// ============================================================
const fs = require('fs');
const path = require('path');

module.exports = function stan(kopie, DATA_DIR) {
    const AUTO = path.join(kopie.BACKUP_DIR, 'autokopia.json');
    const META = path.join(DATA_DIR, 'stan.json');
    let data = {};
    try { data = JSON.parse(fs.readFileSync(AUTO, 'utf8')) || {}; } catch (e) { data = {}; }
    let version = 0;
    try { version = JSON.parse(fs.readFileSync(META, 'utf8')).version || 0; } catch (e) { version = Object.keys(data).length ? 1 : 0; }

    // zmiany graczy z ostatnich minut — gdy MG wyśle starszy stan, nakładamy je ponownie
    const ops = [];
    const KEEP_OPS = 300, KEEP_MS = 60 * 60 * 1000;

    let timer = null, dirty = false;
    function persistNow() {
        clearTimeout(timer); timer = null;
        if (!dirty) return;
        dirty = false;
        try {
            if (Object.keys(data).some(k => k.startsWith(kopie.PREFIX))) kopie.saveBackup(JSON.stringify(data));
            kopie.writeAtomic(META, JSON.stringify({ version, t: Date.now() }));
        } catch (e) { console.error('Zapis stanu nie powiódł się:', e.message); dirty = true; }
    }
    function persist() { dirty = true; if (!timer) timer = setTimeout(persistNow, 1200); }

    const P = kopie.PREFIX;
    const valid = (k, v) => typeof k === 'string' && k.startsWith(P) && typeof v === 'string';

    function bump(keys) { version++; persist(); return keys; }

    function replaceAll(map) {
        const next = {};
        for (const [k, v] of Object.entries(map || {})) if (valid(k, v)) next[k] = v;
        const keys = new Set([...Object.keys(data), ...Object.keys(next)]);
        data = next;
        return bump([...keys]);
    }
    function applyPatch(set = {}, del = []) {
        const keys = [];
        for (const [k, v] of Object.entries(set || {})) if (valid(k, v) && data[k] !== v) { data[k] = v; keys.push(k); }
        for (const k of del || []) if (typeof k === 'string' && k in data) { delete data[k]; keys.push(k); }
        return keys;
    }

    // zmiana od MG: { base, set, del } albo { full }
    function dmPush(body) {
        let keys;
        if (body.full) keys = replaceAll(body.full);
        else { keys = applyPatch(body.set, body.del); if (keys.length) bump(keys); }
        const base = +body.base || 0;
        const merged = {};
        // zmiany graczy, których MG jeszcze nie widział — nałóż ponownie na to, co przysłał
        const again = ops.filter(o => o.v > base);
        again.forEach(o => { try { (o.apply(data) || []).forEach(k => { merged[k] = data[k]; }); } catch (e) {} });
        if (again.length && Object.keys(merged).length) { version++; persist(); }
        return { version, keys, merged };
    }

    // zmiana od gracza: funkcja modyfikuje dane i zwraca zmienione klucze
    function playerOp(apply) {
        const keys = apply(data) || [];
        if (!keys.length) return { version, keys };
        version++;
        ops.push({ v: version, apply, t: Date.now() });
        while (ops.length > KEEP_OPS || (ops.length && Date.now() - ops[0].t > KEEP_MS)) ops.shift();
        persist();
        return { version, keys };
    }

    return {
        get data() { return data; }, get version() { return version; },
        replaceAll, dmPush, playerOp, persistNow,
        values: (keys) => Object.fromEntries(keys.map(k => [k, k in data ? data[k] : null]))
    };
};
