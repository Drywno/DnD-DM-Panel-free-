// ============================================================
//  Widok gracza: z pełnych danych MG wycina tylko to, co gracz może zobaczyć,
//  oraz bezpieczne akcje gracza (PW, sloty, ekwipunek, ruch żetonu, rzuty).
// ============================================================
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');

const P = 'dnd5e_dm_';
const BUILTIN_MAPS = ['world', 'city', 'forest', 'forest2', 'fortress'];

// Kuźnia map z panelu — żeby wiedzieć, które elementy wnętrz są tylko dla MG
let MF = null;
function mapForge(root) {
    if (MF) return MF;
    try {
        const ctx = { window: {}, console };
        vm.createContext(ctx);
        vm.runInContext(fs.readFileSync(path.join(root, 'js', 'mapforge.js'), 'utf8') + '\n;this.__MF = MapForge;', ctx);
        MF = ctx.__MF;
    } catch (e) { MF = { meta: () => ({}) }; }
    return MF;
}

// Klasy i zestawy z panelu — żeby awans gracza liczył się tak samo jak u MG
let RULES5 = null;
function rules5(root) {
    if (RULES5) return RULES5;
    try {
        const ctx = { window: {}, console };
        vm.createContext(ctx);
        vm.runInContext(['kits.js', 'classdata.js'].map(f => fs.readFileSync(path.join(root, 'js', f), 'utf8')).join('\n;\n') + '\n;this.__R = { Kits, ClassData };', ctx);
        RULES5 = ctx.__R;
    } catch (e) { console.error('Nie wczytano danych klas:', e.message); RULES5 = null; }
    return RULES5;
}
// Sloty zaklęć wg poziomu postaci (SRD 5.1)
const FULL_SLOTS = [[2], [3], [4, 2], [4, 3], [4, 3, 2], [4, 3, 3], [4, 3, 3, 1], [4, 3, 3, 2], [4, 3, 3, 3, 1], [4, 3, 3, 3, 2], [4, 3, 3, 3, 2, 1], [4, 3, 3, 3, 2, 1], [4, 3, 3, 3, 2, 1, 1], [4, 3, 3, 3, 2, 1, 1],
    [4, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1, 1], [4, 3, 3, 3, 3, 1, 1, 1, 1], [4, 3, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 3, 2, 2, 1, 1]];
const HALF_SLOTS = [[], [2], [3], [3], [4, 2], [4, 2], [4, 3], [4, 3], [4, 3, 2], [4, 3, 2], [4, 3, 3], [4, 3, 3], [4, 3, 3, 1], [4, 3, 3, 1], [4, 3, 3, 2], [4, 3, 3, 2], [4, 3, 3, 3, 1], [4, 3, 3, 3, 1], [4, 3, 3, 3, 2], [4, 3, 3, 3, 2]];
function slotsFor(ck, level) {
    let arr = null;
    if (['bard', 'cleric', 'druid', 'sorcerer', 'wizard'].includes(ck)) arr = FULL_SLOTS[level - 1];
    else if (['paladin', 'ranger'].includes(ck)) arr = HALF_SLOTS[level - 1];
    else if (ck === 'warlock') { const n = level >= 17 ? 4 : level >= 11 ? 3 : level >= 2 ? 2 : 1, lv = Math.min(5, Math.ceil(level / 2)); return { [lv]: n }; }
    if (!arr) return null;
    return Object.fromEntries(arr.map((n, i) => [i + 1, n]));
}

const J = (data, k, d) => { try { const v = data[P + k]; return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
const pct = (hp, max) => max > 0 ? Math.max(0, Math.min(100, Math.round(hp / max * 4) * 25)) : 100;
function hpState(c) {
    if ((c.hp ?? 1) <= 0) return 'nieprzytomny';
    const p = c.maxHp ? c.hp / c.maxHp : 1;
    return p >= 1 ? 'zdrowy' : p > 0.5 ? 'lekko ranny' : p > 0.25 ? 'ranny' : 'ciężko ranny';
}

module.exports = function gracz(root) {
    rules5(root);
    const MFm = () => mapForge(root);

    function filterTok(t) {
        if (!t) return t;
        return {
            mode: t.mode, party: t.party || null, chars: t.chars || {}, comp: t.comp || {},
            others: (t.others || []).filter(o => !o.hidden).map(o => ({ id: o.id, kind: o.kind, name: o.name, size: o.size || 1, disp: o.disp, x: o.x, y: o.y, hp: o.max ? pct(o.hp ?? o.max, o.max) : undefined, max: o.max ? 100 : undefined }))
        };
    }
    function filterInterior(it) {
        if (!it || !Array.isArray(it.levels)) return it || null;
        const mf = MFm();
        return { ...it, levels: it.levels.map(L => ({ ...L, walls: String(L.walls || '').replace(/S/g, '#'), objects: (L.objects || []).filter(o => !(mf.meta(o.t) || {}).dm) })) };
    }

    // teren pola walki tak, jak widzi go gracz (sekretne przejścia = ściana, bez elementów tylko dla MG)
    function fightInterior(data, cid, vt) {
        if (vt.kind !== 'atlas' || !vt.mapId) return null;
        const mf = MFm();
        const mm = ((J(data, `atlas_${cid}`, {}) || {}).maps || {})[vt.mapId];
        let it = mm && mm.interior; try { if (it && mf.migrate) it = mf.migrate(it); } catch (e) {}
        if (!it || !Array.isArray(it.levels)) return null;
        return { ...it, levels: it.levels.map(L => ({ ...L, walls: String(L.walls || '').replace(/S/g, '#'), objects: (L.objects || []).filter(o => !(mf.meta(o.t) || {}).dm) })) };
    }
    const tokLv = (vt, t) => (t && t.lv) || vt.levelId || null;
    // mgła wojny: co widzą podani obserwatorzy na danym poziomie
    function visionOn(lv, cols, rows, paint, viewers) {
        const mf = MFm(); if (!mf.vision) return null;
        const O = mf.sightGrid(lv, cols, rows, paint, { player: true });
        return mf.vision(O, cols, rows, viewers, { dark: lv ? +lv.dark || 0 : 0, lights: lv ? mf.lightsOf(lv) : [] });
    }
    // po ruchu drużyny: wrogowie w zasięgu wzroku kogokolwiek z drużyny zostają „odkryci” (c.seen)
    function discover(data, cid, vt, cs) {
        if (!vt?.fog || !cs?.combatants?.length) return false;
        const chars = J(data, `characters_${cid}`, []) || [], npcs = J(data, `npcs_${cid}`, []) || [], mf = MFm();
        const inParty = (c) => String(c.id).endsWith('-druzyna') || !!(c.npcId && (npcs.find(n => n.id === c.npcId) || {}).party);
        const ally = (c) => c.type === 'pc' || c.type === 'player' || inParty(c) || c.disp === 'friendly';
        const eyes = (c) => c.type === 'pc' || c.type === 'player' || inParty(c);
        const it = fightInterior(data, cid, vt);
        const levels = new Set(cs.combatants.filter(c => eyes(c) && vt.tokens?.[c.id] && (c.hp ?? 1) > 0).map(c => tokLv(vt, vt.tokens[c.id])));
        let changed = false;
        levels.forEach(lvId => {
            const lv = it ? (it.levels.find(q => q.id === lvId) || null) : null;
            const cols = lv ? lv.cols : vt.kind === 'image' && vt.w ? Math.max(1, Math.floor((vt.w - (vt.ox || 0)) / vt.cell)) : (vt.cols || 26);
            const rows = lv ? lv.rows : vt.kind === 'image' && vt.h ? Math.max(1, Math.floor((vt.h - (vt.oy || 0)) / vt.cell)) : (vt.rows || 18);
            const on = (c) => vt.tokens?.[c.id] && (!it || tokLv(vt, vt.tokens[c.id]) === lvId);
            const viewers = cs.combatants.filter(c => eyes(c) && on(c) && (c.hp ?? 1) > 0).map(c => {
                const t = vt.tokens[c.id], chId = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null);
                const n = c.npcId && npcs.find(x => x.id === c.npcId);
                return { x: t.x, y: t.y, n: Math.max(1, Math.min(4, c.size || 1)), light: t.light ? 8 : 0,
                    dv: chId ? mf.darkvisionOf((chars.find(x => x.id === chId) || {}).race) : n ? mf.darkvisionOf(n.race, n.stats?.senses) : 0 };
            });
            const V = visionOn(lv, cols, rows, lv ? ((vt.terL || {})[lv.id] || {}) : (vt.ter || {}), viewers);
            cs.combatants.forEach(c => { if (!ally(c) && !c.seen && on(c) && seesArea(V, cols, rows, vt.tokens[c.id].x, vt.tokens[c.id].y, Math.max(1, c.size || 1))) { c.seen = true; changed = true; } });
        });
        return changed;
    }
    const seesArea = (V, cols, rows, x, y, n) => { if (!V) return true; for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) { const cx = x + i, cy = y + j; if (cx >= 0 && cy >= 0 && cx < cols && cy < rows && V[cy * cols + cx]) return true; } return false; };
    const ownerOf = (data, cid, npcId) => { const n = (J(data, `npcs_${cid}`, []) || []).find(x => x.id === npcId); return n && n.party ? n.party.charId || null : null; };
    // którym żetonem rusza gracz: swoim albo towarzysza, którego prowadzi
    function actorId(data, cid, chId, kto) {
        const myId = `char-${chId}`;
        if (!kto || kto === myId) return myId;
        const cs = J(data, 'combat_state', null);
        const c = (cs?.combatants || []).find(x => x.id === String(kto));
        if (!c || !c.npcId || ownerOf(data, cid, c.npcId) !== chId) throw new Error('Tym żetonem nie możesz ruszać.');
        return c.id;
    }
    function fightTerrain(data, cid, vt, lvId) {
        const mf = MFm(); if (!mf.terrain) return null;
        let lv = null, cols, rows;
        const it = fightInterior(data, cid, vt);
        if (it) lv = it.levels.find(q => q.id === (lvId || vt.levelId)) || it.levels[it.ground || 0] || null;
        if (lv) { cols = lv.cols; rows = lv.rows; }
        else if (vt.kind === 'image' && vt.w && vt.cell) { cols = Math.max(1, Math.floor((vt.w - (vt.ox || 0)) / vt.cell)); rows = Math.max(1, Math.floor((vt.h - (vt.oy || 0)) / vt.cell)); }
        else if (!vt.kind || vt.kind === 'blank') { cols = vt.cols || 26; rows = vt.rows || 18; }
        else { cols = 300; rows = 300; }
        const paint = lv ? ((vt.terL || {})[lv.id] || {}) : (vt.ter || {});
        return mf.terrain(lv, cols, rows, paint, { player: true });
    }

    function view(data, player, extra = {}) {
        const cid = player.campaignId;
        const camp = (J(data, 'campaigns', []) || []).find(c => c.id === cid) || null;
        const chars = J(data, `characters_${cid}`, []) || [];
        const meFull = chars.find(c => c.id === player.charId) || null;
        const me = meFull ? (({ notes, ...rest }) => rest)(meFull) : null;     // prywatne notatki MG zostają u MG
        const party = chars.map(c => ({
            id: c.id, name: c.name, race: c.race, class: c.class, level: c.level || 1, ac: c.ac, speed: c.speed, pv: c.portrait ? (c.portraitV || 1) : null,
            hp: { current: c.hp?.current ?? 0, max: c.hp?.max ?? 0, temp: c.hp?.temp || 0 }, me: c.id === player.charId,
            player: (extra.players || []).find(p => p.charId === c.id)?.name || null,
            // karta kolegi do podglądu: bez notatek MG, prywatnych notatek gracza i historii postaci; portret osobno (/api/portret)
            sheet: c.id === player.charId ? null : (({ notes, playerNotes, backstory, personality, ideals, bonds, flaws, portrait, ...rest }) => rest)(c)
        }));
        const quests = (J(data, `quests_${cid}`, []) || []).filter(q => q.status !== 'Nieznane' && !q.hidden).map(q => ({
            id: q.id, title: q.title, type: q.type, status: q.status || 'Brak', giver: q.giver, location: q.location, reward: q.reward,
            description: q.description, objectives: q.objectives || [], updatedAt: q.updatedAt, closedAt: q.closedAt,
            acceptedBy: q.acceptedBy || null, reported: q.reported || null, pos: q.pos || null
        }));
        const table = J(data, `tavern_live_${cid}`, null);

        // atlas
        const L = J(data, `locations_${cid}`, []) || [];
        const disc = L.filter(l => l.discovered !== false);
        const ids = new Set(disc.map(l => l.id));
        const locations = disc.map(l => ({
            id: l.id, name: l.name, type: l.type, mapType: l.mapType || 'world', x: l.x, y: l.y, rotation: l.rotation, color: l.color || null,
            hasSubmap: !!l.hasSubmap, interior: !!l.interior, submapUrl: l.submapUrl || null, linkMap: l.linkMap || null,
            text: l.readAloud || l.description || '',
            connections: (l.connections || []).filter(c => typeof c === 'string' ? ids.has(c) : (ids.has(c.id) && c.style !== 'secret'))
        }));
        const A = J(data, `atlas_${cid}`, {}) || {};
        const maps = {};
        Object.entries(A.maps || {}).forEach(([mid, mm]) => {
            if (!BUILTIN_MAPS.includes(mid) && !ids.has(mid)) return;
            const fi = filterInterior(mm.interior);
            // mgła wojny we wnętrzu: stworzenia widać tylko w zasięgu wzroku drużyny (albo własnego pionka)
            const fogTok = (k, v) => {
                const t = filterTok(v);
                if (!mm.fog || !fi || !t) return t;
                const lv = fi.levels.find(q => q.id === k); if (!lv) return t;
                const mf = MFm(); const dvOf = (cid0) => mf.darkvisionOf ? mf.darkvisionOf((chars.find(c => c.id === cid0) || {}).race) : 0;
                const partyNpcs = (J(data, `npcs_${cid}`, []) || []).filter(n => n && n.party);
                const viewers = t.mode === 'split'
                    ? Object.entries(t.chars || {}).filter(([id]) => mm.fogShare !== false || id === player.charId).map(([id, p]) => ({ x: p.x, y: p.y, n: 1, dv: Math.max(dvOf(id), ...partyNpcs.filter(n => n.party.charId === id).map(n => mf.darkvisionOf(n.race, n.stats?.senses))) }))
                    : (t.party ? [{ x: t.party.x, y: t.party.y, n: 1, dv: Math.max(0, ...chars.map(c => dvOf(c.id)), ...partyNpcs.map(n => mf.darkvisionOf(n.race, n.stats?.senses))) }] : []);
                if (mm.fogShare !== false) Object.entries(t.comp || {}).forEach(([nid, p]) => { const n = partyNpcs.find(x => x.id === nid && !x.party.charId); if (n && p) viewers.push({ x: p.x, y: p.y, n: 1, dv: mf.darkvisionOf(n.race, n.stats?.senses) }); });
                const V = viewers.length ? visionOn(lv, lv.cols, lv.rows, {}, viewers) : new Uint8Array(lv.cols * lv.rows);
                return { ...t, others: (t.others || []).filter(o => seesArea(V, lv.cols, lv.rows, o.x, o.y, o.size || 1)) };
            };
            maps[mid] = {
                grid: mm.grid || null, tokens: filterTok(mm.tokens),
                tokensL: Object.fromEntries(Object.entries(mm.tokensL || {}).map(([k, v]) => [k, fogTok(k, v)])),
                interior: fi, fog: !!(mm.fog && fi), fogShare: mm.fogShare !== false
            };
        });
        // własna mapa świata: tylko nazwa, wymiary i skrót obrazu (sam obraz pod /api/mapa-swiata)
        const wd = A.world && typeof A.world === 'object' ? A.world : null;
        const world = wd ? { name: String(wd.name || '').slice(0, 80) || null, w: +wd.w || null, h: +wd.h || null,
            v: wd.url ? require('crypto').createHash('sha1').update(String(wd.url)).digest('hex').slice(0, 12) : null } : null;
        const atlas = { party: ids.has(A.party) ? A.party : null, trail: (A.trail || []).filter(t => ids.has(t.id)), maps, world };

        // walka
        const cs = J(data, 'combat_state', null);
        const vt = J(data, `vtt_${cid}`, null);
        let combat = null;
        // plansza walki trafia do graczy dopiero, gdy Mistrz Gry rozpocznie walkę
        if (cs?.active && (cs.combatants || []).length) {
            const all = cs?.combatants || [];
            const vis = all.filter(c => !c.hidden);
            const act = cs?.active ? all[cs.currentTurn] : null;
            const myId = `char-${player.charId}`;
            // gracz widzi piętro, na którym stoi jego żeton (inni są tam, gdzie są)
            const isInt = vt && vt.kind === 'atlas' && !!fightInterior(data, cid, vt);
            // towarzysz w turze, który prowadzi ten gracz → gracz rusza jego żetonem i widzi jego piętro
            const ctrlMine = (c) => !!(c && c.npcId && ownerOf(data, cid, c.npcId) === player.charId);
            const focusId = act && !act.hidden && ctrlMine(act) && vt?.tokens?.[act.id] ? act.id : myId;
            const myLv = vt && vt.tokens?.[focusId] ? tokLv(vt, vt.tokens[focusId]) : (vt ? vt.levelId || null : null);
            const sameLv = (id) => !isInt || tokLv(vt, vt.tokens?.[id]) === myLv;
            const itv = isInt ? fightInterior(data, cid, vt) : null;
            // mgła wojny w walce
            const npcsAll = J(data, `npcs_${cid}`, []) || [];
            const mf0 = MFm();
            // oczy drużyny: bohaterowie i towarzysze (NPC w drużynie)
            const inParty = (c) => String(c.id).endsWith('-druzyna') || !!(c.npcId && (npcsAll.find(n => n.id === c.npcId) || {}).party);
            const isAlly = (c) => c.type === 'pc' || c.type === 'player' || inParty(c) || c.disp === 'friendly';
            const dvOfC = (c) => {
                if (!mf0.darkvisionOf) return 0;
                const chId0 = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null);
                if (chId0) return mf0.darkvisionOf((chars.find(x => x.id === chId0) || {}).race);
                const n = c.npcId && npcsAll.find(x => x.id === c.npcId);
                return n ? mf0.darkvisionOf(n.race, n.stats?.senses) : 0;
            };
            let fogV = null, fogCols = 0, fogRows = 0, viewers = [];
            if (vt && vt.fog) {
                const lvF = itv ? (itv.levels.find(q => q.id === myLv) || itv.levels[itv.ground || 0]) : null;
                fogCols = lvF ? lvF.cols : vt.kind === 'image' && vt.w ? Math.max(1, Math.floor((vt.w - (vt.ox || 0)) / vt.cell)) : (vt.cols || 26);
                fogRows = lvF ? lvF.rows : vt.kind === 'image' && vt.h ? Math.max(1, Math.floor((vt.h - (vt.oy || 0)) / vt.cell)) : (vt.rows || 18);
                // czyimi oczami patrzy gracz: w turze prowadzonego towarzysza — tylko jego, w swojej turze — tylko swoimi,
                // w turach innych — swoimi i swoich towarzyszy; przy wspólnym widzeniu — całej drużyny
                const npcTurn = focusId !== myId, ownTurn = act && act.id === myId;
                const mineEye = (c) => npcTurn ? c.id === focusId : ownTurn ? c.id === myId : (c.id === myId || ctrlMine(c));
                const watch = all.filter(c => vt.tokens?.[c.id] && sameLv(c.id) && (vt.fogShare ? (c.type === 'pc' || c.type === 'player' || inParty(c)) : mineEye(c)) && (c.hp ?? 1) > 0);
                viewers = watch.map(c => ({ id: c.id, x: vt.tokens[c.id].x, y: vt.tokens[c.id].y, n: Math.max(1, Math.min(4, c.size || 1)), dv: dvOfC(c), light: vt.tokens[c.id].light ? 8 : 0 }));
                const paint = lvF ? ((vt.terL || {})[lvF.id] || {}) : (vt.ter || {});
                fogV = visionOn(lvF, fogCols, fogRows, paint, viewers) || null;
            }
            // wróg, którego drużyna jeszcze nie zobaczyła, nie istnieje dla graczy (nawet w kolejce)
            const known = (c) => !fogV || isAlly(c) || c.seen || !vt?.tokens?.[c.id] || fogOk(c);
            const fogOk = (c) => { if (!fogV || isAlly(c)) return true; const t = vt.tokens?.[c.id]; return !!t && seesArea(fogV, fogCols, fogRows, t.x, t.y, Math.max(1, c.size || 1)); };
            combat = {
                active: !!cs?.active, round: cs?.round || 0,
                turn: act ? (act.hidden || !known(act) ? '?' : act.id) : null,
                me: myId, focus: focusId,
                order: vis.filter(known).map(c => {
                    const pc = c.type === 'pc' || c.type === 'player';
                    const seen = fogOk(c) || !vt?.tokens?.[c.id];
                    return { id: c.id, name: c.name, unseen: !seen, type: c.type, init: c.initiative, pc, me: c.id === myId, charId: c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null),
                        hp: pc ? { current: c.hp, max: c.maxHp } : null, state: seen ? hpState(c) : '—', conds: seen ? c.conditions || [] : [], size: c.size || 1, disp: c.disp || null,
                        away: !!(vt && vt.tokens?.[c.id] && !sameLv(c.id)), ctrl: ctrlMine(c), npcId: ctrlMine(c) ? c.npcId : undefined,
                        pv: pc ? (() => { const id0 = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null); const ch0 = chars.find(x => x.id === id0); return ch0 && ch0.portrait ? (ch0.portraitV || 1) : null; })() : null };
                }),
                scene: vt ? { kind: vt.kind || 'blank', name: vt.name, bg: vt.bg, cols: vt.cols, rows: vt.rows, cell: vt.cell, ox: vt.ox || 0, oy: vt.oy || 0,
                    grid: vt.grid !== false, galpha: vt.galpha ?? 0.3, diag: vt.diag, mapId: vt.mapId || null, levelId: vt.levelId || null,
                    url: vt.kind === 'image' ? vt.url : null, w: vt.w, h: vt.h, playersMove: vt.playersMove !== false,
                    ter: isInt ? ((vt.terL || {})[myLv] || {}) : (vt.ter || {}), ...(isInt ? { levelId: myLv, levels: itv.levels.map(L => ({ id: L.id, name: L.name })) } : {}),
                    fog: !!vt.fog, viewers: vt.fog ? viewers : undefined } : null,
                tokens: vt ? Object.fromEntries(Object.entries(vt.tokens || {}).filter(([id]) => { const c = vis.find(x => x.id === id); return c && sameLv(id) && fogOk(c); }).map(([id, t]) => [id, { x: t.x, y: t.y }])) : {},
                tpl: vt?.tpl || [],
                move: vt && vt.tokens?.[focusId] ? (({ speed, total, moved, remaining, dash, stopped, limit, myTurn }) => ({ speed, total, moved, remaining, dash, stopped, limit, myTurn }))(moveInfo(data, vt, cs, focusId)) : null
            };
        }

        // towarzysze drużyny: pełna karta tylko dla gracza, który danego NPC prowadzi
        const companions = (J(data, `npcs_${cid}`, []) || []).filter(n => n && n.party && typeof n.party === 'object').map(n => {
            const mine = n.party.charId && n.party.charId === player.charId;
            const max = parseInt(n.stats?.hp, 10) || 0;
            const base = { id: n.id, name: n.name, race: n.race || '', role: n.role || '', owner: n.party.charId || null,
                ownerName: (chars.find(c => c.id === n.party.charId) || {}).name || null, mine: !!mine,
                hp: n.stats ? { current: Math.max(0, Math.min(max, n.party.hp ?? max)), max } : null, size: ({ Large: 2, Huge: 3, Gargantuan: 4 })[n.stats?.size] || 1 };
            return mine ? { ...base, description: n.description || '', motivations: n.motivations || '', gear: n.gear || '', inventory: Array.isArray(n.inventory) ? n.inventory : [], coins: n.coins || {}, disposition: n.disposition, kind: n.kind, hasStats: !!n.hasStats, stats: n.stats || null } : base;
        });

        return {
            version: extra.version, player: { id: player.id, name: player.name, charId: player.charId },
            campaign: camp ? { id: camp.id, name: camp.name } : null,
            character: me, party, companions, quests, locations, atlas, combat, table,
            live: extra.live || null, scena: extra.scena && (BUILTIN_MAPS.includes(extra.scena.mapId) || ids.has(extra.scena.mapId)) ? extra.scena : (extra.scena ? { ...extra.scena, mapId: null, levelId: null } : null),
            online: extra.online || []
        };
    }

    // ---------- ruch w walce: ile stóp zostało w tej turze ----------
    function feet(dx, dy, diag) {
        dx = Math.abs(dx); dy = Math.abs(dy);
        const mx = Math.max(dx, dy), mn = Math.min(dx, dy);
        return diag === 'alt' ? (mx + Math.floor(mn / 2)) * 5 : mx * 5;
    }
    const STOP = ['Pochwycenie', 'Skrepowanie', 'Paraliz', 'Ogluszenie', 'Nieprzytomnosc', 'Spetryfikowanie'];
    function moveInfo(data, vt, cs, id) {
        const cb = (cs?.combatants || []).find(c => c.id === id);
        const act = cs?.active ? cs.combatants?.[cs.currentTurn] : null;
        const tag = act ? `${cs.round}:${act.id}` : '';
        const t = vt?.tokens?.[id] || {};
        let speed = +cb?.speed || 0;
        if (!speed) {
            const chId = String(id).replace(/^char-/, '');
            for (const [k, v] of Object.entries(data)) {
                if (!k.startsWith(`${P}characters_`)) continue;
                try { const ch = JSON.parse(v).find(c => c.id === chId); if (ch) { speed = parseInt(ch.speed, 10) || 30; break; } } catch (e) {}
            }
        }
        speed = speed || 30;
        const stopped = (cb?.conditions || []).some(c => STOP.includes(c));
        const dash = !!(tag && t.dash === tag);
        const total = stopped ? 0 : speed * (dash ? 2 : 1);
        const moved = tag && t.tt === tag ? (t.moved || 0) : 0;
        return { tag, myTurn: !!(act && act.id === id), speed, total, moved, remaining: Math.max(0, total - moved), dash, stopped, limit: vt?.limit !== false };
    }

    // ---------- akcje gracza ----------
    const int = (v, lo, hi) => { const n = Math.round(Number(v)); if (!Number.isFinite(n)) throw new Error('Niepoprawna liczba.'); return Math.max(lo, Math.min(hi, n)); };
    function cleanInventory(v) {
        if (!Array.isArray(v)) throw new Error('Niepoprawny ekwipunek.');
        return v.slice(0, 400).map(it => {
            const o = { name: String(it?.name ?? '').slice(0, 120), quantity: int(it?.quantity ?? 1, 0, 99999), weight: Number.isFinite(+it?.weight) ? Math.max(0, Math.min(10000, +it.weight)) : 0 };
            ['notes', 'type', 'category', 'cost', 'description'].forEach(k => { if (it?.[k] != null) o[k] = String(it[k]).slice(0, k === 'description' ? 2000 : 300); });
            if (it?.equipped != null) o.equipped = !!it.equipped;
            // pozostałe proste pola przedmiotu z bazy SRD (obrażenia, właściwości…)
            Object.entries(it || {}).slice(0, 40).forEach(([k, v]) => {
                if (k in o || !/^[a-zA-Z_]{1,30}$/.test(k)) return;
                if (typeof v === 'string') o[k] = v.slice(0, 600);
                else if (typeof v === 'number' && Number.isFinite(v)) o[k] = v;
                else if (typeof v === 'boolean') o[k] = v;
            });
            return o;
        });
    }
    const RULES = [
        [/^hp\.current$/, (v, c) => int(v, 0, c.hp?.max ?? 9999)],
        [/^hp\.temp$/, (v) => int(v, 0, 9999)],
        [/^deathSaves\.(successes|failures)$/, (v) => int(v, 0, 3)],
        [/^spellSlots\.([1-9])\.used$/, (v, c, m) => int(v, 0, c.spellSlots?.[m[1]]?.total || 0)],
        [/^hitDicePool\.current$/, (v, c) => int(v, 0, c.hitDicePool?.max ?? c.level ?? 1)],
        [/^currency\.(cp|sp|ep|gp|pp)$/, (v) => int(v, 0, 1e8)],
        [/^classResources\.([\w-]+)\.current$/, (v, c, m) => { const r = c.classResources?.[m[1]]; if (!r) throw new Error('Brak takiego zasobu.'); return int(v, 0, r.max ?? 99); }],
        [/^inspiration$/, (v) => { if (v) throw new Error('Natchnienie przyznaje Mistrz Gry.'); return false; }],
        [/^playerNotes$/, (v) => String(v ?? '').slice(0, 20000)],
        [/^inventory$/, (v) => cleanInventory(v)]
    ];
    function setPath(obj, p, val) {
        const parts = p.split('.');
        let o = obj;
        for (let i = 0; i < parts.length - 1; i++) { if (!o[parts[i]] || typeof o[parts[i]] !== 'object') o[parts[i]] = {}; o = o[parts[i]]; }
        o[parts[parts.length - 1]] = val;
    }

    // zwraca funkcję apply(data) → zmienione klucze (żeby dało się ją powtórzyć po starszym zapisie MG)
    function buildOp(player, body) {
        const cid = player.campaignId, chId = player.charId;
        if (!cid || !chId) throw new Error('Mistrz Gry nie przypisał Ci jeszcze postaci.');
        const kChars = `${P}characters_${cid}`;
        const withChar = (data, fn) => {
            const list = J(data, `characters_${cid}`, []) || [];
            const c = list.find(x => x.id === chId);
            if (!c) throw new Error('Nie znaleziono Twojej postaci.');
            fn(c);
            data[kChars] = JSON.stringify(list);
            return c;
        };
        const syncCombatHp = (data, c, keys) => {
            const cs = J(data, 'combat_state', null);
            if (!cs || !Array.isArray(cs.combatants)) return;
            const cb = cs.combatants.find(x => x.id === `char-${chId}`);
            if (!cb) return;
            cb.hp = Math.max(0, Math.min(cb.maxHp || c.hp?.max || 0, c.hp?.current ?? cb.hp));
            cb.defeated = cb.hp <= 0;
            data[`${P}combat_state`] = JSON.stringify(cs);
            keys.push(`${P}combat_state`);
        };

        if (body.typ === 'pole') {
            const changes = Array.isArray(body.zmiany) ? body.zmiany : [{ path: body.path, value: body.value }];
            if (!changes.length || changes.length > 20) throw new Error('Niepoprawna zmiana.');
            // sprawdź wszystkie od razu (na aktualnych danych)
            return (data) => {
                const keys = [kChars];
                let touchedHp = false;
                const c = withChar(data, (ch) => {
                    changes.forEach(({ path: p, value }) => {
                        const rule = RULES.find(([re]) => re.test(String(p)));
                        if (!rule) throw new Error(`Tego pola nie możesz zmieniać: ${p}`);
                        setPath(ch, p, rule[1](value, ch, String(p).match(rule[0])));
                        if (String(p).startsWith('hp.')) touchedHp = true;
                    });
                    if (touchedHp && ch.hp.current > 0) ch.deathSaves = { successes: 0, failures: 0 };
                });
                if (touchedHp) syncCombatHp(data, c, keys);
                return keys;
            };
        }
        // cała karta z arkusza gracza: bierzemy tylko to, co gracz może zmieniać sam
        if (body.typ === 'karta') {
            const k = body.karta;
            if (!k || typeof k !== 'object') throw new Error('Niepoprawna karta.');
            const txt = (v, n = 20000) => String(v ?? '').slice(0, n);
            return (data) => {
                const keys = [kChars];
                let touchedHp = false;
                const c = withChar(data, (ch) => {
                    if (k.hp && typeof k.hp === 'object') {
                        ch.hp = ch.hp || { current: 0, max: 0, temp: 0 };
                        const cur = int(k.hp.current ?? ch.hp.current, 0, ch.hp.max ?? 9999), tmp = int(k.hp.temp ?? ch.hp.temp ?? 0, 0, 9999);
                        if (cur !== ch.hp.current || tmp !== (ch.hp.temp || 0)) touchedHp = true;
                        ch.hp.current = cur; ch.hp.temp = tmp;
                    }
                    if (k.deathSaves) ch.deathSaves = { successes: int(k.deathSaves.successes ?? 0, 0, 3), failures: int(k.deathSaves.failures ?? 0, 0, 3) };
                    if (k.spellSlots && ch.spellSlots) Object.entries(ch.spellSlots).forEach(([lv, sl]) => { if (sl && k.spellSlots[lv]) sl.used = int(k.spellSlots[lv].used ?? sl.used ?? 0, 0, sl.total || 0); });
                    if (k.hitDicePool && ch.hitDicePool) ch.hitDicePool.current = int(k.hitDicePool.current ?? ch.hitDicePool.current, 0, ch.hitDicePool.max ?? ch.level ?? 1);
                    if (k.currency) { ch.currency = ch.currency || {}; ['cp', 'sp', 'ep', 'gp', 'pp'].forEach(m => { if (k.currency[m] != null) ch.currency[m] = int(k.currency[m], 0, 1e8); }); }
                    if (k.classResources && ch.classResources) Object.entries(ch.classResources).forEach(([rk, r]) => { if (r && k.classResources[rk]) r.current = int(k.classResources[rk].current ?? r.current, 0, r.max ?? 99); });
                    if (Array.isArray(k.inventory)) ch.inventory = cleanInventory(k.inventory);
                    if (k.playerNotes != null) ch.playerNotes = txt(k.playerNotes);
                    // własny obrazek postaci (zmniejszony w przeglądarce do ~256 px)
                    if (k.portrait !== undefined && k.portrait !== ch.portrait) {
                        const okImg = typeof k.portrait === 'string' && k.portrait.length < 400000 && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(k.portrait);
                        if (okImg) { ch.portrait = k.portrait; ch.portraitV = Date.now(); }
                        else if (!k.portrait) { delete ch.portrait; ch.portraitV = Date.now(); }
                    }
                    if (k.spellsNotes != null) ch.spellsNotes = txt(k.spellsNotes);
                    if (k.features && k.features.custom != null) { ch.features = ch.features || {}; ch.features.custom = txt(k.features.custom); }
                    if (k.backstory && typeof k.backstory === 'object') { ch.backstory = ch.backstory || {}; ['personality', 'ideals', 'bonds', 'flaws', 'history'].forEach(f => { if (k.backstory[f] != null) ch.backstory[f] = txt(k.backstory[f]); }); }
                    // księga zaklęć: gracz wybiera czary sam (jak przy tworzeniu postaci)
                    if (Array.isArray(k.spells)) ch.spells = k.spells.slice(0, 150).map(sp => {
                        const o = {};
                        Object.entries(sp || {}).slice(0, 30).forEach(([f, v]) => {
                            if (!/^[a-zA-Z_]{1,30}$/.test(f)) return;
                            if (typeof v === 'string') o[f] = v.slice(0, f === 'desc' ? 6000 : 300);
                            else if (typeof v === 'number' && Number.isFinite(v)) o[f] = v;
                            else if (typeof v === 'boolean') o[f] = v;
                        });
                        o.level = int(o.level ?? 0, 0, 9);
                        return o;
                    }).filter(sp => sp.name);
                    if (touchedHp && ch.hp.current > 0) ch.deathSaves = { successes: 0, failures: 0 };
                });
                if (touchedHp) syncCombatHp(data, c, keys);
                return keys;
            };
        }
        // przekazanie przedmiotu albo monet innemu bohaterowi drużyny
        if (body.typ === 'daj') {
            const komu = String(body.komu || '');
            if (!komu || komu === chId) throw new Error('Wybierz, komu dajesz.');
            const fn = (data) => {
                const list = J(data, `characters_${cid}`, []) || [];
                const me = list.find(x => x.id === chId), to = list.find(x => x.id === komu);
                if (!me) throw new Error('Nie znaleziono Twojej postaci.');
                if (!to) throw new Error('Tego bohatera nie ma w drużynie.');
                const parts = [];
                if (body.przedmiot) {
                    const inv = me.inventory = me.inventory || [];
                    const i = int(body.przedmiot.idx ?? -1, -1, 9999), it = inv[i];
                    if (!it || it.name !== String(body.przedmiot.nazwa || '')) throw new Error('Tego przedmiotu już nie masz — odśwież ekwipunek.');
                    const have = int(it.quantity ?? 1, 0, 99999), q = int(body.przedmiot.ile ?? 1, 1, 99999);
                    if (q > have) throw new Error(`Masz tylko ${have} szt.`);
                    const moved = { ...it, quantity: q }; delete moved.equipped;
                    if (q >= have) inv.splice(i, 1); else it.quantity = have - q;
                    const tinv = to.inventory = to.inventory || [];
                    const same = tinv.find(x => x.name === it.name);
                    if (same) same.quantity = int(same.quantity ?? 1, 0, 99999) + q; else tinv.push(moved);
                    parts.push(`${it.name}${q > 1 ? ` ×${q}` : ''}`);
                }
                if (body.monety && typeof body.monety === 'object') {
                    const NM = { pp: 'sz. platyny', gp: 'sz. złota', ep: 'sz. elektrum', sp: 'sz. srebra', cp: 'sz. miedzi' };
                    me.currency = me.currency || {}; to.currency = to.currency || {};
                    Object.keys(NM).forEach(m => {
                        const q = int(body.monety[m] ?? 0, 0, 1e8); if (!q) return;
                        const have = int(me.currency[m] ?? 0, 0, 1e8);
                        if (q > have) throw new Error(`Masz tylko ${have} ${NM[m]}.`);
                        me.currency[m] = have - q; to.currency[m] = int(to.currency[m] ?? 0, 0, 1e8) + q;
                        parts.push(`${q} ${NM[m]}`);
                    });
                }
                if (!parts.length) throw new Error('Nic nie wybrano.');
                fn.meta.log = `daje ${to.name}: ${parts.join(', ')}`;
                data[kChars] = JSON.stringify(list);
                return [kChars];
            };
            fn.meta = {};
            return fn;
        }
        // koniec tury: gracz kończy turę swoją albo prowadzonego towarzysza
        if (body.typ === 'koniec_tury') {
            const fn = (data) => {
                const k = `${P}combat_state`;
                const cs = J(data, 'combat_state', null);
                if (!cs?.active || !(cs.combatants || []).length) throw new Error('Walka nie trwa.');
                const cur = cs.combatants[cs.currentTurn];
                const mine = cur && (cur.id === `char-${chId}` || (cur.npcId && ownerOf(data, cid, cur.npcId) === chId));
                if (!mine) throw new Error('To nie Twoja tura.');
                fn.meta.log = cur.id === `char-${chId}` ? 'kończy turę' : `kończy turę towarzysza: ${cur.name}`;
                let guard = cs.combatants.length;
                do {
                    cs.currentTurn++;
                    if (cs.currentTurn >= cs.combatants.length) { cs.currentTurn = 0; cs.round = (cs.round || 1) + 1; }
                    guard--;
                } while (cs.combatants[cs.currentTurn].defeated && guard > 0);
                data[k] = JSON.stringify(cs);
                return [k];
            };
            fn.meta = {};
            return fn;
        }
        // przejście schodami na inne piętro (żeton musi stać na schodach)
        if (body.typ === 'schody') {
            return (data) => {
                const k = `${P}vtt_${cid}`;
                const vt = J(data, `vtt_${cid}`, null);
                const id = actorId(data, cid, chId, body.kto);
                if (!vt || !vt.tokens || !vt.tokens[id]) throw new Error('Twojego żetonu nie ma na polu walki.');
                if (vt.playersMove === false) throw new Error('Mistrz Gry zablokował ruch żetonów.');
                const cs = J(data, 'combat_state', null);
                const mv = moveInfo(data, vt, cs, id);
                if (!cs?.active) throw new Error('Między piętrami chodzi się w swojej turze walki.');
                if (!mv.myTurn) throw new Error('Na inne piętro przejdziesz dopiero w swojej turze.');
                const mf = MFm(), it = fightInterior(data, cid, vt);
                if (!it) throw new Error('Tu nie ma pięter.');
                const t = vt.tokens[id], lvId = tokLv(vt, t), idx = it.levels.findIndex(L => L.id === lvId);
                const me = (cs?.combatants || []).find(c => c.id === id), n = Math.max(1, Math.min(4, me?.size || 1));
                const st = idx >= 0 ? mf.stairsAt(it.levels[idx], t.x, t.y, n) : null;
                if (!st || !it.levels[idx + st.sd]) throw new Error('Stań na schodach, żeby przejść na inne piętro.');
                const tgt = it.levels[idx + st.sd].id;
                const taken = (x, y, nn) => Object.entries(vt.tokens).some(([oid, o]) => {
                    if (oid === id || tokLv(vt, o) !== tgt) return false;
                    const oc = (cs?.combatants || []).find(c => c.id === oid); const on = Math.max(1, Math.min(4, oc?.size || 1));
                    return x < o.x + on && x + nn > o.x && y < o.y + on && y + nn > o.y;
                });
                const land = mf.stairsLanding(it, idx, st.o, st.sd, n, taken, { player: true, paint: (vt.terL || {})[tgt] || {} });
                if (!land) throw new Error('Przy schodach na tamtym piętrze nie ma miejsca.');
                t.lv = land.levelId; t.x = land.x; t.y = land.y;
                data[k] = JSON.stringify(vt);
                if (discover(data, cid, vt, cs)) { data[`${P}combat_state`] = JSON.stringify(cs); return [k, `${P}combat_state`]; }
                return [k];
            };
        }
        if (body.typ === 'ruch' || body.typ === 'sprint') {
            const x = body.typ === 'ruch' ? int(body.x, 0, 999) : 0, y = body.typ === 'ruch' ? int(body.y, 0, 999) : 0;
            return (data) => {
                const k = `${P}vtt_${cid}`;
                const vt = J(data, `vtt_${cid}`, null);
                const id = actorId(data, cid, chId, body.kto);
                if (!vt || !vt.tokens || !vt.tokens[id]) throw new Error('Twojego żetonu nie ma na polu walki.');
                if (vt.playersMove === false) throw new Error('Mistrz Gry zablokował ruch żetonów.');
                const cs = J(data, 'combat_state', null);
                const t = vt.tokens[id];
                const mv = moveInfo(data, vt, cs, id);
                if (!cs?.active) throw new Error('Walka jeszcze się nie zaczęła.');
                if (!mv.myTurn) throw new Error('Poczekaj na swoją turę.');
                if (body.typ === 'sprint') {
                    if (!cs?.active) throw new Error('Sprint ma sens tylko w walce.');
                    t.dash = t.dash === mv.tag ? null : mv.tag;
                    if (t.tt !== mv.tag) { t.tt = mv.tag; t.moved = 0; }
                } else {
                    const dist = feet(x - t.x, y - t.y, vt.diag);
                    const me = (cs?.combatants || []).find(c => c.id === id), n = Math.max(1, Math.min(4, me?.size || 1));
                    const myLv = tokLv(vt, t);
                    const taken = Object.entries(vt.tokens).some(([oid, o]) => {
                        if (oid === id || tokLv(vt, o) !== myLv) return false;
                        const oc = (cs?.combatants || []).find(c => c.id === oid);
                        if (!oc || (oc.hp ?? 1) <= 0) return false;
                        const on = Math.max(1, Math.min(4, oc.size || 1));
                        return x < o.x + on && x + n > o.x && y < o.y + on && y + n > o.y;
                    });
                    if (taken) throw new Error('To pole jest zajęte.');
                    let ft = dist;
                    const T = fightTerrain(data, cid, vt, myLv);
                    if (T) {
                        for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) if (T.at(x + i, y + j) === 3) throw new Error('Tam nie można wejść — przeszkoda.');
                        const r = MFm().reach(T, t.x, t.y, n, vt.diag)(x, y);
                        if (!r) throw new Error('Nie da się tam dojść — przeszkody na drodze.');
                        ft = r.ft;
                    }
                    if (cs?.active && mv.limit && ft > mv.remaining) throw new Error(`Za daleko: ${ft} ft${ft > dist ? ' (trudny teren)' : ''}, zostało Ci ${mv.remaining} ft ruchu.`);
                    if (cs?.active) { t.moved = mv.moved + ft; t.tt = mv.tag; }
                    t.x = x; t.y = y;
                }
                data[k] = JSON.stringify(vt);
                if (body.typ === 'ruch' && discover(data, cid, vt, cs)) { data[`${P}combat_state`] = JSON.stringify(cs); return [k, `${P}combat_state`]; }
                return [k];
            };
        }
        if (body.typ === 'pionek') {
            const mapId = String(body.mapId || ''), levelId = body.levelId ? String(body.levelId) : null;
            const x = int(body.x, 0, 400), y = int(body.y, 0, 400);
            return (data) => {
                const L = J(data, `locations_${cid}`, []) || [];
                const known = BUILTIN_MAPS.includes(mapId) || L.some(l => l.id === mapId && l.discovered !== false && l.hasSubmap);
                if (!known) throw new Error('Nie znasz tej mapy.');
                const ka = `${P}atlas_${cid}`, A = J(data, `atlas_${cid}`, {}) || {};
                const mm = (A.maps || {})[mapId];
                const t = mm && (levelId ? (mm.tokensL || {})[levelId] : mm.tokens);
                if (!t || t.mode !== 'split' || !t.chars || !t.chars[chId]) throw new Error('Twojego pionka nie ma na tej mapie.');
                if (mm.playersMove === false) throw new Error('Mistrz Gry zablokował ruch pionków na tej mapie.');
                if (mm.interior && Array.isArray(mm.interior.levels)) {
                    const lv = mm.interior.levels.find(q => q.id === levelId) || mm.interior.levels[mm.interior.ground || 0];
                    if (lv) {
                        if (x >= lv.cols || y >= lv.rows) throw new Error('Poza mapą.');
                        if ('#hXLPBVS'.includes(String(lv.walls || '')[y * lv.cols + x] || '.')) throw new Error('Tam nie można stanąć.');
                        const mf = MFm();
                        if (mf.terrain && mf.terrain({ ...lv, walls: String(lv.walls || '').replace(/S/g, '#') }, lv.cols, lv.rows, {}, { player: true }).at(x, y) === 3) throw new Error('Tam nie można wejść — przeszkoda.');
                    }
                }
                const busy = [...Object.entries(t.chars).filter(([id]) => id !== chId).map(([, p]) => ({ ...p, size: 1 })), ...(t.others || []).filter(o => (o.hp ?? 1) > 0)]
                    .some(o => { const n = o.size || 1; return x < o.x + n && x + 1 > o.x && y < o.y + n && y + 1 > o.y; });
                if (busy) throw new Error('To pole jest zajęte.');
                t.chars[chId] = { ...t.chars[chId], x, y };
                data[ka] = JSON.stringify(A);
                return [ka];
            };
        }
        if (body.typ === 'awans') {
            const R = rules5(root);
            if (!R) throw new Error('Serwer nie ma danych klas — awans zrób u Mistrza Gry.');
            const meta = {};
            const fn = (data) => {
                const keys = [kChars];
                const c = withChar(data, (ch) => {
                    const CD = R.ClassData, ck = R.Kits.classKey(ch.class);
                    const lvl = ch.level || 1, nl = lvl + 1;
                    if (nl > 20) throw new Error('To już maksymalny poziom.');
                    if (+body.poziom !== nl) throw new Error('Karta zmieniła się w międzyczasie — odśwież i spróbuj ponownie.');
                    const need = CD.XP_THRESHOLDS[nl] || 0;
                    if ((ch.xp || 0) < need) throw new Error(`Za mało doświadczenia: ${ch.xp || 0} / ${need} PD.`);
                    const A = ch.abilityScores = ch.abilityScores || {};
                    const conMod = Math.floor(((A.con ?? 10) - 10) / 2);
                    const die = ch.hitDie || CD.HIT_DIE[ck] || 8;
                    // PW: średnia albo rzut na serwerze
                    let gain = body.pw === 'rzut' ? crypto.randomInt(1, die + 1) + conMod : Math.floor(die / 2) + 1 + conMod;
                    gain = Math.max(1, gain);
                    meta.rzut = body.pw === 'rzut' ? gain : null;
                    ch.level = nl;
                    ch.hp = ch.hp || { current: 0, max: 0, temp: 0 };
                    ch.hp.max = (ch.hp.max || 0) + gain; ch.hp.current = (ch.hp.current || 0) + gain;
                    ch.hitDicePool = ch.hitDicePool || { current: 0, max: 0, die };
                    ch.hitDicePool.max = nl; ch.hitDicePool.current = Math.min((ch.hitDicePool.current || 0) + 1, nl); ch.hitDicePool.die = die;
                    // podklasa
                    if (ck && CD.isSubclassLevel(ck, nl) && !ch.subclass) {
                        const subs = CD.getSubclassesForClass(ck) || [];
                        const pick = subs.find(s => s.key === body.podklasa);
                        if (subs.length && !pick) throw new Error('Wybierz podklasę.');
                        if (pick) { ch.subclass = pick.key; ch.subclassFeatures = ch.subclassFeatures || []; CD.getNewSubclassFeatures(ck, pick.key, nl).forEach(f => ch.subclassFeatures.push({ ...f, level: nl })); }
                    } else if (ch.subclass) {
                        ch.subclassFeatures = ch.subclassFeatures || [];
                        CD.getNewSubclassFeatures(ck, ch.subclass, nl).forEach(f => { if (!ch.subclassFeatures.some(x => x.name === f.name)) ch.subclassFeatures.push({ ...f, level: nl }); });
                    }
                    // wzrost cech albo atut
                    if (ck && CD.isASILevel(ck, nl)) {
                        if (body.atut) {
                            const feat = CD.FEATS.find(f => f.key === body.atut);
                            if (!feat) throw new Error('Nie ma takiego atutu.');
                            ch.feats = ch.feats || []; ch.feats.push({ key: feat.key, name: feat.name, desc: feat.desc, level: nl });
                            const ef = feat.effects || {};
                            if (ef.abilityIncrease) Object.entries(ef.abilityIncrease).forEach(([ab, v]) => { if ((A[ab] ?? 10) + v <= 20) A[ab] = (A[ab] ?? 10) + v; });
                            if (ef.abilityChoice && ef.abilityChoice.includes(body.atutCecha)) { const ab = body.atutCecha; if ((A[ab] ?? 10) + (ef.abilityBonus || 1) <= 20) A[ab] = (A[ab] ?? 10) + (ef.abilityBonus || 1); }
                            if (ef.hpPerLevel) { ch.hp.max += ef.hpPerLevel * nl; ch.hp.current += ef.hpPerLevel * nl; }
                            if (ef.speedBonus) ch.speed = (ch.speed || 30) + ef.speedBonus;
                            meta.extra = `atut: ${feat.name}`;
                        } else {
                            const inc = body.cechy || {};
                            let sum = 0;
                            for (const [ab, v] of Object.entries(inc)) {
                                if (!['str', 'dex', 'con', 'int', 'wis', 'cha'].includes(ab)) throw new Error('Nieznana cecha.');
                                const n = int(v, 0, 2); if (!n) continue;
                                if ((A[ab] ?? 10) + n > 20) throw new Error('Cecha nie może przekroczyć 20.');
                                sum += n;
                            }
                            if (sum > 2) throw new Error('Możesz rozdzielić najwyżej 2 punkty.');
                            for (const [ab, v] of Object.entries(inc)) { const n = int(v, 0, 2); if (n) A[ab] = (A[ab] ?? 10) + n; }
                            if (sum) meta.extra = 'wzrost cech +' + sum;
                        }
                    }
                    // nowe zdolności klasowe (pobrane przez gracza z SRD)
                    ch.classFeatures = ch.classFeatures || [];
                    (Array.isArray(body.zdolnosci) ? body.zdolnosci : []).slice(0, 12).forEach(f => {
                        const o = { name: String(f?.name || '').slice(0, 120), index: String(f?.index || '').slice(0, 80), desc: String(f?.desc || '').slice(0, 5000) };
                        if (o.name && !ch.classFeatures.some(x => (o.index && x.index === o.index) || x.name === o.name)) ch.classFeatures.push(o);
                    });
                    if ((CD.EXTRA_ATTACK[ck] || []).includes(nl)) ch.extraAttacks = (ch.extraAttacks || 0) + 1;
                    // sloty zaklęć
                    const sl = slotsFor(ck, nl);
                    if (sl) { ch.spellSlots = ch.spellSlots || {}; Object.entries(sl).forEach(([k, n]) => { const used = ch.spellSlots[k]?.used || 0; ch.spellSlots[k] = { used: Math.min(used, n), total: n }; }); }
                    // zasoby klasowe
                    ch.classResources = ch.classResources || {};
                    (CD.getResourcesForLevel(ck || '', nl, ch) || []).forEach(r => { if (!r.isPassive) ch.classResources[r.key] = { current: r.max, max: r.max }; });
                    ch.levelHistory = ch.levelHistory || []; ch.levelHistory.push({ level: nl, hpGained: gain, timestamp: new Date().toISOString(), byPlayer: true });
                    meta.log = `awansuje na poziom ${nl}! (+${gain} PW${meta.extra ? ', ' + meta.extra : ''})`;
                    meta.gain = gain;
                });
                syncCombatHp(data, c, keys);
                return keys;
            };
            fn.meta = meta;
            return fn;
        }
        if (body.typ === 'zadanie') {
            const qid = String(body.id || ''), akcja = String(body.akcja || '');
            if (!['przyjmij', 'zglos'].includes(akcja)) throw new Error('Nieznana akcja zlecenia.');
            const meta = {};
            const fn = (data) => {
                const k = `${P}quests_${cid}`;
                const list = J(data, `quests_${cid}`, []) || [];
                const q = list.find(x => x.id === qid);
                if (!q || q.status === 'Nieznane' || q.hidden) throw new Error('Nie ma takiego ogłoszenia.');
                const chName = ((J(data, `characters_${cid}`, []) || []).find(c => c.id === chId) || {}).name || null;
                const who = { name: player.name, char: chName, charId: chId, at: new Date().toISOString() };
                if (akcja === 'przyjmij') {
                    if ((q.status || 'Brak') !== 'Brak') throw new Error(q.status === 'Przyjęte' ? 'To zlecenie jest już przyjęte.' : 'Tego zlecenia nie da się już przyjąć.');
                    q.status = 'Przyjęte'; q.acceptedBy = who; delete q.reported;
                    meta.log = `przyjmuje zlecenie „${q.title || 'bez tytułu'}”`;
                } else {
                    if (q.status !== 'Przyjęte') throw new Error('Wykonanie zgłasza się tylko dla przyjętych zleceń.');
                    if (q.reported) throw new Error('Wykonanie już zgłoszono — decyzja należy do Mistrza Gry.');
                    q.reported = who;
                    meta.log = `zgłasza wykonanie zlecenia „${q.title || 'bez tytułu'}”`;
                }
                q.updatedAt = who.at;
                data[k] = JSON.stringify(list);
                return [k];
            };
            fn.meta = meta;
            return fn;
        }
        if (body.typ === 'stol') {
            const ALLOWED = ['siadam', 'wstaje', 'rzut', 'karta', 'dobierz', 'pas', 'podwoj', 'gram'];
            const akcja = String(body.akcja || '');
            if (!ALLOWED.includes(akcja)) throw new Error('Nieznany ruch przy stole.');
            const req = { id: crypto.randomBytes(5).toString('hex'), pid: player.id, charId: chId, name: player.name, akcja, t: Date.now() };
            return (data) => {
                const k = `${P}tavern_req_${cid}`;
                const list = (J(data, `tavern_req_${cid}`, []) || []).slice(-29);
                if (list.some(r => r.id === req.id)) return [];
                list.push(req);
                data[k] = JSON.stringify(list);
                return [k];
            };
        }
        throw new Error('Nieznana akcja.');
    }

    // ---------- rzuty kośćmi (losowane na serwerze) ----------
    // given: wyniki z kości 3D gracza — [[wartości kości], …] w kolejności kości w wyrażeniu (k20 z ułatwieniem: dwie wartości)
    function roll(expr, mode, given) {
        let gi = 0;
        const take = (n, s) => {
            const g = given && given[gi++];
            if (!Array.isArray(g) || g.length !== n || !g.every(v => Number.isInteger(v) && v >= 1 && v <= s)) throw new Error('Niepoprawny wynik kości.');
            return g.slice();
        };
        const src = String(expr || '').toLowerCase().replace(/\s+/g, '').replace(/k/g, 'd');
        if (!/^[+-]?(\d*d\d+|\d+)([+-](\d*d\d+|\d+))*$/.test(src) || src.length > 40) throw new Error('Nie rozumiem rzutu. Przykład: 1k20+5 albo 2k6+3.');
        const terms = src.match(/[+-]?(\d*d\d+|\d+)/g);
        let total = 0, dice = 0; const parts = [];
        terms.forEach(t => {
            const sign = t.startsWith('-') ? -1 : 1;
            const body = t.replace(/^[+-]/, '');
            if (body.includes('d')) {
                let [n, s] = body.split('d').map(Number); n = n || 1;
                if (n > 50 || s < 2 || s > 1000) throw new Error('Za dużo kości albo dziwna kość.');
                dice += n; if (dice > 60) throw new Error('Za dużo kości naraz.');
                const advMode = n === 1 && s === 20 && (mode === 'adv' || mode === 'dis');
                const phys = given ? take(advMode ? 2 : n, s) : null;
                let rolls = phys ? phys.slice(0, n) : Array.from({ length: n }, () => crypto.randomInt(1, s + 1));
                let dropped = null;
                if (advMode) {
                    const second = phys ? phys[1] : crypto.randomInt(1, 21);
                    const keep = mode === 'adv' ? Math.max(rolls[0], second) : Math.min(rolls[0], second);
                    dropped = keep === rolls[0] ? second : rolls[0];
                    rolls = [keep];
                }
                const sum = rolls.reduce((a, b) => a + b, 0);
                total += sign * sum;
                parts.push({ die: `${n}k${s}`, rolls, dropped, sign });
            } else { total += sign * Number(body); parts.push({ mod: sign * Number(body) }); }
        });
        const d20 = parts.find(p => p.die === '1k20');
        if (given && gi !== given.length) throw new Error('Niepoprawny wynik kości.');
        return { expr: src.replace(/d/g, 'k'), total, parts, mode: mode || null, kosci3d: !!given, crit: d20 ? (d20.rolls[0] === 20 ? 'max' : d20.rolls[0] === 1 ? 'min' : null) : null };
    }

    return { view, buildOp, roll, feet, moveInfo };
};
