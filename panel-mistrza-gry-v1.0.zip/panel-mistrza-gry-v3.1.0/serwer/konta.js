// ============================================================
//  Konta: hasło Mistrza Gry, miejsca graczy (kody zaproszeń), sesje logowania
// ============================================================
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const SESSION_DAYS = 60;
const MG_DAYS = 14;

module.exports = function konta(DATA_DIR, writeAtomic) {
    const FILE = path.join(DATA_DIR, 'konta.json');
    const SFILE = path.join(DATA_DIR, 'sesje.json');
    const read = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } };

    let K = { mg: null, gracze: [], max: 4, ...read(FILE, {}) };
    K.gracze = Array.isArray(K.gracze) ? K.gracze : [];
    let S = read(SFILE, {});
    const save = () => writeAtomic(FILE, JSON.stringify(K, null, 2));
    let sTimer = null;
    const saveSessions = () => { clearTimeout(sTimer); sTimer = setTimeout(() => { try { writeAtomic(SFILE, JSON.stringify(S)); } catch (e) {} }, 1500); };
    const flush = () => { clearTimeout(sTimer); try { writeAtomic(SFILE, JSON.stringify(S)); } catch (e) {} };

    // ---------- hasła ----------
    function hash(pw, salt = crypto.randomBytes(16).toString('hex')) {
        return { salt, hash: crypto.scryptSync(String(pw), salt, 32).toString('hex') };
    }
    function verify(pw, rec) {
        if (!rec || !rec.salt) return false;
        const a = Buffer.from(hash(pw, rec.salt).hash, 'hex'), b = Buffer.from(rec.hash, 'hex');
        return a.length === b.length && crypto.timingSafeEqual(a, b);
    }
    const hasDm = () => !!(K.mg && K.mg.hash);
    // zbyt proste hasła, które zgaduje się w pierwszej kolejności
    const WEAK = ['12345678', '123456789', '1234567890', '87654321', 'password', 'password1', 'haslo123', 'hasło123', 'qwertyui', 'qwerty123', 'zaq12wsx', 'dungeons', 'dragons', 'mistrzgry', 'mistrz123', 'dnd12345', 'karczma1', '11111111', 'abcdefgh', 'iloveyou'];
    function weakReason(pw) {
        const p = String(pw || '');
        if (p.length < 8) return 'Hasło musi mieć co najmniej 8 znaków.';
        if (/^(.)\1+$/.test(p)) return 'Hasło nie może składać się z jednego powtórzonego znaku.';
        if (WEAK.includes(p.toLowerCase())) return 'To hasło jest zbyt popularne — wymyśl inne.';
        if (/^\d+$/.test(p) && p.length < 12) return 'Same cyfry to za mało — dodaj litery albo wydłuż hasło do 12 znaków.';
        return null;
    }
    function setDmPassword(pw, opts = {}) {
        const why = weakReason(pw);
        if (why && !opts.force) throw new Error(why);
        if (String(pw || '').length < 6) throw new Error('Hasło musi mieć co najmniej 6 znaków.');
        K.mg = hash(pw); save();
        // wyloguj wszystkie stare sesje MG
        Object.keys(S).forEach(t => { if (S[t].rola === 'mg') delete S[t]; });
        flush();
    }
    const checkDm = (pw) => verify(pw, K.mg);

    // ---------- gracze ----------
    function code() {
        const b = crypto.randomBytes(8);
        const c = Array.from(b, x => ALPHA[x % ALPHA.length]).join('');
        return `${c.slice(0, 4)}-${c.slice(4)}`;
    }
    const normCode = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const list = () => K.gracze.map(g => ({ ...g }));
    const get = (id) => K.gracze.find(g => g.id === id) || null;
    function byCode(c) {
        const n = normCode(c);
        if (n.length !== 8) return null;
        let hit = null;
        K.gracze.forEach(g => {
            const a = Buffer.from(normCode(g.kod)), b = Buffer.from(n);
            if (a.length === b.length && crypto.timingSafeEqual(a, b)) hit = g;
        });
        return hit;
    }
    function upsert(p) {
        const name = String(p.name || '').trim().slice(0, 40) || 'Gracz';
        let g = p.id ? get(p.id) : null;
        if (!g) {
            if (K.gracze.length >= Math.max(1, K.max || 4) + 4) throw new Error('Za dużo miejsc dla graczy.');
            g = { id: crypto.randomBytes(6).toString('hex'), kod: code(), utworzono: Date.now() };
            K.gracze.push(g);
        }
        g.name = name;
        g.charId = p.charId ? String(p.charId) : null;
        g.campaignId = p.campaignId ? String(p.campaignId) : null;
        save();
        return { ...g };
    }
    function regen(id) {
        const g = get(id); if (!g) throw new Error('Nie ma takiego gracza.');
        g.kod = code(); save(); dropFor(id);
        return { ...g };
    }
    function remove(id) {
        K.gracze = K.gracze.filter(g => g.id !== id); save(); dropFor(id);
    }
    function setMax(n) { K.max = Math.max(1, Math.min(8, +n || 4)); save(); }

    // ---------- sesje ----------
    function create(rola, pid, info = {}) {
        const t = crypto.randomBytes(32).toString('hex');
        S[t] = { rola, pid: pid || null, t: Date.now(), last: Date.now(), ip: info.ip || null, ua: info.ua ? String(info.ua).slice(0, 160) : null };
        saveSessions();
        return t;
    }
    function session(token) {
        if (!token || !S[token]) return null;
        const s = S[token];
        if (Date.now() - s.last > SESSION_DAYS * 86400000) { delete S[token]; saveSessions(); return null; }
        // MG: sesja najwyżej 14 dni od zalogowania i wygasa po 3 dniach bez używania
        if (s.rola === 'mg' && (Date.now() - s.t > MG_DAYS * 86400000 || Date.now() - s.last > 3 * 86400000)) { delete S[token]; saveSessions(); return null; }
        if (s.rola === 'mg' && Date.now() - s.last > 600000) { s.last = Date.now(); saveSessions(); }
        if (s.rola === 'gracz' && !get(s.pid)) { delete S[token]; saveSessions(); return null; }
        if (Date.now() - s.last > 3600000) { s.last = Date.now(); saveSessions(); }
        return s;
    }
    function drop(token) { if (S[token]) { delete S[token]; saveSessions(); } }
    // sesje MG (do listy „gdzie jesteś zalogowany” i wylogowania innych urządzeń)
    const mgSessions = () => Object.entries(S).filter(([, v]) => v.rola === 'mg').map(([t, v]) => ({ t, od: v.t, ostatnio: v.last, ip: v.ip, ua: v.ua }));
    function dropMgExcept(keep) { let n = 0; Object.keys(S).forEach(t => { if (S[t].rola === 'mg' && t !== keep) { delete S[t]; n++; } }); flush(); return n; }
    function dropFor(pid) { const out = []; Object.keys(S).forEach(t => { if (S[t].pid === pid) { out.push(t); delete S[t]; } }); flush(); return out; }

    return { hasDm, setDmPassword, checkDm, list, get, byCode, upsert, regen, remove, setMax, get max() { return K.max || 4; }, create, session, drop, dropFor, flush, weakReason, mgSessions, dropMgExcept, MG_DAYS };
};
