// ============================================================
//  Kopie zapasowe danych panelu (folder „kopie”)
// ============================================================
const fs = require('fs');
const path = require('path');

module.exports = function kopie(BACKUP_DIR) {
    // ------------------------------------------------------------
    //  Kopie zapasowe
    //  kopie/autokopia.json           — zawsze najnowszy stan (zapis po każdej zmianie)
    //  kopie/kopia_RRRR-MM-DD.json    — stan z końca każdego dnia (30 dni)
    //  kopie/historia/godz_*.json     — stan sprzed zmian w danej godzinie (48 ostatnich)
    //  kopie/historia/przed_zmiana_*  — automatycznie, gdy z danych nagle dużo ubyło (20)
    //  kopie/reczne/*.json            — kopie zrobione przyciskiem „Zrób kopię teraz” (100)
    //  Każdy plik zapisywany jest najpierw jako .tmp i podmieniany — przerwany zapis nie psuje kopii.
    // ------------------------------------------------------------
    const HIST_DIR = path.join(BACKUP_DIR, 'historia');
    const MANUAL_DIR = path.join(BACKUP_DIR, 'reczne');
    const INDEX_FILE = path.join(BACKUP_DIR, 'indeks.json');
    const KEEP = { daily: 30, hourly: 48, guard: 20, manual: 100 };
    const PREFIX = 'dnd5e_dm_';

    const pad = (n) => String(n).padStart(2, '0');
    function stamp(d = new Date()) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
    function today() { return stamp(); }
    function hourStamp(d = new Date()) { return `${stamp(d)}_${pad(d.getHours())}`; }
    function fullStamp(d = new Date()) { return `${hourStamp(d)}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`; }

    function writeAtomic(file, body) {
        fs.mkdirSync(path.dirname(file), { recursive: true });
        const tmp = file + '.tmp';
        fs.writeFileSync(tmp, body);
        fs.renameSync(tmp, file);
    }
    function copyAtomic(from, to) { if (fs.existsSync(from)) writeAtomic(to, fs.readFileSync(from)); }

    // co jest w kopii: liczba kampanii, bohaterów, NPC, sesji…
    function statsOf(data) {
        const s = { kampanie: 0, bohaterowie: 0, npc: 0, sesje: 0, zadania: 0, notatki: 0, lokacje: 0, wlasne: 0 };
        const len = (v) => { try { const a = JSON.parse(v); return Array.isArray(a) ? a.length : 0; } catch (e) { return 0; } };
        for (const [k, v] of Object.entries(data)) {
            if (!k.startsWith(PREFIX) || typeof v !== 'string') continue;
            const key = k.slice(PREFIX.length);
            if (key === 'campaigns') s.kampanie += len(v);
            else if (key.startsWith('characters_')) s.bohaterowie += len(v);
            else if (key.startsWith('npcs_')) s.npc += len(v);
            else if (key.startsWith('sessions_')) s.sesje += len(v);
            else if (key.startsWith('quests_')) s.zadania += len(v);
            else if (key.startsWith('notes_')) s.notatki += len(v);
            else if (key.startsWith('locations_')) s.lokacje += len(v);
            else if (/^custom_(monsters|spells|equipment)$/.test(key)) s.wlasne += len(v);
        }
        return s;
    }
    const score = (s) => Object.values(s || {}).reduce((a, b) => a + b, 0);

    function parseBackup(body) {
        const data = JSON.parse(body);
        if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('to nie jest kopia panelu');
        if (!Object.keys(data).some(k => k.startsWith(PREFIX))) throw new Error('brak danych panelu w pliku');
        return data;
    }

    function readIndex() { try { return JSON.parse(fs.readFileSync(INDEX_FILE, 'utf8')); } catch (e) { return {}; } }
    function saveIndex(ix) { try { writeAtomic(INDEX_FILE, JSON.stringify(ix)); } catch (e) { /* indeks to tylko pamięć podręczna */ } }
    function indexEntry(rel, extra) {
        const ix = readIndex();
        const file = path.join(BACKUP_DIR, rel);
        let st; try { st = fs.statSync(file); } catch (e) { delete ix[rel]; saveIndex(ix); return null; }
        let e = ix[rel];
        if (!e || e.size !== st.size || extra) {
            let stats = extra?.stats;
            if (!stats) { try { stats = statsOf(JSON.parse(fs.readFileSync(file, 'utf8'))); } catch (err) { stats = null; } }
            e = { ...(e || {}), ...(extra || {}), size: st.size, t: (!extra && e?.t && e.size === st.size) ? e.t : st.mtimeMs, stats };
            ix[rel] = e; saveIndex(ix);
        }
        return e;
    }
    function prune(dir, re, keep) {
        if (!fs.existsSync(dir)) return;
        const files = fs.readdirSync(dir).filter(f => re.test(f)).sort();
        const ix = readIndex(); let ch = false;
        files.slice(0, Math.max(0, files.length - keep)).forEach(f => {
            try { fs.unlinkSync(path.join(dir, f)); } catch (e) {}
            const rel = path.relative(BACKUP_DIR, path.join(dir, f)).split(path.sep).join('/');
            if (ix[rel]) { delete ix[rel]; ch = true; }
        });
        if (ch) saveIndex(ix);
    }

    let lastSync = null;
    function saveBackup(body) {
        const data = parseBackup(body);
        const stats = statsOf(data);
        const auto = path.join(BACKUP_DIR, 'autokopia.json');
        const prev = fs.existsSync(auto) ? indexEntry('autokopia.json') : null;
        let guard = false;
        if (prev) {
            // 1) stan sprzed pierwszej zmiany w tej godzinie
            const hourly = path.join(HIST_DIR, `godz_${hourStamp()}.json`);
            if (!fs.existsSync(hourly)) { copyAtomic(auto, hourly); indexEntry(`historia/godz_${hourStamp()}.json`, { stats: prev.stats }); }
            // 2) z danych nagle dużo ubyło — zachowaj poprzedni stan osobno
            const before = score(prev.stats), now = score(stats);
            if (before > 0 && (now < before * 0.7 || before - now >= 5 || body.length < prev.size * 0.5)) {
                const rel = `historia/przed_zmiana_${fullStamp()}.json`;
                copyAtomic(auto, path.join(BACKUP_DIR, rel));
                indexEntry(rel, { stats: prev.stats, note: `ubyło: ${before} → ${now} wpisów` });
                guard = true;
            }
        }
        writeAtomic(auto, body);
        writeAtomic(path.join(BACKUP_DIR, `kopia_${today()}.json`), body);
        indexEntry('autokopia.json', { stats });
        indexEntry(`kopia_${today()}.json`, { stats });
        prune(BACKUP_DIR, /^kopia_\d{4}-\d{2}-\d{2}\.json$/, KEEP.daily);
        prune(HIST_DIR, /^godz_.*\.json$/, KEEP.hourly);
        prune(HIST_DIR, /^przed_zmiana_.*\.json$/, KEEP.guard);
        lastSync = Date.now();
        return { ok: true, t: lastSync, stats, guard };
    }

    function slug(s) {
        return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l').replace(/Ł/g, 'L')
            .replace(/[^\w-]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '').slice(0, 40);
    }
    function saveManual(body, name) {
        const data = parseBackup(body);
        const stats = statsOf(data);
        const rel = `reczne/${fullStamp()}${slug(name) ? '_' + slug(name) : ''}.json`;
        writeAtomic(path.join(BACKUP_DIR, rel), body);
        const e = indexEntry(rel, { stats, name: String(name || '').slice(0, 80) });
        prune(MANUAL_DIR, /\.json$/, KEEP.manual);
        return { f: rel, kind: 'manual', ...e };
    }

    const SAFE_REL = /^(autokopia\.json|kopia_\d{4}-\d{2}-\d{2}\.json|historia\/[\w.-]+\.json|reczne\/[\w.-]+\.json)$/;
    function listBackups() {
        const out = [];
        const add = (rel, kind) => { const e = indexEntry(rel); if (e) out.push({ f: rel, kind, ...e }); };
        if (fs.existsSync(path.join(BACKUP_DIR, 'autokopia.json'))) add('autokopia.json', 'auto');
        const ls = (dir) => fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.endsWith('.json')) : [];
        ls(BACKUP_DIR).filter(f => /^kopia_\d{4}-\d{2}-\d{2}\.json$/.test(f)).forEach(f => add(f, 'daily'));
        ls(HIST_DIR).forEach(f => add(`historia/${f}`, f.startsWith('przed_zmiana_') ? 'guard' : 'hourly'));
        ls(MANUAL_DIR).forEach(f => add(`reczne/${f}`, 'manual'));
        // usuń z indeksu wpisy po plikach skasowanych ręcznie
        const ix = readIndex(), known = new Set(out.map(o => o.f));
        let ch = false; Object.keys(ix).forEach(k => { if (!known.has(k)) { delete ix[k]; ch = true; } });
        if (ch) saveIndex(ix);
        return out.sort((a, b) => b.t - a.t);
    }


    return { BACKUP_DIR, PREFIX, statsOf, score, parseBackup, saveBackup, saveManual, listBackups, indexEntry, writeAtomic, SAFE_REL, get lastSync() { return lastSync; } };
};
