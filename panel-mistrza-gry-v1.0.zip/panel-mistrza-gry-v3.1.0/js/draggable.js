/* ============================================
   D&D 5e DM Panel â Draggable System
   ============================================ */

const DraggableManager = {
    maxZ: 500,
    items: [],
    draggingElement: null,
    resizingElement: null,
    startX: 0, startY: 0, origX: 0, origY: 0, origW: 0, origH: 0,

    init() {
        // Load pinned positions
        const saved = StorageManager.getPinnedItems();
        this.items = saved || [];

        // Single global event listeners for performance & bug prevention
        document.addEventListener('mousemove', this.onMouseMove.bind(this));
        document.addEventListener('mouseup', this.onMouseUp.bind(this));
    },

    bringToFront(el) {
        this.maxZ++;
        el.style.zIndex = this.maxZ;
    },

    makeDraggable(el, handleSelector) {
        const handle = handleSelector ? el.querySelector(handleSelector) : el;

        handle.addEventListener('mousedown', (e) => {
            // Ignore if clicked on buttons or inputs
            if (e.target.closest('.note-btn') || e.target.closest('.note-controls') ||
                e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' ||
                e.target.tagName === 'BUTTON' || e.target.tagName === 'SELECT') return;

            this.draggingElement = el;
            this.bringToFront(el);
            el.classList.add('active');

            // Use current absolute positions instead of boundingClientRect to prevent jump bugs
            this.startX = e.clientX;
            this.startY = e.clientY;
            
            // Check computed styles first, if missing use 0
            const style = window.getComputedStyle(el);
            this.origX = parseInt(style.left, 10) || el.offsetLeft || 0;
            this.origY = parseInt(style.top, 10) || el.offsetTop || 0;

            e.preventDefault();
        });
    },

    makeResizable(el) {
        const handle = document.createElement('div');
        handle.className = 'note-resize';
        el.appendChild(handle);

        handle.addEventListener('mousedown', (e) => {
            this.resizingElement = el;
            this.startX = e.clientX;
            this.startY = e.clientY;
            this.origW = el.offsetWidth;
            this.origH = el.offsetHeight;
            e.stopPropagation();
            e.preventDefault();
        });
    },

    onMouseMove(e) {
        if (this.draggingElement) {
            const el = this.draggingElement;
            const dx = e.clientX - this.startX;
            const dy = e.clientY - this.startY;
            let newX = this.origX + dx;
            let newY = this.origY + dy;

            // Constrain to viewport so it doesn't get lost
            const w = el.offsetWidth;
            const h = el.offsetHeight;
            newX = Math.max(0, Math.min(window.innerWidth - w, newX));
            newY = Math.max(0, Math.min(window.innerHeight - h, newY));

            el.style.left = newX + 'px';
            el.style.top = newY + 'px';
            el.style.position = 'absolute';
            
            // Check dock hover
            const dockArea = document.getElementById('heroes-dock-area');
            if (dockArea && (el.classList.contains('pinned-character') || (el.classList.contains('draggable-note') && el.dataset.noteType === 'npc'))) {
                const rect = dockArea.getBoundingClientRect();
                if (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom) {
                    dockArea.classList.add('drag-over');
                } else {
                    dockArea.classList.remove('drag-over');
                }
            }
        }

        if (this.resizingElement) {
            const el = this.resizingElement;
            const w = Math.max(200, this.origW + (e.clientX - this.startX));
            const h = Math.max(100, this.origH + (e.clientY - this.startY));
            el.style.width = w + 'px';
            el.style.height = h + 'px';
        }
    },

    onMouseUp(e) {
        if (this.draggingElement) {
            const el = this.draggingElement;
            this.draggingElement = null; // Clear first to allow other events

            // Check collision with dock
            const dockArea = document.getElementById('heroes-dock-area');
            if (dockArea) dockArea.classList.remove('drag-over');
            
            if (dockArea && (el.classList.contains('pinned-character') || (el.classList.contains('draggable-note') && el.dataset.noteType === 'npc'))) {
                if (e) {
                    const rect = dockArea.getBoundingClientRect();
                    if (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom) {
                        el.classList.remove('active');
                        DockManager.dockElement(el);
                        return; // Successfully docked, don't save position
                    }
                }
            }
            
            el.classList.remove('active');
            this.savePosition(el);
        }
        if (this.resizingElement) {
            this.savePosition(this.resizingElement);
            this.resizingElement = null;
        }
    },

    savePosition(el) {
        const id = el.dataset.itemId;
        if (!id) return;
        const item = {
            id,
            x: parseInt(el.style.left) || 0,
            y: parseInt(el.style.top) || 0,
            w: el.offsetWidth,
            h: el.offsetHeight,
            z: parseInt(el.style.zIndex) || this.maxZ
        };
        const items = this.items.filter(i => i.id !== id);
        items.push(item);
        this.items = items;
        StorageManager.savePinnedItems(items);
    },

    restorePosition(el) {
        const id = el.dataset.itemId;
        if (!id) return;
        const saved = this.items.find(i => i.id === id);
        if (saved) {
            el.style.left = saved.x + 'px';
            el.style.top = saved.y + 'px';
            if (saved.w) el.style.width = saved.w + 'px';
            if (saved.h) el.style.height = saved.h + 'px';
            if (saved.z) el.style.zIndex = saved.z;
            el.style.position = 'absolute';
        }
    },

    removeItem(id) {
        this.items = this.items.filter(i => i.id !== id);
        StorageManager.savePinnedItems(this.items);
    }
};

const DockManager = {
    dockedItems: [],
    
    init() {
        const saved = StorageManager.get('docked_items') || [];
        this.dockedItems = saved.map(item => ({ ...item, el: null })); // el will be bound later
        
        // Wait a bit for other modules (Notes, Characters) to render
        setTimeout(() => {
            this.dockedItems.forEach(item => {
                if (item.type === 'hero') {
                    // Force re-pin if it doesn't exist
                    if (!document.getElementById(`pinned-char-${item.id}`) && window.CharactersModule) {
                        CharactersModule.pinCharacter(item.id);
                    }
                    item.el = document.getElementById(`pinned-char-${item.id}`);
                } else if (item.type === 'npc') {
                    item.el = document.getElementById(`note-${item.id}`);
                }
                
                if (item.el) {
                    item.el.style.display = 'none';
                    item.el.classList.remove('active');
                }
            });
            this.renderDock();
        }, 500); // 500ms should be enough for notes/characters to initialize
    },
    
    saveState() {
        const toSave = this.dockedItems.map(i => ({ id: i.id, title: i.title, type: i.type }));
        StorageManager.set('docked_items', toSave);
    },
    
    dockElement(el) {
        const isNpc = el.classList.contains('draggable-note') && el.dataset.noteType === 'npc';
        const isHero = el.classList.contains('pinned-character');
        
        let id, title, type;
        if (isHero) {
            id = el.dataset.itemId.replace('pinned-char-', ''); // Fix: use actual charId
            title = el.querySelector('.pinned-name')?.textContent || 'Hero';
            type = 'hero';
        } else if (isNpc) {
            id = el.dataset.noteId;
            title = el.querySelector('.note-title')?.textContent || 'NPC';
            type = 'npc';
        } else {
            return;
        }
        
        // Hide element
        el.style.display = 'none';
        
        // Add to docked
        if (!this.dockedItems.find(i => i.id === id)) {
            this.dockedItems.push({ id, title, type, el });
            this.saveState();
        }
        
        this.renderDock();
    },
    
    undockElement(id) {
        const itemIndex = this.dockedItems.findIndex(i => i.id === id);
        if (itemIndex > -1) {
            const item = this.dockedItems[itemIndex];
            this.dockedItems.splice(itemIndex, 1);
            this.saveState();
            
            // It's possible el is missing if DOM wasn't ready on init
            if (!item.el) {
                if (item.type === 'hero') item.el = document.getElementById(`pinned-char-${item.id}`);
                else if (item.type === 'npc') item.el = document.getElementById(`note-${item.id}`);
            }
            
            if (item.el) {
                item.el.style.display = '';
                // Center it on screen
                item.el.style.left = (window.innerWidth / 2 - item.el.offsetWidth / 2) + 'px';
                item.el.style.top = (window.innerHeight / 2 - item.el.offsetHeight / 2) + 'px';
                DraggableManager.bringToFront(item.el);
                DraggableManager.savePosition(item.el);
            } else if (item.type === 'hero' && window.CharactersModule) {
                // If it completely failed to find the element, just recreate it
                CharactersModule.pinCharacter(item.id);
            }
            this.renderDock();
        }
    },
    
    renderDock() {
        const area = document.getElementById('heroes-dock-area');
        if (!area) return;
        
        area.innerHTML = '';
        
        if (this.dockedItems.length === 0) {
            area.innerHTML = '<span style="color:var(--text-muted);font-size:0.75rem;margin:auto;">Brak zadokowanych</span>';
            return;
        }
        
        this.dockedItems.forEach(item => {
            const token = document.createElement('div');
            token.className = `docked-hero ${item.type}`;
            token.title = item.title;
            
            // Get initials
            const initials = item.title.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
            token.textContent = initials;
            
            token.addEventListener('click', () => {
                this.undockElement(item.id);
            });
            
            area.appendChild(token);
        });
    }
};

// Initialize DockManager on load
document.addEventListener('DOMContentLoaded', () => {
    DockManager.init();
});
