/* ============================================
   D&D 5e DM Panel — Karczma: stół do gier
   Gry: Kości (2k6), Oczko, Wysoka karta, Ruletka kości, wolna gra.
   - kości rzucane w 3D (Dice3D), z zapasową animacją 2D,
   - sakiewki bohaterów połączone ze złotem na karcie postaci,
   - stan stołu zapisywany dla każdej kampanii.
   ============================================ */

const TavernModule = (function () {
    const SUITS = [
        { s: '♠︎', color: 'black', name: 'pik' }, { s: '♣︎', color: 'black', name: 'trefl' },
        { s: '♥︎', color: 'red', name: 'kier' }, { s: '♦︎', color: 'red', name: 'karo' }
    ];
    const VALUES = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const RANK = Object.fromEntries(VALUES.map((v, i) => [v, i + 2]));
    const SEAT_COLORS = ['#8b1a1a', '#1f3f7a', '#1f6b45', '#b8892e', '#5a2a7a', '#e8dcc0', '#1b1714', '#a0522d'];
    const GUEST_PURSE = 50;
    const GAMES = {
        dice: { name: 'Kości', icon: 'fa-dice', desc: 'Każdy rzuca 2k6. Najwyższy wynik zgarnia pulę, remis = dogrywka.', min: 2 },
        blackjack: { name: 'Oczko', icon: 'fa-clover', desc: 'Dobieraj karty do 21 przeciw karczmarzowi. Oczko z ręki płaci 3:2.', min: 1 },
        highcard: { name: 'Wysoka karta', icon: 'fa-crown', desc: 'Każdy ciągnie jedną kartę. Najwyższa wygrywa, as jest najwyższy.', min: 2 },
        roulette: { name: 'Ruletka kości', icon: 'fa-skull', desc: 'Po kolei rzut k6 — kto wyrzuci 1, odpada. Ostatni zgarnia pulę.', min: 2 }
    };

    let state = null;          // trwały stan stołu (gracze, zakład, historia)
    let deck = [];
    let seenCards = new Set(); // do animacji rozdawania
    let busy = false;          // trwa rzut / animacja
    let game = null;           // bieżąca gra
    let freeDice = [];         // wolna gra: kości na stole
    let freeCards = [];
    let selectedDice = new Set();
    let loadedFor = null;

    const esc = (s) => App.esc(s);
    const uid = () => Math.random().toString(36).slice(2, 9);
    const cid = () => App.getActiveCampaignId();
    const rnd = (n) => Math.floor(Math.random() * n) + 1;
    const reduceMotion = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    const wait = (ms) => new Promise(r => setTimeout(r, reduceMotion() ? Math.min(ms, 60) : ms));
    const revealed = new Set();   // karty, których odkrycie już pokazano

    /* ── Stan i zapis ───────────────────────────── */
    function load() {
        const key = cid() || 'none';
        if (loadedFor === key && state) return;
        loadedFor = key;
        state = StorageManager.get(`tavern_${key}`) || { players: [], bet: 10, history: [], useSheetGold: true };
        game = null; freeDice = []; freeCards = []; selectedDice.clear();
    }
    function save() { StorageManager.set(`tavern_${loadedFor}`, state); }

    // imiona w kronice w kolorze miejsca przy stole (jasne kolory przyciemnione — kronika jest na pergaminie)
    function whoColors(msg) {
        const list = state.players.map((p, i) => ({ n: esc(p.name || ''), c: p.color || SEAT_COLORS[i % SEAT_COLORS.length] })).filter(x => x.n.length > 1).sort((a, b) => b.n.length - a.n.length);
        const h = esc(msg);
        if (!list.length) return h;
        const rx = new RegExp(list.map(x => x.n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'g');
        return h.replace(rx, (m) => { const x = list.find(y => y.n === m); const c = /^#(e|f|d)/i.test(x.c) ? '#6b4a2b' : x.c; return `<b class="tg-who" style="color:${c}">${m}</b>`; });
    }
    function log(msg, kind = '') {
        const time = new Date().toLocaleTimeString(window.LOC || 'pl-PL', { hour: '2-digit', minute: '2-digit' });
        state.history.unshift({ time, msg, kind });
        state.history = state.history.slice(0, 60);
        save();
    }

    /* ── Złoto ──────────────────────────────────── */
    function charOf(p) {
        if (p.type !== 'pc' || !p.refId || !state.useSheetGold || !cid()) return null;
        return (StorageManager.getCharacters(cid()) || []).find(c => c.id === p.refId) || null;
    }
    function gold(p) {
        const c = charOf(p);
        if (c) return (c.currency && c.currency.gp) || 0;
        return p.purse ?? GUEST_PURSE;
    }
    function addGold(p, amount) {
        const c = charOf(p);
        if (c) {
            const chars = StorageManager.getCharacters(cid());
            const cc = chars.find(x => x.id === c.id);
            cc.currency = Object.assign({ cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 }, cc.currency || {});
            cc.currency.gp = Math.max(0, (cc.currency.gp || 0) + amount);
            StorageManager.saveCharacters(cid(), chars);
        } else {
            p.purse = Math.max(0, (p.purse ?? GUEST_PURSE) + amount);
            save();
        }
    }
    function takeBets(indices, bet) {
        const broke = indices.filter(i => gold(state.players[i]) < bet);
        if (broke.length) {
            App.showToast(`Za mało złota: ${broke.map(i => state.players[i].name).join(', ')}`, 'warning');
            return false;
        }
        indices.forEach(i => addGold(state.players[i], -bet));
        return true;
    }

    /* ── Talia ──────────────────────────────────── */
    function newDeck() {
        deck = [];
        SUITS.forEach(su => VALUES.forEach(v => deck.push({ id: uid(), val: v, suit: su.s, color: su.color })));
        for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    }
    function draw() {
        if (deck.length === 0) { newDeck(); log('Talia się skończyła — przetasowano nową.', 'info'); }
        return deck.pop();
    }
    function bjScore(cards) {
        let s = 0, aces = 0;
        cards.forEach(c => { if (c.val === 'A') { aces++; s += 11; } else if ('JQK'.includes(c.val)) s += 10; else s += parseInt(c.val, 10); });
        while (s > 21 && aces) { s -= 10; aces--; }
        return s;
    }

    /* ── Kości: 3D z zapasem 2D ─────────────────── */
    // rzut kośćmi na blacie stołu: wynik losujemy od razu, a kości 3D wpadają na stół (u MG i u graczy tak samo)
    // groups: [{qty, sides, color}] → [[vals]]; meta.by = {gracz: grupa}, meta.free = indeksy kości w wolnej grze
    let throwSeq = 0, lastThrow = null, throwing = false;
    const throwKey = (pos) => (lastThrow && pos != null && pos >= 0) ? `t${lastThrow.id}-${pos}` : null;
    async function throwDice(groups, meta = {}) {
        const vals = groups.map(g => Array.from({ length: g.qty }, () => rnd(g.sides)));
        const dice = [], by = {};
        groups.forEach((g, gi) => { const who = meta.who ? meta.who[gi] : null; vals[gi].forEach(v => { if (who != null) (by[who] = by[who] || []).push(dice.length); dice.push({ v, color: g.color || null }); }); });
        lastThrow = { id: Date.now().toString(36) + (++throwSeq), dice, by, free: meta.free || null, label: meta.label || '' };
        busy = true; throwing = true; render();
        try { await wait(window.TavernDice ? TavernDice.DUR + 200 + dice.length * 110 : 650); }
        finally { throwing = false; busy = false; }
        return vals;
    }
    const cubeAt = (v, pos, color, cls = '') => window.TavernDice ? TavernDice.cube(v, { key: throwKey(pos), color: color || undefined, cls }) : dieFace(v, { cls: 'big ' + cls, color });

    function dieFace(n, opts = {}) {
        const pips = { 1: [5], 2: [1, 9], 3: [1, 5, 9], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] }[n] || [];
        const cells = Array.from({ length: 9 }, (_, i) => `<i class="${pips.includes(i + 1) ? 'on' : ''}"></i>`).join('');
        return `<div class="tg-die ${opts.cls || ''}" style="${opts.color ? `--die:${opts.color}` : ''}" ${opts.attr || ''}>${cells}</div>`;
    }

    /* ── Gracze ─────────────────────────────────── */
    function addPlayer(name, type = 'guest', refId = null) {
        name = String(name || '').trim();
        if (!name) return;
        if (state.players.some(p => p.name === name)) { App.showToast(`${name} już siedzi przy stole`, 'info'); return; }
        if (state.players.length >= 8) { App.showToast('Przy stole mieści się 8 graczy', 'warning'); return; }
        state.players.push({ id: uid(), name, type, refId, purse: GUEST_PURSE });
        log(`${name} siada przy stole.`);
        render();
    }
    function addFromSelect(sel) {
        const el = typeof sel === 'string' ? document.getElementById(sel) : sel;
        if (!el || !el.value) return;
        const [type, id] = el.value.split('|');
        const src = type === 'pc' ? StorageManager.getCharacters(cid()) : StorageManager.getNPCs(cid());
        const o = (src || []).find(x => x.id === id);
        if (o) addPlayer(o.name, type, o.id);
        el.value = '';
    }
    function addWholeParty() {
        (StorageManager.getCharacters(cid()) || []).forEach(c => { if (!state.players.some(p => p.refId === c.id)) state.players.push({ id: uid(), name: c.name, type: 'pc', refId: c.id, purse: GUEST_PURSE }); });
        log('Drużyna siada przy stole.');
        render();
    }
    function removePlayer(idx) {
        if (game) { App.showToast('Najpierw dokończ grę', 'warning'); return; }
        const p = state.players[idx]; if (!p) return;
        state.players.splice(idx, 1);
        log(`${p.name} odchodzi od stołu.`);
        render();
    }
    function updateGold(idx, amount) {
        const p = state.players[idx]; if (!p) return;
        addGold(p, amount);
        render();
    }
    function setBet(v) { state.bet = Math.max(1, parseInt(v, 10) || 10); save(); render(); }
    function toggleSheetGold() { state.useSheetGold = !state.useSheetGold; save(); render(); }

    /* ═══════════════ GRY ═══════════════ */
    function start(kind) {
        if (busy) return;
        const def = GAMES[kind];
        if (state.players.length < def.min) { App.showToast(`${def.name}: potrzeba co najmniej ${def.min} graczy`, 'warning'); return; }
        if (kind === 'blackjack') { game = { kind, phase: 'select' }; render(); return; }
        const all = state.players.map((_, i) => i);
        if (!takeBets(all, state.bet)) return;
        const pot = state.bet * all.length;
        freeDice = []; freeCards = [];
        if (kind === 'dice') game = { kind, pot, order: all, turn: 0, rolls: {}, tieRound: 0 };
        if (kind === 'roulette') game = { kind, pot, alive: all.slice(), out: [], turn: 0, last: null };
        if (kind === 'highcard') game = { kind, pot, order: all, turn: 0, cards: {}, shown: new Set(), tieRound: 0 };
        log(`${def.name}: zakład ${state.bet} mz, pula ${pot} mz.`, 'start');
        render();
    }

    function payout(winners, pot, label) {
        const share = Math.floor(pot / winners.length);
        winners.forEach(i => addGold(state.players[i], share));
        const names = winners.map(i => state.players[i].name).join(' i ');
        log(`${label}: wygrywa ${names} (+${share} mz).`, 'win');
        App.showToast(`Wygrywa ${names}! +${share} mz`, 'success');
        game.winners = winners;
        game.done = true;
    }

    /* ── Kości 2k6 ── */
    async function diceRoll(all = false) {
        if (!game || game.kind !== 'dice' || game.done || busy) return;
        const who = all ? game.order.slice(game.turn) : [game.order[game.turn]];
        const res = await throwDice(who.map(i => ({ qty: 2, sides: 6, color: SEAT_COLORS[i % SEAT_COLORS.length] })), { who, label: who.length > 1 ? 'Kości toczą się po stole…' : `Rzuca: <b>${esc(state.players[who[0]].name)}</b>` });
        who.forEach((i, k) => {
            game.rolls[i] = res[k];
            log(`${state.players[i].name}${game.tieRound ? ' (dogrywka)' : ''}: ${res[k].join(' + ')} = ${res[k][0] + res[k][1]}`);
        });
        game.turn += who.length;
        if (game.turn >= game.order.length) {
            const sums = game.order.map(i => game.rolls[i][0] + game.rolls[i][1]);
            const max = Math.max(...sums);
            const top = game.order.filter((i, k) => sums[k] === max);
            if (top.length === 1) payout(top, game.pot, 'Kości');
            else {
                game.tieRound++;
                log(`Remis (${max}) między: ${top.map(i => state.players[i].name).join(', ')} — dogrywka!`, 'info');
                App.showToast('Remis — dogrywka!', 'info');
                game.order = top; game.turn = 0; game.prev = { ...game.rolls }; game.rolls = {};
            }
        }
        render();
    }

    /* ── Ruletka kości ── */
    async function roulettePull() {
        if (!game || game.kind !== 'roulette' || game.done || busy) return;
        const i = game.alive[game.turn];
        const [[v]] = await throwDice([{ qty: 1, sides: 6, color: SEAT_COLORS[i % SEAT_COLORS.length] }], { who: [i], label: `<i class="fa-solid fa-skull"></i> Rzuca: <b>${esc(state.players[i].name)}</b>…` });
        game.last = { i, v };
        if (v === 1) {
            game.out.push(i);
            game.alive.splice(game.turn, 1);
            log(`${state.players[i].name} wyrzuca 1 — odpada!`, 'lose');
            if (game.alive.length === 1) payout(game.alive, game.pot, 'Ruletka kości');
            else if (game.turn >= game.alive.length) game.turn = 0;
        } else {
            log(`${state.players[i].name} wyrzuca ${v} — przeżywa.`);
            game.turn = (game.turn + 1) % game.alive.length;
        }
        render();
    }

    /* ── Wysoka karta (po kolei, z napięciem) ── */
    function hcRanks() {
        return game.order.filter(i => game.cards[i] && game.shown.has(i)).map(i => ({ i, r: RANK[game.cards[i].val] }));
    }
    async function highcardDraw() {
        if (!game || game.kind !== 'highcard' || game.done || busy) return;
        const i = game.order[game.turn];
        const p = state.players[i];
        busy = true;
        const c = draw();
        game.cards[i] = c;
        game.msg = `${esc(p.name)} sięga po kartę…`;
        render();                                   // karta wylatuje z talii zakryta
        await wait(750);

        // ile może zmienić ta karta? ostatni gracz z szansą = dłuższe napięcie
        const best = Math.max(0, ...hcRanks().map(x => x.r));
        const isLast = game.turn === game.order.length - 1;
        const tense = document.querySelector(`.tg-card3d[data-cid="${c.id}"]`);
        if (tense) tense.classList.add('tense');
        game.msg = isLast && best ? `Ostatnia karta… ${esc(p.name)} musi pobić ${VALUES[best - 2]}!` : `${esc(p.name)} odkrywa…`;
        const st = document.querySelector('.tg-status'); if (st) st.innerHTML = game.msg;
        await wait(isLast ? 1900 : 1200);
        if (tense) { tense.classList.remove('tense'); tense.classList.add('reveal'); }
        await wait(950);

        game.shown.add(i); revealed.add(c.id);
        const r = RANK[c.val];
        let note;
        if (!best) note = `${esc(p.name)} otwiera: ${c.val}${c.suit}`;
        else if (r > best) note = `<b>Nowy prowadzący!</b> ${esc(p.name)} — ${c.val}${c.suit}`;
        else if (r === best) note = `<b>Remis na prowadzeniu!</b> ${esc(p.name)} — ${c.val}${c.suit}`;
        else note = `${esc(p.name)} — ${c.val}${c.suit}, za słabo`;
        game.flash = r > best ? 'lead' : r === best ? 'tie' : 'low';
        log(`${p.name} ciągnie ${c.val}${c.suit}${game.tieRound ? ' (dogrywka)' : ''}.`);
        game.turn++;
        game.msg = note;

        if (game.turn >= game.order.length) {
            const ranks = hcRanks();
            const max = Math.max(...ranks.map(x => x.r));
            const top = ranks.filter(x => x.r === max).map(x => x.i);
            if (top.length === 1) { payout(top, game.pot, 'Wysoka karta'); game.msg = null; }
            else {
                game.tieRound++;
                log(`Remis na ${VALUES[max - 2]} — dogrywka!`, 'info');
                App.showToast('Remis — dogrywka!', 'info');
                game.prevCards = { ...game.prevCards, ...game.cards };
                game.order = top; game.cards = {}; game.shown = new Set(); game.turn = 0;
                game.msg = `<span class="tg-tag">Dogrywka</span> ${top.map(t => esc(state.players[t].name)).join(' i ')} ciągną ponownie`;
            }
        }
        busy = false;
        render();
    }

    /* ── Oczko ── */
    async function bjDeal(pick) {
        if (busy) return;
        const idx = Array.isArray(pick) ? pick : [...document.querySelectorAll('.tg-bj-pick input:checked')].map(c => +c.value);
        if (!idx.length) { App.showToast('Wybierz co najmniej jednego gracza', 'warning'); return; }
        if (!takeBets(idx, state.bet)) return;
        if (deck.length < (idx.length + 1) * 5) { newDeck(); log('Przetasowano talię.', 'info'); }
        game = { kind: 'blackjack', phase: 'deal', players: idx, turn: 0, hands: {}, dealer: [] };
        idx.forEach(i => { game.hands[i] = { cards: [], bet: state.bet, done: false }; });
        log(`Oczko: grają ${idx.map(i => state.players[i].name).join(', ')} (zakład ${state.bet} mz).`, 'start');
        busy = true;
        for (let round = 0; round < 2; round++) {          // rozdanie jak przy prawdziwym stole
            for (const i of idx) { game.hands[i].cards.push(draw()); render(); await wait(330); }
            game.dealer.push(draw()); render(); await wait(330);
        }
        busy = false;
        game.phase = 'play';
        idx.forEach(i => { if (bjScore(game.hands[i].cards) === 21) { game.hands[i].done = true; game.hands[i].natural = true; log(`${state.players[i].name} — oczko z ręki!`, 'win'); } });
        await bjAdvance(true);
        render();
    }
    function bjCurrent() { return game && game.phase === 'play' ? game.players[game.turn] : null; }
    async function bjAdvance(checkCurrent) {
        if (!checkCurrent) game.turn++;
        while (game.turn < game.players.length && game.hands[game.players[game.turn]].done) game.turn++;
        if (game.turn >= game.players.length) await bjDealer();
    }
    async function bjHit() {
        const i = bjCurrent(); if (i === null || busy) return;
        const h = game.hands[i];
        busy = true;
        h.cards.push(draw());
        render();
        await wait(520);
        busy = false;
        const s = bjScore(h.cards);
        if (s > 21) { h.done = true; h.bust = true; log(`${state.players[i].name} dobiera — ${s}, fura!`, 'lose'); await bjAdvance(); }
        else if (s === 21) { h.done = true; log(`${state.players[i].name} — 21!`); await bjAdvance(); }
        render();
    }
    async function bjStand() {
        const i = bjCurrent(); if (i === null || busy) return;
        game.hands[i].done = true;
        log(`${state.players[i].name} pasuje przy ${bjScore(game.hands[i].cards)}.`);
        await bjAdvance(); render();
    }
    async function bjDouble() {
        const i = bjCurrent(); if (i === null || busy) return;
        const h = game.hands[i];
        if (h.cards.length !== 2) return;
        if (gold(state.players[i]) < h.bet) { App.showToast('Za mało złota, by podwoić', 'warning'); return; }
        addGold(state.players[i], -h.bet); h.bet *= 2;
        busy = true;
        h.cards.push(draw()); render(); await wait(520);
        busy = false;
        h.done = true;
        const s = bjScore(h.cards);
        if (s > 21) h.bust = true;
        log(`${state.players[i].name} podwaja (${h.bet} mz) i dobiera — ${s}${s > 21 ? ', fura!' : ''}.`);
        await bjAdvance(); render();
    }
    async function bjDealer() {
        busy = true;
        game.phase = 'dealer';
        game.msg = 'Karczmarz odkrywa kartę…';
        render();                                   // zakryta karta się odwraca
        await wait(1000);
        const live = game.players.filter(i => !game.hands[i].bust);
        if (live.length) while (bjScore(game.dealer) < 17) {
            game.msg = `Karczmarz ma ${bjScore(game.dealer)} — dobiera…`; render(); await wait(650);
            game.dealer.push(draw()); render(); await wait(700);
        }
        game.msg = null;
        busy = false;
        game.phase = 'done';
        const d = bjScore(game.dealer), dBust = d > 21, dNatural = game.dealer.length === 2 && d === 21;
        log(`Karczmarz: ${d}${dBust ? ' — fura!' : dNatural ? ' — oczko!' : ''}.`);
        game.players.forEach(i => {
            const h = game.hands[i], s = bjScore(h.cards), p = state.players[i];
            if (h.bust) { h.result = 'lose'; return; }
            if (h.natural && !dNatural) { const w = h.bet + Math.floor(h.bet * 1.5); addGold(p, w); h.result = 'win'; h.won = w; log(`${p.name} wygrywa oczkiem 3:2 (+${w - h.bet} mz).`, 'win'); return; }
            if (dBust || s > d) { addGold(p, h.bet * 2); h.result = 'win'; h.won = h.bet * 2; log(`${p.name} wygrywa (+${h.bet} mz).`, 'win'); }
            else if (s === d) { addGold(p, h.bet); h.result = 'push'; log(`${p.name} remisuje — zwrot zakładu.`); }
            else { h.result = 'lose'; log(`${p.name} przegrywa (${s} vs ${d}).`, 'lose'); }
        });
        game.done = true;
    }

    /* ── Wolna gra ── */
    async function freeRoll(count) {
        if (busy) return;
        count = Math.max(1, Math.min(10, count || 2));
        const [vals] = await throwDice([{ qty: count, sides: 6 }], { free: Array.from({ length: count }, (_, k) => k), label: `Rzut ${count}k6…` });
        freeDice = vals; selectedDice.clear();
        log(`Rzut ${count}k6: ${vals.join(', ')} (suma ${vals.reduce((a, b) => a + b, 0)}).`);
        render();
    }
    async function rerollSelected() {
        if (busy) return;
        if (!selectedDice.size) { App.showToast('Kliknij kości, które chcesz przerzucić', 'info'); return; }
        const idx = [...selectedDice];
        const [vals] = await throwDice([{ qty: idx.length, sides: 6 }], { free: idx, label: 'Przerzut…' });
        idx.forEach((d, k) => { freeDice[d] = vals[k]; });
        selectedDice.clear();
        log(`Przerzut: ${freeDice.join(', ')} (suma ${freeDice.reduce((a, b) => a + b, 0)}).`);
        render();
    }
    function toggleDieSelection(i) { selectedDice.has(i) ? selectedDice.delete(i) : selectedDice.add(i); render(); }
    function drawCard() {
        if (game) { App.showToast('Najpierw dokończ grę', 'warning'); return; }
        if (busy) return;
        const c = draw(); freeCards.push(c);
        log(`Dobrana karta: ${c.val}${c.suit}`);
        render();
    }
    function clearTable() {
        if (game && !game.done && game.kind !== 'blackjack') {
            // przerwana gra — zwrot zakładów
            const back = game.kind === 'roulette' ? game.alive.concat(game.out) : (game.kind === 'dice' || game.kind === 'highcard') ? state.players.map((_, i) => i) : [];
            back.forEach(i => state.players[i] && addGold(state.players[i], state.bet));
            if (back.length) log('Gra przerwana — zwrócono zakłady.', 'info');
        } else if (game && game.kind === 'blackjack' && game.phase === 'play') {
            game.players.forEach(i => addGold(state.players[i], game.hands[i].bet));
            log('Rozdanie przerwane — zwrócono zakłady.', 'info');
        }
        game = null; freeDice = []; freeCards = []; selectedDice.clear();
        render();
    }
    function resetTable() { newDeck(); clearTable(); log('Nowa talia — przetasowano 52 karty.', 'info'); render(); }
    function clearHistory() { state.history = []; save(); render(); }

    /* ═══════════════ RENDER ═══════════════ */
    function card(c, hidden = false, extra = '') {
        if (!c) return '';
        const isNew = !seenCards.has(c.id); seenCards.add(c.id);
        // karta, która była zakryta, a teraz jest odkryta → animacja odwrócenia
        let cls = isNew ? 'fly-pending' : '';
        if (!hidden && !isNew && c._wasHidden && !revealed.has(c.id)) { cls = 'reveal'; revealed.add(c.id); }
        if (hidden) c._wasHidden = true; else if (isNew) revealed.add(c.id);
        const face = 'JQK'.includes(c.val) ? `<div class="tg-face-art">${c.val}<small>${c.suit}</small></div>` : c.val === 'A' ? `<div class="tg-pip big">${c.suit}</div>` : `<div class="tg-pip">${c.suit}</div>`;
        return `<div class="tg-card3d ${hidden ? 'down' : ''} ${cls} ${extra}" data-cid="${c.id}">
            <div class="tg-inner">
                <div class="tg-card tg-front ${c.color}"><span class="tg-idx tl">${c.val}<br>${c.suit}</span>${face}<span class="tg-idx br">${c.val}<br>${c.suit}</span></div>
                <div class="tg-card tg-back back"></div>
            </div></div>`;
    }

    function deckPile() {
        const n = Math.min(6, Math.ceil(deck.length / 9));
        return `<div class="tg-deck" id="tg-deck" title="Talia: ${deck.length} kart">${Array.from({ length: Math.max(1, n) }, (_, k) => `<div class="tg-card back" style="--k:${k}"></div>`).join('')}<span>${deck.length}</span></div>`;
    }

    // Karty „wylatują” z talii: liczymy odległość od stosu i odpalamy animację
    function launchCards() {
        const pile = document.getElementById('tg-deck');
        const cards = document.querySelectorAll('.tg-card3d.fly-pending');
        if (!cards.length) return;
        const pr = pile ? pile.getBoundingClientRect() : null;
        cards.forEach((el, k) => {
            const r = el.getBoundingClientRect();
            const dx = pr ? (pr.left + pr.width / 2) - (r.left + r.width / 2) : 0;
            const dy = pr ? (pr.top + pr.height / 2) - (r.top + r.height / 2) : -120;
            el.style.setProperty('--dx', dx + 'px');
            el.style.setProperty('--dy', dy + 'px');
            el.style.setProperty('--delay', (k * 0.09) + 's');
            el.classList.remove('fly-pending');
            el.classList.add('fly');
        });
    }

    function seat(p, i) {
        const color = SEAT_COLORS[i % SEAT_COLORS.length];
        const g = gold(p);
        const linked = !!charOf(p);
        let cls = '', badge = '';
        if (game) {
            if (game.kind === 'dice' && !game.done && game.order[game.turn] === i) cls = 'turn';
            if (game.kind === 'roulette' && !game.done && game.alive[game.turn] === i) cls = 'turn';
            if (game.kind === 'roulette' && game.out.includes(i)) cls = 'out';
            if (game.kind === 'blackjack' && game.phase === 'play' && bjCurrent() === i) cls = 'turn';
            if (game.winners && game.winners.includes(i)) cls = 'winner';
            if (game.kind === 'dice') {
                const r = game.rolls[i] || (game.prev && game.prev[i]);
                if (r) badge = `<div class="tg-seat-dice">${r.map(v => dieFace(v, { color })).join('')}<b>${r[0] + r[1]}</b></div>`;
            }
            if (game.kind === 'highcard') {
                if (!game.done && game.order[game.turn] === i) cls = 'turn';
                const c = (game.shown.has(i) && game.cards[i]) || (game.prevCards && game.prevCards[i]);
                if (c) badge = `<div class="tg-seat-dice"><span class="tg-mini ${c.color}">${c.val}${c.suit}</span></div>`;
            }
            if (game.kind === 'roulette' && game.out.includes(i)) badge = `<div class="tg-seat-dice"><span class="tg-dead"><i class="fa-solid fa-skull"></i> odpadł</span></div>`;
        }
        const typeLabel = p.type === 'pc' ? 'Bohater' : p.type === 'npc' ? 'NPC' : 'Gość';
        return `<div class="tg-seat ${cls}" style="--seat:${color}">
            <div class="tg-seat-top">
                <span class="tg-seat-token"></span>
                <div class="tg-seat-name"><b>${esc(p.name)}</b><small>${typeLabel}${linked ? ' · złoto z karty' : ''}</small></div>
                <button class="tg-x" onclick="TavernModule.removePlayer(${i})" title="Odejdź od stołu">&times;</button>
            </div>
            <div class="tg-purse">
                <span class="tg-coins"><i class="fa-solid fa-coins"></i> <b>${g}</b> mz</span>
                <span class="tg-purse-btns">
                    <button onclick="TavernModule.updateGold(${i},-5)">−5</button><button onclick="TavernModule.updateGold(${i},-1)">−1</button>
                    <button onclick="TavernModule.updateGold(${i},1)">+1</button><button onclick="TavernModule.updateGold(${i},5)">+5</button>
                </span>
            </div>
            ${badge}
        </div>`;
    }

    function tableArea() {
        if (throwing && lastThrow) {
            return `<div class="tg-play">${game && game.pot ? `<div class="tg-pot"><span class="tg-chips"></span>Pula: <b>${game.pot}</b> mz</div>` : ''}
                <div class="tg-row tg-dice-row">${lastThrow.dice.map((d, k) => cubeAt(d.v, k, d.color)).join('')}</div>
                <div class="tg-status">${lastThrow.label || 'Kości toczą się po stole…'}</div></div>`;
        }
        if (!game) {
            if (freeCards.length || freeDice.length) {
                const sum = freeDice.reduce((a, b) => a + b, 0);
                return `<div class="tg-play">${deckPile()}
                    ${freeCards.length ? `<div class="tg-row">${freeCards.map(c => card(c)).join('')}</div><div class="tg-note">Suma kart (oczko): <b>${bjScore(freeCards)}</b></div>` : ''}
                    ${freeDice.length ? `<div class="tg-row tg-dice-row">${freeDice.map((v, i) => `<div class="td-pick ${selectedDice.has(i) ? 'sel' : ''}" onclick="TavernModule.toggleDieSelection(${i})" title="Kliknij, aby zaznaczyć do przerzutu">${cubeAt(v, lastThrow && lastThrow.free ? lastThrow.free.indexOf(i) : -1)}</div>`).join('')}</div>
                        <div class="tg-note">Suma: <b>${sum}</b>${selectedDice.size ? ` · zaznaczono ${selectedDice.size}` : ' · kliknij kości, by wybrać do przerzutu'}</div>` : ''}
                </div>`;
            }
            return `<div class="tg-menu">
                ${Object.entries(GAMES).map(([k, g]) => `
                    <button class="tg-game" onclick="TavernModule.start('${k}')">
                        <i class="fa-solid ${g.icon}"></i><b>${g.name}</b><span>${g.desc}</span>
                        <em>${g.min > 1 ? `od ${g.min} graczy` : 'od 1 gracza'}</em>
                    </button>`).join('')}
            </div>`;
        }
        const potHtml = game.pot ? `<div class="tg-pot"><span class="tg-chips"></span>Pula: <b>${game.pot}</b> mz</div>` : '';

        if (game.kind === 'dice') {
            const last = Object.keys(game.rolls).length ? game.order.filter(i => game.rolls[i]).slice(-1)[0] : null;
            const status = game.done ? `<i class="fa-solid fa-trophy"></i> Wygrywa ${game.winners.map(i => esc(state.players[i].name)).join(' i ')}!`
                : `${game.tieRound ? '<span class="tg-tag">Dogrywka</span> ' : ''}Rzuca: <b>${esc(state.players[game.order[game.turn]].name)}</b>`;
            return `<div class="tg-play">${potHtml}
                <div class="tg-row tg-dice-row">${last !== null ? game.rolls[last].map((v, j) => cubeAt(v, lastThrow && lastThrow.by[last] ? lastThrow.by[last][j] : -1, SEAT_COLORS[last % SEAT_COLORS.length])).join('') : '<div class="tg-note">Kości czekają na pierwszy rzut…</div>'}</div>
                ${last !== null ? `<div class="tg-note">${esc(state.players[last].name)}: <b>${game.rolls[last][0] + game.rolls[last][1]}</b></div>` : ''}
                <div class="tg-status ${game.done ? 'win' : ''}">${status}</div></div>`;
        }
        if (game.kind === 'roulette') {
            const l = game.last;
            const status = game.done ? `<i class="fa-solid fa-trophy"></i> Ostatni przy życiu: ${esc(state.players[game.winners[0]].name)}!`
                : `<i class="fa-solid fa-skull"></i> Rzuca: <b>${esc(state.players[game.alive[game.turn]].name)}</b> — jedynka odpada`;
            return `<div class="tg-play">${potHtml}
                <div class="tg-row tg-dice-row">${l ? cubeAt(l.v, lastThrow && lastThrow.by[l.i] ? lastThrow.by[l.i][0] : -1, SEAT_COLORS[l.i % SEAT_COLORS.length], l.v === 1 ? 'fatal' : '') : '<div class="tg-note">Kto pierwszy?</div>'}</div>
                ${l ? `<div class="tg-note ${l.v === 1 ? 'bad' : 'good'}">${esc(state.players[l.i].name)}: ${l.v === 1 ? 'jedynka — odpada!' : `${l.v} — przeżywa`}</div>` : ''}
                <div class="tg-status ${game.done ? 'win' : ''}">${status}</div></div>`;
        }
        if (game.kind === 'highcard') {
            const slots = game.order.map((i, k) => {
                const c = game.cards[i];
                const isTurn = !game.done && k === game.turn && !c;
                const won = game.winners && game.winners.includes(i);
                const inner = c ? card(c, !game.shown.has(i), won ? 'winner' : '') : `<div class="tg-slot ${isTurn ? 'turn' : ''}"><i class="fa-solid fa-hand"></i></div>`;
                return `<div class="tg-labeled ${isTurn ? 'turn' : ''}" style="--seat:${SEAT_COLORS[i % SEAT_COLORS.length]}">${inner}<span>${esc(state.players[i].name)}</span></div>`;
            }).join('');
            const status = game.done ? `<i class="fa-solid fa-trophy"></i> Wygrywa ${esc(state.players[game.winners[0]].name)}!`
                : game.msg || `Ciągnie: <b>${esc(state.players[game.order[game.turn]].name)}</b>`;
            return `<div class="tg-play">${deckPile()}${potHtml}
                <div class="tg-row tg-hc-row">${slots}</div>
                <div class="tg-status ${game.done ? 'win' : ''} ${game.flash && !game.done ? 'flash-' + game.flash : ''}">${status}</div></div>`;
        }
        if (game.kind === 'blackjack') {
            if (game.phase === 'select') {
                return `<div class="tg-play"><div class="tg-status">Kto gra w oczko? Zakład: <b>${state.bet} mz</b></div>
                    <div class="tg-bj-pick">${state.players.map((p, i) => `<label><input type="checkbox" value="${i}" checked> ${esc(p.name)} <small>${gold(p)} mz</small></label>`).join('')}</div></div>`;
            }
            const d = bjScore(game.dealer);
            const dealerCards = game.dealer.map((c, k) => card(c, k === 1 && (game.phase === 'play' || game.phase === 'deal'))).join('');
            const hands = game.players.map(i => {
                const h = game.hands[i], s = bjScore(h.cards);
                const res = h.result === 'win' ? `<span class="tg-res win">+${h.won - h.bet} mz</span>` : h.result === 'push' ? '<span class="tg-res">remis</span>' : h.result === 'lose' || h.bust ? '<span class="tg-res lose">przegrana</span>' : '';
                return `<div class="tg-hand ${bjCurrent() === i ? 'turn' : ''}" style="--seat:${SEAT_COLORS[i % SEAT_COLORS.length]}">
                    <div class="tg-hand-head"><b>${esc(state.players[i].name)}</b><span class="tg-score ${s > 21 ? 'bust' : s === 21 ? 'bj' : ''}">${s}</span>${h.natural ? '<span class="tg-tag">oczko!</span>' : ''}${h.bet > state.bet ? '<span class="tg-tag">×2</span>' : ''}${res}</div>
                    <div class="tg-row tight">${h.cards.map(c => card(c)).join('')}</div></div>`;
            }).join('');
            return `<div class="tg-play">${deckPile()}
                <div class="tg-dealer"><div class="tg-hand-head"><b><i class="fa-solid fa-beer-mug-empty"></i> Karczmarz</b>${game.phase === 'dealer' || game.phase === 'done' ? `<span class="tg-score ${d > 21 ? 'bust' : ''}">${d}</span>` : ''}</div><div class="tg-row tight">${dealerCards}</div></div>
                <div class="tg-hands">${hands}</div>
                ${game.done ? '<div class="tg-status win">Rozdanie zakończone</div>' : game.phase === 'play' ? `<div class="tg-status">Ruch: <b>${esc(state.players[bjCurrent()].name)}</b> (${bjScore(game.hands[bjCurrent()].cards)})</div>` : `<div class="tg-status">${game.msg || 'Karczmarz rozdaje karty…'}</div>`}</div>`;
        }
        return '';
    }

    function actions() {
        const dis = busy ? 'disabled' : '';
        if (!game) {
            return `<div class="tg-actions">
                <button class="btn-secondary" ${dis} onclick="TavernModule.freeRoll(+document.getElementById('tg-free-n').value)"><i class="fa-solid fa-dice"></i> Rzuć
                    <select id="tg-free-n" onclick="event.stopPropagation()">${[1, 2, 3, 4, 5, 6].map(n => `<option value="${n}"${n === 2 ? ' selected' : ''}>${n}k6</option>`).join('')}</select></button>
                ${freeDice.length ? `<button class="btn-secondary" ${dis} onclick="TavernModule.rerollSelected()"><i class="fa-solid fa-rotate"></i> Przerzuć wybrane</button>` : ''}
                <button class="btn-secondary" ${dis} onclick="TavernModule.drawCard()"><i class="fa-solid fa-clone"></i> Dobierz kartę</button>
                ${freeDice.length || freeCards.length ? '<button class="btn-secondary" onclick="TavernModule.clearTable()"><i class="fa-solid fa-broom"></i> Zgarnij</button>' : ''}
                <button class="btn-secondary" onclick="TavernModule.resetTable()"><i class="fa-solid fa-shuffle"></i> Przetasuj</button>
            </div>`;
        }
        if (game.done) return `<div class="tg-actions">
            <button class="btn-primary" onclick="TavernModule.start('${game.kind}')"><i class="fa-solid fa-rotate-right"></i> Jeszcze raz (${state.bet} mz)</button>
            <button class="btn-secondary" onclick="TavernModule.clearTable()"><i class="fa-solid fa-broom"></i> Inna gra</button></div>`;
        const cancel = `<button class="btn-secondary" ${dis} onclick="TavernModule.clearTable()"><i class="fa-solid fa-xmark"></i> Przerwij</button>`;
        if (game.kind === 'dice') return `<div class="tg-actions">
            <button class="btn-primary" ${dis} onclick="TavernModule.diceRoll()"><i class="fa-solid fa-dice"></i> Rzuć 2k6</button>
            ${game.order.length - game.turn > 1 ? `<button class="btn-secondary" ${dis} onclick="TavernModule.diceRoll(true)"><i class="fa-solid fa-dice-d6"></i> Rzuć za wszystkich</button>` : ''}${cancel}</div>`;
        if (game.kind === 'roulette') return `<div class="tg-actions"><button class="btn-danger" ${dis} onclick="TavernModule.roulettePull()"><i class="fa-solid fa-dice-one"></i> Rzuć k6</button>${cancel}</div>`;
        if (game.kind === 'highcard') return `<div class="tg-actions"><button class="btn-primary" ${dis} onclick="TavernModule.highcardDraw()"><i class="fa-solid fa-clone"></i> ${esc(state.players[game.order[game.turn]].name)} ciągnie kartę</button>${cancel}</div>`;
        if (game.kind === 'blackjack') {
            if (game.phase === 'select') return `<div class="tg-actions"><button class="btn-primary" onclick="TavernModule.bjDeal()"><i class="fa-solid fa-clone"></i> Rozdaj</button>${cancel}</div>`;
            if (game.phase !== 'play') return `<div class="tg-actions"><button class="btn-secondary" disabled><i class="fa-solid fa-hourglass-half"></i> Chwileczkę…</button></div>`;
            const i = bjCurrent();
            const canDouble = i !== null && game.hands[i].cards.length === 2;
            return `<div class="tg-actions">
                <button class="btn-primary" ${dis} onclick="TavernModule.bjHit()"><i class="fa-solid fa-hand-pointer"></i> Dobierz</button>
                <button class="btn-secondary" ${dis} onclick="TavernModule.bjStand()"><i class="fa-solid fa-hand"></i> Pas</button>
                ${canDouble ? `<button class="btn-secondary" ${dis} onclick="TavernModule.bjDouble()"><i class="fa-solid fa-coins"></i> Podwój</button>` : ''}${cancel}</div>`;
        }
        return '';
    }

    function render() {
        if (state) publish();
        const box = document.getElementById('tavern-content');
        if (!box || !state) return;
        const chars = cid() ? StorageManager.getCharacters(cid()) || [] : [];
        const npcs = cid() ? StorageManager.getNPCs(cid()) || [] : [];
        const taken = new Set(state.players.map(p => p.refId).filter(Boolean));
        const opts = `<option value="">Dosiądź się…</option>
            ${chars.filter(c => !taken.has(c.id)).length ? `<optgroup label="Drużyna">${chars.filter(c => !taken.has(c.id)).map(c => `<option value="pc|${esc(c.id)}">${esc(c.name)}</option>`).join('')}</optgroup>` : ''}
            ${npcs.filter(n => !taken.has(n.id)).length ? `<optgroup label="NPC">${npcs.filter(n => !taken.has(n.id)).map(n => `<option value="npc|${esc(n.id)}">${esc(n.name)}</option>`).join('')}</optgroup>` : ''}`;
        const gameName = game ? GAMES[game.kind].name : 'Wybierz grę';

        box.innerHTML = `
        <div class="tg-layout ${busy ? 'is-busy' : ''}">
            <div class="tg-side">
            <aside class="tg-seats">
                <div class="tg-panel-head"><h3><i class="fa-solid fa-chair"></i> Przy stole</h3><span>${state.players.length}/8</span></div>
                <div class="tg-add">
                    <select onchange="TavernModule.addFromSelect(this)">${opts}</select>
                    <div class="tg-add-row"><input type="text" id="tg-guest" placeholder="Gość z sali…" onkeydown="if(event.key==='Enter'){TavernModule.addPlayer(this.value)}">
                        <button class="btn-primary btn-small" onclick="TavernModule.addPlayer(document.getElementById('tg-guest').value)"><i class="fa-solid fa-plus"></i></button></div>
                    ${chars.some(c => !taken.has(c.id)) ? '<button class="btn-secondary btn-small tg-party-btn" onclick="TavernModule.addWholeParty()"><i class="fa-solid fa-users"></i> Cała drużyna</button>' : ''}
                </div>
                <div class="tg-seat-list">${state.players.length ? state.players.map(seat).join('') : '<div class="empty-state"><i class="fa-solid fa-chair"></i><span>Stół czeka na graczy</span></div>'}</div>
                <label class="tg-sheet-gold"><input type="checkbox" ${state.useSheetGold ? 'checked' : ''} onchange="TavernModule.toggleSheetGold()"> Bohaterowie grają złotem z karty postaci</label>
            </aside>
                <div class="tg-log">
                    <div class="tg-panel-head"><h3><i class="fa-solid fa-scroll"></i> Kronika stołu</h3>${state.history.length ? '<button class="tg-link" onclick="TavernModule.clearHistory()">wyczyść</button>' : ''}</div>
                    <div class="tg-log-list">${state.history.length ? state.history.map(h => `<div class="${h.kind}"><time>${h.time}</time>${whoColors(h.msg)}</div>`).join('') : '<div class="tg-log-empty">Jeszcze nic się nie wydarzyło.</div>'}</div>
                </div>
            </div>

            <section class="tg-main">
                <div class="tg-table">
                    <div class="tg-table-head">
                        <span class="tg-game-name">${gameName}</span>
                        <span class="tg-meta"><i class="fa-solid fa-clone"></i> ${deck.length}/52
                            <label class="tg-bet">Zakład <select onchange="TavernModule.setBet(this.value)" ${game && !game.done ? 'disabled' : ''}>${[1, 5, 10, 25, 50, 100].map(v => `<option value="${v}"${state.bet === v ? ' selected' : ''}>${v} mz</option>`).join('')}</select></label></span>
                    </div>
                    <div class="tg-felt">${tableArea()}</div>
                    ${actions()}
                </div>
            </section>
        </div>`;
        launchCards();
        if (window.TavernDice) TavernDice.play(box);
    }

    /* ═══════════════ GRACZE ONLINE ═══════════════
       Stan stołu trafia do wspólnych danych (tavern_live_*), a ruchy graczy
       przychodzą jako prośby (tavern_req_*) — rozstrzyga je panel MG. */
    let notice = null, lastPub = '';
    const pubCard = (c, down) => down ? { down: true } : { val: c.val, suit: c.suit, color: c.color };
    const plain = (h) => String(h || '').replace(/<[^>]+>/g, '');
    function publish() {
        if (!loadedFor || loadedFor === 'none') return;
        let g = null;
        if (game) {
            g = { kind: game.kind, name: GAMES[game.kind].name, pot: game.pot || 0, done: !!game.done, winners: game.winners || [], msg: plain(game.msg), tieRound: game.tieRound || 0 };
            if (game.kind === 'dice') Object.assign(g, { order: game.order, turn: game.turn, rolls: game.rolls, prev: game.prev || {} });
            if (game.kind === 'roulette') Object.assign(g, { alive: game.alive, out: game.out, turn: game.turn, last: game.last });
            if (game.kind === 'highcard') Object.assign(g, { order: game.order, turn: game.turn, cards: Object.fromEntries(Object.entries(game.cards).map(([i, c]) => [i, pubCard(c, !game.shown.has(+i))])) });
            if (game.kind === 'blackjack') Object.assign(g, { phase: game.phase, players: game.players || [], turn: game.turn, current: bjCurrent(),
                dealer: (game.dealer || []).map((c, k) => pubCard(c, k === 1 && (game.phase === 'play' || game.phase === 'deal'))),
                dealerScore: game.phase === 'dealer' || game.phase === 'done' ? bjScore(game.dealer) : null,
                hands: Object.fromEntries(Object.entries(game.hands || {}).map(([i, h]) => [i, { cards: h.cards.map(c => pubCard(c)), score: bjScore(h.cards), bet: h.bet, done: !!h.done, bust: !!h.bust, natural: !!h.natural, result: h.result || null, won: h.won || 0 }])) });
        }
        const snap = {
            bet: state.bet, deck: deck.length, busy,
            players: state.players.map((p, i) => ({ i, name: p.name, type: p.type, refId: p.refId || null, gold: gold(p), color: SEAT_COLORS[i % SEAT_COLORS.length] })),
            game: g, free: { dice: freeDice, cards: freeCards.map(c => pubCard(c)), sum: freeDice.reduce((a, b) => a + b, 0) },
            history: state.history.slice(0, 14), notice,
            throw: lastThrow, throwing
        };
        const js = JSON.stringify(snap);
        if (js === lastPub) return;
        lastPub = js;
        StorageManager.set(`tavern_live_${loadedFor}`, { ...snap, t: Date.now() });
    }
    function tell(r, text) { notice = { charId: r.charId, text, t: Date.now() }; }
    let processing = false;
    async function processRequests() {
        if (processing || !cid()) return;
        load();
        if (!deck.length) newDeck();
        const reqs = StorageManager.get(`tavern_req_${loadedFor}`) || [];
        state.doneReq = state.doneReq || [];
        const todo = reqs.filter(r => !state.doneReq.includes(r.id));
        if (!todo.length) return;
        processing = true;
        try {
            for (const r of todo) {
                if (busy) { setTimeout(processRequests, 500); break; }
                state.doneReq = state.doneReq.concat(r.id).slice(-80); save();
                if (Date.now() - (r.t || 0) > 5 * 60000) continue;            // stare prośby (np. po restarcie) pomijamy
                const ch = (StorageManager.getCharacters(cid()) || []).find(c => c.id === r.charId);
                const seatIdx = state.players.findIndex(p => p.type === 'pc' && p.refId === r.charId);
                const myTurn = () => game && !game.done && (
                    (game.kind === 'dice' && game.order[game.turn] === seatIdx) || (game.kind === 'roulette' && game.alive[game.turn] === seatIdx) ||
                    (game.kind === 'highcard' && game.order[game.turn] === seatIdx) || (game.kind === 'blackjack' && bjCurrent() === seatIdx));
                switch (r.akcja) {
                    case 'siadam':
                        if (!ch) { tell(r, 'Nie masz jeszcze postaci.'); break; }
                        if (seatIdx >= 0) { tell(r, 'Już siedzisz przy stole.'); break; }
                        if (game && !game.done) { tell(r, 'Poczekaj, aż skończy się bieżąca gra.'); break; }
                        addPlayer(ch.name, 'pc', ch.id); break;
                    case 'wstaje':
                        if (seatIdx < 0) break;
                        if (game && !game.done) { tell(r, 'Nie odchodzi się od stołu w trakcie gry!'); break; }
                        game = null; removePlayer(seatIdx); break;
                    case 'rzut':
                        if (seatIdx < 0) { tell(r, 'Najpierw dosiądź się do stołu.'); break; }
                        if (!game) { tell(r, 'Mistrz Gry jeszcze nie wybrał gry.'); break; }
                        if (game.done) { tell(r, 'Runda skończona — wybierz „Jeszcze jedna runda”.'); break; }
                        if (!myTurn()) { tell(r, 'To nie Twoja kolej.'); break; }
                        if (game.kind === 'dice') await diceRoll(false);
                        else if (game.kind === 'roulette') await roulettePull();
                        else if (game.kind === 'highcard') await highcardDraw();
                        break;
                    case 'karta':
                        tell(r, 'Przy tym stole gra się w gry wybrane przez Mistrza Gry.'); break;
                    case 'gram': {
                        // gracz prosi o kolejną rundę tej samej gry
                        if (seatIdx < 0) { tell(r, 'Najpierw dosiądź się do stołu.'); break; }
                        if (!game) { tell(r, 'Mistrz Gry jeszcze nie wybrał gry.'); break; }
                        if (!game.done) { tell(r, 'Ta runda jeszcze trwa.'); break; }
                        const kind = game.kind, prevPlayers = (game.players || []).filter(i => i < state.players.length);
                        const before = game;
                        start(kind);
                        if (game === before) { tell(r, 'Nie da się zacząć — ktoś nie ma złota na zakład albo brakuje graczy.'); break; }
                        if (kind === 'blackjack' && game && game.phase === 'select') {
                            const who = prevPlayers.includes(seatIdx) ? prevPlayers : [...prevPlayers, seatIdx];
                            await bjDeal(who.length ? who : state.players.map((_, i) => i));
                            if (game && game.phase === 'select') { game = before; tell(r, 'Nie da się rozdać — ktoś nie ma złota na zakład.'); }
                        }
                        break;
                    }
                    case 'dobierz': case 'pas': case 'podwoj':
                        if (!game || game.kind !== 'blackjack' || !myTurn()) { tell(r, 'To nie Twoja kolej.'); break; }
                        if (r.akcja === 'dobierz') await bjHit(); else if (r.akcja === 'pas') await bjStand(); else await bjDouble();
                        break;
                    default: tell(r, 'Karczmarz nie rozumie.');
                }
                render();
            }
        } finally { processing = false; }
    }
    window.addEventListener('panel-remote', (e) => { if ((e.detail?.keys || []).some(k => k.includes('tavern_req_'))) processRequests(); });
    setTimeout(() => { try { if (window.StorageManager && StorageManager.syncAvailable && StorageManager.syncAvailable() && cid()) { load(); if (!deck.length) newDeck(); render(); processRequests(); } } catch (e) {} }, 3000);

    function activate() {
        load();
        // przy wejściu na zakładkę nie animujemy kart, które już leżą
        document.querySelectorAll('.tg-card3d').forEach(el => seenCards.add(el.dataset.cid));
        if (!deck.length) newDeck();
        render();
    }

    return {
        activate, start, addPlayer, addFromSelect, addWholeParty, removePlayer, updateGold, setBet, toggleSheetGold,
        diceRoll, roulettePull, highcardDraw, bjDeal, bjHit, bjStand, bjDouble,
        freeRoll, rerollSelected, toggleDieSelection, drawCard, clearTable, resetTable, clearHistory,
        // zgodność ze starymi nazwami
        startDiceGame: () => start('dice'), startRoulette: () => start('roulette'), startBlackjackSelect: () => start('blackjack'),
        diceGameRoll: () => diceRoll(), startBlackjack: () => bjDeal()
    };
})();
window.TavernModule = TavernModule;
