/* ============================================
   D&D 5e DM Panel — Main App Controller
   ============================================ */

const App = {
    currentTab: 'dashboard',
    modules: {},

    init() {

        // pakiet kampanii (opcjonalny): jego kampania wraca na listę, gdyby zniknęła
        try {
            const P = window.PANEL_PAKIET;
            const campaigns = StorageManager.getCampaigns();
            if (P && P.kampania && !campaigns.find(c => c.id === P.kampania)) {
                campaigns.push({ id: P.kampania, name: P.nazwa || 'Kampania', description: 'Odzyskana kampania' });
                StorageManager.saveCampaigns(campaigns);
                StorageManager.setActiveCampaignId(P.kampania);
            }
        } catch (e) {}

        // Initialize core systems
        DraggableManager.init();
        DiceRoller.init();

        // Register modules (they may not exist yet if scripts haven't loaded)
        this.registerModules();

        // Bind navigation
        this.bindNavigation();

        // Bind campaign selector
        this.bindCampaignSelector();

        // Bind sidebar actions
        this.bindSidebarActions();

        // Load campaigns into selector
        this.loadCampaignSelector();

        // Restore last active campaign
        const lastCampaign = StorageManager.getActiveCampaignId();
        if (lastCampaign) {
            const select = document.getElementById('campaign-select');
            if (select) select.value = lastCampaign;
        }

        // Initialize all modules
        Object.values(this.modules).forEach(m => {
            if (m && m.init) m.init();
        });

        // Restore last tab or show dashboard
        const [hash, hashSub] = window.location.hash.replace('#', '').split('/');
        if (hash && document.getElementById(`tab-${hash}`)) {
            this.switchTab(hash, hashSub);
        } else {
            this.switchTab('dashboard');
        }

        // Update dashboard
        this.updateDashboard();

        console.log('⚔️ DM Panel initialized');
    },

    registerModules() {
        this.modules = {
            bestiary: window.BestiaryModule || null,
            spells: window.SpellsModule || null,
            equipment: window.EquipmentModule || null,
            characters: window.CharactersModule || null,
            npcs: window.NPCsModule || null,
            campaign: window.CampaignsModule || null,
            notes: window.NotesModule || null,
            combat: window.CombatModule || null,
            tavern: window.TavernModule || null,
            rules: window.RulesModule || null,
            online: window.OnlineModule || null,
            party: null
        };
    },

    // ---- Navigation ----
    bindNavigation() {
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                this.switchTab(tab.dataset.tab, tab.dataset.subtab);
            });
        });
    },

    // Highlight the matching menu entry and update the top bar title
    markNav(tabName, subtab) {
        const items = [...document.querySelectorAll('.nav-tab')];
        let active = null;
        if (subtab) active = items.find(t => t.dataset.tab === tabName && t.dataset.subtab === subtab);
        if (!active) active = items.find(t => t.dataset.tab === tabName && (!t.dataset.subtab || t.dataset.subtab === 'overview'));
        items.forEach(t => t.classList.toggle('active', t === active));
        const title = document.getElementById('topbar-title');
        if (title && active) {
            const group = active.closest('.nav-group')?.querySelector('.nav-group-title')?.textContent || '';
            title.innerHTML = `<span class="topbar-crumb">${group}</span><span class="topbar-page">${active.querySelector('.nav-icon')?.innerHTML || ''} ${active.querySelector('.nav-label')?.textContent || ''}</span>`;
        }
        const hash = subtab && subtab !== 'overview' ? `${tabName}/${subtab}` : tabName;
        if (window.location.hash.replace('#', '') !== hash) history.replaceState(null, '', '#' + hash);
    },

    switchTab(tabName, subtab) {
        if (!document.getElementById(`tab-${tabName}`)) return;
        // Deactivate current
        const currentModule = this.modules[this.currentTab];
        if (currentModule && currentModule.deactivate && this.currentTab !== tabName) {
            currentModule.deactivate();
        }

        // Update tab panels
        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        const activePanel = document.getElementById(`tab-${tabName}`);
        if (activePanel) { activePanel.classList.add('active'); activePanel.scrollTop = 0; }

        this.currentTab = tabName;

        // Activate new module
        const newModule = this.modules[tabName];
        if (tabName === 'campaign' && subtab && newModule && newModule.openSubtab) {
            newModule.openSubtab(subtab);
        } else if (newModule && newModule.activate) {
            newModule.activate();
        }

        this.markNav(tabName, tabName === 'campaign' ? (subtab || (newModule && newModule.getSubtab && newModule.getSubtab())) : null);

        // Special: update dashboard when switching to it
        if (tabName === 'dashboard') {
            this.updateDashboard();
        }
    },

    // ---- Campaign Selector ----
    bindCampaignSelector() {
        const select = document.getElementById('campaign-select');
        const newBtn = document.getElementById('btn-new-campaign');

        if (select) {
            select.addEventListener('change', () => {
                const id = select.value;
                StorageManager.setActiveCampaignId(id || null);
                this.onCampaignChange();
            });
        }

        if (newBtn) {
            newBtn.addEventListener('click', () => this.showNewCampaignModal());
        }
    },

    loadCampaignSelector() {
        const select = document.getElementById('campaign-select');
        if (!select) return;

        const campaigns = StorageManager.getCampaigns();
        const activeId = StorageManager.getActiveCampaignId();

        // Keep the default option
        select.innerHTML = '<option value="">— Wybierz kampanię —</option>';
        campaigns.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c.id;
            opt.textContent = c.name;
            if (c.id === activeId) opt.selected = true;
            select.appendChild(opt);
        });
    },

    onCampaignChange() {
        // Refresh all modules
        Object.values(this.modules).forEach(m => {
            if (m && m.activate) m.activate();
        });

        // Refresh notes overlay
        if (this.modules.notes && this.modules.notes.refreshNotes) {
            this.modules.notes.refreshNotes();
        }

        this.updateDashboard();
    },

    showNewCampaignModal() {
        const body = `
            <div class="form-group">
                <label>Nazwa kampanii</label>
                <input type="text" id="new-campaign-name" placeholder="np. Curse of Strahd">
            </div>
            <div class="form-group">
                <label>Opis</label>
                <textarea id="new-campaign-desc" placeholder="Krótki opis kampanii..."></textarea>
            </div>
            <div class="form-group">
                <label>Świat</label>
                <input type="text" id="new-campaign-world" placeholder="np. Forgotten Realms, Homebrew">
            </div>
            <div class="form-group">
                <label for="new-campaign-map">Mapa świata</label>
                <select id="new-campaign-map">
                    ${window.PANEL_PAKIET?.mapy?.world ? '<option value="default">Gotowa kraina (mapa dołączona do panelu)</option>' : ''}
                    <option value="parch">Pusty pergamin — narysuję swój świat</option>
                    <option value="own">Własny obraz — wybiorę plik</option>
                </select>
            </div>
        `;
        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-primary" onclick="App.createCampaign()">Utwórz kampanię</button>
        `;
        this.showModal('📜 Nowa Kampania', body, footer);
    },

    createCampaign() {
        const name = document.getElementById('new-campaign-name')?.value?.trim();
        const desc = document.getElementById('new-campaign-desc')?.value?.trim();
        const world = document.getElementById('new-campaign-world')?.value?.trim();

        if (!name) {
            this.showToast('Podaj nazwę kampanii', 'error');
            return;
        }

        const campaign = {
            id: StorageManager.generateId(),
            name,
            description: desc || '',
            world: world || '',
            createdAt: new Date().toISOString(),
            plotNotes: '',
            campaignNotes: ''
        };

        StorageManager.saveCampaign(campaign);
        StorageManager.setActiveCampaignId(campaign.id);
        const mapMode = document.getElementById('new-campaign-map')?.value || 'default';
        if (mapMode === 'parch' && window.Atlas?.setWorld) Atlas.setWorld(campaign.id, { ...Atlas.parchment(), parch: true, name: world || '' });

        this.loadCampaignSelector();
        document.getElementById('campaign-select').value = campaign.id;
        this.onCampaignChange();
        this.closeModal();
        this.showToast(`Kampania "${name}" utworzona!`, 'success');
        if (mapMode === 'own' && window.Atlas?.worldPicker) setTimeout(() => Atlas.worldPicker({ cId: campaign.id }), 350);
    },

    getActiveCampaignId() {
        return StorageManager.getActiveCampaignId();
    },

    getActiveCampaign() {
        const id = this.getActiveCampaignId();
        return id ? StorageManager.getCampaign(id) : null;
    },

    // ---- Dashboard ----
    updateDashboard() {
        const esc = (v) => this.esc(v);
        const campaignId = this.getActiveCampaignId();
        const campaign = this.getActiveCampaign();
        const hero = document.getElementById('dash-hero');
        const stats = document.getElementById('dash-stats');
        const set = (id, html) => { const el = document.getElementById(id); if (el) el.innerHTML = html; };
        const empty = (msg, icon = 'fa-feather') => `<div class="empty-state"><i class="fa-solid ${icon}"></i><span>${msg}</span></div>`;

        if (!campaign) {
            if (hero) hero.innerHTML = `
                <div class="dash-hero-main">
                    <div class="dash-eyebrow">Witaj, Mistrzu Gry</div>
                    <h2 class="dash-hero-title">Wybierz lub utwórz kampanię</h2>
                    <p class="dash-hero-desc">Kampania grupuje bohaterów, NPC, sesje, zadania i notatki.</p>
                </div>
                <div class="dash-hero-actions"><button class="btn-primary" onclick="App.showNewCampaignModal()"><i class="fa-solid fa-plus"></i> Nowa kampania</button></div>`;
            if (stats) stats.innerHTML = '';
            ['dash-party-content', 'dash-notes-content', 'dash-recent-content', 'dash-quests-content'].forEach(id => set(id, empty('Brak aktywnej kampanii')));
            return;
        }

        const sessions = StorageManager.getSessions(campaignId);
        const chars = StorageManager.getCharacters(campaignId);
        const npcs = StorageManager.getNPCs(campaignId);
        const quests = StorageManager.getQuests(campaignId);
        const notes = StorageManager.getNotes(campaignId);
        const activeQuests = quests.filter(q => !['Zaliczone', 'Odrzucone', 'Nieudane', 'Nieznane'].includes(q.status));
        const created = campaign.createdAt && !isNaN(new Date(campaign.createdAt)) ? new Date(campaign.createdAt).toLocaleDateString(window.LOC || 'pl-PL') : null;
        const inCombat = window.CombatModule && CombatModule.isActive && CombatModule.isActive();

        if (hero) hero.innerHTML = `
            <div class="dash-hero-main">
                <div class="dash-eyebrow">Aktywna kampania${campaign.world ? ` · <i class="fa-solid fa-earth-europe"></i> ${esc(campaign.world)}` : ''}</div>
                <h2 class="dash-hero-title">${esc(campaign.name)}</h2>
                ${campaign.description ? `<p class="dash-hero-desc">${esc(campaign.description)}</p>` : ''}
                ${created ? `<div class="dash-hero-meta"><i class="fa-regular fa-calendar"></i> Rozpoczęta ${created}</div>` : ''}
            </div>
            <div class="dash-hero-actions">
                <button class="btn-primary" data-action="new-session"><i class="fa-solid fa-plus"></i> Nowa sesja</button>
                <button class="btn-secondary" data-goto="combat"><i class="fa-solid fa-khanda"></i> ${inCombat ? 'Wróć do walki' : 'Walka'}</button>
                <button class="btn-secondary" data-action="new-note"><i class="fa-solid fa-pen"></i> Notatka</button>
            </div>`;

        if (stats) {
            const tile = (icon, value, label, tab, sub, accent) => `
                <button class="stat-tile" data-goto="${tab}" ${sub ? `data-subtab="${sub}"` : ''} style="--accent:${accent}">
                    <i class="fa-solid ${icon}"></i>
                    <span class="stat-value">${value}</span>
                    <span class="stat-label">${label}</span>
                </button>`;
            stats.innerHTML =
                tile('fa-hat-wizard', chars.length, 'Bohaterowie', 'characters', '', 'var(--sapphire)') +
                tile('fa-users', npcs.length, 'NPC', 'npcs', '', 'var(--emerald)') +
                tile('fa-calendar-days', sessions.length, 'Sesje', 'campaign', 'sessions', 'var(--gold)') +
                tile('fa-scroll', activeQuests.length, 'Aktywne zadania', 'campaign', 'quests', 'var(--crimson)');
        }

        // Party
        if (chars.length === 0) {
            set('dash-party-content', `${empty('Brak bohaterów w drużynie', 'fa-hat-wizard')}<button class="btn-secondary btn-small dash-empty-cta" onclick="CharactersModule.showAddCharacterModal()">+ Dodaj bohatera</button>`);
        } else {
            set('dash-party-content', chars.map(c => {
                const max = c.hp?.max || 0, cur = c.hp?.current || 0;
                const hpPct = max ? Math.max(0, Math.min(100, Math.round((cur / max) * 100))) : 100;
                const hpClass = hpPct > 50 ? 'hp-high' : hpPct > 25 ? 'hp-mid' : 'hp-low';
                const initials = (c.name || '?').split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
                return `<div class="party-row" data-char="${esc(c.id)}" tabindex="0" title="Otwórz kartę postaci">
                    <div class="party-avatar">${esc(initials)}${c.portrait && window.Portrait ? Portrait.img(c.portrait) : ''}</div>
                    <div class="party-info">
                        <div class="party-name">${esc(c.name)}</div>
                        <div class="party-meta">${esc(c.race || '')} ${esc(c.class || '')} · Poz. ${c.level || 1}${c.ac ? ` · <i class="fa-solid fa-shield-halved"></i> ${c.ac}` : ''}</div>
                    </div>
                    <div class="party-hp">
                        <div class="hp-bar"><div class="hp-bar-fill ${hpClass}" style="width:${hpPct}%"></div></div>
                        <div class="party-hp-text ${hpClass}">${cur}/${max}</div>
                    </div>
                </div>`;
            }).join(''));
        }

        // Quests
        if (activeQuests.length === 0) {
            set('dash-quests-content', empty(quests.length ? 'Wszystkie zadania zamknięte' : 'Brak zadań', 'fa-scroll'));
        } else {
            set('dash-quests-content', activeQuests.slice(0, 6).map(q => `
                <div class="quest-row">
                    <span class="quest-dot ${q.status === 'Przyjęte' ? 'accepted' : 'pending'}"></span>
                    <span class="quest-title">${esc(q.title || q.name || 'Zadanie')}</span>
                    <span class="quest-status">${esc(q.status === 'Przyjęte' ? 'w toku' : 'oczekuje')}</span>
                </div>`).join('') + (activeQuests.length > 6 ? `<div class="dash-more">…i ${activeQuests.length - 6} więcej</div>` : ''));
        }

        // Notes — tablica karteczek (przypinanie / chowanie / kolory)
        if (window.NotesModule && NotesModule.renderDashboard) NotesModule.renderDashboard(document.getElementById('dash-notes-content'));

        // Recent session
        if (sessions.length === 0) {
            set('dash-recent-content', `${empty('Brak sesji', 'fa-calendar-days')}<button class="btn-secondary btn-small dash-empty-cta" data-action="new-session">+ Zaplanuj pierwszą sesję</button>`);
        } else {
            const last = sessions[sessions.length - 1];
            const summary = last.summary || '';
            set('dash-recent-content', `
                <div class="recent-date">${esc(last.date || '')} · sesja ${sessions.length}</div>
                <div class="recent-title">${esc(last.title || 'Sesja')}</div>
                <div class="recent-summary">${esc(summary.substring(0, 320))}${summary.length > 320 ? '…' : ''}</div>`);
        }
    },

    // ---- Sidebar Actions ----
    bindSidebarActions() {
        const exportBtn = document.getElementById('btn-export-data');
        const importBtn = document.getElementById('btn-import-data');
        const importInput = document.getElementById('import-file-input');

        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportData());
        }

        if (importBtn) {
            importBtn.addEventListener('click', () => importInput?.click());
        }

        if (importInput) {
            importInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (!file) return;
                if (window.Enhancements && Enhancements.importFile) { Enhancements.importFile(file); importInput.value = ''; return; }
                const reader = new FileReader();
                reader.onload = (ev) => {
                    const success = StorageManager.importAll(ev.target.result);
                    if (success) {
                        this.showToast('Dane zaimportowane pomyślnie!', 'success');
                        this.loadCampaignSelector();
                        this.onCampaignChange();
                    } else {
                        this.showToast('Błąd importu danych', 'error');
                    }
                };
                reader.readAsText(file);
                importInput.value = '';
            });
        }
    },

    exportData() {
        const data = StorageManager.exportAll();
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `dm_panel_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        try { localStorage.setItem(StorageManager.PREFIX + 'last_export', JSON.stringify(Date.now())); } catch (e) {}
        if (window.Enhancements) Enhancements.renderBackupStatus();
        this.showToast('Kopia zapasowa zapisana!', 'success');
    },

    // ---- Modal System ----
    showModal(title, bodyHtml, footerHtml) {
        const backdrop = document.getElementById('modal-backdrop');
        const titleEl = document.getElementById('modal-title');
        const bodyEl = document.getElementById('modal-body');
        const footerEl = document.getElementById('modal-footer');
        const closeBtn = document.getElementById('modal-close');

        document.getElementById('modal')?.classList.remove('modal-wide', 'modal-ne');
        if (titleEl) titleEl.textContent = title;
        if (bodyEl) bodyEl.innerHTML = bodyHtml;
        if (footerEl) footerEl.innerHTML = footerHtml || '';
        if (backdrop) backdrop.classList.remove('hidden');

        // Focus first field for faster typing
        setTimeout(() => {
            const first = bodyEl && bodyEl.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea, select');
            if (first) first.focus();
        }, 60);

        if (closeBtn) {
            closeBtn.onclick = () => this.closeModal();
        }

        // Close on backdrop click
        if (backdrop) {
            backdrop.onclick = (e) => {
                if (e.target === backdrop) this.closeModal();
            };
        }

        // Close on Escape (remove stale handler first so they don't stack)
        if (this._modalEscHandler) document.removeEventListener('keydown', this._modalEscHandler);
        this._modalEscHandler = (e) => {
            if (e.key === 'Escape') this.closeModal();
        };
        document.addEventListener('keydown', this._modalEscHandler);
    },

    closeModal() {
        const backdrop = document.getElementById('modal-backdrop');
        if (backdrop) backdrop.classList.add('hidden');
        if (this._modalEscHandler) {
            document.removeEventListener('keydown', this._modalEscHandler);
            this._modalEscHandler = null;
        }
    },

    // ---- Toast Notifications ----
    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const icons = { success: 'fa-circle-check', error: 'fa-triangle-exclamation', info: 'fa-circle-info', warning: 'fa-circle-exclamation' };
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
        toast.innerHTML = `<i class="fa-solid ${icons[type] || icons.info} toast-icon"></i><span class="toast-msg"></span><button class="toast-close" aria-label="Zamknij">&times;</button>`;
        toast.querySelector('.toast-msg').textContent = message;
        const remove = () => { toast.classList.add('leaving'); setTimeout(() => toast.remove(), 250); };
        toast.querySelector('.toast-close').onclick = remove;
        container.appendChild(toast);
        // Keep the stack short
        while (container.children.length > 4) container.firstElementChild.remove();
        setTimeout(remove, type === 'error' ? 5000 : 3200);
    },

    esc(str) {
        return String(str ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Small delay to ensure all module scripts have loaded
    setTimeout(() => {
        App.registerModules();
        App.init();
    }, 100);
});
