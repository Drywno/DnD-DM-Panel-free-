/* ============================================
   D&D 5e DM Panel - Dice Roller (Pure CSS/SVG)
   ============================================ */

const DiceRoller = {
    history: [],
    isRolling: false,

    init() {
        this.history = StorageManager.getDiceHistory();
        this.bindEvents();
        this.renderHistory();
        this.injectCSS();
    },

    addToHistory(result) {
        const historyContainer = document.getElementById('dice-history');
        if (historyContainer) {
            const historyEntry = document.createElement('div');
            historyEntry.className = 'dice-history-entry';
            
            // Format individual rolls
            let rollDetails = '';
            if (result.rollGroups && result.rollGroups.length > 0) {
                rollDetails = result.rollGroups.map(g => {
                    if (g.rolls.length > 1) {
                        return `[${g.rolls.join(', ')}]`;
                    } else if (g.rolls.length === 1) {
                        return `[${g.rolls[0]}]`;
                    }
                    return '';
                }).filter(Boolean).join(' ');
            }

            const modText = result.modifier !== 0 ? (result.modifier > 0 ? ` +${result.modifier}` : ` ${result.modifier}`) : '';

            historyEntry.innerHTML = `
                <div>
                    <span class="roll-expr">${result.expression}</span>
                    <span class="roll-details">${rollDetails}${modText}</span>
                </div>
                <span class="roll-result ${result.isCritical ? 'roll-critical' : ''} ${result.isFumble ? 'roll-fumble' : ''}">${result.isCoin ? result.totalText : result.total}</span>
            `;
            
            historyContainer.prepend(historyEntry);
            
            // limit history length to 20
            while(historyContainer.children.length > 20) {
                historyContainer.removeChild(historyContainer.lastChild);
            }
        }
    },

    injectCSS() {
        if (!document.getElementById('dice-roller-styles')) {
            const style = document.createElement('style');
            style.id = 'dice-roller-styles';
            style.textContent = `
                .dice-overlay {
                    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
                    pointer-events: none; z-index: 9999;
                    display: flex; justify-content: center; align-items: center;
                    opacity: 0; transition: opacity 0.3s ease;
                    background: transparent;
                    transform: none !important; /* Override translate(-50%, -50%) from main.css */
                }
                .dice-overlay.show { opacity: 1; pointer-events: auto; }
                
                .dice-anim-container {
                    position: relative;
                    width: 200px; height: 200px;
                    display: flex; justify-content: center; align-items: center;
                }
                
                .dice-anim-svg {
                    width: 150px; height: 150px;
                    filter: drop-shadow(0 15px 25px rgba(0,0,0,0.4));
                    transform-origin: center center;
                    transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), filter 0.4s ease;
                }

                .dice-anim-container.rolling {
                    animation: diceThrow 1s cubic-bezier(0.28, 0.84, 0.42, 1) forwards;
                }

                .dice-anim-svg.rolling {
                    animation: diceSpin 1s cubic-bezier(0.25, 1, 0.5, 1) forwards;
                }

                .dice-anim-result-text {
                    position: absolute;
                    top: 50%; left: 50%;
                    transform: translate(-50%, -50%) scale(0);
                    font-size: 5rem; font-weight: 900;
                    color: #fff;
                    text-shadow: 0 0 20px var(--text-gold), 0 0 40px var(--text-gold);
                    opacity: 0;
                    pointer-events: none;
                }

                .dice-anim-result-text.show {
                    animation: resultPop 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
                }

                @keyframes diceThrow {
                    0% { transform: translateY(-400px) scale(0.3); opacity: 0; }
                    40% { transform: translateY(20px) scale(1); opacity: 1; }
                    60% { transform: translateY(-40px) scale(1); }
                    80% { transform: translateY(10px) scale(1); }
                    100% { transform: translateY(0) scale(1); opacity: 1; }
                }

                @keyframes diceSpin {
                    0% { transform: rotate(-1080deg); }
                    100% { transform: rotate(0deg); }
                }

                @keyframes resultPop {
                    0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
                    50% { transform: translate(-50%, -50%) scale(1.2); opacity: 1; }
                    100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
    },

    bindEvents() {
        document.querySelectorAll('.dice-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.dataset.coin) {
                    this.flipCoin();
                    return;
                }
                const dice = btn.dataset.dice;
                if (!dice) return;
                const sides = parseInt(dice.replace('d', ''));
                this.roll(1, sides);
            });
        });

        const rollBtn = document.getElementById('btn-roll-custom');
        const exprInput = document.getElementById('dice-expression');
        if (rollBtn) {
            rollBtn.addEventListener('click', () => {
                let expr = exprInput.value.trim();
                if (expr) {
                    const mode = document.querySelector('input[name="roll-mode"]:checked').value;
                    const modVal = parseInt(document.getElementById('dice-modifier').value) || 0;
                    if (modVal !== 0) expr += (modVal > 0 ? `+${modVal}` : `${modVal}`);
                    this.rollExpression(expr, mode);
                }
            });
        }
        if (exprInput) {
            exprInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    let expr = exprInput.value.trim();
                    if (expr) {
                        const mode = document.querySelector('input[name="roll-mode"]:checked').value;
                        const modVal = parseInt(document.getElementById('dice-modifier').value) || 0;
                        if (modVal !== 0) expr += (modVal > 0 ? `+${modVal}` : `${modVal}`);
                        this.rollExpression(expr, mode);
                    }
                }
            });
        }
    },

    flipCoin() {
        if (this.isRolling) return null;
        this.isRolling = true;
        const r = Math.floor(Math.random() * 2);
        const result = {
            expression: 'Rzut monet\u0105',
            isCoin: true,
            rolls: [r],
            rollGroups: [{ count: 1, sides: 2, rolls: [r], sum: r, sign: 1 }],
            modifier: 0,
            total: r,
            totalText: r === 1 ? 'Orze\u0142' : 'Reszka',
            timestamp: Date.now(),
            isCritical: r === 1,
            isFumble: r === 0
        };
        // moneta 3D (ta sama co u graczy); bez niej — dawna animacja 2D
        if (window.Coin3D) {
            Coin3D.flip(r === 1).then(() => { this._updateHistoryAndToast(result); this.addToHistory(result); }).finally(() => { this.isRolling = false; });
            return result;
        }
        this.animateRoll(result);
        return result;
    },

    async roll(count, sides) {
        const mode = document.querySelector('input[name="roll-mode"]:checked')?.value || 'normal';
        const modVal = parseInt(document.getElementById('dice-modifier')?.value, 10) || 0;
        const modStr = modVal === 0 ? '' : (modVal > 0 ? `+${modVal}` : `${modVal}`);
        return this.rollExpression(`${count}d${sides}${modStr}`, mode);
    },

    // Rozbiór wyrażenia: "1d20+1d4-2" → grupy kości + modyfikator
    parseExpr(expr) {
        const parts = String(expr).replace(/\s+/g, '').toLowerCase().split(/(?=[+-])/).filter(Boolean);
        if (!parts.length) throw new Error('Puste wyrażenie');
        const groups = []; let modifier = 0;
        for (let p of parts) {
            const sign = p[0] === '-' ? -1 : 1;
            if (p[0] === '+' || p[0] === '-') p = p.slice(1);
            if (p.includes('d') || p.includes('k')) {
                const [c, sd] = p.split(/[dk]/);
                const count = c ? parseInt(c, 10) : 1, sides = parseInt(sd, 10);
                if (isNaN(count) || isNaN(sides) || count < 1 || count > 100 || sides < 2) throw new Error('Błędny format rzutu (np. 1d20+3)');
                groups.push({ count, sides, sign });
            } else {
                const m = parseInt(p, 10);
                if (isNaN(m)) throw new Error('Błędny format rzutu (np. 1d20+3)');
                modifier += sign * m;
            }
        }
        if (!groups.length) throw new Error('Brak kości w wyrażeniu');
        return { groups, modifier };
    },

    /* Wspólna logika rzutu (2D i 3D).
       Ułatwienie / utrudnienie według zasad 5e:
       - jeśli w wyrażeniu jest k20 — rzucasz każdą k20 dwa razy i bierzesz wyższy/niższy wynik,
         pozostałe kości i modyfikator liczą się raz (np. 1d20+1d4+3),
       - jeśli k20 nie ma — całe wyrażenie rzucane dwa razy, liczy się lepsza/gorsza suma.
       roller(specs) → Promise<[[wartości], ...]> w tej samej kolejności co specs. */
    async computeRoll(expr, mode, roller) {
        const { groups, modifier } = this.parseExpr(expr);
        const adv = mode === 'advantage' || mode === 'disadvantage';
        const better = (a, b) => mode === 'advantage' ? a >= b : a <= b;
        const hasD20 = groups.some(g => g.sides === 20);
        const specs = [];
        if (!adv) groups.forEach((g, gi) => specs.push({ gi, set: 0, qty: g.count, sides: g.sides }));
        else if (hasD20) groups.forEach((g, gi) => { specs.push({ gi, set: 0, qty: g.count, sides: g.sides }); if (g.sides === 20) specs.push({ gi, set: 1, qty: g.count, sides: 20 }); });
        else [0, 1].forEach(set => groups.forEach((g, gi) => specs.push({ gi, set, qty: g.count, sides: g.sides })));

        const vals = await roller(specs);
        const get = (gi, set) => vals[specs.findIndex(sp => sp.gi === gi && sp.set === set)] || [];
        let rollGroups, altTotal = null;
        if (!adv) {
            rollGroups = groups.map((g, gi) => ({ ...g, rolls: get(gi, 0), dropped: [] }));
        } else if (hasD20) {
            rollGroups = groups.map((g, gi) => {
                if (g.sides !== 20) return { ...g, rolls: get(gi, 0), dropped: [] };
                const a = get(gi, 0), b = get(gi, 1), kept = [], dropped = [];
                a.forEach((x, k) => { const y = b[k]; if (better(x, y)) { kept.push(x); dropped.push(y); } else { kept.push(y); dropped.push(x); } });
                return { ...g, rolls: kept, dropped };
            });
        } else {
            const setTotal = (set) => groups.reduce((t, g, gi) => t + get(gi, set).reduce((a, b) => a + b, 0) * g.sign, 0);
            const t0 = setTotal(0), t1 = setTotal(1);
            const keep = better(t0, t1) ? 0 : 1;
            rollGroups = groups.map((g, gi) => ({ ...g, rolls: get(gi, keep), dropped: get(gi, 1 - keep) }));
            altTotal = (keep ? t0 : t1) + modifier;
        }
        rollGroups.forEach(g => { g.sum = g.rolls.reduce((a, b) => a + b, 0); });
        const total = rollGroups.reduce((t, g) => t + g.sum * g.sign, 0) + modifier;
        const d20s = rollGroups.filter(g => g.sides === 20);
        const singleD20 = d20s.length === 1 && d20s[0].count === 1;
        const label = mode === 'advantage' ? ' · ułatwienie' : mode === 'disadvantage' ? ' · utrudnienie' : '';
        return {
            expression: expr.replace(/\s+/g, '') + label,
            mode, rolls: rollGroups.flatMap(g => g.rolls), rollGroups, modifier, total, altTotal,
            timestamp: Date.now(),
            isCritical: singleD20 && d20s[0].rolls[0] === 20,
            isFumble: singleD20 && d20s[0].rolls[0] === 1
        };
    },

    // Opis rzutu do historii i zwoju, np. "[17 ~~4~~] +1d4 [3] +3"
    describe(result, html = true) {
        const strike = (v) => html ? `<s class="roll-dropped">${v}</s>` : `(${v})`;
        let out = result.rollGroups.map(g => {
            const kept = g.rolls.join(', ');
            const dropped = g.dropped && g.dropped.length ? ` ${g.dropped.map(strike).join(' ')}` : '';
            return `${g.sign < 0 ? '−' : ''}[${kept}${dropped}]`;
        }).join(' ');
        if (result.modifier) out += ` ${result.modifier > 0 ? '+' : '−'} ${Math.abs(result.modifier)}`;
        if (result.altTotal !== null && result.altTotal !== undefined) out += html ? ` <span class="roll-alt">(drugi rzut: ${result.altTotal})</span>` : ` (drugi rzut: ${result.altTotal})`;
        return out;
    },

    async rollExpression(expr, mode = 'normal', label = '') {
        if (this.isRolling) return null;
        this.isRolling = true;
        try {
            const result = await this.computeRoll(expr, mode, async (specs) =>
                specs.map(sp => Array.from({ length: sp.qty }, () => Math.floor(Math.random() * sp.sides) + 1)));
            if (label) result.label = String(label).slice(0, 90);
            this.animateRoll(result);
            return result;
        } catch (e) {
            console.error(e);
            this.isRolling = false;
            this.showError(e.message || 'Nieprawidłowe wyrażenie');
            return null;
        }
    },

    getDiceSVG(sides) {
        if (sides === 'coin') {
            return `<svg width="100%" height="100%" viewBox="0 0 100 100" style="filter: drop-shadow(0 15px 25px rgba(0,0,0,0.6));">
                <defs>
                    <linearGradient id="goldRimOuter" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#fff4b0"/>
                        <stop offset="30%" stop-color="#d4af37"/>
                        <stop offset="70%" stop-color="#aa7c11"/>
                        <stop offset="100%" stop-color="#fff4b0"/>
                    </linearGradient>
                    <radialGradient id="goldFace" cx="40%" cy="40%" r="60%">
                        <stop offset="0%" stop-color="#ffe373"/>
                        <stop offset="50%" stop-color="#d4af37"/>
                        <stop offset="100%" stop-color="#8a610c"/>
                    </radialGradient>
                    <linearGradient id="sunburstGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#e2bc43"/>
                        <stop offset="100%" stop-color="#91640a"/>
                    </linearGradient>
                </defs>
                
                <!-- Outer Rim Bevel -->
                <circle cx="50" cy="50" r="49" fill="#5c4104"/>
                <circle cx="50" cy="50" r="48" fill="url(#goldRimOuter)"/>
                <circle cx="50" cy="50" r="46.5" fill="#8a610c"/>
                <circle cx="50" cy="50" r="45" fill="url(#goldFace)"/>
                
                <!-- Milled Edge (Outer Rings) -->
                <circle cx="50" cy="50" r="43.5" fill="none" stroke="#fff4b0" stroke-width="1.5" stroke-dasharray="2,5" opacity="0.6"/>
                <circle cx="50" cy="50" r="43.5" fill="none" stroke="#5c4104" stroke-width="1.5" stroke-dasharray="2,5" stroke-dashoffset="1" opacity="0.6"/>

                <!-- Geometric Sunburst Background -->
                <!-- r=22.28 => Circ~140. Dash 3,7 => 10 => 14 rays -->
                <circle cx="50" cy="50" r="22.28" fill="none" stroke="url(#sunburstGrad)" stroke-width="32" stroke-dasharray="3,7" opacity="0.5"/>
                
                <!-- Inner Decorative Rings -->
                <circle cx="50" cy="50" r="39" fill="none" stroke="#5c4104" stroke-width="1"/>
                <circle cx="50" cy="50" r="38" fill="none" stroke="#ffe373" stroke-width="0.5" opacity="0.8"/>
                <circle cx="50" cy="50" r="7" fill="none" stroke="#5c4104" stroke-width="0.5" opacity="0.4"/>
                
                <!-- 4 Cardinal Diamonds -->
                <path d="M 50 6 L 53 10 L 50 14 L 47 10 Z" fill="#fff4b0" stroke="#8a610c" stroke-width="0.5"/>
                <path d="M 50 94 L 53 90 L 50 86 L 47 90 Z" fill="#fff4b0" stroke="#8a610c" stroke-width="0.5"/>
                <path d="M 6 50 L 10 47 L 14 50 L 10 53 Z" fill="#fff4b0" stroke="#8a610c" stroke-width="0.5"/>
                <path d="M 94 50 L 90 47 L 86 50 L 90 53 Z" fill="#fff4b0" stroke="#8a610c" stroke-width="0.5"/>

                <!-- Small intricate rivets between diamonds -->
                <circle cx="19" cy="19" r="1.5" fill="#5c4104"/><circle cx="18.5" cy="18.5" r="1" fill="#fff4b0"/>
                <circle cx="81" cy="19" r="1.5" fill="#5c4104"/><circle cx="80.5" cy="18.5" r="1" fill="#fff4b0"/>
                <circle cx="19" cy="81" r="1.5" fill="#5c4104"/><circle cx="18.5" cy="80.5" r="1" fill="#fff4b0"/>
                <circle cx="81" cy="81" r="1.5" fill="#5c4104"/><circle cx="80.5" cy="80.5" r="1" fill="#fff4b0"/>

                <!-- D&D Logo Shadow (3D effect) -->
                <text x="51.5" y="67.5" text-anchor="middle" font-family="'Font Awesome 6 Brands', sans-serif" font-weight="400" font-size="50" fill="#5c4104">&#xf38d;</text>
                <!-- D&D Logo Gold Face -->
                <text x="50" y="66" text-anchor="middle" font-family="'Font Awesome 6 Brands', sans-serif" font-weight="400" font-size="50" fill="url(#goldRimOuter)" stroke="#8a610c" stroke-width="1.5">&#xf38d;</text>
            </svg>`;
        }
        const props = 'width="100%" height="100%" viewBox="0 0 100 100" fill="rgba(30, 25, 20, 0.95)" stroke="var(--text-gold)" stroke-width="3" stroke-linejoin="round"';
        
        let fontSize = 28;
        if (sides === 100) fontSize = 20;

        const txt = `<text x="50" y="62" text-anchor="middle" font-family="sans-serif" font-size="${fontSize}" fill="#ffffff" stroke="rgba(0,0,0,0.8)" stroke-width="1" font-weight="bold">D${sides}</text>`;

        switch(sides) {
            case 4:
                return `<svg ${props}><polygon points="50,10 90,80 10,80" /><polygon points="50,10 50,80 10,80" fill="rgba(255,255,255,0.1)" stroke="none"/>${txt.replace('y="62"','y="68"')}</svg>`;
            case 6:
                return `<svg ${props}><rect x="15" y="15" width="70" height="70" rx="10" /><rect x="15" y="15" width="35" height="70" fill="rgba(255,255,255,0.1)" stroke="none"/>${txt}</svg>`;
            case 8:
                return `<svg ${props}><polygon points="50,10 90,50 50,90 10,50" /><polygon points="50,10 50,90 10,50" fill="rgba(255,255,255,0.1)" stroke="none"/>${txt}</svg>`;
            case 10:
                return `<svg ${props}>
                    <polygon points="50,5 95,45 50,95 5,45" />
                    <polygon points="50,5 5,45 50,60" fill="rgba(255,255,255,0.15)" stroke="none"/>
                    <polygon points="5,45 50,95 50,60" fill="rgba(0,0,0,0.2)" stroke="none"/>
                    <polygon points="50,5 95,45 50,60" fill="rgba(255,255,255,0.05)" stroke="none"/>
                    <polygon points="95,45 50,95 50,60" fill="rgba(0,0,0,0.4)" stroke="none"/>
                    <polyline points="50,5 50,60 50,95" fill="none" />
                    <polyline points="5,45 50,60 95,45" fill="none" />
                    ${txt.replace('y="62"', 'y="52"')}
                </svg>`;
            case 100:
                // Zocchihedron (sphere) representation for D100
                return `<svg ${props}>
                    <circle cx="50" cy="50" r="45" fill="rgba(30, 25, 20, 0.95)" />
                    <!-- Globe grid lines -->
                    <ellipse cx="50" cy="50" rx="45" ry="15" fill="none" stroke="var(--text-gold)" stroke-width="1.5" stroke-opacity="0.4"/>
                    <ellipse cx="50" cy="50" rx="15" ry="45" fill="none" stroke="var(--text-gold)" stroke-width="1.5" stroke-opacity="0.4"/>
                    <ellipse cx="50" cy="50" rx="45" ry="35" fill="none" stroke="var(--text-gold)" stroke-width="1" stroke-opacity="0.2"/>
                    <ellipse cx="50" cy="50" rx="35" ry="45" fill="none" stroke="var(--text-gold)" stroke-width="1" stroke-opacity="0.2"/>
                    <!-- 3D highlight -->
                    <circle cx="35" cy="30" r="15" fill="rgba(255,255,255,0.15)" stroke="none" filter="blur(2px)"/>
                    <!-- Outer border -->
                    <circle cx="50" cy="50" r="45" fill="none" stroke="var(--text-gold)" stroke-width="3"/>
                    ${txt}
                </svg>`;
            case 12:
                return `<svg ${props}><polygon points="50,10 90,35 75,85 25,85 10,35" /><polygon points="50,10 90,35 50,55" fill="rgba(255,255,255,0.1)" stroke="none"/>${txt}</svg>`;
            case 20:
                return `<svg ${props}>
                    <!-- Outline and Base -->
                    <polygon points="50,5 90,25 90,75 50,95 10,75 10,25" />
                    <!-- Left Side Shading -->
                    <polygon points="50,5 30,35 10,25" fill="rgba(255,255,255,0.15)" stroke="none"/>
                    <polygon points="10,25 30,35 10,75" fill="rgba(255,255,255,0.05)" stroke="none"/>
                    <polygon points="10,75 30,35 50,80" fill="rgba(0,0,0,0.1)" stroke="none"/>
                    <polygon points="10,75 50,80 50,95" fill="rgba(0,0,0,0.3)" stroke="none"/>
                    <!-- Right Side Shading -->
                    <polygon points="50,5 90,25 70,35" fill="rgba(255,255,255,0.25)" stroke="none"/>
                    <polygon points="90,25 90,75 70,35" fill="rgba(0,0,0,0.15)" stroke="none"/>
                    <polygon points="90,75 50,80 70,35" fill="rgba(0,0,0,0.25)" stroke="none"/>
                    <polygon points="90,75 50,95 50,80" fill="rgba(0,0,0,0.4)" stroke="none"/>
                    <!-- Top Center Shading -->
                    <polygon points="50,5 70,35 30,35" fill="rgba(255,255,255,0.3)" stroke="none"/>
                    <!-- Internal Lines -->
                    <polyline points="50,5 30,35 70,35 50,5" fill="none" />
                    <polyline points="30,35 50,80 70,35" fill="none" />
                    <line x1="10" y1="25" x2="30" y2="35" />
                    <line x1="90" y1="25" x2="70" y2="35" />
                    <line x1="10" y1="75" x2="30" y2="35" />
                    <line x1="90" y1="75" x2="70" y2="35" />
                    <line x1="10" y1="75" x2="50" y2="80" />
                    <line x1="90" y1="75" x2="50" y2="80" />
                    <line x1="50" y1="95" x2="50" y2="80" />
                    <!-- Text placement centered in the main triangle -->
                    ${txt.replace('y="62"', 'y="60"')}
                </svg>`;
            default:
                return `<svg ${props}><circle cx="50" cy="50" r="45"/><circle cx="50" cy="50" r="45" fill="url(#grad)" stroke="none"/>${txt}</svg>`;
        }
    },

    animateRoll(result) {
        this.isRolling = true;
        let overlay = document.getElementById('dice-overlay');
        
        const match = result.expression.match(/d(\d+)/i);
        let sides = match ? parseInt(match[1]) : 20;
        if (result.isCoin) sides = 'coin';
        const diceHtml = this.getDiceSVG(sides);

        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'dice-overlay';
            overlay.className = 'dice-overlay';
            document.body.appendChild(overlay);
        } else {
            // Remove any old inline styles that might be stuck from previous versions
            overlay.removeAttribute('style');
        }

        overlay.innerHTML = `
            <div class="dice-anim-container">
                <div class="dice-anim-svg" id="anim-svg">${diceHtml}</div>
                <div class="dice-anim-result-text" id="anim-res"></div>
            </div>
        `;

        const container = overlay.querySelector('.dice-anim-container');
        const icon = overlay.querySelector('#anim-svg');
        const resDiv = overlay.querySelector('#anim-res');

        overlay.classList.add('show');
        
        // Start throwing and spinning animation
        container.classList.add('rolling');
        icon.classList.add('rolling');

        // Stop spin and show result after 1 second
        setTimeout(() => {
            icon.classList.remove('rolling');
            icon.style.transform = 'scale(1.15)'; // Slightly larger when landed
            icon.style.filter = 'brightness(0.5) drop-shadow(0 20px 30px rgba(0,0,0,0.8))'; // darken dice
            
            resDiv.textContent = result.isCoin ? result.totalText : result.total;
            if (result.isCritical) resDiv.style.color = 'var(--gold-light)';
            if (result.isFumble) resDiv.style.color = 'var(--danger-color)';
            resDiv.classList.add('show');
            
            this._updateHistoryAndToast(result);
            this.addToHistory(result);

            setTimeout(() => {
                overlay.classList.remove('show');
                this.isRolling = false;
            }, 1800);
            
        }, 1000);
    },

    _updateHistoryAndToast(result) {
        const container = document.getElementById('dice-result');
        if (!container) return;

        let critClass = '';
        if (result.isCritical) critClass = 'roll-critical';
        else if (result.isFumble) critClass = 'roll-fumble';

        let critLabel = '';
        if (result.isCritical) critLabel = '<span style="color:var(--gold-light);font-size:0.75rem;">🌟 NATURAL 20!</span>';
        if (result.isFumble) critLabel = '<span style="color:var(--danger-color);font-size:0.75rem;">💀 KRYTYCZNA PORAŻKA!</span>';

        container.innerHTML = `
            <div class="result-value ${critClass}" style="${result.isCoin && result.isCritical ? 'color:var(--gold);' : (result.isCoin && result.isFumble ? 'color:#ddd;' : '')}">${result.isCoin ? result.totalText : result.total}</div>
            ${!result.isCoin && result.rollGroups ? `<div class="result-detail">${result.expression} ${this.describe(result)}</div>` : ''}
            ${critLabel && !result.isCoin ? `<div>${critLabel}</div>` : ''}
        `;
        
        container.style.animation = 'none';
        container.offsetHeight; 
        container.style.animation = 'pulse 0.3s ease-in-out';
    },

    addToHistory(result) {
        this.history.unshift(result);
        if (this.history.length > 50) this.history.pop();
        StorageManager.saveDiceHistory(this.history);
        this.renderHistory();
    },

    // Historia rzutów: moje (MG) + rzuty graczy z dziennika stołu, każdy w swoim kolorze
    renderHistory() {
        const box = document.getElementById('dice-history');
        if (!box) return;
        const esc = (v) => String(v ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
        const k = (v) => String(v || '').replace(/(\d*)d(\d+)/gi, '$1k$2');
        const chip = (v, sides, off) => `<span class="dh-ch ${off ? 'off' : ''} ${!off && sides === 20 && v === 20 ? 'max' : ''} ${!off && sides === 20 && v === 1 ? 'min' : ''}">${v}</span>`;
        const modTxt = (m) => m ? `<span class="dh-mod">${m > 0 ? '+' : '−'}${Math.abs(m)}</span>` : '';
        const local = this.history.map(r => {
            const exprRaw = String(r.expression || '').split(' · ')[0];
            const mode = r.mode === 'advantage' ? 'ułatwienie' : r.mode === 'disadvantage' ? 'utrudnienie' : '';
            const dice = r.isCoin ? '' : (r.rollGroups || []).map(g => `${g.sign < 0 ? '<span class="dh-mod">−</span>' : ''}${g.rolls.map(v => chip(v, g.sides)).join('')}${(g.dropped || []).map(v => chip(v, g.sides, true)).join('')}`).join('') + modTxt(r.modifier);
            return { t: r.timestamp || 0, who: 'MG', color: '#e9c46a', label: r.label || (r.isCoin ? 'Rzut monetą' : ''), expr: r.isCoin ? '' : k(exprRaw), mode, dice,
                total: r.isCoin ? r.totalText : r.total, crit: r.isCoin ? '' : r.isCritical ? 'max' : r.isFumble ? 'min' : '', mg: true, alt: r.altTotal };
        });
        const remote = (window.OnlineModule?.rolls?.() || []).map(e => {
            const r = e.rzut || {}; const coin = e.opis === 'Rzut monetą';
            const dice = coin ? '' : (r.parts || []).map(p => p.die ? `${p.sign < 0 ? '<span class="dh-mod">−</span>' : ''}${(p.rolls || []).map(v => chip(v, parseInt(String(p.die).split('k')[1], 10))).join('')}${p.dropped != null ? chip(p.dropped, 0, true) : ''}` : modTxt(p.mod)).join('');
            return { t: e.t || 0, who: e.postac || e.kto || '?', sub: e.postac ? e.kto : '', color: /^#[0-9a-f]{6}$/i.test(e.kolor || '') ? e.kolor : '#c9a35c', label: e.opis || '', expr: coin ? '' : k(r.expr),
                mode: r.mode === 'adv' ? 'ułatwienie' : r.mode === 'dis' ? 'utrudnienie' : '', dice, total: coin ? (r.total === 2 ? 'Orzeł' : 'Reszka') : r.total, crit: coin ? '' : r.crit || '', mg: e.rola === 'mg', secret: e.tylkoMG, av: e.av };
        });
        let f = 'all'; try { f = localStorage.getItem('dnd5e_dh_filter') || 'all'; } catch (e) {}
        const all = local.concat(remote).filter(x => f === 'all' || (f === 'mg' ? x.mg : !x.mg)).sort((a, b) => b.t - a.t).slice(0, 60);
        const players = remote.filter(x => !x.mg).length;
        const head = `<div class="dh-head"><span class="dh-title"><i class="fa-solid fa-clock-rotate-left"></i> Historia</span>
            <div class="dh-seg">${[['all', 'Wszystkie'], ['mg', 'Moje'], ['pl', `Gracze${players ? ` (${players})` : ''}`]].map(([id, l]) => `<button type="button" data-dhf="${id}" class="${f === id ? 'on' : ''}">${l}</button>`).join('')}</div>
            ${this.history.length ? '<button type="button" class="dh-clear" data-dh-clear title="Wyczyść moje rzuty"><i class="fa-solid fa-trash-can"></i></button>' : ''}</div>`;
        const today = new Date().toDateString();
        const when = (t) => { if (!t) return ''; const d = new Date(t); return (d.toDateString() === today ? '' : d.toLocaleDateString(window.LOC || 'pl-PL', { day: '2-digit', month: '2-digit' }) + ' ') + d.toLocaleTimeString(window.LOC || 'pl-PL', { hour: '2-digit', minute: '2-digit' }); };
        box.innerHTML = head + (all.length ? all.map(x => `<div class="dh-row ${x.crit ? 'c-' + x.crit : ''}" style="--who:${x.color}">
                <i class="dh-dot" title="${esc(x.sub ? `${x.who} (${x.sub})` : x.who)}">${esc(String(x.who).trim().charAt(0).toUpperCase())}${x.av && window.Portrait ? Portrait.img(Portrait.fromAv(x.av)) : ''}</i>
                <div class="dh-main">
                    <div class="dh-top"><b class="dh-who">${esc(x.who)}</b>${x.secret ? '<i class="fa-solid fa-eye-slash dh-sec" title="Ukryty przed graczami"></i>' : ''}<time>${when(x.t)}</time></div>
                    ${x.label ? `<div class="dh-lbl" title="${esc(x.label)}">${esc(x.label)}</div>` : ''}
                    ${x.expr || x.dice ? `<div class="dh-dice">${x.expr ? `<span class="dh-expr">${esc(x.expr)}</span>` : ''}${x.dice}${x.mode ? `<em class="dh-mode">${x.mode}</em>` : ''}${x.alt != null ? `<em class="dh-mode">drugi: ${x.alt}</em>` : ''}</div>` : ''}
                </div>
                <span class="dh-total">${esc(x.total)}</span>
            </div>`).join('') : '<p class="empty-state">Brak rzutów</p>');
        if (!box._dhBound) {
            box._dhBound = true;
            box.addEventListener('click', (e) => {
                const fb = e.target.closest('[data-dhf]');
                if (fb) { try { localStorage.setItem('dnd5e_dh_filter', fb.dataset.dhf); } catch (er) {} this.renderHistory(); return; }
                if (e.target.closest('[data-dh-clear]')) { this.history = []; StorageManager.saveDiceHistory(this.history); this.renderHistory(); }
            });
            window.addEventListener('panel-log', () => this.renderHistory());
        }
    },

    showError(msg) {
        const container = document.getElementById('dice-result');
        if (container) {
            container.innerHTML = `<div style="color:var(--danger-color);font-size:1rem;margin-top:10px;">${msg}</div>`;
        }
    }
};

window.DiceRoller = DiceRoller;