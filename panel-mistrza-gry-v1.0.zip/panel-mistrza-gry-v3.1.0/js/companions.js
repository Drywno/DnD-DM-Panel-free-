/* ============================================
   Towarzysze: NPC dołączeni do drużyny.
   npc.party = { charId: id bohatera, który go prowadzi | null (idzie osobno), hp: bieżące PW }
   - w walce żetonem rusza gracz tego bohatera (w turze NPC),
   - gracz widzi kartę, ekwipunek i zdolności swojego towarzysza,
   - na mapach idzie krok za swoim bohaterem (albo osobno, gdy nikt go nie prowadzi).
   ============================================ */
const Companions = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const cid = () => App.getActiveCampaignId();
    const npcs = () => (cid() ? StorageManager.getNPCs(cid()) || [] : []);
    const chars = () => (cid() ? StorageManager.getCharacters(cid()) || [] : []);
    const mod = (v) => Math.floor(((parseInt(v, 10) || 10) - 10) / 2);
    const SIZE_N = { Tiny: 1, Small: 1, Medium: 1, Large: 2, Huge: 3, Gargantuan: 4 };
    const combatId = (npcId) => `npc-${npcId}-druzyna`;

    const list = () => npcs().filter(n => n.party && typeof n.party === 'object');
    const ownerName = (charId) => (chars().find(c => c.id === charId) || {}).name || '';

    function save(npcId, fn) {
        const n = npcs().find(x => x.id === npcId); if (!n) return null;
        fn(n);
        StorageManager.saveNPC(cid(), n);
        refresh();
        return n;
    }
    function refresh() {
        try { window.PartyModule?.render?.(); } catch (e) {}
        try { if (document.getElementById('npc-detail') && !document.getElementById('npc-detail').classList.contains('hidden')) { const id = document.querySelector('#npcs-list .sel')?.dataset.npc; if (id) NPCsModule.showDetail(id); } } catch (e) {}
        try { if (App.currentTab === 'campaign' && window.Atlas?.refresh) Atlas.refresh(); } catch (e) {}
    }

    // okno: do drużyny / zmiana prowadzącego
    function join(npcId) {
        const n = npcs().find(x => x.id === npcId); if (!n) return;
        const cs = chars();
        const cur = n.party ? n.party.charId || '' : (cs[0]?.id || '');
        App.showModal(n.party ? `Towarzysz: ${n.name}` : `Do drużyny: ${n.name}`, `
            <p class="modal-hint">Towarzysz idzie z drużyną po mapach i walczy po jej stronie. Gracz bohatera, który go prowadzi, rusza jego żetonem w turze NPC i widzi jego kartę, ekwipunek i zdolności.</p>
            <label class="ne-f"><span>Kto go prowadzi</span><select id="cmp-owner">
                ${cs.map(c => `<option value="${esc(c.id)}" ${cur === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
                <option value="" ${n.party && !n.party.charId ? 'selected' : ''}>Nikt — idzie osobno (rusza nim MG)</option>
            </select></label>
            ${n.hasStats ? '' : '<p class="modal-hint" style="color:#e8b24a"><i class="fa-solid fa-triangle-exclamation"></i> Ten NPC nie ma statystyk — w walce nie dostanie żetonu. Dodaj je w edycji NPC.</p>'}`,
            `${n.party ? '<button class="btn-danger" id="cmp-leave"><i class="fa-solid fa-person-walking-arrow-right"></i> Odchodzi z drużyny</button>' : ''}<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="cmp-ok"><i class="fa-solid fa-people-group"></i> ${n.party ? 'Zapisz' : 'Dołącz'}</button>`);
        document.getElementById('cmp-ok').onclick = () => {
            const owner = document.getElementById('cmp-owner').value || null;
            save(npcId, (x) => { x.party = { ...(x.party || {}), charId: owner, since: x.party?.since || Date.now() }; if (x.party.hp == null && x.stats) x.party.hp = parseInt(x.stats.hp, 10) || 10; });
            App.closeModal();
            App.showToast(owner ? `${n.name} dołącza do drużyny — prowadzi: ${ownerName(owner)}` : `${n.name} dołącza do drużyny (idzie osobno)`, 'success');
        };
        const lv = document.getElementById('cmp-leave');
        if (lv) lv.onclick = () => leave(npcId);
    }
    async function leave(npcId) {
        const n = npcs().find(x => x.id === npcId); if (!n) return;
        App.closeModal();
        if (!await Ask.confirm('NPC zostaje tam, gdzie jest — możesz go potem znów przyjąć.', { title: `${n.name} odchodzi z drużyny?`, ok: 'Odchodzi' })) return;
        save(npcId, (x) => { delete x.party; });
        App.showToast(`${n.name} nie jest już w drużynie`, 'info');
    }
    function setOwner(npcId, charId) {
        save(npcId, (x) => { if (x.party) x.party.charId = charId || null; });
    }

    // uczestnicy walki (PW pamiętane między walkami)
    function combatants() {
        return list().filter(n => n.hasStats && n.stats).map(n => {
            const st = n.stats, max = parseInt(st.hp, 10) || 10, ib = mod(st.dex) + (parseInt(st.initBonus, 10) || 0);
            const hp = Math.max(0, Math.min(max, n.party.hp ?? max));
            return { id: combatId(n.id), name: n.name, type: 'npc', disp: 'friendly', npcId: n.id, ctrl: n.party.charId || null,
                ac: parseInt(st.ac, 10) || 10, hp, maxHp: max, initiative: Math.floor(Math.random() * 20) + 1 + ib,
                dexMod: mod(st.dex), speed: parseInt(st.speeds?.walk ?? st.speed, 10) || 30, size: SIZE_N[st.size] || 1 };
        });
    }
    function syncHp(c) {
        if (!c || !c.npcId || !String(c.id).endsWith('-druzyna')) return;
        const all = npcs(), n = all.find(x => x.id === c.npcId);
        if (!n || !n.party || n.party.hp === c.hp) return;
        n.party.hp = c.hp;
        StorageManager.set(`npcs_${cid()}`, all);
    }

    // sekcja w panelu drużyny
    function sectionHTML() {
        const L = list(); const cs = chars();
        return `<div class="cmp-sec">
            <div class="cmp-h"><i class="fa-solid fa-handshake-angle"></i><b>Towarzysze (NPC w drużynie)</b><small>${L.length ? `${L.length}` : 'brak — dołącz NPC z zakładki „NPC i wrogowie”'}</small></div>
            ${L.length ? `<div class="cmp-list">${L.map(n => {
                const max = parseInt(n.stats?.hp, 10) || 0, hp = n.party.hp ?? max;
                return `<div class="cmp-row">
                    <span class="cmp-seal"><i class="fa-solid fa-user-shield"></i></span>
                    <div class="cmp-id"><b>${esc(n.name)}</b><small>${esc([n.role, n.race].filter(Boolean).join(' · ') || 'NPC')}${n.hasStats ? ` · KP ${n.stats.ac} · ${hp}/${max} PW` : ' · bez statystyk'}</small></div>
                    <label class="cmp-own"><span>Prowadzi</span><select data-comp-owner="${esc(n.id)}">${cs.map(c => `<option value="${esc(c.id)}" ${n.party.charId === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}<option value="" ${!n.party.charId ? 'selected' : ''}>nikt (osobno)</option></select></label>
                    <button class="btn-icon" data-comp-sheet="${esc(n.id)}" title="Karta NPC"><i class="fa-solid fa-scroll"></i></button>
                    <button class="btn-icon btn-danger" data-comp-leave="${esc(n.id)}" title="Odchodzi z drużyny"><i class="fa-solid fa-person-walking-arrow-right"></i></button>
                </div>`;
            }).join('')}</div>` : ''}
        </div>`;
    }
    function onClick(e) {
        const s = e.target.closest('[data-comp-sheet]'); if (s) { NPCsModule.showSheet(s.dataset.compSheet); return true; }
        const l = e.target.closest('[data-comp-leave]'); if (l) { leave(l.dataset.compLeave); return true; }
        return false;
    }
    function onChange(e) {
        const o = e.target.closest('[data-comp-owner]'); if (!o) return false;
        setOwner(o.dataset.compOwner, o.value);
        App.showToast(o.value ? `Prowadzi: ${ownerName(o.value)}` : 'Towarzysz idzie osobno', 'info');
        return true;
    }
    // dla map: [{ id, name, owner, size }]
    const forMaps = () => list().map(n => ({ id: n.id, name: n.name, owner: n.party.charId || null, size: SIZE_N[n.stats?.size] || 1, hp: n.stats ? { current: n.party.hp ?? (parseInt(n.stats.hp, 10) || 0), max: parseInt(n.stats.hp, 10) || 0 } : null }));

    return { list, join, leave, setOwner, combatants, combatId, syncHp, sectionHTML, onClick, onChange, forMaps };
})();
window.Companions = Companions;
