/* ============================================
   D&D 5e — Widok gracza
   Własna karta postaci, drużyna, mapa, walka, zadania,
   dziennik stołu i kości. Dane przychodzą z serwera MG.
   ============================================ */
const Player = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const qs = new URLSearchParams(location.search);
    const JAKO = qs.get('jako');                          // podgląd MG
    const H = { 'Content-Type': 'application/json', 'X-Panel': '1' };
    const $ = (s, r = document) => r.querySelector(s);
    const mod = (s) => Math.floor(((+s || 10) - 10) / 2);
    const sign = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);
    const profOf = (lvl) => Math.ceil((lvl || 1) / 4) + 1;
    const AB = ['STR', 'DEX', 'CON', 'INT', 'WIS', 'CHA'];
    const AB_PL = { STR: 'Siła', DEX: 'Zręczność', CON: 'Kondycja', INT: 'Inteligencja', WIS: 'Mądrość', CHA: 'Charyzma' };
    const AB_SHORT = { STR: 'SIŁ', DEX: 'ZRĘ', CON: 'KON', INT: 'INT', WIS: 'MDR', CHA: 'CHA' };
    const SKILL_EN = { 'Acrobatics': 'Akrobatyka', 'Animal Handling': 'Opieka nad zwierzętami', 'Arcana': 'Wiedza mistyczna', 'Athletics': 'Atletyka', 'Deception': 'Oszustwo', 'History': 'Historia', 'Insight': 'Wgląd', 'Intimidation': 'Zastraszanie', 'Investigation': 'Śledztwo', 'Medicine': 'Medycyna', 'Nature': 'Natura', 'Perception': 'Percepcja', 'Performance': 'Występy', 'Persuasion': 'Perswazja', 'Religion': 'Religia', 'Sleight of Hand': 'Zwinne dłonie', 'Stealth': 'Skradanie', 'Survival': 'Sztuka przetrwania' };
    const BUILTIN = { world: { name: 'Mapa świata', url: 'assets/pergamin.jpg' }, ...((window.PANEL_PAKIET && window.PANEL_PAKIET.mapy) || {}) };
    const DEFAULT_SUBMAP = 'assets/oak_table_texture_1789741203855.jpg';
    const STATUS = { 'Brak': ['Do wzięcia', 'open'], 'Przyjęte': ['W trakcie', 'active'], 'Zaliczone': ['Wykonane', 'done'], 'Nieudane': ['Nieudane', 'failed'], 'Odrzucone': ['Odrzucone', 'rejected'] };
    const QTYPE = { main: ['Zadanie główne', 'fa-crown'], side: ['Zlecenie', 'fa-scroll'], personal: ['Sprawa osobista', 'fa-feather'], bounty: ['List gończy', 'fa-skull'] };
    const COND_DESC = { Oslepienie: 'Nic nie widzi. Ataki w nią — ułatwienie, jej ataki — utrudnienie.', Zauroczenie: 'Nie zaatakuje zauroczyciela.', Gluchota: 'Nic nie słyszy.',
        Przerazenie: 'Utrudnienie w atakach i testach, gdy widzi źródło strachu; nie zbliży się do niego.', Pochwycenie: 'Szybkość 0.', Obezwladnienie: 'Brak akcji i reakcji.',
        Niewidzialnosc: 'Ataki w nią — utrudnienie, jej ataki — ułatwienie.', Paraliz: 'Brak akcji i ruchu. Trafienie z 5 stóp jest krytyczne.', Spetryfikowanie: 'Zamieniona w kamień.',
        Zatrucie: 'Utrudnienie w atakach i testach cech.', Lezenie: 'Ataki w nią z 5 stóp — ułatwienie, z dalszej odległości — utrudnienie. Jej ataki — utrudnienie. Wstanie kosztuje połowę szybkości.',
        Skrepowanie: 'Szybkość 0. Ataki w nią — ułatwienie, jej ataki — utrudnienie.', Ogluszenie: 'Brak akcji i ruchu. Ataki w nią — ułatwienie.',
        Nieprzytomnosc: 'Leży bez ruchu. Trafienie z 5 stóp jest krytyczne.', Zmeczenie: 'Poziomy wyczerpania.', Koncentracja: 'Podtrzymuje czar — obrażenia wymagają rzutu obronnego Kondycji.' };
    const COND_PL = { Oslepienie: 'Oślepienie', Gluchota: 'Głuchota', Przerazenie: 'Przerażenie', Obezwladnienie: 'Obezwładnienie', Niewidzialnosc: 'Niewidzialność', Paraliz: 'Paraliż', Lezenie: 'Leżenie', Skrepowanie: 'Skrępowanie', Ogluszenie: 'Ogłuszenie', Nieprzytomnosc: 'Nieprzytomność', Zmeczenie: 'Zmęczenie' };
    // zakładki jak w panelu MG: [ikona, nazwa, grupa w menu]
    const TABS = { postac: ['fa-user-shield', 'Moja postać', 'Bohater'], druzyna: ['fa-people-group', 'Drużyna', 'Bohater'], mapa: ['fa-map', 'Mapa', 'Graj'], walka: ['fa-khanda', 'Walka', 'Graj'], stol: ['fa-dice', 'Stół do gier', 'Graj'], czat: ['fa-comments', 'Czat i rzuty', 'Graj'], zadania: ['fa-scroll', 'Tablica ogłoszeń', 'Kampania'], spells: ['fa-wand-magic-sparkles', 'Magia', 'Kompendium'], equipment: ['fa-box-open', 'Ekwipunek', 'Kompendium'], bestiary: ['fa-dragon', 'Bestiariusz', 'Kompendium'], rules: ['fa-book', 'Zasady', 'Kompendium'] };
    const OWN = ['postac', 'spells', 'equipment', 'bestiary', 'rules'];          // te zakładki mają własne sekcje z modułami MG

    let V = null, me = null, log = [], es = null, connected = false;
    const ui = { tab: (t => t === 'wiedza' ? 'bestiary' : TABS[t] ? t : 'postac')(localStorage.getItem('pl_tab')), mode: null, map: null, level: {}, z: {}, sec: JSON.parse(localStorage.getItem('pl_sec') || '{}'), liveSeen: localStorage.getItem('pl_live') || '', lastTurn: null, unread: 0, qview: localStorage.getItem('pl_qview') || (innerWidth <= 760 ? 'lista' : 'tablica'), stol: localStorage.getItem('pl_stol') || 'czat', mgOnline: null, gwait: false, ghist: false, minis: localStorage.getItem('pl_minis') !== '0', follow: localStorage.getItem('pl_follow') !== '0', mapPing: false, wiedza: localStorage.getItem('pl_wiedza') || 'bestia', rcat: 'all', rq: '', bq: '', bcr: '' };
    const app = () => document.getElementById('pl-app');

    // ---------- sieć ----------
    async function api(path, body) {
        const r = await fetch(path, body ? { method: 'POST', headers: H, body: JSON.stringify(body), cache: 'no-store' } : { cache: 'no-store' });
        if (r.status === 401) { const j = await r.json().catch(() => ({})); location.href = j.sesja ? '/logowanie?blad=sesja' : '/logowanie'; throw new Error('Zaloguj się ponownie.'); }
        const j = await r.json().catch(() => ({}));
        if (!r.ok || j.ok === false) throw new Error(j.error || `Serwer odpowiedział ${r.status}`);
        return j;
    }
    let loading = null, again = false;
    async function load() {
        if (loading) { again = true; return loading; }
        loading = (async () => {
            try {
                const prev = V;
                V = await api(`/api/gracz/stan${JAKO ? `?jako=${encodeURIComponent(JAKO)}` : ''}`);
                // zmiana z karty jeszcze leci do serwera — nie cofaj jej na ekranie
                if (kartaBusy && prev?.character && V.character && prev.character.id === V.character.id) V.character = prev.character;
                onData(prev);
            } catch (e) { if (!V) fatal(e.message); }
        })();
        await loading; loading = null;
        if (again) { again = false; load(); }
    }
    function connect() {
        if (es) es.close();
        es = new EventSource('/api/events');
        es.addEventListener('hello', (e) => { connected = true; try { ui.mgOnline = !!JSON.parse(e.data).online?.mg; } catch (er) {} dot(); });
        es.addEventListener('stan', () => load());
        es.addEventListener('nastroj', (e) => { try { window.Nastroj?.apply(JSON.parse(e.data)); } catch (er) {} });
        es.addEventListener('ops', () => { if (JAKO) load(); });
        es.addEventListener('online', (e) => { if (V) { const d = JSON.parse(e.data); V.online = d.gracze || []; const mg = !!d.mg; const ch = mg !== ui.mgOnline; ui.mgOnline = mg; if (ui.tab === 'druzyna' || (ch && ui.tab === 'stol')) render(); } });
        es.addEventListener('log', (e) => {
            const entry = JSON.parse(e.data);
            log.push(entry); if (log.length > 200) log = log.slice(-200);
            if (ui.tab === 'czat') renderLog(); else if (entry.pid !== V?.player?.id) { ui.unread++; tabsBadges(); }
            if (diceOpen()) diceHistory();
            if (entry.pid !== V?.player?.id && entry.typ === 'rzut' && entry.rola === 'mg') toast(`${entry.szept ? '🤫 Mistrz Gry (tylko dla ciebie)' : '🎲 Mistrz Gry'}: ${entry.opis ? entry.opis + ' — ' : ''}${entry.rzut.total}`);
            else if (entry.pid !== V?.player?.id && entry.typ === 'wiad') toast(entry.szept ? `🤫 Mistrz Gry (tylko do ciebie): ${entry.tekst}` : `💬 ${entry.kto}: ${entry.tekst}`);
        });
        es.addEventListener('scena', (e) => {
            const d = JSON.parse(e.data); if (!V) return;
            const prev = V.scena; V.scena = d;
            const moved = !prev || prev.mapId !== d.mapId || prev.levelId !== d.levelId;
            if (!moved || !d.mapId) { if (ui.tab === 'mapa') render(); return; }
            if (ui.tab === 'mapa') mapTransition(prev, d);
            else { ui.mapPing = true; ui.banner = true; tabsBadges(); try { navigator.vibrate?.(40); } catch (er) {} }
        });
        es.addEventListener('ping', (e) => {
            const p = JSON.parse(e.data); if (!V) return;
            const board = $('#pl-map'), G = ui.geo, shown = $('#pl-mapname')?.dataset.map;
            if (ui.tab === 'mapa' && board && shown === p.mapId && (!p.levelId || !G || G.levelId === p.levelId)) { MapEmblems.ping(board, p); try { navigator.vibrate?.(25); } catch (er) {} }
            else if (p.pid !== V.player.id) { ui.mapPing = true; tabsBadges(); toast(`${p.kto} wskazuje coś na mapie`); }
        });
        es.addEventListener('live', (e) => { const d = JSON.parse(e.data); if (V) { V.live = d.clear ? null : d; if (d.board) { V.tablica = d.board; if (ui.tab === 'zadania') render(); } showLive(); } });
        // ktoś wszedł na to konto na innym urządzeniu — to okno zostaje wylogowane
        es.addEventListener('wylogowano', () => { try { es.close(); } catch (er) {} es = null; location.replace('/logowanie?blad=sesja'); });
        es.onerror = () => { connected = false; dot(); };
    }
    async function act(body, optimistic) {
        if (JAKO) { toast('To tylko podgląd Mistrza Gry — zmiany robi gracz.'); return false; }
        if (optimistic) { optimistic(); render(); }
        try { await api('/api/gracz/akcja', body); return true; }
        catch (e) { toast(e.message, 'bad'); load(); return false; }
    }
    // ---------- kości 3D: ta sama biblioteka, blat i zwój z wynikiem co u Mistrza Gry ----------
    const D3 = (() => {
        const COLORS = [['krew', '#8b1a1a', '#d9b25f', 'Krwisty'], ['kosc', '#e8dcc0', '#8b1a1a', 'Kość słoniowa'], ['szmaragd', '#1f6b45', '#d9b25f', 'Szmaragd'], ['szafir', '#1f3f7a', '#e8dcc0', 'Szafir'], ['obsydian', '#1b1714', '#c9a35c', 'Obsydian'], ['zloto', '#b8892e', '#1b1714', 'Złoto'], ['ametyst', '#5a2a7a', '#e8dcc0', 'Ametyst']];
        const SUP = [4, 6, 8, 10, 12, 20, 100];
        let box = null, initP = null, failed = false, busy = false, hideT = null, tray = null, resEl = null;
        const col = () => COLORS.find(c => c[0] === localStorage.getItem('pl_dcolor')) || COLORS[0];
        const on = () => localStorage.getItem('pl_d3') !== '0';
        const ok = () => on() && !failed && location.protocol !== 'file:' && typeof DiceBoxModule !== 'undefined';
        const canvas = () => document.getElementById('dice-canvas-3d');
        function init() {
            if (initP) return initP;
            const DiceBox = DiceBoxModule.default;
            box = new DiceBox({ container: '#dice-box-container', id: 'dice-canvas-3d', origin: new URL('.', location.href).href.replace(/\/$/, ''), assetPath: '/assets/dice-box/', theme: 'default', themeColor: col()[1],
                scale: 5.5, gravity: 1.6, mass: 1, friction: 0.8, restitution: 0.1, linearDamping: 0.5, angularDamping: 0.4, spinForce: 5, throwForce: 4.8, startingHeight: 6, settleTimeout: 5000, delay: 10,
                lightIntensity: 1.1, shadowTransparency: 0.6, enableShadows: true, offscreen: true });
            initP = Promise.race([box.init(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 30000))])
                .then(() => { box.hide('dice-hidden'); return box; })
                .catch(e => { failed = true; console.warn('[kości 3D]', e); throw e; })
                .finally(() => dicePanelSettings());
            return initP;
        }
        // blat i zwój z wynikiem — te same elementy i style co w panelu MG
        function build() {
            tray = document.createElement('div'); tray.id = 'dice-tray'; tray.className = 'dice-tray';
            tray.innerHTML = '<div class="dice-tray-felt"></div><div class="dice-tray-hint">kliknij, aby zabrać kości</div>';
            document.body.appendChild(tray);
            resEl = document.createElement('div'); resEl.className = 'dice-tray-result'; resEl.setAttribute('aria-live', 'polite');
            document.body.appendChild(resEl);
            resEl.addEventListener('mousedown', () => { if (!busy) hide(); });
            document.addEventListener('mousedown', (e) => { if (!busy && tray.classList.contains('show') && !e.target.closest('#dice-fab, #dice-roller')) hide(); }, true);
            document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && tray.classList.contains('show') && !busy) hide(); }, true);
        }
        function showTray() {
            if (!tray) build();
            clearTimeout(hideT);
            resEl.className = 'dice-tray-result'; resEl.innerHTML = '';
            tray.classList.add('show');
            canvas()?.classList.remove('fading', 'dice-hidden');
            document.body.classList.add('dice-rolling');
            box.show(); box.clear();
        }
        function hide() {
            clearTimeout(hideT);
            if (!tray) return;
            tray.classList.remove('show'); document.body.classList.remove('dice-rolling');
            resEl?.classList.remove('show');
            const c = canvas(); c?.classList.add('fading');
            setTimeout(() => { if (!tray.classList.contains('show') && box) { box.clear(); box.hide('dice-hidden'); c?.classList.remove('fading'); } }, 350);
        }
        function result(html, cls, ms) {
            if (!resEl) build();
            resEl.innerHTML = html;
            resEl.className = `dice-tray-result show ${cls || ''}`;
            clearTimeout(hideT); hideT = setTimeout(hide, ms);
        }
        // grupy kości w kolejności z wyrażenia (k20 z ułatwieniem = dwie k20)
        function groupsOf(wyr, tryb) {
            const src = String(wyr || '').toLowerCase().replace(/\s+/g, '').replace(/k/g, 'd');
            const terms = src.match(/[+-]?(\d*d\d+|\d+)/g) || [];
            const gs = [];
            for (const t of terms) {
                const body = t.replace(/^[+-]/, ''); if (!body.includes('d')) continue;
                let [n, s] = body.split('d').map(Number); n = n || 1;
                if (!SUP.includes(s)) return null;
                gs.push({ qty: n === 1 && s === 20 && (tryb === 'adv' || tryb === 'dis') ? 2 : n, sides: s });
            }
            return gs.length && gs.reduce((a, g) => a + g.qty, 0) <= 15 ? gs : null;
        }
        async function roll(groups) {
            await init();
            if (busy) throw new Error('busy');
            busy = true;
            showTray();
            try {
                const [main, alt] = [col()[1], col()[2]];
                const res = await Promise.race([box.roll(groups.map((g, i) => ({ qty: g.qty, sides: g.sides, themeColor: i % 2 ? alt : main }))),
                    new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 20000))]);
                const by = {};
                res.forEach(r => { (by[r.groupId] = by[r.groupId] || []).push(r.value === 0 && r.sides === 100 ? 100 : r.value); });
                return Object.keys(by).map(Number).sort((a, b) => a - b).map(k => by[k]);
            } catch (e) { hide(); throw e; }
            finally { busy = false; }
        }
        const warm = () => { if (ok()) { const go = () => init().catch(() => {}); 'requestIdleCallback' in window ? requestIdleCallback(go, { timeout: 5000 }) : setTimeout(go, 2000); } };
        return { ok, on, roll, groupsOf, hide, result, warm, COLORS, col, failed: () => failed,
            setOn: (v) => { localStorage.setItem('pl_d3', v ? '1' : '0'); if (v) warm(); },
            setColor: (id) => { localStorage.setItem('pl_dcolor', id); try { box?.updateConfig({ themeColor: col()[1] }); } catch (e) {} } };
    })();
    // opis rzutu jak w historii MG: 1k20 [17 / 4] +3
    const rollDetail = (r) => r.parts.map(p => p.die ? `${p.sign < 0 ? '− ' : ''}${esc(p.die)} [${p.rolls.join(', ')}${p.dropped != null ? ` <s>${p.dropped}</s>` : ''}]` : `${p.mod < 0 ? '−' : '+'} ${Math.abs(p.mod)}`).join(' ');
    const isCoin = (e) => e.opis === 'Rzut monetą';
    const coinText = (e) => e.rzut.total === 2 ? 'Orzeł' : 'Reszka';
    // wynik na zwoju (same kości leżą na stole)
    function show3DResult(e) {
        const r = e.rzut;
        D3.result(`<div class="dtr-expr">${esc(e.opis ? `${e.opis} · ${r.expr}` : r.expr)}${r.mode === 'adv' ? ' · ułatwienie' : r.mode === 'dis' ? ' · utrudnienie' : ''}</div>
            <div class="dtr-total">${isCoin(e) ? coinText(e) : r.total}</div>
            <div class="dtr-detail">${rollDetail(r)}</div>
            ${r.crit === 'max' ? '<div class="dtr-flag crit">Naturalna 20!</div>' : r.crit === 'min' ? '<div class="dtr-flag fumble">Krytyczna porażka</div>' : ''}`,
            r.crit === 'max' ? 'crit' : r.crit === 'min' ? 'fumble' : '', r.crit ? 4500 : 3200);
        try { navigator.vibrate?.(r.crit ? [40, 60, 40] : 30); } catch (er) {}
    }
    // jeden rzut gracza: kości 3D na jego ekranie (wynik z fizyki zapisuje serwer), a gdy 3D nie działa — losuje serwer
    async function rollEntry(wyr, opis, tryb, extra) {
        extra = extra || {};
        // rzut monetą: serwer losuje, a moneta 3D (ta sama co u MG) pokazuje wynik
        if (opis === 'Rzut monetą' && window.Coin3D) {
            const j = await api('/api/dziennik', { typ: 'rzut', wyr: '1k2', opis, tryb: 'n', ...extra });
            await Coin3D.flip(j.wpis.rzut.total === 2);
            return j.wpis;
        }
        const groups = D3.ok() ? D3.groupsOf(wyr, tryb) : null;
        if (groups) {
            try {
                const kosci = await D3.roll(groups);
                const j = await api('/api/dziennik', { typ: 'rzut', wyr, opis, tryb, kosci, ...extra });
                show3DResult(j.wpis);
                return j.wpis;
            } catch (e) { if (e.message !== 'busy' && !/timeout|init/i.test(e.message)) { D3.hide(); throw e; } if (e.message === 'busy') throw new Error('Kości jeszcze się toczą…'); }
        }
        const j = await api('/api/dziennik', { typ: 'rzut', wyr, opis, tryb, ...extra });
        if (!(await rollAnim(j.wpis))) showRoll(j.wpis);
        return j.wpis;
    }
    async function roll(wyr, opis, tryb, extra) {
        if (JAKO) { toast('To tylko podgląd Mistrza Gry.'); return; }
        try {
            const w = await rollEntry(wyr, opis, tryb || ui.mode, extra);
            if (!log.some(x => x.id === w.id)) log.push(w);
            dicePanelResult(w);
            return w;
        } catch (e) { toast(e.message, 'bad'); }
    }

    // ---------- start ----------
    async function boot() {
        try {
            me = await api('/api/ja');
            if (!me.rola) { location.href = me.sesja ? '/logowanie?blad=sesja' : '/logowanie'; return; }
            if (me.rola === 'mg' && !JAKO) { location.href = '/'; return; }
            await load();
            const j = await api('/api/dziennik').catch(() => ({ wpisy: [] }));
            log = j.wpisy || [];
            connect();
            D3.warm();
            setInterval(() => { if (!connected) load(); }, 20000);
        } catch (e) { fatal(e.message); }
    }
    function fatal(msg) {
        app().innerHTML = `<div class="pl-boot"><div class="pl-boot-seal">!</div><p>${esc(msg)}</p><button class="pl-btn gold" onclick="location.reload()">Spróbuj ponownie</button></div>`;
    }

    function onData(prev) {
        if (!document.body.classList.contains('pl-ready')) shell();
        // walka: przełącz, gdy się zaczyna; powiadom o turze
        const c = V.combat;
        if (c?.active && !prev?.combat?.active && !JAKO) { ui.tab = 'walka'; toast('⚔ Rozpoczyna się walka!', 'warn'); }
        const myTurn = c?.active && (c.turn === c.me || (c.focus && c.turn === c.focus));
        if (myTurn && ui.lastTurn !== `${c.round}:${c.turn}`) {
            ui.lastTurn = `${c.round}:${c.turn}`;
            const npcT = c.turn !== c.me ? c.order.find(o => o.id === c.turn) : null;
            if (!JAKO) { try { navigator.vibrate?.([120, 60, 120]); } catch (e) {} toast(npcT ? `Tura towarzysza: ${npcT.name} — prowadzisz go!` : 'Twoja tura!', 'turn'); }
        }
        if (!myTurn && c?.active) ui.lastTurn = `${c.round}:${c.turn}`;
        // stół do gier: komunikat od karczmarza dla mnie
        const n = V.table?.notice;
        if (n && n.charId && n.charId === V.character?.id && n.t !== ui.noticeT && Date.now() - n.t < 60000) { ui.noticeT = n.t; toast(n.text); }
        if (JSON.stringify(V.table) !== JSON.stringify(prev?.table)) ui.gwait = false;
        render();
        if (ui.qsheet && $('#pl-overlay .pl-qsheet')) ui.qsheet.draw();
        showLive();
    }

    // ---------- moduły panelu MG w trybie gracza (karta postaci, bestiariusz, zasady) ----------
    let bestInit = false, compInit = {}, sheetFor = null, sheetSig = '', kartaT = null, kartaBusy = false;
    function initModules() {
        window.GraczBridge = {
            campaignId: () => V?.campaign?.id || null,
            character: () => V?.character || null,
            saveCharacter: saveSheetChar,
            quests: () => V?.quests || [],
            roll: (expr, label) => roll(expr, label),
            switchTab: (t) => go(t === 'characters' ? 'postac' : t),
            give: (idx) => giveModal({ idx })
        };
        const CM = window.CharactersModule;
        if (CM) {
            try { CM.init(); } catch (e) { console.warn('[karta]', e); }
            const dm = (what) => () => toast(`${what} — to zmienia Mistrz Gry.`);
            Object.assign(CM, {
                levelUp: () => levelUpSheet(), levelUpFor: () => levelUpSheet(),
                addXP: dm('Doświadczenie'), toggleInspiration: dm('Natchnienie'), cycleSkill: dm('Biegłości'), toggleSave: dm('Biegłości w rzutach obronnych'),
                recalcAC: dm('Klasa Pancerza'), showKitModal: dm('Ekwipunek startowy'), addLanguage: dm('Języki'), applyRaceData: dm('Rasa'), applyClassData: dm('Klasa'),
                rollCheck: (label, m) => roll(`k20${m >= 0 ? '+' : ''}${m}`, label),
                rollDamage: (label, e) => roll(String(e).replace(/−/g, '-').replace(/d/g, 'k'), `${label} — obrażenia`),
                useHitDie: () => hitDie()
            });
            const sh = $('#character-sheet');
            if (sh) new MutationObserver(lockSheet).observe(sh, { childList: true, subtree: true });
        }
        try { RulesModule.init(); } catch (e) {}
        const pdf = $('#pl-pdf');
        if (pdf) pdf.onclick = () => { if (!V?.character) { toast('Nie masz jeszcze postaci.'); return; } CharactersModule.exportToPDF(V.character.id); };
    }
    // pola, które gracz zmienia sam; resztę karty prowadzi Mistrz Gry
    const FREE = /^(hp\.(current|temp)|currency\.\w+|backstory\.\w+|notes|spellsNotes|features\.custom)$/;
    function lockSheet() {
        const sh = $('#character-sheet'); if (!sh) return;
        sh.querySelectorAll('[data-field]').forEach(i => { if ((JAKO || !FREE.test(i.dataset.field)) && !i.disabled) { i.disabled = true; i.classList.add('pl-locked'); i.title = 'To pole zmienia Mistrz Gry'; } });
        sh.querySelectorAll('.sh-sec-title').forEach(h => { if (h.textContent.includes('Notatki Mistrza Gry')) h.innerHTML = '<i class="fa-solid fa-feather"></i> Moje notatki'; });
        const ta = sh.querySelector('textarea[data-field="notes"]');
        if (ta && !ta.dataset.pl) { ta.dataset.pl = '1'; ta.placeholder = 'Twoje notatki: plany, imiona, poszlaki… Widzisz je Ty i Mistrz Gry.'; }
    }
    function sheetTab() {
        const ch = V.character;
        $('#pl-nochar').hidden = !!ch;
        const sh = $('#character-sheet');
        if (!ch || !window.CharactersModule) { sh.classList.add('hidden'); sheetFor = null; return; }
        const sig = JSON.stringify(ch);
        if (sheetFor !== ch.id) { sheetFor = ch.id; sheetSig = sig; CharactersModule.activate(); CharactersModule.showCharacterSheet(ch.id); return; }
        if (sig !== sheetSig) {
            sheetSig = sig;
            const panel = $('#tab-postac'), top = panel?.scrollTop || 0, snap = snapView(sh);
            CharactersModule.refreshFromStorage();
            if (panel) panel.scrollTop = top;
            restoreView(sh, snap);
        }
    }
    function saveSheetChar(ch) {
        if (JAKO) { toast('To tylko podgląd Mistrza Gry — zmiany robi gracz.'); return; }
        if (!ch || !V?.character || ch.id !== V.character.id) return;
        if (JSON.stringify(ch) === JSON.stringify(V.character)) return;      // nic się nie zmieniło
        V.character = JSON.parse(JSON.stringify(ch));
        if (ui.tab === 'postac') sheetSig = JSON.stringify(V.character);   // zmiana z kompendium → karta odświeży się przy wejściu
        chips();
        kartaBusy = true; clearTimeout(kartaT);
        kartaT = setTimeout(async () => {
            try { await api('/api/gracz/akcja', { typ: 'karta', karta: V.character }); }
            catch (e) { toast(e.message, 'bad'); }
            kartaBusy = false; load();
        }, 350);
    }
    async function hitDie() {
        const ch = V.character; if (!ch || JAKO) return;
        const hd = ch.hitDicePool || { current: ch.level || 1, max: ch.level || 1, die: ch.hitDie || 8 };
        if (hd.current <= 0) { toast('Nie masz już kości wytrzymałości.'); return; }
        const cm = mod(ch.abilityScores?.con);
        try {
            const w = await rollEntry(`1k${hd.die || 8}${cm >= 0 ? '+' : ''}${cm}`, 'Kość wytrzymałości');
            const heal = Math.max(0, w.rzut.total);
            const c = JSON.parse(JSON.stringify(ch));
            c.hitDicePool = { ...hd, current: hd.current - 1 };
            c.hp.current = Math.min(c.hp.max, c.hp.current + heal);
            saveSheetChar(c);
            toast(`Kość wytrzymałości: +${heal} PW`, 'good');
            CharactersModule.refreshFromStorage();
        } catch (er) { toast(er.message, 'bad'); }
    }

    // ---------- szkielet ----------
    function shell() {
        $('#pl-boot')?.remove();
        document.body.classList.add('pl-ready');
        if (JAKO) { $('#pl-preview').hidden = false; $('#pl-logout').hidden = true; }
        $('#pl-nav').onclick = (e) => { const b = e.target.closest('button[data-tab]'); if (b) go(b.dataset.tab); };
        // telefon: dolny pasek zakładek + arkusz „Więcej”
        const more = $('#pl-more');
        $('#pl-bnav').onclick = (e) => {
            // uwaga: <body> też ma data-tab (bieżąca zakładka) — szukamy tylko przycisków
            const t = e.target.closest('button[data-tab]'); if (t) { go(t.dataset.tab); return; }
            if (e.target.closest('[data-more]')) setMore(more.hidden);
        };
        more.onclick = (e) => {
            if (e.target === more) { setMore(false); return; }
            const t = e.target.closest('button[data-tab]'); if (t) { go(t.dataset.tab); return; }
            if (e.target.closest('[data-install]')) { setMore(false); $('#pl-install')?.click(); return; }
            if (e.target.closest('[data-logout]')) $('#pl-logout')?.click();
        };
        $('#pl-top-install').onclick = () => $('#pl-install')?.click();
        dicePanelInit();
        installButton();
        $('#pl-top-hero').onclick = (e) => { if (e.target.closest('[data-tabgo]')) go('postac'); };
        $('#pl-logout')?.addEventListener('click', async () => { try { await api('/api/logout', {}); } catch (e) {} location.href = '/logowanie'; });
        // zwijane menu jak u MG (na telefonie domyślnie zwinięte)
        const setSide = (c) => { document.body.classList.toggle('sidebar-collapsed', c); try { localStorage.setItem('pl_sidebar', c ? '1' : '0'); } catch (e) {} };
        setSide(document.documentElement.classList.contains('pl-pre-collapsed'));
        $('#btn-toggle-sidebar').onclick = () => setSide(!document.body.classList.contains('sidebar-collapsed'));
        document.addEventListener('keydown', (e) => {
            if (e.target.closest('input, textarea, select, [contenteditable]') || e.ctrlKey || e.metaKey || e.altKey) return;
            const k = Object.keys(TABS)[+e.key - 1]; if (k && /^[1-9]$/.test(e.key)) go(k);
        });
        const m = $('#pl-main');
        m.addEventListener('click', onClick);
        m.addEventListener('change', onChange);
        m.addEventListener('input', onInput);
        initModules();
    }
    // dane przyszły w trakcie przeciągania żetonu albo przesuwania mapy — dorysuj po puszczeniu
    function flushRender() { setTimeout(() => { if (ui.renderLater && !$('#pl-main')?.querySelector('.dragging, [data-panning]')) render(); }, 60); }
    document.addEventListener('pointerup', flushRender, true);
    document.addEventListener('pointercancel', flushRender, true);
    function setMore(open) {
        const m = $('#pl-more'); if (!m) return;
        m.hidden = !open; document.body.classList.toggle('pl-more-open', !!open);
        if (open) document.body.classList.remove('dice-open');
    }
    function go(tab) {
        setMore(false);
        if (!TABS[tab]) return;
        ui.tab = tab; localStorage.setItem('pl_tab', tab);
        if (tab === 'czat') ui.unread = 0;
        if (tab === 'mapa') ui.mapPing = false;
        if (innerWidth <= 760) document.body.classList.add('sidebar-collapsed');
        render(true);
    }
    function dot() {
        const txt = connected ? (ui.mgOnline === false ? 'MG offline' : 'Przy stole') : 'Łączę…';
        document.querySelectorAll('.pl-conn').forEach(d => { d.classList.toggle('ok', connected); d.classList.toggle('off', !connected); d.title = connected ? `Połączono ze stołem${ui.mgOnline === false ? ' (Mistrz Gry offline)' : ''}` : 'Łączę ponownie…'; });
        document.querySelectorAll('#pl-conn-t, .pl-conn-t').forEach(t => { t.textContent = txt; });
    }
    function tabsBadges() {
        const c = V?.combat;
        document.querySelectorAll('[data-badge]').forEach(b => {
            const k = b.dataset.badge;
            let t = '';
            if (k === 'walka' && c?.active) t = c.turn === c.me ? '!' : '⚔';
            if (k === 'czat' && ui.unread) t = String(Math.min(ui.unread, 9));
            if (k === 'stol' && V?.table?.game && !V.table.game.done && myTableTurn()) t = '!';
            if (k === 'mapa' && ui.mapPing) t = '•';
            b.textContent = t; b.hidden = !t;
        });
    }
    // ---------- odświeżenie bez „skakania”: przewinięcie, rozwinięte sekcje i pisany tekst zostają ----------
    try { ui.det = JSON.parse(localStorage.getItem('pl_det') || '{}'); } catch (e) { ui.det = {}; }
    document.addEventListener('toggle', (e) => {
        const d = e.target; if (!(d instanceof HTMLDetailsElement) || !d.dataset.det) return;
        ui.det[d.dataset.det] = d.open; try { localStorage.setItem('pl_det', JSON.stringify(ui.det)); } catch (er) {}
    }, true);
    const scrollKey = (el) => `${el.id || ''}|${typeof el.className === 'string' ? el.className.replace(/\s+(open|on|active|mine|now|sel|turn)\b/g, '') : ''}|${el.dataset?.det || el.dataset?.sec || ''}`;
    function snapView(root) {
        const sc = [], seen = {};
        if (root) root.querySelectorAll('*').forEach(el => {
            if (el.scrollTop <= 0 && el.scrollLeft <= 0) return;
            const k = scrollKey(el); const i = seen[k] = (seen[k] || 0) + 1;
            sc.push({ k, i, t: el.scrollTop, l: el.scrollLeft });
        });
        const a = document.activeElement;
        const foc = a && root?.contains(a) && (a.id || a.name) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)
            ? { sel: a.id ? `#${CSS.escape(a.id)}` : `${a.tagName.toLowerCase()}[name="${CSS.escape(a.name)}"]`, v: a.value, s: a.selectionStart, e: a.selectionEnd } : null;
        return { sc, foc };
    }
    function restoreView(root, snap) {
        if (!root || !snap) return;
        root.querySelectorAll('details[data-det]').forEach(d => { const v = ui.det[d.dataset.det]; if (v !== undefined) d.open = v; });
        if (snap.sc.length) {
            const seen = {}, by = {};
            root.querySelectorAll('*').forEach(el => { const k = scrollKey(el); const i = seen[k] = (seen[k] || 0) + 1; by[`${k}#${i}`] = el; });
            snap.sc.forEach(x => { const el = by[`${x.k}#${x.i}`]; if (el) { el.scrollTop = x.t; el.scrollLeft = x.l; } });
        }
        if (snap.foc) {
            const el = root.querySelector(snap.foc.sel);
            if (el && el !== document.activeElement) {
                if ('value' in el && el.type !== 'file' && el.value !== snap.foc.v) el.value = snap.foc.v;
                try { el.focus({ preventScroll: true }); if (snap.foc.s != null && el.setSelectionRange) el.setSelectionRange(snap.foc.s, snap.foc.e); } catch (e) {}
            }
        }
    }
    function render(switched) {
        if (!V || !document.body.classList.contains('pl-ready')) return;
        chips();
        const [icon, name, group] = TABS[ui.tab];
        document.querySelectorAll('#pl-nav .nav-tab, #pl-bnav [data-tab], #pl-more [data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === ui.tab));
        $('#pl-bnav [data-more]')?.classList.toggle('active', !['postac', 'mapa', 'walka', 'stol', 'czat'].includes(ui.tab));
        $('#topbar-title').innerHTML = `<span class="topbar-crumb">${group}</span><span class="topbar-page"><i class="fa-solid ${icon}"></i> ${name}</span>`;
        document.body.dataset.tab = ui.tab;
        const own = OWN.includes(ui.tab);
        const panelId = own ? `tab-${ui.tab}` : 'tab-pl';
        document.querySelectorAll('main > .tab-panel').forEach(p => p.classList.toggle('active', p.id === panelId));
        const panel = $('#' + panelId);
        if (switched) panel.scrollTop = 0;
        if (ui.tab === 'postac') { sheetTab(); tabsBadges(); dot(); return; }
        if (ui.tab === 'spells' || ui.tab === 'equipment') {
            const M = ui.tab === 'spells' ? window.SpellsModule : window.EquipmentModule;
            if (M) { if (!compInit[ui.tab]) { compInit[ui.tab] = true; M.init(); } else if (switched) M.activate?.(); }
            tabsBadges(); dot(); return;
        }
        if (ui.tab === 'bestiary') { if (!bestInit) { bestInit = true; BestiaryModule.init(); } else if (switched) BestiaryModule.activate(); tabsBadges(); dot(); return; }
        if (ui.tab === 'rules') { if (switched) RulesModule.activate(); tabsBadges(); dot(); return; }
        const keep = panel.scrollTop;
        const m0 = $('#pl-main');
        if (!switched && (ui.tab === 'walka' || ui.tab === 'mapa') && m0.querySelector('.dragging, [data-panning]')) { ui.renderLater = true; tabsBadges(); dot(); return; }
        ui.renderLater = false;
        const oldBg = [...m0.querySelectorAll('img[data-keep="bg"]')];
        const snap = switched ? null : snapView(m0);
        $('#pl-head').innerHTML = `<h2><i class="fa-solid ${icon}"></i> ${name}</h2><div class="tab-actions">${headActions()}</div>`;
        const m = $('#pl-main');
        m.className = `pl-main pl-v-${ui.tab}`;
        m.innerHTML = ({ druzyna: party, mapa: mapView, walka: combatView, zadania: quests, stol: gamesView, czat: chatView })[ui.tab]?.() || '';
        // to samo tło co przed chwilą: przenieś już wczytany obrazek zamiast wczytywać go od nowa (bez prześwitywania)
        m.querySelectorAll('img[data-keep="bg"]').forEach(img => {
            const old = oldBg.find(o => o.getAttribute('src') === img.getAttribute('src') && o.complete);
            if (old) { oldBg.splice(oldBg.indexOf(old), 1); old.className = img.className; old.setAttribute('style', img.getAttribute('style') || ''); img.replaceWith(old); }
        });
        panel.scrollTop = keep;
        if (snap) restoreView(m, snap); else m.querySelectorAll('details[data-det]').forEach(d => { const v = ui.det[d.dataset.det]; if (v !== undefined) d.open = v; });
        if (ui.tab === 'mapa') { bindMap(); mapBanner(); }
        if (ui.tab === 'zadania') { fitQuestBoard(); bindQuestBoard(); }
        if (ui.tab === 'walka') bindBoard();
        if (ui.tab === 'czat') renderLog();
        if (ui.tab === 'stol') { requestAnimationFrame(tgLaunch); if (window.TavernDice) TavernDice.play($('#pl-main')); }
        tabsBadges(); dot();
    }
    function chips() {
        const ch = V.character;
        const cls = ch && window.Kits ? Kits.CLASS_META[Kits.classKey(ch.class)] : null;
        const av = `<span class="pl-av" style="--c:${cls?.color || '#8a6a3a'}"><i class="fa-solid ${cls?.icon || 'fa-user'}"></i>${ch?.portrait && window.Portrait ? Portrait.img(ch.portrait) : ''}</span>`;
        $('#pl-who').innerHTML = `${av}<div><b>${esc(ch?.name || V.player.name)}</b><small>${ch ? `${esc([ch.race, cls?.pl || ch.class].filter(Boolean).join(' · '))} ${ch.level || 1}` : 'bez postaci'} · gra: ${esc(V.player.name)}</small></div>`;
        const mw = $('#pl-more-who'); if (mw) mw.innerHTML = $('#pl-who').innerHTML + `<small class="pl-more-camp">${esc(V.campaign?.name || '')}</small>`;
        const hpPct = ch?.hp?.max ? Math.max(0, Math.min(100, ch.hp.current / ch.hp.max * 100)) : 0;
        $('#pl-top-hero').innerHTML = ch ? `<button class="pl-top-chip" data-tabgo="postac" title="Moja postać">${av}<span><b>${esc(ch.name)}</b><small><i class="fa-solid fa-heart"></i> ${ch.hp?.current ?? 0}/${ch.hp?.max ?? 0}${ch.hp?.temp ? ` +${ch.hp.temp}` : ''} · <i class="fa-solid fa-shield"></i> ${ch.ac ?? '?'}</small><i class="pl-top-hp" style="width:${hpPct}%"></i></span></button>` : '';
        $('#pl-campname').textContent = V.campaign?.name || 'Przy stole';
    }
    function headActions() {
        const hint = { druzyna: 'Twoi towarzysze i ich stan', mapa: 'Widzisz to, co pokazuje Mistrz Gry', walka: V.combat?.active ? `Runda ${V.combat.round || 1}` : 'Plansza walki', zadania: 'Przeciągaj kartki · kliknij, by przeczytać i przyjąć', stol: 'Dosiądź się i graj w swojej turze', czat: 'Rzuty i wiadomości całego stołu' }[ui.tab] || '';
        return `<span class="tab-hint">${esc(hint)}</span>`;
    }
    const sec = (id, icon, title, body, open = true) => {
        const isOpen = ui.sec[id] ?? open;
        return `<section class="pl-sec ${isOpen ? 'open' : ''}" data-sec="${id}"><h3 data-toggle="${id}"><i class="fa-solid ${icon}"></i>${title}<i class="fa-solid fa-chevron-down pl-chev"></i></h3><div class="pl-sec-b">${body}</div></section>`;
    };
    // towarzysze (NPC w drużynie): swoich gracz widzi w całości — kartę, ekwipunek, zdolności
    function companionsHTML() {
        const L = V.companions || []; if (!L.length) return '';
        const txt = (t) => esc(t).replace(/\n/g, '<br>');
        return `<h3 class="pl-sub"><i class="fa-solid fa-handshake-angle"></i> Towarzysze</h3><div class="pl-comps">${L.map(cp => {
            const pct = cp.hp ? Math.max(0, Math.min(100, cp.hp.current / Math.max(1, cp.hp.max) * 100)) : 0;
            const head = `<div class="pl-comp-h"><span class="pl-av"><i class="fa-solid fa-user-shield"></i></span><div><b>${esc(cp.name)}</b><small>${esc([cp.role, cp.race].filter(Boolean).join(' · ') || 'NPC')} · ${cp.mine ? 'prowadzisz go Ty' : cp.ownerName ? `prowadzi: ${esc(cp.ownerName)}` : 'idzie osobno'}</small>
                ${cp.hp ? `<div class="pl-hp-bar sm"><i style="width:${pct}%"></i></div><small>${cp.hp.current}/${cp.hp.max} PW</small>` : ''}</div></div>`;
            if (!cp.mine) return `<div class="pl-comp-card">${head}</div>`;
            return `<div class="pl-comp-card mine">${head}
                ${cp.description ? `<p class="pl-comp-t">${txt(cp.description)}</p>` : ''}
                ${!(cp.hasStats && cp.stats) && (cp.gear || (cp.inventory || []).length) ? `<div class="pl-comp-sec"><h4><i class="fa-solid fa-sack-xmark"></i> Ekwipunek</h4><p>${esc((cp.inventory || []).map(it => `${it.name}${it.quantity > 1 ? ` ×${it.quantity}` : ''}`).join(', '))}${cp.gear ? `<br>${txt(cp.gear)}` : ''}</p></div>` : ''}
                ${cp.motivations ? `<div class="pl-comp-sec"><h4><i class="fa-solid fa-compass"></i> Czego chce</h4><p>${txt(cp.motivations)}</p></div>` : ''}
                ${cp.hasStats && cp.stats && window.NPCsModule ? `<div class="pl-comp-sec"><h4><i class="fa-solid fa-dice-d20"></i> Statystyki i zdolności <small>kliknij wartość, by rzucić</small></h4><div class="nb-host">${NPCsModule.statBlockHTML(NPCsModule.normNPC({ ...cp, hasStats: true }))}</div></div>` : ''}
            </div>`;
        }).join('')}</div>`;
    }
    // drużyna jak u Mistrza Gry: te same karty bohaterów, tylko do podglądu (bez PW, awansu i odpoczynków)
    function teamSheet(c) {
        const raw = c.me ? V.character : c.sheet; if (!raw) return null;
        let ch = { ...raw, hp: c.hp, portrait: c.pv && window.Portrait ? Portrait.url(c.id, c.pv) : null };
        try { if (CharactersModule.normalizeCharacter) ch = CharactersModule.normalizeCharacter(ch) || ch; } catch (e) {}
        return ch;
    }
    function party() {
        const on = new Set((V.online || []).map(g => g.charId));
        if (window.CharactersModule?.heroCard) {
            const cards = (V.party || []).map(c => {
                const ch = teamSheet(c); if (!ch) return '';
                const give = !c.me && V.character && !JAKO ? `<div class="hc-give"><button class="pl-give-btn" data-give="${esc(c.id)}" title="Daj przedmiot albo monety"><i class="fa-solid fa-hand-holding-heart"></i> Daj coś</button></div>` : '';
                try { return CharactersModule.heroCard(ch, { view: true, me: c.me, player: c.player, online: c.me || on.has(c.id), extra: give }); } catch (e) { return ''; }
            }).join('');
            if (cards) return `<div class="pl-heroes characters-grid">${cards}</div>${companionsHTML()}`;
        }
        return `<div class="pl-party">${(V.party || []).map(c => {
            const cls = window.Kits ? Kits.CLASS_META[Kits.classKey(c.class)] : null;
            const pct = c.hp.max ? Math.max(0, Math.min(100, c.hp.current / c.hp.max * 100)) : 0;
            return `<div class="pl-pcard ${c.me ? 'me' : ''}" style="--c:${cls?.color || '#8a6a3a'}">
                <span class="pl-av"><i class="fa-solid ${cls?.icon || 'fa-user'}"></i>${c.pv && window.Portrait ? Portrait.img(Portrait.url(c.id, c.pv)) : ''}${on.has(c.id) || c.me ? '<i class="pl-on"></i>' : ''}</span>
                <div class="pl-pcard-b"><b>${esc(c.name)}${c.me ? ' <small>(Ty)</small>' : ''}</b><small>${esc([c.race, c.class].filter(Boolean).join(' · '))} ${c.level}${c.player ? ` · gra: ${esc(c.player)}` : ''}</small>
                    <div class="pl-hp-bar sm"><i style="width:${pct}%"></i></div>
                    <div class="pl-pcard-s"><span>${c.hp.current}/${c.hp.max} PW${c.hp.temp ? ` +${c.hp.temp}` : ''}</span><span>KP ${c.ac ?? '?'}</span></div>
                    ${!c.me && V.character && !JAKO ? `<button class="pl-give-btn" data-give="${esc(c.id)}" title="Daj przedmiot albo monety"><i class="fa-solid fa-hand-holding-heart"></i> Daj coś</button>` : ''}</div>
            </div>`;
        }).join('') || '<div class="pl-empty"><p>Drużyna jest jeszcze pusta.</p></div>'}</div>${companionsHTML()}`;
    }

    // ---------- zadania: tablica ogłoszeń + lista ----------
    const qRng = (id) => { let s = 0; for (const c of String(id)) s = (s * 31 + c.charCodeAt(0)) >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); };
    const CLOSEDQ = ['Zaliczone', 'Nieudane', 'Odrzucone'];
    const STAMP = { 'Przyjęte': 'PRZYJĘTE', 'Zaliczone': 'WYKONANE', 'Nieudane': 'NIEUDANE', 'Odrzucone': 'ODRZUCONE' };
    // pozycje kartek przesunięte przez gracza (tylko u niego — tablica MG się nie zmienia)
    const qposKey = () => `pl_qpos_${V?.campaign?.id || ''}_${V?.player?.id || ''}`;
    const qPos = () => { try { return JSON.parse(localStorage.getItem(qposKey()) || '{}'); } catch (e) { return {}; } };
    function quests() {
        const qs = V.quests || [];
        if (!window.QuestBoard?.renderPlayer) return questBoard(qs);
        const pos = qPos();
        const list = qs.map(q => pos[q.id] ? { ...q, pos: pos[q.id] } : q);
        const open = qs.filter(q => !CLOSEDQ.includes(q.status));
        const lista = ui.qview === 'lista';
        const seg = `<div class="pl-seg" role="group" aria-label="Widok"><button data-qview="tablica" class="${lista ? '' : 'on'}"><i class="fa-solid fa-chalkboard"></i> Tablica</button><button data-qview="lista" class="${lista ? 'on' : ''}"><i class="fa-solid fa-list"></i> Lista</button></div>`;
        const sum = `<div class="pl-qsum"><span><i class="fa-solid fa-hand-pointer"></i> ${open.filter(q => q.status === 'Brak').length} do wzięcia</span><span><i class="fa-solid fa-person-running"></i> ${open.filter(q => q.status === 'Przyjęte').length} w trakcie</span><span><i class="fa-solid fa-stamp"></i> ${qs.length - open.length} zakończonych</span>
                ${seg}${V.tablica && window.TavernBoard ? '<button class="pl-chalk-btn" data-chalk title="Menu, nocleg i plotka z karczmy"><i class="fa-solid fa-beer-mug-empty"></i> Tablica karczmy</button>' : ''}${!lista && Object.keys(pos).length ? '<button class="btn-secondary btn-small" data-qreset><i class="fa-solid fa-table-cells-large"></i> Ułóż jak u Mistrza Gry</button>' : ''}</div>`;
        if (lista) return sum + (questList(qs.filter(q => q.status !== 'Nieznane')) || '<div class="pl-empty"><p>Na tablicy nie ma jeszcze ogłoszeń.</p></div>');
        return `${sum}
            <div class="pl-qbwrap" id="pl-qbwrap"><div class="pl-qbstage" id="pl-qbstage">${QuestBoard.renderPlayer(list, { closed: true, hint: 'Przeciągaj kartki, by je układać · kliknij, by przeczytać i przyjąć' })}</div></div>`;
    }
    // przeciąganie kartek po tablicy (tablica jest przeskalowana do ekranu — przeliczamy przez skalę)
    function bindQuestBoard() {
        const stage = $('#pl-qbstage'), boardEl = stage?.querySelector('.qb-free'); if (!boardEl) return;
        const NW = QuestBoard.NOTE_MAX_W || 300;
        let drag = null;
        const k = () => (new DOMMatrix(getComputedStyle(stage).transform).a) || 1;
        boardEl.addEventListener('pointerdown', (e) => {
            const card = e.target.closest('.qp'); if (!card || e.button !== 0) return;
            drag = { card, id: card.dataset.qid, sx: e.clientX, sy: e.clientY, ox: card.offsetLeft, oy: card.offsetTop, moved: false, pid: e.pointerId, k: k() };
        });
        boardEl.addEventListener('pointermove', (e) => {
            if (!drag) return;
            const dx = (e.clientX - drag.sx) / drag.k, dy = (e.clientY - drag.sy) / drag.k;
            if (!drag.moved && Math.hypot(dx, dy) < 5) return;
            if (!drag.moved) {
                drag.moved = true;
                try { drag.card.setPointerCapture(drag.pid); } catch (er) {}
                drag.card.classList.add('dragging');
                const maxZ = Math.max(1, ...[...boardEl.querySelectorAll('.qp')].map(n => (+n.style.zIndex || 1) - (n.classList.contains('qp-bounty') ? 400 : 0)));
                drag.card.style.zIndex = maxZ + 1 + (drag.card.classList.contains('qp-bounty') ? 400 : 0);
            }
            e.preventDefault();
            drag.card.style.left = `${Math.max(0, Math.min(boardEl.clientWidth - drag.card.offsetWidth, drag.ox + dx))}px`;
            drag.card.style.top = `${Math.max(0, drag.oy + dy)}px`;
        });
        const end = () => {
            if (!drag) return;
            const { card, id, moved } = drag; drag = null;
            if (!moved) return;
            card._dragged = true;
            card.classList.remove('dragging'); card.classList.add('dropped'); setTimeout(() => card.classList.remove('dropped'), 450);
            const span = Math.max(1, boardEl.clientWidth - NW);
            const x = Math.max(0, Math.min(1, parseFloat(card.style.left) / span)), y = Math.round(parseFloat(card.style.top));
            const z = (+card.style.zIndex || 1) - (card.classList.contains('qp-bounty') ? 400 : 0);
            const all = qPos(); all[id] = { x, y, z };
            try { localStorage.setItem(qposKey(), JSON.stringify(all)); } catch (er) {}
            card.style.left = `calc(${x} * (100% - ${NW}px))`;
            // tablica rośnie, gdy kartka zjedzie niżej
            const need = y + card.offsetHeight + 160;
            if (need > boardEl.offsetHeight) { boardEl.style.height = need + 'px'; fitQuestBoard(); }
        };
        boardEl.addEventListener('pointerup', end);
        boardEl.addEventListener('pointercancel', end);
    }
    function questNote(q, k) {
        const r = qRng(q.id), ty = q.type in QTYPE ? q.type : 'side', tilt = ((r() - .5) * 7).toFixed(1);
        const objs = q.objectives || [], done = objs.filter(o => o.done).length;
        const mine = q.acceptedBy && q.acceptedBy.charId && q.acceptedBy.charId === V.character?.id;
        return `<button class="pl-note n-${ty} ${q.status === 'Przyjęte' ? 'is-active' : ''} ${mine ? 'mine' : ''}" data-quest="${esc(q.id)}" style="--tilt:${tilt}deg;--d:${k * 45}ms">
            <span class="pl-note-pin ${ty === 'bounty' ? 'dagger' : ''}"></span>
            <span class="pl-note-kind"><i class="fa-solid ${QTYPE[ty][1]}"></i> ${ty === 'bounty' ? 'Poszukiwany' : QTYPE[ty][0]}</span>
            <b class="pl-note-title">${esc(q.title || 'Bez tytułu')}</b>
            ${ty === 'bounty' ? '<span class="pl-note-wanted">żywy lub martwy</span>' : ''}
            ${q.description ? `<span class="pl-note-text">${esc(q.description.length > 110 ? q.description.slice(0, 108) + '…' : q.description)}</span>` : ''}
            <span class="pl-note-foot">${q.reward ? `<span><i class="fa-solid fa-coins"></i> ${esc(q.reward)}</span>` : ''}${objs.length ? `<span><i class="fa-solid fa-list-check"></i> ${done}/${objs.length}</span>` : ''}</span>
            ${STAMP[q.status] ? `<span class="pl-stamp s-${(STATUS[q.status] || STATUS.Brak)[1]}">${STAMP[q.status]}</span>` : ''}
            ${q.reported && q.status === 'Przyjęte' ? '<span class="pl-note-flag"><i class="fa-solid fa-bell"></i> zgłoszone</span>' : ''}
        </button>`;
    }
    function questBoard(qs) {
        const open = qs.filter(q => !CLOSEDQ.includes(q.status)).sort((a, b) => (a.status === 'Przyjęte') - (b.status === 'Przyjęte') || ['main', 'bounty', 'side', 'personal'].indexOf(a.type) - ['main', 'bounty', 'side', 'personal'].indexOf(b.type));
        const closed = qs.filter(q => CLOSEDQ.includes(q.status));
        return `<div class="pl-board">
                <div class="pl-board-head"><i class="fa-solid fa-thumbtack"></i> Ogłoszenia <small>${open.filter(q => q.status === 'Brak').length} do wzięcia · ${open.filter(q => q.status === 'Przyjęte').length} w trakcie</small></div>
                <div class="pl-notes">${open.map(questNote).join('') || '<p class="pl-muted pl-center">Nic nowego na tablicy.</p>'}</div>
            </div>
            ${closed.length ? `<details class="pl-archive"><summary><i class="fa-solid fa-box-archive"></i> Zakończone <small>${closed.length}</small></summary><div class="pl-notes small">${closed.map(questNote).join('')}</div></details>` : ''}
            <p class="pl-muted pl-center">Dotknij kartki, by przeczytać ogłoszenie i je przyjąć.</p>`;
    }
    function questList(qs) {
        const groups = [['Przyjęte', 'W trakcie'], ['Brak', 'Do wzięcia'], ['done', 'Zakończone']];
        return groups.map(([k, t]) => {
            const list = qs.filter(q => k === 'done' ? CLOSEDQ.includes(q.status) : q.status === k);
            if (!list.length) return '';
            return `<h3 class="pl-h">${t} <small>${list.length}</small></h3><div class="pl-quests">${list.map(q => {
                const ty = QTYPE[q.type] || QTYPE.side, stt = STATUS[q.status] || STATUS.Brak;
                return `<article class="pl-quest t-${esc(q.type || 'side')} s-${stt[1]}" data-quest="${esc(q.id)}"><header><i class="fa-solid ${ty[1]}"></i><span>${ty[0]}</span><em>${stt[0]}</em></header>
                    <h4>${esc(q.title)}</h4>${q.description ? `<p>${esc(q.description)}</p>` : ''}
                    ${q.objectives?.length ? `<ul>${q.objectives.map(o => `<li class="${o.done ? 'done' : ''}"><i class="fa-${o.done ? 'solid fa-square-check' : 'regular fa-square'}"></i>${esc(o.text)}</li>`).join('')}</ul>` : ''}
                    <footer>${q.giver ? `<span><i class="fa-solid fa-user"></i> ${esc(q.giver)}</span>` : ''}${q.location ? `<span><i class="fa-solid fa-location-dot"></i> ${esc(q.location)}</span>` : ''}${q.reward ? `<span><i class="fa-solid fa-coins"></i> ${esc(q.reward)}</span>` : ''}${q.acceptedBy ? `<span><i class="fa-solid fa-handshake"></i> ${esc(q.acceptedBy.char || q.acceptedBy.name)}</span>` : ''}</footer></article>`;
            }).join('')}</div>`;
        }).join('');
    }
    // tablica MG ma stałą szerokość — u gracza skalujemy ją do ekranu, żeby wyglądała identycznie
    const QB_W = 1180;
    // na komputerze tablica ma pełną szerokość zakładki — dokładnie jak u Mistrza Gry;
    // dopiero na wąskim ekranie (telefon) zmniejszamy całą tablicę, żeby zmieściła się w całości
    const QB_MIN = 760;
    function fitQuestBoard() {
        const wrap = $('#pl-qbwrap'), stage = $('#pl-qbstage'); if (!wrap || !stage) return;
        const W = wrap.clientWidth;
        if (W >= QB_MIN) { stage.style.width = '100%'; stage.style.transform = ''; wrap.style.height = ''; return; }
        stage.style.width = QB_W + 'px';
        const k = W / QB_W;
        stage.style.transform = `scale(${k})`;
        wrap.style.height = Math.ceil(stage.offsetHeight * k) + 'px';
    }
    window.addEventListener('resize', () => { if (ui.tab === 'zadania') fitQuestBoard(); });
    function questSheet(id) {
        const ov = $('#pl-overlay');
        const draw = () => {
            const q = (V.quests || []).find(x => x.id === id);
            if (!q) { ov.innerHTML = ''; return; }
            const ty = q.type in QTYPE ? q.type : 'side', stt = STATUS[q.status] || STATUS.Brak;
            const objs = q.objectives || [];
            const when = (iso) => iso ? new Date(iso).toLocaleDateString(window.LOC || 'pl-PL', { day: 'numeric', month: 'long' }) : '';
            let actions = '';
            if (q.status === 'Brak') actions = `<button class="pl-btn gold big" data-qaccept="${esc(q.id)}"><i class="fa-solid fa-handshake"></i> Przyjmij zlecenie</button><p class="pl-muted pl-center">Przyjęcie zobaczy Mistrz Gry i cała drużyna.</p>`;
            else if (q.status === 'Przyjęte' && !q.reported) actions = `<button class="pl-btn big" data-qreport="${esc(q.id)}"><i class="fa-solid fa-bell"></i> Zgłoś wykonanie Mistrzowi Gry</button>`;
            else if (q.status === 'Przyjęte') actions = `<p class="pl-muted pl-center"><i class="fa-solid fa-hourglass-half"></i> Wykonanie zgłosił(a) ${esc(q.reported.char || q.reported.name)} — czekamy na decyzję Mistrza Gry.</p>`;
            ov.innerHTML = `<div class="pl-sheet-bg" data-close><div class="pl-qsheet n-${ty} s-${stt[1]}" role="dialog" aria-label="${esc(q.title)}">
                <button class="pl-icon pl-qclose" data-close><i class="fa-solid fa-xmark"></i></button>
                <div class="pl-qpaper">
                    <span class="pl-note-kind"><i class="fa-solid ${QTYPE[ty][1]}"></i> ${ty === 'bounty' ? 'List gończy' : QTYPE[ty][0]}</span>
                    <h2>${esc(q.title || 'Bez tytułu')}</h2>
                    ${ty === 'bounty' ? '<div class="pl-note-wanted">poszukiwany — żywy lub martwy</div>' : ''}
                    ${STAMP[q.status] ? `<span class="pl-stamp big s-${stt[1]}">${STAMP[q.status]}</span>` : ''}
                    ${q.description ? `<p class="pl-qdesc">${esc(q.description)}</p>` : ''}
                    ${objs.length ? `<h4>Cele</h4><ul class="pl-qobj">${objs.map(o => `<li class="${o.done ? 'done' : ''}"><i class="fa-${o.done ? 'solid fa-square-check' : 'regular fa-square'}"></i>${esc(o.text)}</li>`).join('')}</ul>` : ''}
                    <dl class="pl-qmeta">
                        ${q.giver ? `<div><dt><i class="fa-solid fa-user-tie"></i> Zleceniodawca</dt><dd>${esc(q.giver)}</dd></div>` : ''}
                        ${q.location ? `<div><dt><i class="fa-solid fa-location-dot"></i> Miejsce</dt><dd>${esc(q.location)}</dd></div>` : ''}
                        ${q.reward ? `<div><dt><i class="fa-solid fa-coins"></i> Nagroda</dt><dd>${esc(q.reward)}</dd></div>` : ''}
                        ${q.acceptedBy ? `<div><dt><i class="fa-solid fa-handshake"></i> Przyjął(a)</dt><dd>${esc(q.acceptedBy.char || q.acceptedBy.name)}${q.acceptedBy.at ? ` · ${when(q.acceptedBy.at)}` : ''}</dd></div>` : ''}
                    </dl>
                </div>
                <div class="pl-qactions">${actions}</div>
            </div></div>`;
        };
        draw();
        ui.qsheet = { id, draw };
        ov.onclick = async (e) => {
            const b = (s) => e.target.closest(s);
            if (e.target.matches('[data-close]') || b('button[data-close]')) { ov.innerHTML = ''; ui.qsheet = null; return; }
            if (b('[data-qaccept]')) {
                const ok = await act({ typ: 'zadanie', id, akcja: 'przyjmij' }, () => { const q = V.quests.find(x => x.id === id); if (q) { q.status = 'Przyjęte'; q.acceptedBy = { name: V.player.name, char: V.character?.name, charId: V.character?.id, at: new Date().toISOString() }; } });
                if (ok) { draw(); const st = ov.querySelector('.pl-stamp'); st?.classList.add('slam'); try { navigator.vibrate?.(60); } catch (er) {} toast('Zlecenie przyjęte!', 'good'); }
                return;
            }
            if (b('[data-qreport]')) {
                const ok = await act({ typ: 'zadanie', id, akcja: 'zglos' }, () => { const q = V.quests.find(x => x.id === id); if (q) q.reported = { name: V.player.name, char: V.character?.name, at: new Date().toISOString() }; });
                if (ok) { draw(); toast('Zgłoszono wykonanie — decyzja należy do Mistrza Gry.'); }
            }
        };
    }

    // ---------- czat i rzuty ----------
    function chatView() {
        return `<div class="pl-table"><div class="pl-log" id="pl-log"></div>
            <form class="pl-say ${ui.priv ? 'priv' : ''}" id="pl-say"><button type="button" class="pl-say-priv" id="pl-say-priv" aria-pressed="${ui.priv ? 'true' : 'false'}" title="Prywatnie do Mistrza Gry — reszta stołu nie zobaczy"><i class="fa-solid fa-user-secret"></i><span>Do MG</span></button><input id="pl-say-t" maxlength="600" placeholder="${ui.priv ? 'Prywatnie do Mistrza Gry… (też rzut, np. k20+5)' : 'Napisz do stołu albo rzuć, np. 2k6+3'}" autocomplete="off"><button class="btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i></button></form></div>`;
    }

    // ---------- stół do gier: ten sam stół co u MG, gracz wykonuje tylko swoje ruchy ----------
    const GAMES = {
        dice: { name: 'Kości', icon: 'fa-dice', desc: 'Każdy rzuca 2k6. Najwyższy wynik zgarnia pulę, remis = dogrywka.', min: 2 },
        blackjack: { name: 'Oczko', icon: 'fa-clover', desc: 'Dobieraj karty do 21 przeciw karczmarzowi. Oczko z ręki płaci 3:2.', min: 1 },
        highcard: { name: 'Wysoka karta', icon: 'fa-crown', desc: 'Każdy ciągnie jedną kartę. Najwyższa wygrywa, as jest najwyższy.', min: 2 },
        roulette: { name: 'Ruletka kości', icon: 'fa-skull', desc: 'Po kolei rzut k6 — kto wyrzuci 1, odpada. Ostatni zgarnia pulę.', min: 2 }
    };
    const tgSeen = new Map();          // klucz karty → co pokazywała (do animacji rozdania i odkrycia)
    const tgDie = (n, opts = {}) => { const pips = { 1: [5], 2: [1, 9], 3: [1, 5, 9], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] }[n] || []; return `<div class="tg-die ${opts.cls || ''}" style="${opts.color ? `--die:${opts.color}` : ''}">${Array.from({ length: 9 }, (_, i) => `<i class="${pips.includes(i + 1) ? 'on' : ''}"></i>`).join('')}</div>`; };
    function tgCard(c, key, extra = '') {
        if (!c) return '';
        const sig = c.down ? 'down' : `${c.val}${c.suit}`, was = tgSeen.get(key);
        let cls = was === undefined ? 'fly-pending' : (was === 'down' && sig !== 'down' ? 'reveal' : '');
        tgSeen.set(key, sig);
        if (c.down) return `<div class="tg-card3d down ${cls} ${extra}" data-cid="${key}"><div class="tg-inner"><div class="tg-card tg-front"></div><div class="tg-card tg-back back"></div></div></div>`;
        const face = 'JQK'.includes(c.val) ? `<div class="tg-face-art">${esc(c.val)}<small>${esc(c.suit)}</small></div>` : c.val === 'A' ? `<div class="tg-pip big">${esc(c.suit)}</div>` : `<div class="tg-pip">${esc(c.suit)}</div>`;
        return `<div class="tg-card3d ${cls} ${extra}" data-cid="${key}"><div class="tg-inner">
            <div class="tg-card tg-front ${esc(c.color)}"><span class="tg-idx tl">${esc(c.val)}<br>${esc(c.suit)}</span>${face}<span class="tg-idx br">${esc(c.val)}<br>${esc(c.suit)}</span></div>
            <div class="tg-card tg-back back"></div></div></div>`;
    }
    function tgLaunch() {
        const pile = $('#tg-deck'), cards = document.querySelectorAll('#pl-main .tg-card3d.fly-pending');
        if (!cards.length) return;
        const pr = pile ? pile.getBoundingClientRect() : null;
        cards.forEach((el, k) => {
            const r = el.getBoundingClientRect();
            el.style.setProperty('--dx', (pr ? (pr.left + pr.width / 2) - (r.left + r.width / 2) : 0) + 'px');
            el.style.setProperty('--dy', (pr ? (pr.top + pr.height / 2) - (r.top + r.height / 2) : -120) + 'px');
            el.style.setProperty('--delay', (k * 0.09) + 's');
            el.classList.remove('fly-pending'); el.classList.add('fly');
        });
    }
    function tableTurn(T) {
        const g = T?.game;
        if (!g || g.done) return null;
        if (g.kind === 'dice' || g.kind === 'highcard') return g.order?.[g.turn] ?? null;
        if (g.kind === 'roulette') return g.alive?.[g.turn] ?? null;
        if (g.kind === 'blackjack') return g.phase === 'play' ? g.current ?? null : null;
        return null;
    }
    function mySeat(T) { const id = V?.character?.id; return id ? (T?.players || []).find(p => p.type === 'pc' && p.refId === id) || null : null; }
    function myTableTurn() { const T = V?.table, me = mySeat(T); return !!me && tableTurn(T) === me.i; }
    function gamesView() {
        const T = V.table;
        const myId = V.character?.id;
        const offline = ui.mgOnline === false ? '<p class="pl-warn"><i class="fa-solid fa-plug-circle-xmark"></i> Mistrz Gry nie ma teraz otwartego panelu — ruchy zostaną rozpatrzone, gdy wróci.</p>' : '';
        if (!T) return `<div class="empty-state empty-state-wide pl-tg-empty"><i class="fa-solid fa-dice"></i><span>Stół do gier jest jeszcze pusty</span><small>Gdy Mistrz Gry otworzy karczemny stół, dosiądziesz się tutaj.</small>
            ${myId ? '<button class="btn-primary" data-gact="siadam"><i class="fa-solid fa-chair"></i> Dosiądź się</button>' : ''}</div>${offline}`;
        const P = T.players || [], g = T.game, me = mySeat(T), turn = tableTurn(T), busy = !!T.busy;
        const nameOf = (i) => esc(P[i]?.name || '?'), colorOf = (i) => P[i]?.color || '#8b1a1a';
        // miejsca przy stole
        const seats = P.map(p => {
            let cls = '', badge = '';
            if (g) {
                if (p.i === turn) cls = 'turn';
                if (g.kind === 'roulette' && g.out?.includes(p.i)) cls = 'out';
                if (g.winners?.includes(p.i)) cls = 'winner';
                if (g.kind === 'dice') { const r = g.rolls?.[p.i] || g.prev?.[p.i]; if (r) badge = `<div class="tg-seat-dice">${r.map(v => tgDie(v, { color: p.color })).join('')}<b>${r[0] + r[1]}</b></div>`; }
                if (g.kind === 'highcard') { const c = g.cards?.[p.i]; if (c && !c.down) badge = `<div class="tg-seat-dice"><span class="tg-mini ${esc(c.color)}">${esc(c.val)}${esc(c.suit)}</span></div>`; }
                if (g.kind === 'roulette' && g.out?.includes(p.i)) badge = '<div class="tg-seat-dice"><span class="tg-dead"><i class="fa-solid fa-skull"></i> odpadł</span></div>';
            }
            const mine = me && p.i === me.i;
            return `<div class="tg-seat ${cls} ${mine ? 'pl-tg-mine' : ''}" style="--seat:${p.color}">
                <div class="tg-seat-top"><span class="tg-seat-token"></span>
                    <div class="tg-seat-name"><b>${esc(p.name)}</b><small>${p.type === 'pc' ? 'Bohater' : p.type === 'npc' ? 'NPC' : 'Gość'}${mine ? ' · to Ty' : ''}</small></div>
                    ${mine ? '<span class="pl-tg-you">Ty</span>' : ''}</div>
                <div class="tg-purse"><span class="tg-coins"><i class="fa-solid fa-coins"></i> <b>${p.gold}</b> mz</span></div>
                ${badge}
            </div>`;
        }).join('');
        const TH = T.throw || null;
        // animujemy tylko świeży rzut (wejście na zakładkę później nie powtarza starego rzutu)
        const fresh = TH && Math.abs(Date.now() - parseInt(String(TH.id).slice(0, 8), 36)) < 15000;
        const tkey = (pos) => TH && fresh && pos != null && pos >= 0 ? `t${TH.id}-${pos}` : null;
        const cubeAt = (v, pos, color, cls = '') => window.TavernDice ? TavernDice.cube(v, { key: tkey(pos), color: color || undefined, cls }) : tgDie(v, { cls: 'big ' + cls, color });
        const deck = `<div class="tg-deck" id="tg-deck" title="Talia: ${T.deck} kart">${Array.from({ length: Math.max(1, Math.min(6, Math.ceil((T.deck || 0) / 9))) }, (_, k) => `<div class="tg-card back" style="--k:${k}"></div>`).join('')}<span>${T.deck}</span></div>`;
        const pot = g?.pot ? `<div class="tg-pot"><span class="tg-chips"></span>Pula: <b>${g.pot}</b> mz</div>` : '';
        // sukno
        let felt = '';
        if (T.throwing && TH) {
            felt = `<div class="tg-play">${pot}<div class="tg-row tg-dice-row">${TH.dice.map((d, k) => cubeAt(d.v, k, d.color)).join('')}</div>
                <div class="tg-status">${esc(String(TH.label || 'Kości toczą się po stole…').replace(/<[^>]+>/g, ''))}</div></div>`;
        } else if (!g) {
            const fd = T.free?.dice || [], fc = T.free?.cards || [];
            felt = fd.length || fc.length ? `<div class="tg-play">${deck}
                    ${fc.length ? `<div class="tg-row">${fc.map((c, k) => tgCard(c, 'f' + k)).join('')}</div>` : ''}
                    ${fd.length ? `<div class="tg-row tg-dice-row">${fd.map((v, i) => cubeAt(v, TH && TH.free ? TH.free.indexOf(i) : -1)).join('')}</div><div class="tg-note">Suma: <b>${T.free.sum}</b></div>` : ''}</div>`
                : `<div class="tg-menu pl-tg-menu">${Object.values(GAMES).map(x => `<div class="tg-game"><i class="fa-solid ${x.icon}"></i><b>${x.name}</b><span>${x.desc}</span><em>${x.min > 1 ? `od ${x.min} graczy` : 'od 1 gracza'}</em></div>`).join('')}</div>
                   <div class="tg-status">Mistrz Gry wybiera grę…</div>`;
        } else if (g.kind === 'dice') {
            const last = Object.keys(g.rolls || {}).length ? g.order.filter(i => g.rolls[i]).slice(-1)[0] : null;
            const status = g.done ? `<i class="fa-solid fa-trophy"></i> Wygrywa ${g.winners.map(nameOf).join(' i ')}!` : `${g.tieRound ? '<span class="tg-tag">Dogrywka</span> ' : ''}Rzuca: <b>${nameOf(turn)}</b>`;
            felt = `<div class="tg-play">${pot}
                <div class="tg-row tg-dice-row">${last != null ? g.rolls[last].map((v, j) => cubeAt(v, TH && TH.by && TH.by[last] ? TH.by[last][j] : -1, colorOf(last))).join('') : '<div class="tg-note">Kości czekają na pierwszy rzut…</div>'}</div>
                ${last != null ? `<div class="tg-note">${nameOf(last)}: <b>${g.rolls[last][0] + g.rolls[last][1]}</b></div>` : ''}
                <div class="tg-status ${g.done ? 'win' : ''}">${status}</div></div>`;
        } else if (g.kind === 'roulette') {
            const l = g.last;
            const status = g.done ? `<i class="fa-solid fa-trophy"></i> Ostatni przy życiu: ${nameOf(g.winners[0])}!` : `<i class="fa-solid fa-skull"></i> Rzuca: <b>${nameOf(turn)}</b> — jedynka odpada`;
            felt = `<div class="tg-play">${pot}
                <div class="tg-row tg-dice-row">${l ? cubeAt(l.v, TH && TH.by && TH.by[l.i] ? TH.by[l.i][0] : -1, colorOf(l.i), l.v === 1 ? 'fatal' : '') : '<div class="tg-note">Kto pierwszy?</div>'}</div>
                ${l ? `<div class="tg-note ${l.v === 1 ? 'bad' : 'good'}">${nameOf(l.i)}: ${l.v === 1 ? 'jedynka — odpada!' : `${l.v} — przeżywa`}</div>` : ''}
                <div class="tg-status ${g.done ? 'win' : ''}">${status}</div></div>`;
        } else if (g.kind === 'highcard') {
            const slots = g.order.map((i, k) => {
                const c = g.cards?.[i], isTurn = !g.done && k === g.turn && !c, won = g.winners?.includes(i);
                return `<div class="tg-labeled ${isTurn ? 'turn' : ''}" style="--seat:${colorOf(i)}">${c ? tgCard(c, 'hc' + i, won ? 'winner' : '') : `<div class="tg-slot ${isTurn ? 'turn' : ''}"><i class="fa-solid fa-hand"></i></div>`}<span>${nameOf(i)}</span></div>`;
            }).join('');
            felt = `<div class="tg-play">${deck}${pot}<div class="tg-row tg-hc-row">${slots}</div>
                <div class="tg-status ${g.done ? 'win' : ''}">${g.done ? `<i class="fa-solid fa-trophy"></i> Wygrywa ${nameOf(g.winners[0])}!` : (esc(g.msg) || `Ciągnie: <b>${nameOf(turn)}</b>`)}</div></div>`;
        } else if (g.kind === 'blackjack') {
            if (g.phase === 'select') felt = `<div class="tg-play"><div class="tg-status">Oczko — karczmarz zbiera zakłady (<b>${T.bet} mz</b>) i zaraz rozda karty…</div></div>`;
            else {
                const hands = (g.players || []).map(i => {
                    const h = g.hands[i]; if (!h) return '';
                    const res = h.result === 'win' ? `<span class="tg-res win">+${h.won - h.bet} mz</span>` : h.result === 'push' ? '<span class="tg-res">remis</span>' : h.result === 'lose' || h.bust ? '<span class="tg-res lose">przegrana</span>' : '';
                    return `<div class="tg-hand ${turn === i ? 'turn' : ''} ${me && me.i === i ? 'pl-tg-mine' : ''}" style="--seat:${colorOf(i)}">
                        <div class="tg-hand-head"><b>${nameOf(i)}</b><span class="tg-score ${h.score > 21 ? 'bust' : h.score === 21 ? 'bj' : ''}">${h.score}</span>${h.natural ? '<span class="tg-tag">oczko!</span>' : ''}${h.bet > T.bet ? '<span class="tg-tag">×2</span>' : ''}${res}</div>
                        <div class="tg-row tight">${h.cards.map((c, k) => tgCard(c, `h${i}-${k}`)).join('')}</div></div>`;
                }).join('');
                const ds = g.dealerScore;
                felt = `<div class="tg-play">${deck}
                    <div class="tg-dealer"><div class="tg-hand-head"><b><i class="fa-solid fa-beer-mug-empty"></i> Karczmarz</b>${ds != null ? `<span class="tg-score ${ds > 21 ? 'bust' : ''}">${ds}</span>` : ''}</div><div class="tg-row tight">${(g.dealer || []).map((c, k) => tgCard(c, 'd' + k)).join('')}</div></div>
                    <div class="tg-hands">${hands}</div>
                    ${g.done ? '<div class="tg-status win">Rozdanie zakończone</div>' : g.phase === 'play' ? `<div class="tg-status">Ruch: <b>${nameOf(turn)}</b>${g.hands?.[turn] ? ` (${g.hands[turn].score})` : ''}</div>` : `<div class="tg-status">${esc(g.msg) || 'Karczmarz rozdaje karty…'}</div>`}</div>`;
            }
        }
        // ruchy gracza: dosiąść się, jeszcze jedna runda, rzut w swojej turze
        const dis = busy || ui.gwait ? 'disabled' : '';
        const leave = '<button class="btn-secondary" data-gact="wstaje"><i class="fa-solid fa-person-walking-arrow-right"></i> Odejdź od stołu</button>';
        let acts = '';
        if (ui.gwait) acts = '<button class="btn-secondary" disabled><i class="fa-solid fa-spinner fa-spin"></i> Karczmarz przyjmuje ruch…</button>';
        else if (!myId) acts = '<span class="tg-note">Mistrz Gry nie przypisał Ci jeszcze postaci.</span>';
        else if (!me) acts = g && !g.done ? '<button class="btn-primary" disabled><i class="fa-solid fa-chair"></i> Dosiądziesz się po tej grze</button>' : '<button class="btn-primary" data-gact="siadam"><i class="fa-solid fa-chair"></i> Dosiądź się do stołu</button>';
        else if (!g) acts = `<span class="tg-note"><i class="fa-solid fa-hourglass-half"></i> Siedzisz przy stole — czekamy, aż Mistrz Gry wybierze grę.</span>${leave}`;
        else if (g.done) acts = `<button class="btn-primary" data-gact="gram" ${dis}><i class="fa-solid fa-rotate-right"></i> Jeszcze jedna runda (${T.bet} mz)</button>${leave}`;
        else if (turn === me.i) {
            if (g.kind === 'dice') acts = `<button class="btn-primary pl-tg-go" data-gact="rzut" ${dis}><i class="fa-solid fa-dice"></i> Rzuć 2k6</button>`;
            else if (g.kind === 'roulette') acts = `<button class="btn-danger pl-tg-go" data-gact="rzut" ${dis}><i class="fa-solid fa-dice-one"></i> Rzuć k6</button>`;
            else if (g.kind === 'highcard') acts = `<button class="btn-primary pl-tg-go" data-gact="rzut" ${dis}><i class="fa-solid fa-clone"></i> Ciągnij kartę</button>`;
            else if (g.kind === 'blackjack') acts = `<button class="btn-primary pl-tg-go" data-gact="dobierz" ${dis}><i class="fa-solid fa-hand-pointer"></i> Dobierz</button><button class="btn-secondary" data-gact="pas" ${dis}><i class="fa-solid fa-hand"></i> Pas</button>${g.hands?.[me.i]?.cards?.length === 2 ? `<button class="btn-secondary" data-gact="podwoj" ${dis}><i class="fa-solid fa-coins"></i> Podwój</button>` : ''}`;
        } else if (g.kind === 'blackjack' && g.phase !== 'select' && !(g.players || []).includes(me.i)) acts = '<span class="tg-note">Nie grasz w tym rozdaniu — dołączysz w następnej rundzie.</span>';
        else acts = `<button class="btn-secondary" disabled><i class="fa-solid fa-hourglass-half"></i> ${turn != null ? `Teraz kolej: ${nameOf(turn)}` : 'Chwileczkę…'}</button>`;

        const hist = T.history || [];
        const names = P.map(p => ({ n: esc(p.name || ''), c: p.color || '#8b1a1a' })).filter(x => x.n.length > 1).sort((a, b) => b.n.length - a.n.length);
        const rx = names.length ? new RegExp(names.map(x => x.n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'g') : null;
        const who = (msg) => { const h = esc(msg); return rx ? h.replace(rx, (m) => { const x = names.find(y => y.n === m); return `<b class="tg-who" style="color:${/^#(e|f|d)/i.test(x.c) ? '#6b4a2b' : x.c}">${m}</b>`; }) : h; };
        return `<div class="tg-layout pl-tg ${busy ? 'is-busy' : ''}">
            <div class="tg-side">
            <aside class="tg-seats">
                <div class="tg-panel-head"><h3><i class="fa-solid fa-chair"></i> Przy stole</h3><span>${P.length}/8</span></div>
                <div class="tg-seat-list">${seats || '<div class="empty-state"><i class="fa-solid fa-chair"></i><span>Stół czeka na graczy</span></div>'}</div>
            </aside>
                <div class="tg-log">
                    <div class="tg-panel-head"><h3><i class="fa-solid fa-scroll"></i> Kronika stołu</h3></div>
                    <div class="tg-log-list">${hist.length ? hist.map(h => `<div class="${esc(h.kind || '')}"><time>${esc(h.time)}</time>${who(h.msg)}</div>`).join('') : '<div class="tg-log-empty">Jeszcze nic się nie wydarzyło.</div>'}</div>
                </div>
            </div>
            <section class="tg-main">
                <div class="tg-table">
                    <div class="tg-table-head"><span class="tg-game-name">${g ? esc(GAMES[g.kind]?.name || g.name) : 'Karczemny stół'}</span>
                        <span class="tg-meta"><i class="fa-solid fa-clone"></i> ${T.deck}/52 <span class="tg-bet">Zakład <b>${T.bet} mz</b></span></span></div>
                    <div class="tg-felt">${felt}</div>
                    <div class="tg-actions">${acts}</div>
                </div>
                ${offline}
            </section>
        </div>`;
    }
    function rollHTML(r) {
        const parts = r.parts.map(p => p.die ? `${p.sign < 0 ? '−' : ''}${p.die} [${p.rolls.join(', ')}${p.dropped != null ? ` <s>${p.dropped}</s>` : ''}]` : `${p.mod < 0 ? '−' : '+'}${Math.abs(p.mod)}`).join(' ');
        return `<span class="pl-roll ${r.crit ? 'c-' + r.crit : ''}"><b>${r.total}</b><small>${esc(r.expr)}${r.mode === 'adv' ? ' · ułatwienie' : r.mode === 'dis' ? ' · utrudnienie' : ''} — ${parts}</small></span>`;
    }
    function renderLog() {
        const el = $('#pl-log'); if (!el) return;
        ui.unread = 0; tabsBadges();
        el.innerHTML = log.length ? log.slice(-120).map(e => `<div class="pl-entry r-${e.rola} t-${e.typ} ${e.pid && e.pid === V?.player?.id ? 'mine' : ''} ${e.szept ? 'whisper' : ''}" style="--who:${/^#[0-9a-f]{6}$/i.test(e.kolor || '') ? e.kolor : '#c9a35c'}">
            <div class="pl-entry-h"><i class="who-dot">${esc(String(e.postac || e.kto || '?').trim().charAt(0).toUpperCase())}${e.av && window.Portrait ? Portrait.img(Portrait.fromAv(e.av)) : ''}</i><b>${esc(e.postac || e.kto)}</b>${e.postac ? `<span>${esc(e.kto)}</span>` : ''}<time>${new Date(e.t).toLocaleTimeString(window.LOC || 'pl-PL', { hour: '2-digit', minute: '2-digit' })}</time></div>
            ${e.szept ? `<div class="pl-whisper-tag"><i class="fa-solid fa-user-secret"></i> ${e.dla === 'mg' ? 'prywatnie do Mistrza Gry' : 'prywatnie — tylko dla ciebie'}</div>` : ''}
            ${e.typ === 'rzut' ? `<div>${e.opis ? `<em>${esc(e.opis)}</em> ` : ''}${rollHTML(e.rzut)}</div>` : `<div>${esc(e.tekst)}</div>`}</div>`).join('') : '<p class="pl-muted pl-center">Tu widać rzuty i wiadomości całego stołu.</p>';
        el.scrollTop = el.scrollHeight;
        const f = $('#pl-say');
        if (f) f.onsubmit = async (e) => {
            e.preventDefault();
            const inp = $('#pl-say-t'), v = inp.value.trim(); if (!v) return;
            if (JAKO) { toast('To tylko podgląd.'); return; }
            const isRoll = /^[+-]?\d*[kd]\d+([+-](\d*[kd]\d+|\d+))*$/i.test(v.replace(/\s+/g, ''));
            const priv = ui.priv ? { szept: true } : null;
            try {
                if (isRoll) await roll(v, '', undefined, priv); else await api('/api/dziennik', { typ: 'wiad', tekst: v, ...(priv || {}) });
                inp.value = '';
            } catch (er) { toast(er.message, 'bad'); }
        };
        const pb = $('#pl-say-priv');
        if (pb) pb.onclick = () => {
            ui.priv = !ui.priv;
            f.classList.toggle('priv', ui.priv); pb.setAttribute('aria-pressed', ui.priv ? 'true' : 'false');
            const inp = $('#pl-say-t'); inp.placeholder = ui.priv ? 'Prywatnie do Mistrza Gry… (też rzut, np. k20+5)' : 'Napisz do stołu albo rzuć, np. 2k6+3'; inp.focus();
        };
    }

    // ---------- mapy ----------
    const W = 2500, Hh = 1600;
    function mapsList() {
        const L = V.locations || [], out = [];
        const used = new Set(L.map(l => l.mapType || 'world'));
        const wd = V.atlas?.world;
        Object.entries(BUILTIN).forEach(([id, b]) => {
            if (!(id === 'world' || used.has(id) || V.atlas?.maps?.[id])) return;
            // mapa świata może być własna dla kampanii (obraz i nazwa od Mistrza Gry)
            if (id === 'world' && wd) out.push({ id, name: wd.name || b.name, url: wd.v ? `/api/mapa-swiata?v=${encodeURIComponent(wd.v)}` : b.url, kind: 'world', dim: wd.w && wd.h ? { w: wd.w, h: wd.h } : null });
            else out.push({ id, name: b.name, url: b.url, kind: id === 'world' ? 'world' : 'local' });
        });
        L.filter(l => l.hasSubmap).forEach(l => out.push({ id: l.id, name: l.name, url: l.submapUrl || DEFAULT_SUBMAP, kind: l.interior ? 'interior' : 'local' }));
        return out;
    }
    // gracze zawsze widzą mapę, na której jest Mistrz Gry (nie przełączają jej sami)
    const sceneOn = () => { const s = V?.scena; return !!(s?.mapId && mapsList().some(m => m.id === s.mapId)); };
    function currentMap() {
        const list = mapsList();
        let id = sceneOn() ? V.scena.mapId : null;
        if (!id && V.live?.kind === 'mapa') id = V.live.mapId;
        if (!id && V.atlas?.party) id = (V.locations || []).find(l => l.id === V.atlas.party)?.mapType;
        return list.find(m => m.id === id) || list[0];
    }
    function interiorOf(id) { const it = V.atlas?.maps?.[id]?.interior; return it && MapForge.migrate(JSON.parse(JSON.stringify(it))); }
    // rysunek wnętrza jako obrazek: ten sam rysunek = ten sam adres (bez przeładowania i mignięcia przy każdej zmianie danych)
    const svgCache = new Map();
    const svgUrl = (lv) => {
        const svg = MapForge.svg(lv, { player: true });
        let hit = svgCache.get(svg);
        if (!hit) {
            hit = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
            svgCache.set(svg, hit);
            while (svgCache.size > 6) { const [k, u] = svgCache.entries().next().value; svgCache.delete(k); setTimeout(() => URL.revokeObjectURL(u), 5000); }
        }
        return hit;
    };
    function mapView() {
        const m = currentMap(); if (!m) return '<div class="pl-empty"><p>Brak map.</p></div>';
        const meta = V.atlas?.maps?.[m.id] || {};
        let inner = '', w = W, h = Hh, grid = null, tok = null, lvSel = '';
        if (m.kind === 'interior') {
            const it = interiorOf(m.id);
            if (!it) return `<div class="pl-empty"><p>Ta mapa nie jest jeszcze gotowa.</p></div>`;
            const sceneLv = sceneOn() && V.scena.mapId === m.id ? V.scena.levelId : null;
            let li = it.levels.findIndex(L => L.id === (sceneLv || (V.live?.mapId === m.id && V.live.levelId)));
            if (li < 0) li = it.ground ?? 0;
            const lv = it.levels[li]; const d = MapForge.dims(lv); w = d.w; h = d.h;
            grid = { show: true, size: MapForge.CELL, ox: 0, oy: 0, alpha: 0.3 };
            tok = (meta.tokensL || {})[lv.id];
            ui.geo = { kind: 'interior', lv, mapId: m.id, levelId: lv.id, cell: MapForge.CELL, ox: 0, oy: 0, tok };
            inner = `<img class="pl-mapimg" src="${svgUrl(lv)}" alt="" data-keep="bg">`;
            if (it.levels.length > 1) lvSel = `<span class="pl-maplv"><i class="fa-solid fa-stairs"></i> ${esc(lv.name)}</span>`;
        } else {
            if (m.dim) { w = m.dim.w; h = m.dim.h; }
            inner = `<img class="pl-mapimg" src="${esc(m.url)}" alt="" style="width:100%;height:100%" data-keep="bg">`;
            if (m.kind !== 'world') { grid = { show: true, size: 70, ox: 0, oy: 0, alpha: 0.3, ...(meta.grid || {}) }; tok = meta.tokens; }
            ui.geo = m.kind === 'world' ? null : { kind: 'local', mapId: m.id, levelId: null, cell: grid.size, ox: grid.ox || 0, oy: grid.oy || 0, w, h, tok };
        }
        const here = (V.locations || []).filter(l => (l.mapType || 'world') === m.id && l.x != null);
        const pins = m.kind === 'interior' ? '' : here.filter(l => l.type !== 'region').sort((a, b) => a.y - b.y).map(l => window.MapEmblems
            ? MapEmblems.pin(l, { cls: `${V.atlas?.party === l.id ? 'here' : ''} ${ui.pinSel === l.id ? 'sel' : ''}`, attr: `data-pin="${esc(l.id)}"`, label: esc(l.name), name: esc(l.name), mini: ui.minis })
            : `<button class="pl-pin" data-pin="${esc(l.id)}" style="left:${l.x}%;top:${l.y}%"><i class="fa-solid fa-location-dot"></i><span>${esc(l.name)}</span></button>`).join('')
            + here.filter(l => l.type === 'region').map(l => `<div class="atl-region" style="left:${l.x}%;top:${l.y}%;--rot:${l.rotation || 0}deg">${esc(l.name)}</div>`).join('');
        const partyLoc = m.kind === 'interior' ? null : here.find(l => l.id === V.atlas?.party);
        const partyMark = partyLoc && window.MapEmblems ? `<div class="atl-party mp-party" style="left:${partyLoc.x}%;top:${partyLoc.y}%" title="Drużyna jest tutaj">${MapEmblems.banner}</div>` : '';
        const seen = new Set(), segs = [];
        if (m.kind !== 'interior') here.forEach(a => (a.connections || []).forEach(c => {
            const b = here.find(x => x.id === (typeof c === 'string' ? c : c.id)); if (!b) return;
            const key = [a.id, b.id].sort().join('|'); if (seen.has(key)) return; seen.add(key);
            segs.push({ a, b, style: (typeof c === 'string' ? 'road' : c.style) || 'road', key });
        }));
        const lines = !segs.length ? '' : window.MapEmblems?.routes ? MapEmblems.routes(segs)
            : segs.map(({ a, b }) => `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" vector-effect="non-scaling-stroke"/>`).join('');
        const chars = (V.party || []).map(c => ({ id: c.id, name: c.name, class: c.class, hp: c.hp, pv: c.pv }));
        const list = mapsList();
        const myId = V.character?.id;
        const canMove = !!(tok && grid && tok.mode === 'split' && myId && tok.chars?.[myId] && meta.playersMove !== false && !JAKO);
        let tokHTML = tok && grid ? MapForge.tokensHTML(tok, grid, chars, { player: true, lv: m.kind === 'interior' ? ui.geo?.lv : null, comps: (V.companions || []).map(c => ({ id: c.id, name: c.name, owner: c.owner, size: c.size, hp: c.hp })) }) : '';
        if (tok && grid && myId) tokHTML = tokHTML.replace(`data-tok="${myId}"`, `data-tok="${myId}" ${canMove ? 'data-mine="1"' : ''} data-me="1"`);
        // mgła wojny we wnętrzu (MG włącza ją na mapie)
        let fogHTML = '';
        if (meta.fog && m.kind === 'interior' && ui.geo?.lv && tok) {
            const lv = ui.geo.lv, dvOf = (id) => MapForge.darkvisionOf(((V.party || []).find(p => p.id === id) || {}).race);
            const viewers = tok.mode === 'split'
                ? Object.entries(tok.chars || {}).filter(([id]) => meta.fogShare !== false || id === myId).map(([id, p]) => ({ x: p.x, y: p.y, n: 1, dv: dvOf(id) }))
                : (tok.party ? [{ x: tok.party.x, y: tok.party.y, n: 1, dv: Math.max(0, ...(V.party || []).map(p => dvOf(p.id))) }] : []);
            // towarzysz idący osobno też się rozgląda
            if (meta.fogShare !== false) Object.entries(tok.comp || {}).forEach(([nid, p]) => { const cp = (V.companions || []).find(x => x.id === nid && !x.owner); if (cp && p) viewers.push({ x: p.x, y: p.y, n: 1, dv: cp.stats?.senses?.darkvision ? Math.round(cp.stats.senses.darkvision / 5) : 0 }); });
            fogHTML = `<svg class="vt-fog pl-fog" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${fogLayer({ kind: 'interior', lv, w, h, cell: MapForge.CELL, ox: 0, oy: 0, cols: lv.cols, rows: lv.rows }, null, `mapa:${m.id}:${lv.id}`, viewers, {})}</svg>`;
        }
        return `<div class="pl-mapbar"><span class="pl-mapname" id="pl-mapname" data-map="${esc(m.id)}"><i class="fa-solid fa-map-location-dot"></i><span><small>Mapa Mistrza Gry</small><b>${esc(m.name)}</b></span></span>${lvSel}
                ${m.kind !== 'interior' && window.MapEmblems?.mini ? `<button class="pl-btn ${ui.minis ? 'on' : ''}" data-minis title="Makiety 3D pod znacznikami"><i class="fa-solid fa-cubes"></i></button>` : ''}
</div>
            <div class="pl-vp" id="pl-vp" data-mapkey="${esc(m.id)}">
                <div class="pl-map" id="pl-map" style="width:${w}px;height:${h}px">${inner}
                    ${grid ? MapForge.gridHTML(grid) : ''}
                    ${lines ? `<svg class="pl-lines" viewBox="0 0 100 100" preserveAspectRatio="none">${lines}</svg>` : ''}
                    ${pins}${partyMark}
                    ${tokHTML}${fogHTML}
                </div>
                <div class="pl-maphint"><i class="fa-solid fa-hand-pointer"></i> ${canMove ? 'Przeciągnij swój pionek · ' : ''}przytrzymaj, by wskazać</div>
                <div class="pl-zoom"><button data-z="in">+</button><button data-z="out">−</button><button data-z="fit"><i class="fa-solid fa-expand"></i></button></div>
            </div>
            <div class="pl-pininfo" id="pl-pininfo" hidden></div>`;
    }
    // przejście między mapami: zbliżenie do miejsca, do którego wchodzi MG (albo odjazd), potem nowa mapa wjeżdża z banerem
    function mapTransition(prev, next) {
        const board = $('#pl-map'), vp = $('#pl-vp');
        ui.banner = true;
        if (!board || !vp) { render(); return; }
        const pin = board.querySelector(`[data-pin="${CSS.escape(next.mapId)}"]`);
        const tr = new DOMMatrix(getComputedStyle(board).transform);
        let tf;
        if (pin) {
            const cx = parseFloat(pin.style.left) / 100 * board.offsetWidth, cy = parseFloat(pin.style.top) / 100 * board.offsetHeight, k = tr.a * 3.2;
            tf = `translate(${vp.clientWidth / 2 - cx * k}px, ${vp.clientHeight / 2 - cy * k}px) scale(${k})`;
            board.style.setProperty('--inv', 1 / k);
        } else tf = `translate(${tr.e + vp.clientWidth * .1}px, ${tr.f + vp.clientHeight * .1}px) scale(${tr.a * .8})`;
        board.style.transition = 'none'; void board.offsetWidth; board.style.transition = '';
        board.classList.add('pl-leave');
        void board.offsetWidth;            // wymuś przeliczenie, żeby przejście ruszyło od razu
        board.style.transform = tf;
        vp.classList.add('pl-vp-leave');
        let done = false;
        const go = () => { if (done) return; done = true; render(); };
        board.addEventListener('transitionend', (e) => { if (e.propertyName === 'transform') go(); }, { once: false });
        setTimeout(go, 1200);
    }
    function mapBanner() {
        const vp = $('#pl-vp'); if (!vp || !ui.banner) return;
        ui.banner = false;
        vp.classList.add('pl-enter');
        const m = currentMap(), lvName = ui.geo?.lv?.name;
        const b = document.createElement('div');
        b.className = 'pl-mapbanner';
        b.innerHTML = `<small>Mistrz Gry prowadzi was do</small><b>${esc(m?.name || 'nowej mapy')}</b>${lvName && ui.geo.kind === 'interior' ? `<span>${esc(lvName)}</span>` : ''}`;
        vp.appendChild(b);
        setTimeout(() => b.classList.add('out'), 2300);
        setTimeout(() => b.remove(), 2900);
        // gdzie jesteśmy: puls na moim pionku albo na chorągwi drużyny
        setTimeout(() => { $('#pl-map')?.querySelectorAll('.mf-token[data-me], .mf-token.party, .atl-party').forEach(el => { el.classList.remove('pl-pulse'); void el.offsetWidth; el.classList.add('pl-pulse'); }); }, 500);
    }
    function panZoom(vp, board, key, w, h, focus) {
        const st = ui.z[key] || (ui.z[key] = { z: 0, x: 0, y: 0 });
        // jak u Mistrza Gry: nie da się oddalić dalej niż cała mapa na ekranie, a mapa nie ucieka poza widok
        // mapa zawsze wypełnia okno — nie da się jej oddalić bardziej, niż zajmuje
        const fitK = () => Math.max(vp.clientWidth / w, vp.clientHeight / h);
        const minZ = () => fitK(), maxZ = () => Math.max(2.5, fitK() * 4);
        const clamp = () => {
            st.z = Math.max(minZ(), Math.min(maxZ(), st.z));
            const mw = w * st.z, mh = h * st.z, vw = vp.clientWidth, vh = vp.clientHeight;
            st.x = mw <= vw ? (vw - mw) / 2 : Math.min(0, Math.max(vw - mw, st.x));
            st.y = mh <= vh ? (vh - mh) / 2 : Math.min(0, Math.max(vh - mh, st.y));
        };
        const apply = () => { clamp(); board.style.transform = `translate(${st.x}px, ${st.y}px) scale(${st.z})`; board.style.setProperty('--inv', 1 / st.z); board.style.setProperty('--mf', Math.max(.8, Math.min(1.4, st.z)).toFixed(4)); };
        const fit = () => { const k = fitK(); st.z = k; st.x = (vp.clientWidth - w * k) / 2; st.y = (vp.clientHeight - h * k) / 2; apply(); };
        const zoomAt = (nz, cx, cy) => { nz = Math.max(minZ(), Math.min(maxZ(), nz)); const bx = (cx - st.x) / st.z, by = (cy - st.y) / st.z; st.z = nz; st.x = cx - bx * nz; st.y = cy - by * nz; apply(); };
        if (!st.z) {
            fit();
            if (focus) { const z = Math.min(1.2, Math.max(st.z, vp.clientWidth / (focus.span || 9))); st.z = z; st.x = vp.clientWidth / 2 - focus.x * z; st.y = vp.clientHeight / 2 - focus.y * z; apply(); }
        } else apply();
        const pts = new Map(); let last = null, moved = false;
        vp.onpointerdown = (e) => {
            vp.dataset.panning = '1';
            if (e.target.closest('.pl-zoom, .pl-pin, .atl-pin, [data-mine]')) return;
            pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); vp.setPointerCapture(e.pointerId); last = null; moved = false;
        };
        vp.onpointermove = (e) => {
            if (!pts.has(e.pointerId)) return;
            const prev = pts.get(e.pointerId); pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
            if (pts.size === 1) { st.x += e.clientX - prev.x; st.y += e.clientY - prev.y; if (Math.abs(e.clientX - prev.x) + Math.abs(e.clientY - prev.y) > 1) moved = true; apply(); }
            else if (pts.size === 2) {
                const [a, b] = [...pts.values()], d = Math.hypot(a.x - b.x, a.y - b.y);
                const r = vp.getBoundingClientRect();
                if (last) zoomAt(st.z * d / last, (a.x + b.x) / 2 - r.left, (a.y + b.y) / 2 - r.top);
                last = d; moved = true;
            }
        };
        vp.onpointerup = vp.onpointercancel = (e) => { pts.delete(e.pointerId); if (pts.size < 2) last = null; if (!pts.size) { delete vp.dataset.panning; flushRender(); } };
        vp.onwheel = (e) => { e.preventDefault(); const r = vp.getBoundingClientRect(); zoomAt(st.z * (e.deltaY < 0 ? 1.15 : 1 / 1.15), e.clientX - r.left, e.clientY - r.top); };
        vp.querySelector('.pl-zoom')?.addEventListener('click', (e) => {
            const z = e.target.closest('[data-z]')?.dataset.z; if (!z) return;
            if (z === 'me') return;
            if (z === 'fit') fit(); else zoomAt(st.z * (z === 'in' ? 1.25 : 0.8), vp.clientWidth / 2, vp.clientHeight / 2);
        });
        return { st, moved: () => moved };
    }
    function bindMap() {
        const vp = $('#pl-vp'), board = $('#pl-map'); if (!vp || !board) return;
        const w = parseFloat(board.style.width), h = parseFloat(board.style.height);
        let pz = null;
        // ping: przytrzymaj palec / dwuklik na mapie
        const sendPing = (cx, cy) => {
            if (JAKO) return;
            const r = board.getBoundingClientRect();
            const x = +((cx - r.left) / r.width * 100).toFixed(2), y = +((cy - r.top) / r.height * 100).toFixed(2);
            if (x < 0 || y < 0 || x > 100 || y > 100) return;
            api('/api/wskaz', { mapId: vp.dataset.mapkey, levelId: ui.geo?.levelId || null, x, y }).catch(er => toast(er.message, 'bad'));
            try { navigator.vibrate?.(20); } catch (er) {}
        };
        let hold = null;
        vp.addEventListener('pointerdown', (e) => {
            if (e.target.closest('.pl-zoom, [data-mine], .atl-pin')) return;
            clearTimeout(hold?.t); const sx = e.clientX, sy = e.clientY;
            hold = { sx, sy, t: setTimeout(() => { sendPing(sx, sy); hold = null; }, 550) };
        });
        vp.addEventListener('pointermove', (e) => { if (hold && Math.hypot(e.clientX - hold.sx, e.clientY - hold.sy) > 9) { clearTimeout(hold.t); hold = null; } });
        ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => vp.addEventListener(ev, () => { if (hold) { clearTimeout(hold.t); hold = null; } }));
        vp.addEventListener('dblclick', (e) => { if (!e.target.closest('.pl-zoom, [data-mine], .atl-pin')) { e.preventDefault(); sendPing(e.clientX, e.clientY); } });
        vp.addEventListener('contextmenu', (e) => e.preventDefault());
        const meEl = board.querySelector('.mf-token[data-me]');
        const focus = meEl && ui.geo ? { x: parseFloat(meEl.style.left), y: parseFloat(meEl.style.top), span: ui.geo.cell * 9 } : null;
        requestAnimationFrame(() => { pz = panZoom(vp, board, `map:${vp.dataset.mapkey}:${ui.geo?.levelId || ''}`, w, h, focus); });
        const mine = board.querySelector('.mf-token[data-mine]'), G = ui.geo;
        if (mine && G) {
            const myId = V.character.id, start = G.tok.chars[myId];
            let drag = null;
            const blocked = (x, y) => {
                if (x < 0 || y < 0) return 'Poza mapą';
                if (G.kind === 'interior') { if (x >= G.lv.cols || y >= G.lv.rows) return 'Poza mapą'; if ((BLOCK + 'S').includes(G.lv.walls[y * G.lv.cols + x] || '.')) return 'Tam nie można stanąć'; }
                else if ((G.ox + (x + 1) * G.cell) > G.w || (G.oy + (y + 1) * G.cell) > G.h) return 'Poza mapą';
                const busy = [...Object.entries(G.tok.chars || {}).filter(([id]) => id !== myId).map(([, p]) => ({ ...p, size: 1 })), ...(G.tok.others || []).filter(o => (o.hp ?? 1) > 0)]
                    .some(o => { const n = o.size || 1; return x < o.x + n && x + 1 > o.x && y < o.y + n && y + 1 > o.y; });
                return busy ? 'To pole jest zajęte' : '';
            };
            const ghost = document.createElement('div'); ghost.className = 'pl-ghostcell'; ghost.hidden = true; ghost.style.width = ghost.style.height = G.cell + 'px'; board.appendChild(ghost);
            mine.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); mine.setPointerCapture(e.pointerId); drag = { sx: e.clientX, sy: e.clientY, nx: start.x, ny: start.y }; mine.classList.add('dragging'); });
            mine.addEventListener('pointermove', (e) => {
                if (!drag) return;
                const z = pz?.st.z || 1, dx = (e.clientX - drag.sx) / z, dy = (e.clientY - drag.sy) / z;
                mine.style.left = (G.ox + (start.x + .5) * G.cell + dx) + 'px'; mine.style.top = (G.oy + (start.y + .5) * G.cell + dy) + 'px';
                drag.nx = start.x + Math.round(dx / G.cell); drag.ny = start.y + Math.round(dy / G.cell);
                const why = blocked(drag.nx, drag.ny);
                ghost.hidden = false; ghost.classList.toggle('bad', !!why); ghost.title = why;
                ghost.style.left = (G.ox + drag.nx * G.cell) + 'px'; ghost.style.top = (G.oy + drag.ny * G.cell) + 'px';
            });
            const drop = async () => {
                if (!drag) return; const d = drag; drag = null; ghost.hidden = true; mine.classList.remove('dragging');
                const back = () => { mine.style.left = (G.ox + (start.x + .5) * G.cell) + 'px'; mine.style.top = (G.oy + (start.y + .5) * G.cell) + 'px'; };
                if (d.nx === start.x && d.ny === start.y) { back(); return; }
                const why = blocked(d.nx, d.ny);
                if (why) { back(); toast(why, 'bad'); return; }
                mine.style.left = (G.ox + (d.nx + .5) * G.cell) + 'px'; mine.style.top = (G.oy + (d.ny + .5) * G.cell) + 'px';
                const ok = await act({ typ: 'pionek', mapId: G.mapId, levelId: G.levelId, x: d.nx, y: d.ny }, () => { G.tok.chars[myId] = { ...G.tok.chars[myId], x: d.nx, y: d.ny }; });
                if (!ok) back();
            };
            mine.addEventListener('pointerup', drop); mine.addEventListener('pointercancel', drop);
        }
        board.onclick = (e) => {
            const p = e.target.closest('[data-pin]'); const box = $('#pl-pininfo');
            board.querySelectorAll('.atl-pin.sel').forEach(x => x.classList.remove('sel'));
            if (!p) { box.hidden = true; ui.pinSel = null; return; }
            p.classList.add('sel'); ui.pinSel = p.dataset.pin;
            const l = (V.locations || []).find(x => x.id === p.dataset.pin); if (!l) return;
            box.hidden = false;
            box.innerHTML = `<button class="pl-icon" data-pinclose><i class="fa-solid fa-xmark"></i></button><h4>${esc(l.name)}</h4>${l.text ? `<p>${esc(l.text)}</p>` : '<p class="pl-muted">Nic więcej o tym miejscu nie wiecie.</p>'}`;
        };
    }

    // ---------- walka ----------
    function sceneGeo(sc) {
        if (!sc) return null;
        if (sc.kind === 'atlas') {
            const it = interiorOf(sc.mapId);
            if (it) { const lv = it.levels.find(L => L.id === sc.levelId) || it.levels[it.ground ?? 0]; const d = MapForge.dims(lv); return { kind: 'interior', lv, w: d.w, h: d.h, cell: MapForge.CELL, ox: 0, oy: 0 }; }
            const m = mapsList().find(x => x.id === sc.mapId);
            if (m) return { kind: 'local', url: m.url, w: W, h: Hh, cell: sc.cell || 70, ox: sc.ox || 0, oy: sc.oy || 0 };
        }
        if (sc.kind === 'image' && sc.url) return { kind: 'image', url: sc.url, w: sc.w, h: sc.h, cell: sc.cell, ox: sc.ox || 0, oy: sc.oy || 0 };
        return { kind: 'blank', bg: sc.bg || 'stone', w: (sc.cols || 26) * (sc.cell || 70), h: (sc.rows || 18) * (sc.cell || 70), cell: sc.cell || 70, ox: 0, oy: 0 };
    }
    function tplSVG(t, cell) {
        const col = ({ fire: '#ff6a1a', cold: '#6cc8ff', lightning: '#f3e96a', acid: '#8fe04a', necrotic: '#a066ff', radiant: '#ffe9a8' })[t.el] || '#ff6a1a';
        const dx = t.x1 - t.x0, dy = t.y1 - t.y0, L = Math.hypot(dx, dy), ang = Math.atan2(dy, dx);
        let sh = '';
        if (t.type === 'sphere') sh = `<circle cx="${t.x0}" cy="${t.y0}" r="${L}"/>`;
        else if (t.type === 'cone') { const px = -Math.sin(ang) * L / 2, py = Math.cos(ang) * L / 2; sh = `<path d="M${t.x0} ${t.y0} L${t.x1 + px} ${t.y1 + py} L${t.x1 - px} ${t.y1 - py} Z"/>`; }
        else if (t.type === 'line') { const hw = cell / 2, nx = -Math.sin(ang) * hw, ny = Math.cos(ang) * hw; sh = `<path d="M${t.x0 + nx} ${t.y0 + ny} L${t.x1 + nx} ${t.y1 + ny} L${t.x1 - nx} ${t.y1 - ny} L${t.x0 - nx} ${t.y0 - ny} Z"/>`; }
        else if (t.type === 'cube') { const s = Math.max(Math.abs(dx), Math.abs(dy)); sh = `<rect x="${dx < 0 ? t.x0 - s : t.x0}" y="${dy < 0 ? t.y0 - s : t.y0}" width="${s}" height="${s}"/>`; }
        return `<g class="vt-t" style="--c:${col}"><g class="vt-t-shape">${sh}</g></g>`;
    }
    // zanim MG ogłosi walkę: zamiast planszy — gotowość bohatera, drużyna i ściąga tury
    function calmView() {
        const ch = V.character;
        const sg = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);
        let me = '';
        if (ch) {
            const A = ch.abilityScores || {}, hp = ch.hp || { current: 0, max: 0, temp: 0 };
            const pct = hp.max ? Math.max(0, Math.min(100, hp.current / hp.max * 100)) : 0;
            const ini = mod(A.dex), prof = profOf(ch.level), percSkill = (ch.proficiencies || []).some(p => p === 'Percepcja' || p === 'Perception') ? prof : 0;
            const atk = window.Kits ? Kits.attacks(ch, 6) : [];
            me = `<section class="sh-sec pl-ready-card">
                <h3 class="sh-sec-title"><i class="fa-solid fa-shield-halved"></i> Twoja gotowość</h3>
                <div class="sh-tiles">
                    <div class="sh-tile"><span>Klasa Pancerza</span><b>${ch.ac ?? 10}</b></div>
                    <div class="sh-tile pl-ready-hp"><span>Punkty Wytrzymałości</span><b>${hp.current}<small> / ${hp.max}${hp.temp ? ` +${hp.temp}` : ''}</small></b><i style="width:${pct}%"></i></div>
                    <button class="sh-tile sh-tile-btn" data-roll="k20${ini >= 0 ? '+' : ''}${ini}" data-opis="Inicjatywa"><span>Inicjatywa</span><b>${sg(ini)}</b></button>
                    <div class="sh-tile"><span>Prędkość</span><b>${ch.speed ?? 30} ft</b></div>
                    <div class="sh-tile"><span>Pas. Percepcja</span><b>${10 + mod(A.wis) + percSkill}</b></div>
                </div>
                ${atk.length ? `<div class="sh-attacks">${atk.map(a => `<div class="sh-attack"><i class="fa-solid ${a.ranged ? 'fa-bullseye' : 'fa-khanda'}"></i><span>${esc(a.name)}</span>
                    <button class="sh-roll" data-roll="k20${a.hit >= 0 ? '+' : ''}${a.hit}" data-opis="Atak: ${esc(a.name)}" title="Rzut na trafienie">${sg(a.hit)}</button>
                    <button class="sh-roll dmg" data-roll="${esc(a.dmg.replace('−', '-'))}" data-opis="${esc(a.name)} — obrażenia" title="Rzut na obrażenia">${esc(a.dmg)}</button><em>${esc(a.type)}</em></div>`).join('')}</div>`
                    : '<p class="sh-muted">Nie masz broni w ekwipunku — dodaj ją w karcie postaci.</p>'}
            </section>`;
        }
        const party = (V.party || []).map(p => {
            const pct = p.hp.max ? Math.max(0, Math.min(100, p.hp.current / p.hp.max * 100)) : 0;
            return `<div class="pl-ready-mate ${p.me ? 'me' : ''}"><b>${esc(p.name)}</b><span>${p.hp.current}/${p.hp.max} PW · KP ${p.ac ?? '?'}</span><i><em style="width:${pct}%"></em></i></div>`;
        }).join('');
        return `<div class="pl-calm">
            <div class="pl-calm-hero"><div class="pl-calm-seal"><i class="fa-solid fa-khanda"></i></div>
                <div><h3>Cisza przed burzą</h3><p>Plansza walki i kolejka inicjatywy pojawią się tutaj same, gdy Mistrz Gry ogłosi walkę. Do tego czasu przygotuj bohatera.</p></div></div>
            <div class="pl-calm-grid">
                ${me}
                <section class="sh-sec"><h3 class="sh-sec-title"><i class="fa-solid fa-people-group"></i> Drużyna</h3><div class="pl-ready-party">${party || '<p class="sh-muted">Drużyna jest pusta.</p>'}</div></section>
                <section class="sh-sec pl-calm-turn"><h3 class="sh-sec-title"><i class="fa-solid fa-hourglass-half"></i> Twoja tura w skrócie</h3>
                    <ul>
                        <li><b>Ruch</b> — do wartości prędkości, można go dzielić przed i po akcji.</li>
                        <li><b>Akcja</b> — atak, czar, Sprint, Unik, Odskok, Pomoc, Ukrycie, Przygotowanie, Szukanie, Użycie przedmiotu.</li>
                        <li><b>Akcja dodatkowa</b> — tylko gdy daje ją zdolność albo czar.</li>
                        <li><b>Reakcja</b> — raz na rundę, np. atak okazyjny.</li>
                        <li><b>Drobiazg</b> — otwarcie drzwi, wyciągnięcie broni, krótkie słowo.</li>
                    </ul></section>
            </div>
        </div>`;
    }
    function combatView() {
        const c = V.combat;
        if (!c || !c.active) return calmView();
        const g = sceneGeo(c.scene);
        const act = c.order.find(o => o.id === c.turn);
        const mine = c.order.find(o => o.me);
        // żeton, którym gracz teraz rusza: swój albo prowadzonego towarzysza (w jego turze)
        const fid = c.focus || c.me, fo = c.order.find(o => o.id === fid);
        const ctrlTurn = !!(c.active && fid !== c.me && c.turn === fid);
        const canMove = !!(g && fo && c.tokens[fid] && c.scene?.playersMove !== false && c.turn === fid);
        const mv = c.move;
        const myTurn = c.active && c.turn === c.me;
        const anyTurn = myTurn || ctrlTurn;
        // schody: mój żeton stoi na schodach → przycisk przejścia na inne piętro
        const myT = fo ? c.tokens[fid] : null;
        const lvls = c.scene?.levels || null, lvIdx = lvls ? lvls.findIndex(L => L.id === c.scene.levelId) : -1;
        const stair = g && g.kind === 'interior' && myT && window.MapForge?.stairsAt ? MapForge.stairsAt(g.lv, myT.x, myT.y, Math.max(1, fo.size || 1)) : null;
        const stairTo = stair && lvls && lvls[lvIdx + stair.sd] ? lvls[lvIdx + stair.sd] : null;
        const stairBtn = stairTo && anyTurn && c.scene?.playersMove !== false ? `<button class="pl-btn pl-stair" data-schody title="Przejdź schodami"><i class="fa-solid fa-${stair.sd > 0 ? 'arrow-up' : 'arrow-down'}"></i> ${stair.sd > 0 ? 'Wejdź na' : 'Zejdź do'}: ${esc(stairTo.name)}</button>` : '';
        const moveBox = anyTurn && mv ? `<div class="pl-move ${mv.remaining <= 0 ? 'empty' : ''}">
                <span class="pl-move-l"><i class="fa-solid fa-shoe-prints"></i> Ruch</span>
                <div class="pl-move-bar"><i style="width:${mv.total ? Math.round(mv.remaining / mv.total * 100) : 0}%"></i></div>
                <b>${mv.remaining}<small>/${mv.total} ft</small></b>
                ${stairBtn}${mv.stopped ? '<em>nie możesz się ruszać (stan)</em>' : `<button class="pl-btn ${mv.dash ? 'on' : ''}" data-sprint title="Sprint — akcja: podwaja ruch w tej turze"><i class="fa-solid fa-person-running"></i> ${mv.dash ? 'Sprint ✓' : 'Sprint'}</button>`}
            </div>` : '';
        const banner = c.active ? `<div class="pl-cbanner ${myTurn ? 'mine' : ''}"><span>Runda <b>${c.round}</b></span>${lvls && lvls.length > 1 && lvIdx >= 0 ? `<span class="pl-lvname"><i class="fa-solid fa-stairs"></i> ${esc(lvls[lvIdx].name)}</span>` : ''}${ctrlTurn ? `<span class="pl-eyes" title="Plansza pokazuje to, co widzi Twój towarzysz"><i class="fa-solid fa-eye"></i> oczami: ${esc(fo.name)}</span>` : ''}<b>${myTurn ? 'Twoja tura!' : ctrlTurn ? `Tura towarzysza: ${esc(fo.name)} — prowadzisz go` : act ? `Tura: ${esc(act.name)}` : 'Tura przeciwnika'}</b>${canMove ? `<small>przeciągnij ${ctrlTurn ? 'jego' : 'swój'} żeton</small>` : ''}${anyTurn && !JAKO ? `<button class="pl-btn pl-end" data-endturn title="Zakończ ${ctrlTurn ? 'turę towarzysza' : 'swoją turę'} — następny w kolejce"><i class="fa-solid fa-forward-step"></i> Zakończ turę</button>` : ''}</div>${moveBox}` : '<div class="pl-cbanner idle">Przygotowanie do walki</div>';
        boardGeo = g;
        if (g) {
            g.cols = g.kind === 'interior' ? g.lv.cols : Math.max(1, Math.floor((g.w - g.ox) / g.cell));
            g.rows = g.kind === 'interior' ? g.lv.rows : Math.max(1, Math.floor((g.h - g.oy) / g.cell));
            g.T = window.MapForge?.terrain ? MapForge.terrain(g.kind === 'interior' ? g.lv : null, g.cols, g.rows, c.scene?.ter || {}, { player: true }) : null;
        }
        let board = '';
        if (g) {
            const bg = g.kind === 'interior' ? `<img src="${svgUrl(g.lv)}" alt="" data-keep="bg">` : g.url ? `<img src="${esc(g.url)}" alt="" style="width:100%;height:100%" data-keep="bg">` : '';
            const toks = c.order.map(o => {
                const t = c.tokens[o.id]; if (!t) return '';
                const n = Math.max(1, Math.min(4, o.size || 1)), s = n * g.cell;
                const col = o.pc ? (window.Kits ? (Kits.CLASS_META[Kits.classKey((V.party || []).find(p => p.id === o.charId)?.class)]?.color || '#4a7fc0') : '#4a7fc0') : o.disp === 'friendly' ? '#3f8f4a' : o.type === 'npc' ? '#a8862a' : '#b0301f';
                const ini = String(o.name || '?').replace(/\s*\d+$/, '').trim().split(/\s+/).slice(0, 2).map(x => x[0] || '').join('').toUpperCase();
                const num = (String(o.name).match(/(\d+)$/) || [])[1];
                const pct = o.hp ? Math.max(0, Math.min(100, o.hp.current / Math.max(1, o.hp.max) * 100)) : null;
                return `<div class="vt-tok t-${esc(o.type)} ${o.id === c.turn ? 'turn' : ''} ${o.state === 'nieprzytomny' ? 'down' : ''} ${o.me || (ctrlTurn && o.id === fid) ? 'sel' : ''} ${o.ctrl ? 'ctrl' : ''}" ${o.id === fid && canMove ? 'data-mine="1"' : ''} ${o.id === fid ? 'data-focus="1"' : ''} data-cid="${esc(o.id)}"
                    style="left:${g.ox + t.x * g.cell}px;top:${g.oy + t.y * g.cell}px;--s:${s}px;--c:${col};--hpc:${pct == null ? '#888' : pct > 50 ? '#4caf50' : pct > 20 ? '#e0b030' : '#d6402c'}">
                    <div class="vt-face"><span>${esc(ini)}</span>${num ? `<em>${num}</em>` : ''}${o.pc && o.pv && window.Portrait ? Portrait.img(Portrait.url(o.charId, o.pv)) : ''}</div>
                    ${o.state === 'nieprzytomny' ? '<div class="vt-skull"><i class="fa-solid fa-skull"></i></div>' : ''}
                    ${pct != null ? `<div class="vt-hp"><i style="width:${pct}%"></i></div>` : ''}
                    <div class="vt-name">${esc(o.name)}</div>
                    ${g.T && terMax(g.T, t.x, t.y, n) === 2 ? '<div class="vt-elev" title="Na podwyższeniu"><i class="fa-solid fa-arrow-up"></i></div>' : g.T && terMax(g.T, t.x, t.y, n) === 1 ? '<div class="vt-elev hard" title="Trudny teren"><i class="fa-solid fa-water"></i></div>' : ''}
                    ${ui.target === o.id ? '<div class="pl-tgt-ring"></div>' : ''}</div>`;
            }).join('');
            board = `<div class="pl-vp vt pl-board" id="pl-bvp" data-cell="${g.cell}" data-ox="${g.ox}" data-oy="${g.oy}" data-w="${g.w}" data-h="${g.h}">
                <div class="vt-board pl-map" id="pl-bmap" style="width:${g.w}px;height:${g.h}px">
                    <div class="vt-bg bg-${g.kind === 'blank' ? g.bg : g.kind}">${bg}</div>
                    ${c.scene?.grid !== false ? `<div class="vt-grid" style="--gs:${g.cell}px;--gx:${g.ox}px;--gy:${g.oy}px;--ga:${c.scene?.galpha ?? 0.3}"></div>` : ''}
                    <svg class="vt-ter" width="${g.w}" height="${g.h}" viewBox="0 0 ${g.w} ${g.h}">${terSVG(g, c.scene?.ter)}</svg>
                    <svg class="vt-tpl" width="${g.w}" height="${g.h}" viewBox="0 0 ${g.w} ${g.h}">${(c.tpl || []).map(t => tplSVG(t, g.cell)).join('')}</svg>
                    <div class="vt-toks">${toks}</div>
                    ${c.scene?.fog ? `<svg class="vt-fog" width="${g.w}" height="${g.h}" viewBox="0 0 ${g.w} ${g.h}">${fogLayer(g, c.scene, `walka:${c.scene.mapId || c.scene.kind}:${c.scene.levelId || ''}`, c.scene.viewers || [], c.scene.ter)}</svg>` : ''}
                    <svg class="vt-over" width="${g.w}" height="${g.h}" viewBox="0 0 ${g.w} ${g.h}"></svg>
                </div>
                <div class="pl-zoom"><button data-z="me" title="Pokaż mój żeton"><i class="fa-solid fa-crosshairs"></i></button><button data-z="in">+</button><button data-z="out">−</button><button data-z="fit"><i class="fa-solid fa-expand"></i></button></div>
            </div>`;
        }
        const sorted = c.order.slice().sort((a, b) => b.init - a.init);
        const tIdx = sorted.findIndex(o => o.id === c.turn), mIdx = sorted.findIndex(o => o.me);
        const turnsTo = tIdx >= 0 && mIdx >= 0 ? (mIdx - tIdx + sorted.length) % sorted.length : null;
        const nextId = tIdx >= 0 ? sorted[(tIdx + 1) % sorted.length]?.id : null;
        const order = `<ol class="pl-order">${sorted.map(o => `<li class="${o.id === c.turn ? 'now' : ''} ${o.me ? 'me' : ''} ${o.id === nextId && o.id !== c.turn ? 'next' : ''} ${ui.target === o.id ? 'tgt' : ''} t-${esc(o.type)}" data-tgt="${esc(o.id)}">
            <span class="pl-init">${o.init ?? '–'}</span><b>${esc(o.name)}</b>
            <span class="pl-state">${o.hp ? `${o.hp.current}/${o.hp.max} PW` : esc(o.state)}</span>
            ${o.conds?.length || o.away || o.unseen ? `<small>${o.unseen && !o.away ? '<i class="fa-solid fa-eye-slash"></i> poza zasięgiem wzroku' : ''}${o.away ? '<i class="fa-solid fa-stairs"></i> na innym piętrze' : ''}${o.away && o.conds?.length ? ' · ' : ''}${(o.conds || []).map(k => esc(COND_PL[k] || k)).join(', ')}</small>` : ''}</li>`).join('')}</ol>`;
        // mój stan obok planszy (na komputerze kolumna z prawej, na telefonie pod planszą)
        const ch = V.character;
        const myTok = mine ? c.tokens[mine.id] : null;
        const tag = `${c.round}:${c.turn}`; if (ui.eco?.tag !== tag) ui.eco = { tag, a: false, b: false, r: ui.eco?.round === c.round ? ui.eco.r : false, round: c.round };
        const atk = ch && window.Kits ? Kits.attacks(ch, 4) : [];
        const sg = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);
        const myCard = mine ? `<div class="pl-cme ${myTurn ? 'mine' : ''}">
                <div class="pl-cme-h"><b>${esc(mine.name)}</b><span>${myTurn ? 'Twoja tura' : turnsTo ? `twoja tura za ${turnsTo} ${turnsTo === 1 ? 'ruch' : turnsTo < 5 ? 'ruchy' : 'ruchów'}` : `inicjatywa ${mine.init ?? '–'}`}</span></div>
                ${mine.hp ? `<div class="pl-cme-hp"><i style="width:${Math.max(0, Math.min(100, mine.hp.current / Math.max(1, mine.hp.max) * 100))}%"></i><span>${mine.hp.current} / ${mine.hp.max} PW</span></div>` : ''}
                <div class="pl-cme-s"><span><i class="fa-solid fa-shield-halved"></i> KP ${ch?.ac ?? '?'}</span><span><i class="fa-solid fa-shoe-prints"></i> ${mv ? `${mv.remaining}/${mv.total}` : (parseInt(ch?.speed, 10) || 30)} ft</span>${myTok && g?.T && terMax(g.T, myTok.x, myTok.y, mine.size || 1) === 2 ? '<span class="pl-cme-up"><i class="fa-solid fa-arrow-up"></i> na podwyższeniu</span>' : ''}</div>
                ${mine.conds?.length ? `<div class="pl-cme-cd">${mine.conds.map(k => `<div><b>${esc(COND_PL[k] || k)}</b> ${esc(COND_DESC[k] || '')}</div>`).join('')}</div>` : ''}
                ${myTurn ? `<div class="pl-eco">${[['a', 'fa-hand-fist', 'Akcja'], ['b', 'fa-bolt', 'Dodatkowa'], ['r', 'fa-rotate-left', 'Reakcja']].map(([k, ic, l]) => `<button type="button" data-eco="${k}" class="${ui.eco[k] ? 'used' : ''}"><i class="fa-solid ${ic}"></i> ${l}</button>`).join('')}</div>` : ''}
                ${ch && window.NPCsModule?.pcBlockHTML ? `<details class="pl-comp-sheet" data-det="walka-ja" open><summary>Karta, ataki i zdolności</summary><div class="nb-host">${NPCsModule.pcBlockHTML({ ...ch, hp: { ...(ch.hp || {}), current: mine.hp?.current ?? ch.hp?.current } }, { compact: true })}</div></details>` : ''}
            </div>`
            // moja postać nie stoi w tej walce — statystyki i tak są pod ręką
            : ch ? `<div class="pl-cme">
                <div class="pl-cme-h"><b>${esc(ch.name)}</b><span>nie bierzesz udziału w tej walce</span></div>
                ${ch.hp ? `<div class="pl-cme-hp"><i style="width:${Math.max(0, Math.min(100, (ch.hp.current || 0) / Math.max(1, ch.hp.max || 1) * 100))}%"></i><span>${ch.hp.current ?? 0} / ${ch.hp.max ?? 0} PW</span></div>` : ''}
                <div class="pl-cme-s"><span><i class="fa-solid fa-shield-halved"></i> KP ${ch.ac ?? '?'}</span><span><i class="fa-solid fa-shoe-prints"></i> ${parseInt(ch.speed, 10) || 30} ft</span></div>
                ${window.NPCsModule?.pcBlockHTML ? `<details class="pl-comp-sheet" data-det="walka-ja" open><summary>Karta, ataki i zdolności</summary><div class="nb-host">${NPCsModule.pcBlockHTML(ch, { compact: true })}</div></details>` : ''}
            </div>` : '';
        const tgtCard = `<div id="pl-ctarget">${targetHTML()}</div>`;
        // karta prowadzonego towarzysza (zawsze widoczna; w jego turze — z akcjami)
        const comps = (V.companions || []).filter(x => x.mine);
        const compCard = comps.map(cp => {
            // towarzysz poza walką: jego karta i tak widoczna (bez tury i akcji)
            const o = c.order.find(x => x.ctrl && x.npcId === cp.id) || { id: null, hp: cp.hp, conds: [], state: 'poza walką', away: true };
            const on = !!o.id && c.turn === o.id;
            return `<div class="pl-cme pl-comp ${on ? 'mine' : ''}">
                <div class="pl-cme-h"><b><i class="fa-solid fa-handshake-angle"></i> ${esc(cp.name)}</b><span>${on ? 'jego tura — prowadzisz' : o.id ? 'twój towarzysz' : 'twój towarzysz · poza walką'}</span></div>
                ${cp.hp ? `<div class="pl-cme-hp"><i style="width:${Math.max(0, Math.min(100, (o.hp?.current ?? cp.hp.current) / Math.max(1, cp.hp.max) * 100))}%"></i><span>${o.hp?.current ?? cp.hp.current} / ${cp.hp.max} PW</span></div>` : `<div class="pl-cme-s"><span>${esc(o.state || '')}</span></div>`}
                ${o.conds?.length ? `<div class="pl-cme-cd">${o.conds.map(k => `<div><b>${esc(COND_PL[k] || k)}</b> ${esc(COND_DESC[k] || '')}</div>`).join('')}</div>` : ''}
                ${on ? `<div class="pl-eco">${[['a', 'fa-hand-fist', 'Akcja'], ['b', 'fa-bolt', 'Dodatkowa'], ['r', 'fa-rotate-left', 'Reakcja']].map(([k, ic, l]) => `<button type="button" data-eco="${k}" class="${ui.eco[k] ? 'used' : ''}"><i class="fa-solid ${ic}"></i> ${l}</button>`).join('')}</div>` : ''}
                ${cp.hasStats && cp.stats && window.NPCsModule ? `<details class="pl-comp-sheet" data-det="walka-${esc(cp.id)}" open><summary>Karta, ataki i zdolności</summary><div class="nb-host">${NPCsModule.statBlockHTML((() => { const n = NPCsModule.normNPC({ ...cp, hasStats: true }); n.stats.hpNow = o.hp?.current ?? cp.hp?.current; return n; })(), { compact: true })}</div></details>` : ''}
            </div>`;
        }).join('');
        return `<div class="pl-combat"><div class="pl-cmain">${banner}${board}</div><aside class="pl-cside">${ctrlTurn ? compCard + myCard : myCard + compCard}${tgtCard}${sec('kolejka', 'fa-list-ol', 'Kolejka inicjatywy', order)}</aside></div>`;
    }
    // mgła wojny u gracza: widać to, co widzą postacie; odkryte wcześniej miejsca zostają przyciemnione
    function fogLayer(g, sc, key, viewers, paint) {
        if (!window.MapForge?.vision) return '';
        const lv = g.kind === 'interior' ? g.lv : null;
        const cols = g.cols || (lv ? lv.cols : Math.max(1, Math.floor((g.w - g.ox) / g.cell))), rows = g.rows || (lv ? lv.rows : Math.max(1, Math.floor((g.h - g.oy) / g.cell)));
        const O = MapForge.sightGrid(lv, cols, rows, paint || {}, { player: true });
        const V = MapForge.vision(O, cols, rows, viewers, { dark: lv ? +lv.dark || 0 : 0, lights: lv ? MapForge.lightsOf(lv) : [] });
        const k = `pl_fog_${V_campaign()}_${key}`;
        let seen = null;
        try { seen = MapForge.unpackBits(localStorage.getItem(k), cols * rows); } catch (e) { seen = new Uint8Array(cols * rows); }
        let changed = false;
        for (let i = 0; i < V.length; i++) if (V[i] && !seen[i]) { seen[i] = 1; changed = true; }
        if (changed) { try { localStorage.setItem(k, MapForge.packBits(seen)); } catch (e) {} }
        return MapForge.fogSVG(V, seen, cols, rows, g.cell, g.ox || 0, g.oy || 0);
    }
    const V_campaign = () => V?.campaign?.id || 'x';
    const terMax = (T, x, y, n = 1) => { let m = 0; for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) m = Math.max(m, T.at(x + i, y + j)); return m; };
    // teren namalowany przez MG (meble i ściany widać na mapie)
    function terSVG(g, ter) {
        const P = ter || {}, keys = Object.keys(P); if (!keys.length) return '';
        const cls = { b: 'b', h: 'h', e: 'e' };
        return `<defs><pattern id="pl-p-h" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="12" height="12" fill="rgba(224,170,60,.16)"/><rect width="4" height="12" fill="rgba(224,170,60,.45)"/></pattern>
            <pattern id="pl-p-e" width="18" height="16" patternUnits="userSpaceOnUse"><rect width="18" height="16" fill="rgba(90,150,230,.15)"/><path d="M3 12L9 5L15 12" fill="none" stroke="rgba(120,180,255,.6)" stroke-width="2.4"/></pattern>
            <pattern id="pl-p-b" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="rgba(200,50,40,.22)"/><path d="M0 0L14 14M14 0L0 14" stroke="rgba(230,80,60,.55)" stroke-width="2"/></pattern></defs>`
            + keys.filter(k => cls[P[k]]).map(k => { const [x, y] = k.split(',').map(Number); return `<rect x="${g.ox + x * g.cell}" y="${g.oy + y * g.cell}" width="${g.cell}" height="${g.cell}" fill="url(#pl-p-${cls[P[k]]})"/>`; }).join('');
    }
    function gapFt(a, ta, b, tb) {
        const na = Math.max(1, a.size || 1), nb = Math.max(1, b.size || 1);
        return feetOf(Math.max(0, tb.x - (ta.x + na - 1), ta.x - (tb.x + nb - 1)), Math.max(0, tb.y - (ta.y + na - 1), ta.y - (tb.y + nb - 1)));
    }
    // wybrany cel: stan, odległość, stany
    function targetHTML() {
        const c = V.combat; if (!c || !ui.target) return '';
        const o = c.order.find(x => x.id === ui.target); if (!o) return '';
        const me = c.order.find(x => x.me), tm = me && c.tokens[me.id], tt = c.tokens[o.id];
        const d = tm && tt ? gapFt(me, tm, o, tt) : null;
        const pct = o.hp ? Math.max(0, Math.min(100, o.hp.current / Math.max(1, o.hp.max) * 100)) : null;
        const kind = o.pc ? 'Bohater' : o.disp === 'friendly' ? 'Sojusznik' : o.type === 'npc' ? 'Postać' : 'Przeciwnik';
        return `<div class="pl-tgt ${o.pc || o.disp === 'friendly' ? 'ally' : 'foe'}">
            <div class="pl-tgt-h"><span>Cel</span><b>${esc(o.name)}</b><button type="button" data-tgt-x title="Odznacz">✕</button></div>
            <div class="pl-tgt-s"><em>${kind}</em>${pct != null ? `<span>${o.hp.current}/${o.hp.max} PW</span>` : `<span>${esc(o.state || '')}</span>`}${d != null ? `<span class="${d <= 5 ? 'melee' : ''}"><i class="fa-solid fa-ruler"></i> ${d} ft${d <= 5 ? ' · wręcz' : ''}</span>` : o.away ? '<span><i class="fa-solid fa-stairs"></i> na innym piętrze</span>' : ''}</div>
            ${o.conds?.length ? `<div class="pl-cme-cd">${o.conds.map(k => `<div><b>${esc(COND_PL[k] || k)}</b> ${esc(COND_DESC[k] || '')}</div>`).join('')}</div>` : ''}
        </div>`;
    }
    let boardGeo = null;
    const BLOCK = '#hXLPBV';
    function cellBlocked(x, y, n) {
        const g = boardGeo; if (!g) return false;
        const cols = g.kind === 'interior' ? g.lv.cols : Math.floor((g.w - g.ox) / g.cell), rows = g.kind === 'interior' ? g.lv.rows : Math.floor((g.h - g.oy) / g.cell);
        for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
            const cx = x + i, cy = y + j;
            if (cx < 0 || cy < 0 || cx >= cols || cy >= rows) return true;
            if (g.T) { if (g.T.at(cx, cy) === 3) return true; continue; }
            if (g.kind === 'interior' && BLOCK.includes(g.lv.walls[cy * g.lv.cols + cx] || '.')) return true;
        }
        return false;
    }
    function pathBlocked(x0, y0, x1, y1, n) {
        if (boardGeo?.kind !== 'interior') return false;
        const steps = Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) * 4) || 1;
        for (let k = 1; k <= steps; k++) { const t = k / steps; if (cellBlocked(Math.floor(x0 + (x1 - x0) * t + n / 2), Math.floor(y0 + (y1 - y0) * t + n / 2), 1)) return true; }
        return false;
    }
    function feetOf(dx, dy) {
        dx = Math.abs(dx); dy = Math.abs(dy);
        const mx = Math.max(dx, dy), mn = Math.min(dx, dy);
        return V.combat?.scene?.diag === 'alt' ? (mx + Math.floor(mn / 2)) * 5 : mx * 5;
    }
    function bindBoard() {
        const vp = $('#pl-bvp'), board = $('#pl-bmap'); if (!vp || !board) return;
        const cell = +vp.dataset.cell, ox = +vp.dataset.ox, oy = +vp.dataset.oy, w = +vp.dataset.w, h = +vp.dataset.h;
        let pz = null;
        const mineEl = board.querySelector('.vt-tok[data-focus]') || board.querySelector('.vt-tok.sel') || board.querySelector('.vt-tok.turn');
        const focus = mineEl ? { x: parseFloat(mineEl.style.left) + cell / 2, y: parseFloat(mineEl.style.top) + cell / 2, span: cell * 9 } : null;
        requestAnimationFrame(() => {
            pz = panZoom(vp, board, `board:${V.combat?.scene?.mapId || V.combat?.scene?.kind}:${w}x${h}`, w, h, focus);
            // mój żeton zawsze w zasięgu wzroku — zwłaszcza w mojej turze
            const me = board.querySelector('.vt-tok[data-focus]') || board.querySelector('.vt-tok.sel');
            // zmiana tego, kim gracz teraz patrzy (bohater ↔ prowadzony towarzysz) — pokaż jego okolicę
            const fKey = `${V.combat?.focus || ''}:${V.combat?.scene?.levelId || ''}`, switched = ui.lastFocus !== fKey; ui.lastFocus = fKey;
            if (me && pz) {
                const R = vp.getBoundingClientRect(), T = me.getBoundingClientRect();
                const out = T.right < R.left + 20 || T.left > R.right - 20 || T.bottom < R.top + 20 || T.top > R.bottom - 20;
                if (out || switched || vp.dataset.recenter === '1') {
                    const st = pz.st, cx = parseFloat(me.style.left) + cell / 2, cy = parseFloat(me.style.top) + cell / 2;
                    st.x = vp.clientWidth / 2 - cx * st.z; st.y = vp.clientHeight / 2 - cy * st.z;
                    board.style.transform = `translate(${st.x}px, ${st.y}px) scale(${st.z})`;
                }
            }
        });
        vp.querySelector('[data-z="me"]')?.addEventListener('click', () => { vp.dataset.recenter = '1'; bindBoardCenter(); });
        const bindBoardCenter = () => { const me = board.querySelector('.vt-tok[data-focus]') || board.querySelector('.vt-tok.sel'); if (!me || !pz) return; const st = pz.st; st.x = vp.clientWidth / 2 - (parseFloat(me.style.left) + cell / 2) * st.z; st.y = vp.clientHeight / 2 - (parseFloat(me.style.top) + cell / 2) * st.z; board.style.transform = `translate(${st.x}px, ${st.y}px) scale(${st.z})`; };
        const tok = board.querySelector('[data-mine]'); if (!tok) return;
        const id = tok.dataset.cid, t0 = V.combat.tokens[id];
        let drag = null;
        tok.addEventListener('pointerdown', (e) => {
            e.stopPropagation(); tok.setPointerCapture(e.pointerId);
            drag = { sx: e.clientX, sy: e.clientY, x: t0.x, y: t0.y, nx: t0.x, ny: t0.y };
            tok.classList.add('dragging');
        });
        const size = Math.max(1, Math.min(4, (V.combat.order.find(o => o.id === id)?.size) || 1));
        const check = (d) => {
            const c = V.combat, mv = c.move;
            const ft = feetOf(d.nx - d.x, d.ny - d.y);
            if (cellBlocked(d.nx, d.ny, size)) return { ok: false, ft, why: 'Tam nie można wejść — przeszkoda' };
            const taken = c.order.some(o => {
                if (o.id === id || o.state === 'nieprzytomny') return false;
                const t = c.tokens[o.id]; if (!t) return false;
                const n = Math.max(1, Math.min(4, o.size || 1));
                return d.nx < t.x + n && d.nx + size > t.x && d.ny < t.y + n && d.ny + size > t.y;
            });
            if (taken) return { ok: false, ft, why: 'To pole jest zajęte' };
            if (boardGeo?.T && window.MapForge?.reach) {
                if (!d.reach) d.reach = MapForge.reach(boardGeo.T, d.x, d.y, size, c.scene?.diag);
                const r = d.reach(d.nx, d.ny);
                if (!r) return { ok: false, ft, why: 'Nie da się tam dojść — przeszkody na drodze' };
                const rough = r.ft > ft;
                if (c.active && mv?.limit && r.ft > mv.remaining) return { ok: false, ft: r.ft, path: r.path, rough, why: `Za daleko — ${r.ft} ft${rough ? ' (trudny teren)' : ''}, zostało ${mv.remaining} ft` };
                return { ok: true, ft: r.ft, path: r.path, rough };
            }
            if (pathBlocked(d.x, d.y, d.nx, d.ny, size)) return { ok: false, ft, why: 'Ściana na drodze' };
            if (c.active && mv?.limit && ft > mv.remaining) return { ok: false, ft, why: `Za daleko — zostało ${mv.remaining} ft` };
            return { ok: true, ft };
        };
        tok.addEventListener('pointermove', (e) => {
            if (!drag || !pz) return;
            const z = pz.st.z, dx = (e.clientX - drag.sx) / z, dy = (e.clientY - drag.sy) / z;
            tok.style.left = (ox + drag.x * cell + dx) + 'px'; tok.style.top = (oy + drag.y * cell + dy) + 'px';
            drag.nx = Math.max(0, drag.x + Math.round(dx / cell)); drag.ny = Math.max(0, drag.y + Math.round(dy / cell));
            const chk = check(drag), h = size * cell / 2;
            const x0 = ox + drag.x * cell + h, y0 = oy + drag.y * cell + h, x1 = ox + drag.nx * cell + h, y1 = oy + drag.ny * cell + h;
            const pv = chk.path && chk.path.length > 2 ? chk.path[chk.path.length - 2] : null, ax0 = pv ? ox + pv.x * cell + h : x0, ay0 = pv ? oy + pv.y * cell + h : y0;
            const ang = Math.atan2(y1 - ay0, x1 - ax0), L = Math.hypot(x1 - x0, y1 - y0), ah = Math.min(28, cell * 0.4);
            const bx = x1 - Math.cos(ang) * ah, by = y1 - Math.sin(ang) * ah;
            const p1 = `${x1},${y1} ${bx - Math.sin(ang) * ah * 0.6},${by + Math.cos(ang) * ah * 0.6} ${bx + Math.sin(ang) * ah * 0.6},${by - Math.cos(ang) * ah * 0.6}`;
            const mv = V.combat.move, rem = V.combat.active && mv?.limit ? Math.max(0, mv.remaining - chk.ft) : null;
            if (drag.area == null) {
                drag.area = '';
                if (drag.reach?.cost && V.combat.active && mv?.limit) {
                    let r = ''; const G2 = boardGeo;
                    for (let y = 0; y < G2.rows; y++) for (let x = 0; x < G2.cols; x++) { const v = drag.reach.cost(x, y); if (v != null && v > 0 && v <= mv.remaining) r += `M${ox + x * cell} ${oy + y * cell}h${cell}v${cell}h${-cell}z`; }
                    drag.area = r ? `<path class="vt-reach" d="${r}"/>` : '';
                }
            }
            const pts = chk.path && chk.path.length > 2 ? chk.path.slice(0, -1).filter((q, i, a) => i === 0 || i === a.length - 1 || (q.x - a[i - 1].x) !== (a[i + 1].x - q.x) || (q.y - a[i - 1].y) !== (a[i + 1].y - q.y)).map(q => `${ox + q.x * cell + h},${oy + q.y * cell + h}`).join(' ') : '';
            board.querySelector('.vt-over').innerHTML = `${drag.area}<g class="vt-path pl-arrow ${chk.ok ? 'ok' : 'bad'}">
                <rect class="vt-ghost" x="${ox + drag.nx * cell}" y="${oy + drag.ny * cell}" width="${size * cell}" height="${size * cell}" rx="8"/>
                ${pts ? `<polyline points="${pts} ${bx},${by}" fill="none"/><polygon points="${p1}"/>` : L > 4 ? `<line x1="${x0}" y1="${y0}" x2="${bx}" y2="${by}"/><polygon points="${p1}"/>` : ''}
                <circle cx="${x0}" cy="${y0}" r="7"/>
                <text x="${x1}" y="${y1 - size * cell / 2 - 12}">${chk.ft} ft${chk.rough ? ' · trudny teren' : ''}${chk.ok ? (rem != null ? ` · zostanie ${rem}` : '') : ' ✕'}</text></g>`;
        });
        tok.addEventListener('pointerup', async () => {
            if (!drag) return;
            const d = drag; drag = null; tok.classList.remove('dragging'); board.querySelector('.vt-over').innerHTML = '';
            if (d.nx === d.x && d.ny === d.y) { render(); return; }
            const chk = check(d);
            if (!chk.ok) { toast(chk.why, 'warn'); render(); return; }
            await act({ typ: 'ruch', x: d.nx, y: d.ny, kto: id }, () => {
                V.combat.tokens[id] = { x: d.nx, y: d.ny };
                if (V.combat.active && V.combat.move) { V.combat.move.moved += chk.ft; V.combat.move.remaining = Math.max(0, V.combat.move.remaining - chk.ft); }
            });
        });
    }

    // ---------- kliknięcia na karcie ----------
    function patchChar(fn) { const ch = V.character; if (ch) fn(ch); }
    let notesT = null, invT = null, curT = null;
    // ---------- przekazywanie przedmiotów i monet innemu bohaterowi ----------
    function giveModal({ idx = null, komu = null } = {}) {
        const me = V?.character; if (!me || JAKO) return;
        const others = (V.party || []).filter(c => !c.me);
        if (!others.length) { toast('W drużynie nie ma nikogo, komu można coś dać.'); return; }
        const inv = me.inventory || [], cur = me.currency || {};
        const COINS = [['pp', 'PM', 'platyna'], ['gp', 'SZ', 'złoto'], ['ep', 'EL', 'elektrum'], ['sp', 'SR', 'srebro'], ['cp', 'MD', 'miedź']];
        App.showModal('Daj coś towarzyszowi', `
            <label class="ne-f"><span>Komu</span><select id="gv-to">${others.map(c => `<option value="${esc(c.id)}" ${c.id === komu ? 'selected' : ''}>${esc(c.name)}${c.player ? ` (${esc(c.player)})` : ''}</option>`).join('')}</select></label>
            <div class="gv-sec"><h4><i class="fa-solid fa-box-open"></i> Przedmiot</h4>
                ${inv.length ? `<div class="gv-row"><select id="gv-item"><option value="">— bez przedmiotu —</option>${inv.map((it, i) => `<option value="${i}" ${i === idx ? 'selected' : ''}>${esc(it.name || 'bez nazwy')}${(it.quantity ?? 1) > 1 ? ` (masz ${it.quantity})` : ''}</option>`).join('')}</select>
                <input type="number" id="gv-qty" min="1" value="1" title="Ile sztuk"></div>` : '<p class="pl-muted">Twój ekwipunek jest pusty.</p>'}</div>
            <div class="gv-sec"><h4><i class="fa-solid fa-coins"></i> Monety</h4>
                <div class="gv-coins">${COINS.map(([k, s, n]) => `<label title="${n} — masz ${cur[k] || 0}"><span>${s}</span><input type="number" min="0" max="${cur[k] || 0}" value="0" data-coin="${k}" ${cur[k] ? '' : 'disabled'}><small>z ${cur[k] || 0}</small></label>`).join('')}</div></div>
            <p class="modal-hint">Przedmiot od razu znika z Twojego ekwipunku i trafia do towarzysza. Mistrz Gry zobaczy to w dzienniku.</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="gv-go"><i class="fa-solid fa-hand-holding-heart"></i> Daj</button>`);
        const sel = $('#gv-item'), qty = $('#gv-qty');
        const syncQty = () => { if (!sel || !qty) return; const it = inv[+sel.value]; qty.max = it ? (it.quantity ?? 1) : 1; qty.disabled = !it || (it.quantity ?? 1) <= 1; if (+qty.value > +qty.max) qty.value = qty.max; };
        sel?.addEventListener('change', syncQty); syncQty();
        $('#gv-go').onclick = async () => {
            const body = { typ: 'daj', komu: $('#gv-to').value };
            if (sel && sel.value !== '') { const i = +sel.value; body.przedmiot = { idx: i, nazwa: inv[i].name, ile: Math.max(1, parseInt(qty.value, 10) || 1) }; }
            const mon = {}; document.querySelectorAll('[data-coin]').forEach(el => { const v = parseInt(el.value, 10) || 0; if (v > 0) mon[el.dataset.coin] = v; });
            if (Object.keys(mon).length) body.monety = mon;
            if (!body.przedmiot && !body.monety) { toast('Wybierz przedmiot albo wpisz monety.'); return; }
            $('#gv-go').disabled = true;
            const who = others.find(c => c.id === body.komu)?.name || 'towarzysz';
            if (await act(body)) { App.closeModal(); toast(`${who} dostaje to, co dałeś`); load(); }
            else { const g = $('#gv-go'); if (g) g.disabled = false; }
        };
    }
    async function onClick(e) {
        const b = (s) => e.target.closest(s);
        if (b('[data-toggle]')) { const id = b('[data-toggle]').dataset.toggle; const s = b('[data-sec]'); const open = !s.classList.contains('open'); s.classList.toggle('open', open); ui.sec[id] = open; localStorage.setItem('pl_sec', JSON.stringify(ui.sec)); return; }
        if (b('[data-roll]')) { const r = b('[data-roll]'); roll(String(r.dataset.roll).replace(/d/g, 'k'), r.dataset.opis || r.dataset.lbl || ''); return; }
        if (b('[data-eco]')) { const k = b('[data-eco]').dataset.eco; if (ui.eco) { ui.eco[k] = !ui.eco[k]; b('[data-eco]').classList.toggle('used', ui.eco[k]); } return; }
        if (b('[data-tgt-x]')) { ui.target = null; render(); return; }
        if (b('.pl-order [data-tgt]')) { const id = b('.pl-order [data-tgt]').dataset.tgt; if (id !== V.combat?.me) { ui.target = ui.target === id ? null : id; render(); } return; }
        if (b('#pl-bmap .vt-tok:not([data-mine])')) { const id = b('#pl-bmap .vt-tok').dataset.cid; if (id !== V.combat?.me) { ui.target = ui.target === id ? null : id; render(); } return; }
        if (b('[data-give]')) { giveModal({ komu: b('[data-give]').dataset.give }); return; }
        if (b('[data-peek]')) { const id = b('[data-peek]').dataset.peek; if (id === V.character?.id) { go('postac'); return; } peekSheet(id); return; }
        if (b('[data-endturn]')) { const bt = b('[data-endturn]'); bt.disabled = true; const ok = await act({ typ: 'koniec_tury' }, () => {}); if (ok) toast('Tura zakończona'); else bt.disabled = false; return; }
        if (b('[data-schody]')) { b('[data-schody]').disabled = true; await act({ typ: 'schody', kto: V.combat?.focus || undefined }, () => {}); ui.target = null; return; }
        if (b('[data-sprint]')) { const mv = V.combat?.move; act({ typ: 'sprint', kto: V.combat?.focus || undefined }, () => { if (mv) { mv.dash = !mv.dash; mv.total = mv.speed * (mv.dash ? 2 : 1); mv.remaining = Math.max(0, mv.total - mv.moved); } }); return; }
        if (b('[data-follow]')) { ui.follow = b('[data-follow]').dataset.follow === '1'; localStorage.setItem('pl_follow', ui.follow ? '1' : '0'); if (ui.follow) ui.map = null; render(); return; }
        if (b('[data-minis]')) { ui.minis = !ui.minis; try { localStorage.setItem('pl_minis', ui.minis ? '1' : '0'); } catch { } render(); return; }
        if (b('[data-map-live]')) { ui.map = V.live.mapId; if (V.live.levelId) ui.level[V.live.mapId] = V.live.levelId; render(); return; }
        if (b('[data-enter]')) { ui.map = b('[data-enter]').dataset.enter; render(); return; }
        if (b('[data-pinclose]')) { $('#pl-pininfo').hidden = true; return; }
        if (b('[data-qview]')) { ui.qview = b('[data-qview]').dataset.qview; localStorage.setItem('pl_qview', ui.qview); render(); return; }
        if (b('[data-quest]')) { questSheet(b('[data-quest]').dataset.quest); return; }
        if (b('[data-levelup]')) { levelUpSheet(); return; }
        if (b('#pl-qbstage .qp[data-qid]')) { const c = b('#pl-qbstage .qp[data-qid]'); if (c._dragged) { c._dragged = false; return; } questSheet(c.dataset.qid); return; }
        if (b('[data-chalk]')) { chalkboard(V.tablica); return; }
        if (b('[data-qreset]')) { try { localStorage.removeItem(qposKey()); } catch (er) {} render(); return; }
        if (b('[data-ghist] summary')) { ui.ghist = !b('[data-ghist]').open; return; }
        if (b('[data-gact]')) {
            if (!V.character) { toast('Mistrz Gry nie przypisał Ci jeszcze postaci.'); return; }
            ui.gwait = true; render();
            const ok = await act({ typ: 'stol', akcja: b('[data-gact]').dataset.gact });
            if (!ok) { ui.gwait = false; render(); }
            setTimeout(() => { if (ui.gwait) { ui.gwait = false; if (ui.tab === 'stol') render(); } }, 8000);
            return;
        }
        const ch = V.character; if (!ch) return;
        if (b('[data-hp]')) {
            const kind = b('[data-hp]').dataset.hp, inp = $('#pl-hp-v'), v = Math.abs(parseInt(inp?.value, 10) || 0);
            const hp = { ...ch.hp };
            if (kind === 'temp') { const t = await Ask.prompt('Tymczasowe punkty wytrzymałości', hp.temp || 0, { title: 'Tymczasowe PW', ok: 'Zapisz', type: 'number' }); if (t == null) return; hp.temp = Math.max(0, parseInt(t, 10) || 0); }
            else if (kind === 'set') { const t = await Ask.prompt('Aktualne punkty wytrzymałości', hp.current, { title: 'Ustaw PW', ok: 'Zapisz', type: 'number' }); if (t == null) return; hp.current = Math.max(0, Math.min(hp.max, parseInt(t, 10) || 0)); }
            else {
                if (!v) { inp?.focus(); toast('Wpisz liczbę w pole obok.'); return; }
                if (kind === 'dmg') { const fromTemp = Math.min(hp.temp || 0, v); hp.temp = (hp.temp || 0) - fromTemp; hp.current = Math.max(0, hp.current - (v - fromTemp)); }
                else hp.current = Math.min(hp.max, hp.current + v);
            }
            const ok = await act({ typ: 'pole', zmiany: [{ path: 'hp.current', value: hp.current }, { path: 'hp.temp', value: hp.temp || 0 }] }, () => patchChar(c => { c.hp = hp; if (hp.current > 0) c.deathSaves = { successes: 0, failures: 0 }; }));
            if (ok && kind !== 'temp' && kind !== 'set') floatHp(kind === 'dmg' ? `−${v}` : `+${v}`, kind);
            return;
        }
        if (b('[data-ds]')) {
            const [k, n] = b('[data-ds]').dataset.ds.split(':'); const cur = ch.deathSaves?.[k] || 0, val = cur >= +n ? +n - 1 : +n;
            act({ typ: 'pole', path: `deathSaves.${k}`, value: val }, () => patchChar(c => { c.deathSaves = { successes: 0, failures: 0, ...(c.deathSaves || {}), [k]: val }; }));
            return;
        }
        if (b('[data-hd]')) {
            const hd = ch.hitDicePool || { current: ch.level || 1, max: ch.level || 1, die: ch.hitDie || 8 };
            if (hd.current <= 0) return;
            const cm = mod(ch.abilityScores?.con);
            try {
                const j = { wpis: await rollEntry(`1k${hd.die || 8}${cm >= 0 ? '+' : ''}${cm}`, 'Kość wytrzymałości') };
                const heal = Math.max(0, j.wpis.rzut.total), cur = Math.min(ch.hp.max, ch.hp.current + heal);
                act({ typ: 'pole', zmiany: [{ path: 'hitDicePool.current', value: hd.current - 1 }, { path: 'hp.current', value: cur }] }, () => patchChar(c => { c.hitDicePool = { ...hd, current: hd.current - 1 }; c.hp.current = cur; }));
            } catch (er) { toast(er.message, 'bad'); }
            return;
        }
        if (b('[data-slot]')) {
            const [lv, d] = b('[data-slot]').dataset.slot.split(':'); const s = ch.spellSlots[lv];
            const used = Math.max(0, Math.min(s.total, (s.used || 0) + (+d)));
            act({ typ: 'pole', path: `spellSlots.${lv}.used`, value: used }, () => patchChar(c => { c.spellSlots[lv].used = used; }));
            return;
        }
        if (b('[data-res]') || b('[data-resd]')) {
            const el = b('[data-res]') || b('[data-resd]');
            const [k, n] = (el.dataset.res || el.dataset.resd).split(':'); const r = ch.classResources[k];
            const val = el.dataset.res != null ? Math.max(0, Math.min(r.max, +n)) : Math.max(0, Math.min(r.max, r.current + (+n)));
            act({ typ: 'pole', path: `classResources.${k}.current`, value: val }, () => patchChar(c => { c.classResources[k].current = val; }));
            return;
        }
        if (b('[data-spell]')) {
            const i = +b('[data-spell]').dataset.spell, box = document.querySelector(`[data-spelld="${i}"]`);
            box.hidden = !box.hidden;
            if (!box.hidden && !box.dataset.loaded) {
                box.dataset.loaded = '1';
                const s = (ch.spells || []).slice().sort((a, c) => (a.level || 0) - (c.level || 0) || String(a.name).localeCompare(c.name, 'pl'))[i];
                const idx = s.index || String(s.name || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
                if (s.desc) box.innerHTML = `<p>${esc(s.desc)}</p>`;
                else if (window.SpellPicker?.fillDetails) SpellPicker.fillDetails(box, idx);
            }
            return;
        }
        if (b('[data-invdel]')) {
            const i = +b('[data-invdel]').dataset.invdel; const inv = (ch.inventory || []).filter((_, k) => k !== i);
            act({ typ: 'pole', path: 'inventory', value: inv }, () => patchChar(c => { c.inventory = inv; }));
            return;
        }
        if (b('[data-invadd]')) {
            const inv = [...(ch.inventory || []), { name: '', quantity: 1, weight: 0 }];
            await act({ typ: 'pole', path: 'inventory', value: inv }, () => patchChar(c => { c.inventory = inv; }));
            const ins = document.querySelectorAll('[data-inv$=":name"]'); ins[ins.length - 1]?.focus();
        }
    }
    function onChange(e) {
        const t = e.target;
        if (t.dataset.cur) {
            const k = t.dataset.cur, v = Math.max(0, parseInt(t.value, 10) || 0);
            act({ typ: 'pole', path: `currency.${k}`, value: v }, () => patchChar(c => { c.currency = { ...(c.currency || {}), [k]: v }; }));
        }
    }
    // ---------- awans na wyższy poziom (gdy jest dość PD) ----------
    async function levelUpSheet() {
        const ch = V.character; if (!ch || typeof ClassData === 'undefined') return;
        const CD = ClassData, ck = Kits.classKey(ch.class), lvl = ch.level || 1, nl = lvl + 1;
        if ((ch.xp || 0) < (CD.XP_THRESHOLDS[nl] || 0)) { toast('Za mało doświadczenia na awans.', 'bad'); return; }
        const ov = $('#pl-overlay');
        const A = ch.abilityScores || {}, conMod = mod(A.con), die = ch.hitDie || CD.HIT_DIE[ck] || 8, avg = Math.max(1, Math.floor(die / 2) + 1 + conMod);
        const isASI = ck && CD.isASILevel(ck, nl), isSub = ck && CD.isSubclassLevel(ck, nl) && !ch.subclass;
        const subs = isSub ? (CD.getSubclassesForClass(ck) || []) : [];
        const subFeat = ch.subclass ? CD.getNewSubclassFeatures(ck, ch.subclass, nl) : [];
        const oldRes = CD.getResourcesForLevel(ck || '', lvl, ch) || [], newRes = CD.getResourcesForLevel(ck || '', nl, ch) || [];
        const resCh = newRes.filter(r => !r.isPassive).map(r => { const o = oldRes.find(x => x.key === r.key); return (!o || o.max !== r.max) ? `${r.icon || '◆'} ${r.namePL}: ${o ? o.max : 0} → ${r.max}` : ''; }).filter(Boolean);
        const st = { pw: 'sr', podklasa: '', tryb: 'asi', cechy: {}, atut: '', atutCecha: '', zdolnosci: [], loading: true };
        const AB6 = ['str', 'dex', 'con', 'int', 'wis', 'cha'];
        const used = () => Object.values(st.cechy).reduce((a, b) => a + b, 0);
        const draw = () => {
            const feat = CD.FEATS.find(f => f.key === st.atut);
            ov.innerHTML = `<div class="pl-sheet-bg" data-close><div class="pl-qsheet pl-lvl" role="dialog" aria-label="Awans">
                <button class="pl-icon pl-qclose" data-close><i class="fa-solid fa-xmark"></i></button>
                <div class="pl-lvl-h"><i class="fa-solid fa-angles-up"></i><div><small>Awans</small><b>Poziom ${lvl} → ${nl}</b><span>${esc(ch.name)} · ${esc(ch.class || '')}</span></div></div>
                ${profOf(nl) !== profOf(lvl) ? `<p class="pl-lvl-note"><i class="fa-solid fa-arrow-up"></i> Premia z biegłości: +${profOf(lvl)} → +${profOf(nl)}</p>` : ''}
                <section><h4><i class="fa-solid fa-heart"></i> Punkty wytrzymałości</h4>
                    <div class="pl-seg2"><button data-lv-pw="sr" class="${st.pw === 'sr' ? 'on' : ''}">Średnia: +${avg} PW</button><button data-lv-pw="rzut" class="${st.pw === 'rzut' ? 'on' : ''}">Rzut k${die}${conMod ? (conMod > 0 ? '+' : '') + conMod : ''}</button></div>
                    ${st.pw === 'rzut' ? '<small class="pl-muted">Rzuci serwer w chwili zatwierdzenia — wynik zobaczy cały stół.</small>' : ''}</section>
                ${isSub && subs.length ? `<section><h4><i class="fa-solid fa-shield-halved"></i> Wybierz podklasę</h4>${subs.map(sc => `<button class="pl-opt ${st.podklasa === sc.key ? 'on' : ''}" data-lv-sub="${esc(sc.key)}"><b>${esc(sc.name)}</b><small>${esc(sc.desc || '')}</small></button>`).join('')}</section>` : ''}
                ${isASI ? `<section><h4><i class="fa-solid fa-dumbbell"></i> Wzrost cech albo atut</h4>
                    <div class="pl-seg2"><button data-lv-tryb="asi" class="${st.tryb === 'asi' ? 'on' : ''}">+2 do cech</button><button data-lv-tryb="atut" class="${st.tryb === 'atut' ? 'on' : ''}">Atut</button></div>
                    ${st.tryb === 'asi' ? `<p class="pl-muted">Rozdziel 2 punkty (najwyżej +2 na cechę, maks. 20). Zostało: <b>${2 - used()}</b></p>
                        <div class="pl-asi">${AB6.map(a => { const cur = A[a] ?? 10, add = st.cechy[a] || 0; return `<div class="pl-asi-c"><span>${AB_SHORT[a.toUpperCase()] || a}</span><b>${cur + add}</b>${add ? `<small>+${add}</small>` : '<small>&nbsp;</small>'}<div><button data-lv-asi="${a}:-1" ${add ? '' : 'disabled'}>−</button><button data-lv-asi="${a}:1" ${used() < 2 && add < 2 && cur + add < 20 ? '' : 'disabled'}>+</button></div></div>`; }).join('')}</div>`
                    : `<select id="pl-lv-feat"><option value="">— wybierz atut —</option>${CD.FEATS.map(f => `<option value="${esc(f.key)}" ${st.atut === f.key ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select>
                        ${feat ? `<p class="pl-text">${esc(feat.desc)}</p>${feat.prerequisite ? `<small class="pl-muted">Wymaganie: ${esc(feat.prerequisite)}</small>` : ''}${feat.effects?.abilityChoice ? `<div class="pl-seg2">${feat.effects.abilityChoice.map(a => `<button data-lv-fab="${a}" class="${st.atutCecha === a ? 'on' : ''}">+${feat.effects.abilityBonus || 1} ${AB_SHORT[a.toUpperCase()] || a}</button>`).join('')}</div>` : ''}` : ''}`}
                </section>` : ''}
                <section><h4><i class="fa-solid fa-scroll"></i> Nowe zdolności</h4>
                    ${st.loading ? '<p class="pl-muted"><i class="fa-solid fa-spinner fa-spin"></i> Pobieram opisy z podręcznika…</p>' : ''}
                    ${st.zdolnosci.map(f => `<details class="pl-feat"><summary><span>${esc(f.name)}</span></summary>${f.desc ? `<p>${esc(f.desc)}</p>` : ''}</details>`).join('')}
                    ${subFeat.map(f => `<details class="pl-feat"><summary><span>${esc(f.name)}</span><small>podklasa</small></summary><p>${esc(f.desc || '')}</p></details>`).join('')}
                    ${(CD.EXTRA_ATTACK[ck] || []).includes(nl) ? '<p class="pl-lvl-note"><i class="fa-solid fa-khanda"></i> Dodatkowy atak w akcji Ataku.</p>' : ''}
                    ${resCh.map(t => `<p class="pl-lvl-note">${esc(t)}</p>`).join('')}
                    ${!st.loading && !st.zdolnosci.length && !subFeat.length && !resCh.length ? '<p class="pl-muted">Na tym poziomie nie ma nowych zdolności klasowych.</p>' : ''}</section>
                <div class="pl-qactions"><button class="pl-btn gold big" data-lv-go><i class="fa-solid fa-angles-up"></i> Zatwierdź awans na poziom ${nl}</button></div>
            </div></div>`;
            const sel = ov.querySelector('#pl-lv-feat'); if (sel) sel.onchange = (e) => { st.atut = e.target.value; st.atutCecha = ''; draw(); };
        };
        draw();
        // opisy nowych zdolności klasowych z SRD (jak u MG)
        (async () => {
            try {
                const ld = await Promise.race([APIClient.getClassLevel(ck, nl), new Promise((_, r) => setTimeout(() => r(new Error('t')), 9000))]);
                const fs = await Promise.all((ld?.features || []).map(async f => {
                    try { const d = await APIClient.getFeature(f.index); const desc = Array.isArray(d?.desc) ? d.desc.join('\n') : (d?.desc || ''); return { name: d?.name || f.name, index: f.index, desc: await APIClient.translateText(desc) }; }
                    catch (e) { return { name: f.name, index: f.index, desc: '' }; }
                }));
                st.zdolnosci = fs;
            } catch (e) {}
            st.loading = false;
            if (ov.querySelector('.pl-lvl')) draw();
        })();
        ov.onclick = async (e) => {
            const b = (q) => e.target.closest(q);
            if (e.target.matches('[data-close]') || b('button[data-close]')) { ov.innerHTML = ''; return; }
            if (b('[data-lv-pw]')) { st.pw = b('[data-lv-pw]').dataset.lvPw; draw(); return; }
            if (b('[data-lv-sub]')) { st.podklasa = b('[data-lv-sub]').dataset.lvSub; draw(); return; }
            if (b('[data-lv-tryb]')) { st.tryb = b('[data-lv-tryb]').dataset.lvTryb; draw(); return; }
            if (b('[data-lv-fab]')) { st.atutCecha = b('[data-lv-fab]').dataset.lvFab; draw(); return; }
            if (b('[data-lv-asi]')) { const [a, d] = b('[data-lv-asi]').dataset.lvAsi.split(':'); st.cechy[a] = Math.max(0, Math.min(2, (st.cechy[a] || 0) + +d)); if (!st.cechy[a]) delete st.cechy[a]; draw(); return; }
            if (b('[data-lv-go]')) {
                if (isSub && subs.length && !st.podklasa) { toast('Wybierz podklasę.', 'bad'); return; }
                if (isASI && st.tryb === 'atut' && !st.atut) { toast('Wybierz atut albo przełącz na wzrost cech.', 'bad'); return; }
                if (isASI && st.tryb === 'asi' && used() < 2 && !await Ask.confirm(`Rozdzielono ${used()} z 2 punktów. Niewykorzystane przepadną.`, { title: 'Nie wszystkie punkty', ok: 'Kontynuuj' })) return;
                const fe = st.tryb === 'atut' ? CD.FEATS.find(f => f.key === st.atut) : null;
                if (fe?.effects?.abilityChoice && !st.atutCecha) { toast('Wybierz cechę, którą podnosi atut.', 'bad'); return; }
                const btn = b('[data-lv-go]'); btn.disabled = true;
                try {
                    const r = await api('/api/gracz/akcja', { typ: 'awans', poziom: nl, pw: st.pw, podklasa: st.podklasa || null, cechy: isASI && st.tryb === 'asi' ? st.cechy : null, atut: isASI && st.tryb === 'atut' ? st.atut : null, atutCecha: st.atutCecha || null, zdolnosci: st.zdolnosci });
                    ov.innerHTML = '';
                    toast(`Awans! ${ch.name} ma teraz ${nl}. poziom.`, 'good');
                    try { navigator.vibrate?.([60, 40, 120]); } catch (er) {}
                    celebrate(nl);
                    load();
                } catch (er) { toast(er.message, 'bad'); btn.disabled = false; }
            }
        };
    }
    function celebrate(nl) {
        const el = document.createElement('div'); el.className = 'pl-celebrate';
        el.innerHTML = `<div><i class="fa-solid fa-angles-up"></i><b>Poziom ${nl}!</b></div>${Array.from({ length: 26 }, (_, i) => `<i class="pl-spark" style="--x:${(Math.random() * 100).toFixed(1)}%;--d:${(Math.random() * .6).toFixed(2)}s;--c:${['#e9c46a', '#fff3cf', '#d0614f', '#6fbf73'][i % 4]}"></i>`).join('')}`;
        document.body.appendChild(el); setTimeout(() => el.classList.add('out'), 2200); setTimeout(() => el.remove(), 2800);
    }

    function onInput(e) {
        const t = e.target;
        const ch = V.character; if (!ch) return;
        if (t.dataset.notes != null) {
            ch.playerNotes = t.value;
            const s = $('#pl-notes-s'); if (s) s.textContent = 'Zapisuję…';
            clearTimeout(notesT); notesT = setTimeout(async () => { if (await act({ typ: 'pole', path: 'playerNotes', value: t.value })) { const s2 = $('#pl-notes-s'); if (s2) s2.textContent = 'Zapisano.'; } }, 800);
        }
        if (t.dataset.inv) {
            const [i, f] = t.dataset.inv.split(':');
            const it = ch.inventory[+i]; if (!it) return;
            it[f] = f === 'quantity' ? Math.max(0, parseInt(t.value, 10) || 0) : t.value;
            clearTimeout(invT); invT = setTimeout(() => act({ typ: 'pole', path: 'inventory', value: ch.inventory }), 700);
        }
    }
    function floatHp(txt, kind) {
        const box = $('.pl-hp'); if (!box) return;
        const f = document.createElement('div'); f.className = `pl-float ${kind}`; f.textContent = txt;
        box.appendChild(f); setTimeout(() => f.remove(), 1200);
    }

    // ---------- instalacja aplikacji na telefonie / komputerze ----------
    function installButton() {
        const b = $('#pl-install'); if (!b || !window.PanelApp) return;
        const btns = () => [b, $('#pl-top-install'), $('#pl-more [data-install]')].filter(Boolean);
        const upd = () => { const off = PanelApp.standalone() || !!JAKO; btns().forEach(x => { x.hidden = off; }); };
        upd(); addEventListener('pmg-install-ready', upd);
        b.onclick = () => install();
    }
    // telefony instalują aplikację tylko z adresu https — panel w sieci domowej ma taki adres (usługa local-ip.sh),
    // więc najpierw sprawdzamy, czy telefon do niego dociera, i przenosimy tam gracza (zaloguje się sam)
    async function ping(url, ms = 5000) {
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
        try { const r = await fetch(url + '/api/ping', { cache: 'no-store', signal: ctl.signal }); return r.ok; } catch (e) { return false; } finally { clearTimeout(t); }
    }
    // co blokuje bezpieczny adres: brak certyfikatu na komputerze MG, nazwa *.local-ip.sh blokowana przez router (DNS) albo port https
    async function secureTarget() {
        let s = null;
        try { s = await (await fetch('/api/bezpieczny', { cache: 'no-store' })).json(); } catch (e) { return { why: 'server' }; }
        if (!s?.https || !s.url) return { why: 'nocert', s };
        if (await ping(s.url)) return { ok: true, s };
        const host = s.url.replace(/^https:\/\//, '').replace(/:\d+$/, '');
        const dnsOk = await ping(`http://${host}:${location.port || 80}`);
        return { why: dnsOk ? 'port' : 'dns', s, host };
    }
    // Chrome na Androidzie instaluje aplikację w tle — na części telefonów ikona trafia tylko na listę aplikacji
    // albo Chrome nie ma zgody na dodawanie ikon (Xiaomi, Redmi, POCO, Oppo, Vivo)
    const noIconTips = () => `<div class="pl-install-why tips"><b><i class="fa-solid fa-circle-question"></i> „Instaluję…”, a ikony nie ma?</b>
            <ol class="pl-howto">
                <li>Zajrzyj na <b>listę wszystkich aplikacji</b> (przesuń w górę ekran główny) i poszukaj <b>„Przy stole”</b> — przytrzymaj ikonę i przeciągnij ją na ekran główny.</li>
                <li><b>Xiaomi / Redmi / POCO:</b> Ustawienia → Aplikacje → <b>Chrome</b> → Uprawnienia aplikacji → Inne uprawnienia → <b>Skróty na ekranie głównym</b> → Zezwalaj. <b>Oppo / Realme / Vivo:</b> Ustawienia → Aplikacje → Chrome → Uprawnienia → <b>Skróty</b>. Potem zainstaluj jeszcze raz.</li>
                <li>Nadal nic? Usuń starą próbę (przytrzymaj ikonę → Odinstaluj, jeśli jest), a potem w Chrome menu <b>⋮ → Dodaj do ekranu głównego → Utwórz skrót</b>. Taki skrót też otwiera stół na pełnym ekranie.</li>
            </ol></div>`;
    function afterInstall() {
        App.showModal('Instalacja „Przy stole”', `<div class="pl-install-how"><img src="/app/gracz-192.png" alt=""><div><p class="pl-install-ok"><i class="fa-solid fa-check"></i> Chrome instaluje aplikację — ikona powinna pojawić się w ciągu kilkunastu sekund.</p>${PanelApp.android ? noIconTips() : ''}</div></div>`,
            '<button class="btn-primary" onclick="App.closeModal()">Rozumiem</button>');
    }
    addEventListener('appinstalled', () => toast('Aplikacja „Przy stole” zainstalowana — znajdziesz ją na ekranie głównym albo na liście aplikacji.', 'good'));
    async function install() {
        setMore(false);
        if (!JAKO && me?.gracz?.kod && !/[?&]kod=/.test(location.search)) { try { history.replaceState(null, '', `/gracz?kod=${encodeURIComponent(me.gracz.kod)}`); } catch (e) {} }
        if (PanelApp.canPrompt()) { if (await PanelApp.install()) afterInstall(); return; }
        const iosHow = `<ol class="pl-howto"><li>Otwórz tę stronę w <b>Safari</b>.</li><li>Stuknij <b>Udostępnij</b> <i class="fa-solid fa-arrow-up-from-bracket"></i> na dolnym pasku.</li><li>Wybierz <b>Do ekranu początkowego</b> i potwierdź <b>Dodaj</b>.</li></ol>`;
        const andHow = `<ol class="pl-howto"><li>Stuknij menu <b>⋮</b> w prawym górnym rogu Chrome.</li><li>Wybierz <b>Zainstaluj aplikację</b> — albo <b>Dodaj do ekranu głównego</b> i potem <b>Zainstaluj</b>.</li><li>Jeśli tych opcji nie ma, odśwież stronę, odczekaj kilka sekund i stuknij <b>Zainstaluj aplikację</b> jeszcze raz.</li></ol>`;
        const pcHow = `<ol class="pl-howto"><li>Kliknij ikonę <b>Zainstaluj</b> <i class="fa-solid fa-display"></i> na końcu paska adresu Chrome lub Edge</li><li>albo menu <b>⋮</b> → <b>Zainstaluj „Przy stole”</b>.</li></ol>`;
        const how = PanelApp.ios ? iosHow : PanelApp.android ? andHow : pcHow;
        const show = (body, foot) => App.showModal('Zainstaluj aplikację „Przy stole”', `<div class="pl-install-how"><img src="/app/gracz-192.png" alt=""><div>${body}</div></div>`, foot || '<button class="btn-primary" onclick="App.closeModal()">Rozumiem</button>');
        if (window.isSecureContext) {
            show(`<p class="pl-install-ok"><i class="fa-solid fa-lock"></i> Jesteś na bezpiecznym adresie — telefon może zainstalować aplikację.</p>${how}<p class="pl-muted">Ikona otworzy od razu Twoją postać, bez paska przeglądarki.</p>${PanelApp.android ? noIconTips() : ''}`);
            return;
        }
        show(`<p class="pl-install-wait"><i class="fa-solid fa-spinner fa-spin"></i> Sprawdzam bezpieczny adres stołu…</p>`, ' ');
        const r = await secureTarget();
        const go = r.s?.gracz ? `<a class="btn-primary" href="${esc(r.s.gracz)}"><i class="fa-solid fa-lock"></i> Przejdź do wersji do instalacji</a>` : '';
        if (r.ok && go) {
            show(`<p><b>Telefon instaluje aplikacje tylko z bezpiecznego adresu (https).</b> Stół ma taki adres — przejdź na niego jednym stuknięciem, zalogujesz się sam.</p>
                <p class="pl-muted">Na nowej stronie stuknij jeszcze raz <b>Zainstaluj aplikację</b>${PanelApp.ios ? ' i postępuj według wskazówek' : ''}.</p>`,
                `<button class="btn-secondary" onclick="App.closeModal()">Później</button>${go}`);
            return;
        }
        const origin = location.origin;
        const copy = (t) => `<code>${esc(t)}</code> <button class="btn-secondary btn-small" onclick="navigator.clipboard?.writeText('${esc(t)}').then(()=>this.textContent='Skopiowano').catch(()=>{})">Kopiuj</button>`;
        const why = {
            dns: `<div class="pl-install-why"><b><i class="fa-solid fa-route"></i> Router w tej sieci blokuje bezpieczny adres.</b>
                    <p>Ustaw w telefonie inny serwer nazw (to nic nie psuje, zwykle wręcz przyspiesza internet):</p>
                    ${PanelApp.ios ? `<ol class="pl-howto"><li><b>Ustawienia → Wi‑Fi</b> → stuknij <b>ⓘ</b> przy swojej sieci.</li><li><b>Konfiguruj DNS → Ręcznie</b>, usuń wpisy i dodaj <b>8.8.8.8</b> → <b>Zachowaj</b>.</li></ol>`
                        : `<ol class="pl-howto"><li><b>Ustawienia → Połączenia</b> (lub <b>Sieć i internet</b>) → <b>Prywatny DNS</b>.</li><li>Wybierz <b>Nazwa hosta dostawcy</b> i wpisz ${copy('dns.google')} → <b>Zapisz</b>.</li></ol>`}
                    <p>Potem wróć tutaj i jeszcze raz stuknij <b>Zainstaluj aplikację</b>.</p></div>`,
            port: `<div class="pl-install-why"><b><i class="fa-solid fa-shield-halved"></i> Zapora na komputerze Mistrza Gry blokuje port ${esc((r.s?.url || '').split(':').pop() || '8443')}.</b>
                    <p>Mistrz Gry: <b>Zabezpieczenia Windows → Zapora → Zezwalaj aplikacji przez zaporę</b> → przy <b>Node.js</b> zaznacz <b>Prywatne</b>. Potem stuknij jeszcze raz <b>Zainstaluj aplikację</b>.</p></div>`,
            nocert: `<div class="pl-install-why"><b><i class="fa-solid fa-wifi"></i> Komputer Mistrza Gry nie pobrał jeszcze certyfikatu.</b><p>Potrzebuje do tego internetu — zrobi to sam przy następnym uruchomieniu panelu.</p></div>`,
            server: ''
        }[r.why] || '';
        const flag = PanelApp.ios ? '' : `<details class="pl-install-adv"><summary><i class="fa-solid fa-screwdriver-wrench"></i> Inny sposób: pełna aplikacja bez bezpiecznego adresu (Chrome, jednorazowo)</summary>
                <ol class="pl-howto"><li>Wpisz w pasku adresu Chrome ${copy('chrome://flags/#unsafely-treat-insecure-origin-as-secure')}</li>
                <li>W pole wklej adres stołu ${copy(origin)}</li>
                <li>Ustaw <b>Enabled</b>, stuknij <b>Relaunch</b>, wróć tutaj i jeszcze raz <b>Zainstaluj aplikację</b>.</li></ol></details>`;
        show(`<p><b>Telefon pozwala instalować aplikacje tylko z bezpiecznych adresów (https).</b></p>
            ${why}
            <details class="pl-install-adv"><summary><i class="fa-solid fa-mobile-screen"></i> Od razu: zwykła ikona na ekranie głównym</summary>${PanelApp.ios ? iosHow : `<ol class="pl-howto"><li>Stuknij menu <b>⋮</b> w Chrome.</li><li>Wybierz <b>Dodaj do ekranu głównego</b> → <b>Utwórz skrót</b>.</li></ol>`}</details>
            ${flag}`,
            `<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>${go ? go.replace('Przejdź do wersji do instalacji', 'Spróbuj mimo to') : ''}`);
    }
    // ---------- panel kości — ten sam co u Mistrza Gry (przycisk w rogu, kości, tryb, modyfikator, 3D) ----------
    const diceOpen = () => document.body.classList.contains('dice-open');
    function toggleDice(force) {
        const open = force === undefined ? !diceOpen() : force;
        document.body.classList.toggle('dice-open', open);
        if (open) { dicePanelSettings(); diceHistory(); setTimeout(() => { const i = $('#dice-expression'); if (i && matchMedia('(pointer: fine)').matches) { i.focus(); i.select(); } }, 80); }
        else if (document.activeElement?.closest?.('#dice-roller')) document.activeElement.blur();
    }
    const diceMode = () => ({ advantage: 'adv', disadvantage: 'dis' })[document.querySelector('input[name="roll-mode"]:checked')?.value] || null;
    const diceMod = () => { const m = parseInt($('#dice-modifier')?.value, 10) || 0; return m ? (m > 0 ? `+${m}` : `${m}`) : ''; };
    // przycisk kości można przeciągnąć w dowolne miejsce (zapamiętane na tym urządzeniu); krótkie stuknięcie nadal otwiera kości
    let fabDragged = false;
    function fabDrag() {
        const fab = $('#dice-fab'); if (!fab || fab.dataset.drag) return;
        fab.dataset.drag = '1'; fab.style.touchAction = 'none';
        const KEY = 'pl_fab_pos';
        const bnav = () => (matchMedia('(max-width: 760px)').matches ? parseFloat(getComputedStyle(document.body).getPropertyValue('--bnav')) || 64 : 0);
        const place = (x, y) => {
            const w = fab.offsetWidth || 54, h = fab.offsetHeight || 54, m = 6;
            x = Math.max(m, Math.min(innerWidth - w - m, x));
            y = Math.max(m, Math.min(innerHeight - bnav() - h - m, y));
            fab.style.setProperty('left', `${x}px`, 'important'); fab.style.setProperty('top', `${y}px`, 'important');
            fab.style.setProperty('right', 'auto', 'important'); fab.style.setProperty('bottom', 'auto', 'important');
            return { x, y };
        };
        const restore = () => {
            let p = null; try { p = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) {}
            if (p && typeof p.x === 'number') place(p.x * innerWidth, p.y * innerHeight);
        };
        restore(); addEventListener('resize', restore);
        let st = null;
        fab.addEventListener('pointerdown', (e) => {
            if (e.button !== 0) return;
            const r = fab.getBoundingClientRect();
            st = { id: e.pointerId, sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top, moving: false };
        });
        addEventListener('pointermove', (e) => {
            if (!st || e.pointerId !== st.id) return;
            const dx = e.clientX - st.sx, dy = e.clientY - st.sy;
            if (!st.moving) {
                if (Math.hypot(dx, dy) < 8) return;
                st.moving = true; fab.setPointerCapture?.(e.pointerId); fab.classList.add('dragging');
            }
            e.preventDefault();
            st.last = place(st.ox + dx, st.oy + dy);
        });
        const end = (e) => {
            if (!st || e.pointerId !== st.id) return;
            if (st.moving) {
                fabDragged = true; setTimeout(() => { fabDragged = false; }, 400);
                fab.classList.remove('dragging');
                const r = st.last || { x: fab.getBoundingClientRect().left, y: fab.getBoundingClientRect().top };
                try { localStorage.setItem(KEY, JSON.stringify({ x: r.x / innerWidth, y: r.y / innerHeight })); } catch (er) {}
                if (!localStorage.getItem('pl_fab_tip')) { try { localStorage.setItem('pl_fab_tip', '1'); } catch (er) {} toast('Kostka zostanie tutaj. Dwuklik na niej wraca do rogu.'); }
            }
            st = null;
        };
        addEventListener('pointerup', end); addEventListener('pointercancel', end);
        // dwuklik / podwójne stuknięcie: z powrotem w róg
        fab.addEventListener('dblclick', (e) => {
            e.preventDefault(); toggleDice(false);
            ['left', 'top', 'right', 'bottom'].forEach(k => fab.style.removeProperty(k));
            try { localStorage.removeItem(KEY); } catch (er) {}
        });
    }
    function dicePanelInit() {
        const panel = $('#dice-roller'); if (!panel) return;
        $('#dice-fab').onclick = () => { if (fabDragged) { fabDragged = false; return; } toggleDice(); };
        fabDrag();
        panel.addEventListener('click', (e) => {
            const b = (q) => e.target.closest(q);
            if (b('[data-action="toggle-dice"]')) { toggleDice(false); return; }
            if (b('[data-coin]')) { roll('1k2', 'Rzut monetą', 'n'); return; }
            if (b('[data-dice]')) { roll(`1k${b('[data-dice]').dataset.dice.slice(1)}${diceMod()}`, '', diceMode() || 'n'); return; }
            if (b('#btn-roll-custom')) { customRoll(); return; }
            const sw = b('[data-dcolor]'); if (sw) { D3.setColor(sw.dataset.dcolor); dicePanelSettings(); return; }
            if (b('[data-d3toggle]')) { D3.setOn(!D3.on()); dicePanelSettings(); }
        });
        panel.addEventListener('change', (e) => { if (e.target.name === 'roll-mode') ui.mode = diceMode(); });
        $('#dice-expression').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); customRoll(); } });
        document.addEventListener('mousedown', (e) => { if (diceOpen() && !e.target.closest('#dice-roller, #dice-fab')) toggleDice(false); });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && diceOpen()) { toggleDice(false); return; }
            if (e.key.toLowerCase() === 'd' && !e.ctrlKey && !e.metaKey && !e.altKey && !e.target.closest('input, textarea, select, [contenteditable]')) { e.preventDefault(); toggleDice(); }
        });
        const radio = document.querySelector(`input[name="roll-mode"][value="${ui.mode === 'adv' ? 'advantage' : ui.mode === 'dis' ? 'disadvantage' : 'normal'}"]`); if (radio) radio.checked = true;
        dicePanelSettings();
    }
    function customRoll() {
        const v = ($('#dice-expression')?.value || '').trim().replace(/d/gi, 'k'); if (!v) return;
        roll(`${v}${diceMod()}`, '', diceMode() || 'n');
    }
    function dicePanelSettings() {
        const row = $('#dice3d-settings'); if (!row) return;
        const fileMode = location.protocol === 'file:', cur = D3.col()[0], on = D3.on();
        row.innerHTML = `<div class="d3-head"><span>Kości 3D</span><button class="d3-toggle ${on && !fileMode ? 'on' : ''}" data-d3toggle ${fileMode ? 'disabled' : ''} title="Włącz / wyłącz rzut na stół"><span></span></button></div>
            ${D3.failed() ? '<div class="d3-note">Ta przeglądarka nie obsługuje grafiki 3D (WebGL). Używam animacji 2D.</div>'
              : `<div class="d3-swatches">${D3.COLORS.map(([id, c, a, n]) => `<button class="d3-swatch${id === cur ? ' active' : ''}" data-dcolor="${id}" title="${n}" style="--c:${c};--a:${a}"></button>`).join('')}</div>`}`;
    }
    function dicePanelResult(w) {
        const box = $('#dice-result'); if (!box || !w?.rzut) return;
        const r = w.rzut, coin = isCoin(w);
        box.innerHTML = `<div class="result-value ${!coin && r.crit === 'max' ? 'roll-critical' : !coin && r.crit === 'min' ? 'roll-fumble' : ''}">${coin ? coinText(w) : r.total}</div>
            ${coin ? '' : `<div class="result-detail">${esc(r.expr)} ${rollDetail(r)}</div>`}
            ${!coin && r.crit === 'max' ? '<div><span style="color:var(--gold-light);font-size:0.75rem;">🌟 NATURALNA 20!</span></div>' : !coin && r.crit === 'min' ? '<div><span style="color:var(--danger-color);font-size:0.75rem;">💀 KRYTYCZNA PORAŻKA!</span></div>' : ''}`;
        box.style.animation = 'none'; void box.offsetHeight; box.style.animation = 'pulse 0.3s ease-in-out';
        const fab = $('#dice-fab-last');
        if (fab && !coin) { fab.textContent = r.total; fab.classList.remove('pop', 'crit', 'fumble'); void fab.offsetWidth; fab.classList.add('pop'); if (!coin && r.crit === 'max') fab.classList.add('crit'); if (!coin && r.crit === 'min') fab.classList.add('fumble'); }
        diceHistory();
    }
    // historia moich rzutów (z dziennika stołu)
    function diceHistory() {
        const box = $('#dice-history'); if (!box) return;
        const mine = log.filter(e => e.typ === 'rzut' && e.pid && e.pid === V?.player?.id).slice(-30).reverse();
        const chip = (v, sides, off) => `<span class="dh-ch ${off ? 'off' : ''} ${!off && sides === 20 && v === 20 ? 'max' : ''} ${!off && sides === 20 && v === 1 ? 'min' : ''}">${v}</span>`;
        box.innerHTML = mine.length ? `<div class="dh-head"><span class="dh-title"><i class="fa-solid fa-clock-rotate-left"></i> Moje rzuty</span></div>` + mine.map(e => {
            const r = e.rzut, coin = isCoin(e);
            const dice = coin ? '' : r.parts.map(p => p.die ? `${p.sign < 0 ? '<span class="dh-mod">−</span>' : ''}${p.rolls.map(v => chip(v, parseInt(String(p.die).split('k')[1], 10))).join('')}${p.dropped != null ? chip(p.dropped, 0, true) : ''}` : `<span class="dh-mod">${p.mod < 0 ? '−' : '+'}${Math.abs(p.mod)}</span>`).join('');
            const who = e.postac || e.kto || '?';
            return `<div class="dh-row ${!coin && r.crit ? 'c-' + r.crit : ''}" style="--who:${/^#[0-9a-f]{6}$/i.test(e.kolor || '') ? e.kolor : '#c9a35c'}">
                <i class="dh-dot">${esc(String(who).charAt(0).toUpperCase())}${e.av && window.Portrait ? Portrait.img(Portrait.fromAv(e.av)) : ''}</i>
                <div class="dh-main"><div class="dh-top"><b class="dh-who">${esc(who)}</b><time>${new Date(e.t).toLocaleTimeString(window.LOC || 'pl-PL', { hour: '2-digit', minute: '2-digit' })}</time></div>
                ${e.opis ? `<div class="dh-lbl">${esc(e.opis)}</div>` : ''}
                ${coin ? '' : `<div class="dh-dice"><span class="dh-expr">${esc(r.expr)}</span>${dice}${r.mode === 'adv' ? '<em class="dh-mode">ułatwienie</em>' : r.mode === 'dis' ? '<em class="dh-mode">utrudnienie</em>' : ''}</div>`}</div>
                <span class="dh-total">${coin ? coinText(e) : r.total}</span></div>`;
        }).join('') : '<p class="empty-state">Brak historii rzutów</p>';
    }
    // ---------- animacja kości (u gracza, przed pokazaniem wyniku) ----------
    const DIE_SHAPE = {
        4: '<polygon points="50,6 95,88 5,88"/><path d="M50 6 L50 88 M5 88 L50 60 L95 88" class="e"/>',
        6: '<rect x="10" y="10" width="80" height="80" rx="14"/><path d="M10 10 L26 26 M90 10 L74 26 M10 90 L26 74 M90 90 L74 74" class="e"/>',
        8: '<polygon points="50,4 94,50 50,96 6,50"/><path d="M6 50 L94 50 M50 4 L28 50 L50 96 L72 50 Z" class="e"/>',
        10: '<polygon points="50,4 93,40 78,92 22,92 7,40"/><path d="M50 4 L35 58 L50 70 L65 58 Z M7 40 L35 58 M93 40 L65 58 M22 92 L50 70 L78 92" class="e"/>',
        12: '<polygon points="50,4 94,36 77,90 23,90 6,36"/><polygon points="50,24 72,40 64,66 36,66 28,40" class="e"/>',
        20: '<polygon points="50,3 93,27 93,73 50,97 7,73 7,27"/><path d="M50 3 L28 38 L72 38 Z M28 38 L50 76 L72 38 M7 27 L28 38 M93 27 L72 38 M7 73 L50 76 L93 73 M50 76 L50 97 M28 38 L7 73 M72 38 L93 73" class="e"/>'
    };
    const dieColor = { 4: '#2e86c1', 6: '#8e44ad', 8: '#16a085', 10: '#d35400', 12: '#c0392b', 20: '#b8860b', 100: '#7f8c8d' };
    function rollAnim(e) {
        return new Promise((done) => {
            const r = e.rzut;
            const dice = [];
            r.parts.forEach(p => {
                if (!p.die) return;
                const sides = +String(p.die).split('k')[1];
                p.rolls.forEach(v => dice.push({ sides, v, keep: true }));
                if (p.dropped != null) dice.push({ sides, v: p.dropped, keep: false });
            });
            if (!dice.length) { done(false); return; }
            const show = dice.slice(0, 8);
            const tray = document.createElement('div');
            tray.className = 'pl-tray';
            const mods = r.parts.filter(p => !p.die).reduce((a, p) => a + p.mod, 0);
            tray.innerHTML = `<div class="pl-tray-box">${e.opis ? `<div class="pl-tray-t">${esc(e.opis)}</div>` : ''}<div class="pl-tray-in">${show.map((d, i) => {
                const shape = DIE_SHAPE[d.sides] || DIE_SHAPE[d.sides === 100 ? 10 : 20];
                return `<div class="pl-d3" style="--c:${dieColor[d.sides] || '#b8860b'};--i:${i};--rx:${(Math.random() * 720 - 360) | 0}deg;--ty:${(Math.random() * 40 - 20) | 0}px">
                    <svg viewBox="0 0 100 100">${shape}</svg><b>${1 + Math.floor(Math.random() * d.sides)}</b><small>k${d.sides}</small></div>`;
            }).join('')}${dice.length > 8 ? `<span class="pl-tray-more">+${dice.length - 8}</span>` : ''}</div>
                <div class="pl-tray-sum ${r.crit ? 'c-' + r.crit : ''}"><b>${r.total}</b><span>${esc(r.expr)}${mods ? ` (${mods > 0 ? '+' : '−'}${Math.abs(mods)})` : ''}${r.mode === 'adv' ? ' · ułatwienie' : r.mode === 'dis' ? ' · utrudnienie' : ''}${r.crit === 'max' ? ' · naturalne 20!' : r.crit === 'min' ? ' · naturalna 1' : ''}</span></div></div>`;
            document.body.appendChild(tray);
            try { navigator.vibrate?.(30); } catch (er) {}
            const els = [...tray.querySelectorAll('.pl-d3')];
            const t0 = performance.now();
            const tick = setInterval(() => {
                els.forEach((el, i) => { if (!el.classList.contains('land')) el.querySelector('b').textContent = 1 + Math.floor(Math.random() * show[i].sides); });
            }, 70);
            els.forEach((el, i) => setTimeout(() => {
                el.classList.add('land');
                el.querySelector('b').textContent = show[i].v;
                if (!show[i].keep) el.classList.add('drop');
                else if (show[i].sides === 20 && show[i].v === 20) el.classList.add('max');
                else if (show[i].sides === 20 && show[i].v === 1) el.classList.add('min');
            }, 750 + i * 110));
            const end = 750 + show.length * 110 + 350;
            setTimeout(() => { clearInterval(tick); tray.classList.add('done'); done(true); }, end);
            setTimeout(() => { tray.classList.add('out'); }, end + 2300);
            setTimeout(() => tray.remove(), end + 2700);
            tray.addEventListener('click', () => { tray.classList.add('out'); setTimeout(() => tray.remove(), 300); });
        });
    }

    function showRoll(e) {
        const r = e.rzut;
        const box = document.createElement('div');
        box.className = `pl-rollpop ${r.crit ? 'c-' + r.crit : ''}`;
        box.innerHTML = `<small>${esc(e.opis || r.expr)}</small><b>${r.total}</b><span>${r.parts.map(p => p.die ? `[${p.rolls.join(', ')}${p.dropped != null ? ` / ${p.dropped}` : ''}]` : (p.mod < 0 ? '−' : '+') + Math.abs(p.mod)).join(' ')}${r.crit === 'max' ? ' · naturalne 20!' : r.crit === 'min' ? ' · naturalna 1' : ''}</span>`;
        document.body.appendChild(box);
        setTimeout(() => box.classList.add('out'), 2200);
        setTimeout(() => box.remove(), 2700);
    }

    // ---------- „MG pokazuje” ----------
    function showLive() {
        const L = V?.live;
        const old = $('.pl-live');
        if (!L) { old?.remove(); return; }
        if (L.kind === 'mapa') {
            if (ui.liveSeen !== L.id) { ui.liveSeen = L.id; localStorage.setItem('pl_live', L.id); ui.map = L.mapId; if (L.levelId) ui.level[L.mapId] = L.levelId; ui.tab = 'mapa'; render(); toast('Mistrz Gry pokazuje mapę'); }
            return;
        }
        if (ui.liveSeen === L.id) return;
        if (L.kind === 'tablica' && L.board && window.TavernBoard) { old?.remove(); chalkboard(L.board, L.id); return; }
        old?.remove();
        const el = document.createElement('div');
        el.className = `pl-live k-${L.kind}`;
        el.innerHTML = L.kind === 'obraz'
            ? `<div class="pl-live-img"><img src="${esc(L.url)}" alt=""><div class="pl-live-cap">${esc(L.title || '')}</div><button class="pl-btn" data-lclose>Zamknij</button></div>`
            : `<div class="pl-live-card"><div class="pl-live-seal">✦</div>${L.title ? `<h2>${esc(L.title)}</h2>` : ''}<div class="pl-live-text">${esc(L.text).split(/\n+/).map(p => `<p>${p}</p>`).join('')}</div><button class="pl-btn gold" data-lclose>Zamknij</button></div>`;
        el.onclick = (e) => { if (e.target.closest('[data-lclose]') || e.target === el) { ui.liveSeen = L.id; localStorage.setItem('pl_live', L.id); el.classList.add('out'); setTimeout(() => el.remove(), 300); } };
        document.body.appendChild(el);
    }

    // podgląd karty kolegi z drużyny: ta sama karta co do druku (PDF), tylko do odczytu
    function peekSheet(id) {
        const c = (V.party || []).find(x => x.id === id); const ch = c && teamSheet(c);
        if (!ch || !CharactersModule.sheetPrintHTML) return;
        $('.pl-live')?.remove();
        const el = document.createElement('div');
        el.className = 'pl-live k-peek';
        el.innerHTML = `<div class="pl-peek" role="dialog" aria-label="Karta postaci: ${esc(ch.name)}">
            <div class="pl-peek-head"><i class="fa-solid fa-eye"></i><div><h2>${esc(ch.name)}</h2><small>Podgląd karty${c.player ? ` · gra: ${esc(c.player)}` : ''} — tylko do odczytu</small></div><button class="pl-btn" data-lclose aria-label="Zamknij"><i class="fa-solid fa-xmark"></i></button></div>
            <iframe class="pl-peek-frame" title="Karta postaci" sandbox="allow-same-origin"></iframe></div>`;
        el.onclick = (e) => { if (e.target.closest('[data-lclose]') || e.target === el) { el.classList.add('out'); setTimeout(() => el.remove(), 300); } };
        document.body.appendChild(el);
        const fr = el.querySelector('iframe');
        // ekran zamiast kartki A4: skaluj do szerokości okna, bez okna drukowania
        fr.srcdoc = CharactersModule.sheetPrintHTML(ch).replace('</head>', `<meta name="viewport" content="width=device-width, initial-scale=1"><style>html,body{background:#fbf6ea!important;margin:0}body{padding:12px!important}@media (max-width:640px){.vit{grid-template-columns:repeat(4,1fr)!important}.cols{grid-template-columns:1fr!important}.abil{grid-template-columns:repeat(3,1fr)!important}.head{flex-wrap:wrap}}</style></head>`).replace(/<script[\s\S]*?<\/script>/gi, '');
    }
    // tablica karczmy: kreda na łupku w drewnianej ramie (menu z cenami z Podręcznika Gracza i plotka dnia)
    function chalkboard(B, liveId) {
        if (!B || !window.TavernBoard) return;
        $('.pl-live')?.remove();
        const el = document.createElement('div');
        el.className = 'pl-live k-tablica';
        const when = B.t ? new Date(B.t).toLocaleDateString(window.LOC || 'pl-PL', { day: 'numeric', month: 'long' }) : '';
        el.innerHTML = `<div class="pl-chalk" role="dialog" aria-label="Tablica karczmy">
            <div class="pl-chalk-head"><i class="fa-solid fa-beer-mug-empty"></i><div><h2>Tablica karczmy</h2><small>Wywiesił Mistrz Gry${when ? ` · ${esc(when)}` : ''}</small></div></div>
            ${TavernBoard.slateHTML(B, 'tb-big')}
            <div class="pl-chalk-foot"><button class="pl-btn gold" data-lclose>Zamknij</button></div></div>`;
        const close = () => { if (liveId) { ui.liveSeen = liveId; localStorage.setItem('pl_live', liveId); } el.classList.add('out'); setTimeout(() => el.remove(), 300); };
        el.onclick = (e) => { if (e.target.closest('[data-lclose]') || e.target === el) close(); };
        document.body.appendChild(el);
    }

    function toast(msg, kind = '') {
        const map = { bad: 'error', good: 'success', warn: 'warning', turn: 'turn' };
        if (window.App?.showToast) { App.showToast(msg, map[kind] || 'info'); return; }
        const box = $('#pl-toasts'); if (!box) return;
        const t = document.createElement('div'); t.className = `pl-toast ${kind}`; t.textContent = msg;
        box.appendChild(t); setTimeout(() => t.classList.add('out'), 3200); setTimeout(() => t.remove(), 3700);
    }

    document.addEventListener('DOMContentLoaded', boot);
    window.addEventListener('resize', () => { if (ui.tab === 'mapa' || ui.tab === 'walka') { Object.values(ui.z).forEach(s => { s.z = 0; }); render(); } });
    return { get V() { return V; }, render, ui };
})();
