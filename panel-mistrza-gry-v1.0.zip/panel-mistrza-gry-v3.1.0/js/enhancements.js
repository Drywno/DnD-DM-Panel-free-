/* ============================================
   D&D 5e DM Panel — Usprawnienia (UX layer)
   - Paleta poleceń / wyszukiwarka globalna (Ctrl+K)
   - Skróty klawiszowe
   - Zwijany panel boczny
   - Przypomnienie o kopii zapasowej
   - Nawigacja z pulpitu (data-goto / data-action)
   ============================================ */

const Enhancements = (() => {
    const LS = (k) => StorageManager.PREFIX + 'ui_' + k;
    const lsGet = (k, d) => { try { const v = localStorage.getItem(LS(k)); return v === null ? d : JSON.parse(v); } catch (e) { return d; } };
    const lsSet = (k, v) => { try { localStorage.setItem(LS(k), JSON.stringify(v)); } catch (e) {} };
    const esc = (s) => App.esc(s);
    const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l');

    // Order = keyboard shortcut order (1–9, 0)
    const TABS = [
        { tab: 'dashboard', label: 'Pulpit', icon: 'fa-chess-rook' },
        { tab: 'combat', label: 'Walka', icon: 'fa-khanda' },
        { tab: 'tavern', label: 'Stół do gier', icon: 'fa-dice' },
        { tab: 'characters', label: 'Drużyna', icon: 'fa-hat-wizard' },
        { tab: 'npcs', label: 'NPC i wrogowie', icon: 'fa-users' },
        { tab: 'campaign', label: 'Kampania — przegląd', icon: 'fa-eye', sub: 'overview' },
        { tab: 'bestiary', label: 'Bestiariusz', icon: 'fa-dragon' },
        { tab: 'spells', label: 'Magia', icon: 'fa-wand-magic-sparkles' },
        { tab: 'equipment', label: 'Ekwipunek', icon: 'fa-shield-halved' },
        { tab: 'rules', label: 'Zasady', icon: 'fa-book' }
    ];
    const CAMPAIGN_SUBS = [
        ['sessions', 'Sesje', 'fa-calendar-days'], ['quests', 'Zadania', 'fa-scroll'], ['locations', 'Lokacje', 'fa-location-dot'],
        ['maps', 'Mapy', 'fa-map'], ['plot', 'Fabuła', 'fa-book-open'], ['campaign-notes', 'Notatki MG', 'fa-pen-to-square']
    ];
    const keyFor = (i) => (i === 9 ? '0' : String(i + 1));
    const tabForKey = (k) => TABS[k === '0' ? 9 : +k - 1];

    const isTyping = (e) => {
        const t = e.target;
        return t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
    };
    const modalOpen = () => !document.getElementById('modal-backdrop')?.classList.contains('hidden');
    const click = (id) => document.getElementById(id)?.click();

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------
    const ACTIONS = {
        'new-note': () => click('btn-add-note'),
        'new-session': () => { if (!needCampaign()) return; click('btn-add-session'); },
        'new-location': () => { if (!needCampaign()) return; click('btn-add-location'); },
        'new-quest': () => { if (!needCampaign()) return; App.switchTab('campaign'); CampaignsModule.openSubtab('quests'); setTimeout(() => click('btn-add-quest'), 50); },
        'new-npc': () => NPCsModule.showAddNPCModal(),
        'new-enemy': () => NPCsModule.showAddEnemyModal(),
        'new-hero': () => { if (!needCampaign()) return; CharactersModule.showAddCharacterModal(); },
        'new-campaign': () => App.showNewCampaignModal(),
        'add-combatant': () => { App.switchTab('combat'); setTimeout(() => click('btn-add-combatant'), 50); },
        'export': () => App.exportData(),
        'import': () => click('btn-import-data'),
        'backups': () => openBackups(),
        'toggle-sidebar': () => toggleSidebar(),
        'shortcuts': () => showShortcuts(),
        'focus-dice': () => toggleDice(true),
        'toggle-dice': () => toggleDice(),
        'party-to-combat': () => partyToCombat(),
        'toggle-dice3d': () => {
            if (!window.Dice3D) return;
            const on = !Dice3D.enabled();
            Dice3D.setEnabled(on);
            App.showToast(on ? 'Kości 3D włączone' : 'Kości 3D wyłączone do odświeżenia strony', 'info');
        },
        'toggle-lang': () => window.I18N && I18N.set(window.LANG === 'en' ? 'pl' : 'en'),
        'toggle-theme': () => {
            const on = !document.body.classList.contains('theme-tavern');
            document.body.classList.toggle('theme-tavern', on);
            lsSet('tavernTheme', on);
            App.showToast(on ? 'Motyw karczmy włączony' : 'Motyw karczmy wyłączony', 'info');
        },
        'short-rest': () => { if (!needCampaign()) return; goto('characters'); PartyModule.showShortRest(); },
        'long-rest': () => { if (!needCampaign()) return; goto('characters'); PartyModule.showLongRest(); },
        'award-xp': () => { if (!needCampaign()) return; goto('characters'); PartyModule.showXP(); },
        'group-hp': () => { if (!needCampaign()) return; goto('characters'); PartyModule.showGroupHP(); }
    };

    function needCampaign() {
        if (App.getActiveCampaignId()) return true;
        App.showToast('Najpierw wybierz lub utwórz kampanię', 'warning');
        return false;
    }

    function goto(tab, subtab) {
        App.switchTab(tab, subtab);
    }

    // ---------------------------------------------------------------
    // Combat helpers
    // ---------------------------------------------------------------
    const d20 = () => Math.floor(Math.random() * 20) + 1;
    const abMod = (s) => Math.floor(((s ?? 10) - 10) / 2);

    function partyToCombat() {
        if (!needCampaign()) return;
        const chars = StorageManager.getCharacters(App.getActiveCampaignId());
        if (!chars.length && !(window.Companions && Companions.list().length)) { App.showToast('Drużyna jest pusta', 'warning'); return; }
        const present = new Set(CombatModule.getCombatants().map(c => c.name));
        let added = 0;
        chars.forEach(c => {
            if (present.has(c.name)) return;
            CombatModule.addCombatant({
                name: c.name, type: 'pc', ac: c.ac || 10,
                hp: c.hp?.current ?? 10, maxHp: c.hp?.max ?? 10,
                initiative: d20() + (window.CharactersModule?.initOf ? CharactersModule.initOf(c) : abMod(c.abilityScores?.dex) + (parseInt(c.initBonus, 10) || 0)), id: 'char-' + c.id,
                charId: c.id, speed: parseInt(c.speed, 10) || 30, dexMod: abMod(c.abilityScores?.dex)
            });
            added++;
        });
        // towarzysze (NPC w drużynie)
        const have = new Set(CombatModule.getCombatants().map(c => c.id));
        let comps = 0;
        (window.Companions ? Companions.combatants() : []).forEach(c => { if (have.has(c.id)) return; CombatModule.addCombatant(c); comps++; });
        App.switchTab('combat');
        App.showToast(added || comps ? `Dodano ${added} bohaterów${comps ? ` i ${comps} towarzyszy` : ''} z rzutem na inicjatywę` : 'Cała drużyna jest już w walce', added || comps ? 'success' : 'info');
    }

    function promptMonsterToCombat(m) {
        const ac = Array.isArray(m.armor_class) ? (m.armor_class[0]?.value ?? 10) : (m.armor_class ?? m.ac ?? 10);
        const hp = m.hit_points ?? m.hp ?? 10;
        const dice = m.hit_dice || m.hit_points_roll || '';
        App.showModal(`Do walki: ${m.name}`, `
            <div class="form-row">
                <div class="form-group"><label>Ile sztuk</label><input type="number" id="mc-count" min="1" max="20" value="1"></div>
                <div class="form-group"><label>Punkty wytrzymałości</label>
                    <select id="mc-hp"><option value="avg">Średnie (${hp})</option>${/\d+d\d+/.test(dice) ? `<option value="roll">Losowe (${esc(dice)})</option>` : ''}</select></div>
                <div class="form-group"><label>Inicjatywa</label>
                    <select id="mc-init"><option value="group">Wspólna dla grupy</option><option value="each">Osobno dla każdego</option></select></div>
            </div>
            <p class="modal-hint">KP ${ac} · inicjatywa 1k20${abMod(m.dexterity) >= 0 ? '+' : ''}${abMod(m.dexterity)}. Kolejne sztuki dostaną numery (np. ${esc(m.name)} 1, ${esc(m.name)} 2).</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="mc-go"><i class="fa-solid fa-khanda"></i> Dodaj do walki</button>`);
        document.getElementById('mc-go').onclick = () => {
            const n = Math.max(1, Math.min(20, parseInt(document.getElementById('mc-count').value, 10) || 1));
            const rollHp = document.getElementById('mc-hp').value === 'roll';
            const each = document.getElementById('mc-init').value === 'each';
            const groupInit = d20() + abMod(m.dexterity);
            const rollDice = (expr) => {
                const mm = String(expr).replace(/\s/g, '').match(/(\d+)d(\d+)([+-]\d+)?/);
                if (!mm) return hp;
                let t = +(mm[3] || 0);
                for (let i = 0; i < +mm[1]; i++) t += Math.floor(Math.random() * +mm[2]) + 1;
                return Math.max(1, t);
            };
            for (let i = 1; i <= n; i++) {
                const h = rollHp ? rollDice(dice) : hp;
                CombatModule.addCombatant({
                    name: n > 1 ? `${m.name} ${i}` : m.name, type: 'monster', ac, hp: h, maxHp: h, ref: m.index || null,
                    speed: parseInt(String(m.speed?.walk ?? m.speed ?? 30), 10) || 30, size: ({ Large: 2, Huge: 3, Gargantuan: 4 })[m.size] || 1,
                    initiative: each ? d20() + abMod(m.dexterity) : groupInit
                });
            }
            App.closeModal();
            App.showToast(`Dodano do walki: ${m.name}${n > 1 ? ` ×${n}` : ''}`, 'success');
        };
    }

    // ---------------------------------------------------------------
    // Floating dice panel
    // ---------------------------------------------------------------
    function diceOpen() { return document.body.classList.contains('dice-open'); }
    function toggleDice(force) {
        const open = force === undefined ? !diceOpen() : force;
        document.body.classList.toggle('dice-open', open);
        const i = document.getElementById('dice-expression');
        if (open) {
            const focus = () => { if (diceOpen() && document.activeElement !== i) { i?.focus(); i?.select(); } };
            requestAnimationFrame(focus);
            [80, 200, 400].forEach(t => setTimeout(focus, t));
        } else if (document.activeElement && document.activeElement.closest && document.activeElement.closest('#dice-roller')) {
            document.activeElement.blur();
        }
    }
    function hookDiceFab() {
        const fab = document.getElementById('dice-fab-last');
        const show = (r) => {
            if (!fab || !r || r.isCoin) return;          // wynik monety nie zostaje na przycisku kości
            fab.textContent = r.total;
            fab.classList.remove('pop', 'crit', 'fumble');
            void fab.offsetWidth;
            fab.classList.add('pop');
            if (r.isCritical && !r.isCoin) fab.classList.add('crit');
            if (r.isFumble && !r.isCoin) fab.classList.add('fumble');
        };
        const orig = DiceRoller.addToHistory.bind(DiceRoller);
        DiceRoller.addToHistory = function (r) { orig(r); show(r); };
        if (DiceRoller.history && DiceRoller.history[0]) show(DiceRoller.history[0]);
        // Close on outside click
        document.addEventListener('mousedown', (e) => {
            if (!diceOpen()) return;
            if (e.target.closest('#dice-roller') || e.target.closest('#dice-fab')) return;
            toggleDice(false);
        });
    }

    // ---------------------------------------------------------------
    // Sidebar collapse
    // ---------------------------------------------------------------
    function setSidebar(collapsed) {
        document.body.classList.toggle('sidebar-collapsed', collapsed);
        lsSet('sidebarCollapsed', collapsed);
        const btn = document.getElementById('btn-toggle-sidebar');
        if (btn) btn.setAttribute('aria-expanded', String(!collapsed));
    }
    function toggleSidebar() { setSidebar(!document.body.classList.contains('sidebar-collapsed')); }

    // ---------------------------------------------------------------
    // Backup reminder
    // ---------------------------------------------------------------
    const ago = (t) => {
        if (!t) return '';
        const m = Math.round((Date.now() - t) / 60000);
        if (m < 1) return 'przed chwilą';
        if (m < 60) return `${m} min temu`;
        const h = Math.round(m / 60);
        if (h < 24) return `${h} godz. temu`;
        const d = Math.floor((Date.now() - t) / 86400000);
        return d === 1 ? 'wczoraj' : `${d} dni temu`;
    };
    const when = (t) => new Date(t).toLocaleString(window.LOC || 'pl-PL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    let serverLast = null;
    function renderBackupStatus() {
        const el = document.getElementById('backup-status');
        if (!el) return;
        const kb = StorageManager.getStorageUsageKB ? StorageManager.getStorageUsageKB() : 0;
        const usage = kb > 1024 ? `${(kb / 1024).toFixed(1)} MB` : `${kb} KB`;
        const S = StorageManager.syncState ? StorageManager.syncState() : {};
        let text, cls, tip;
        if (StorageManager.syncAvailable && StorageManager.syncAvailable()) {
            const last = S.last || serverLast;
            if (S.ok === false) { text = 'Autokopia: błąd zapisu'; cls = 'bad'; tip = `Nie udało się zapisać kopii na dysku (${S.error || 'brak połączenia'}). Panel ponawia próbę — kliknij, aby zobaczyć kopie.`; }
            else if (S.locked) { text = 'Autokopia wstrzymana'; cls = 'warn'; tip = 'Czeka na decyzję, którą wersję danych zachować.'; }
            else if (last) { text = `Autokopia: ${ago(last)}`; cls = 'ok'; tip = `Ostatni zapis na dysku: ${when(last)}. Kliknij, aby zarządzać kopiami.`; }
            else { text = 'Autokopia: włączona'; cls = 'ok'; tip = 'Kopia zapisze się przy pierwszej zmianie. Kliknij, aby zarządzać kopiami.'; }
        } else {
            let lastEx = null;
            try { lastEx = JSON.parse(localStorage.getItem(StorageManager.PREFIX + 'last_export')); } catch (e) {}
            const days = lastEx ? Math.floor((Date.now() - lastEx) / 86400000) : null;
            text = lastEx ? `Kopia ręczna: ${ago(lastEx)}` : 'Brak autokopii';
            cls = days === null || days >= 7 ? 'warn' : 'ok';
            tip = 'Panel otwarty bez serwera — autokopia na dysk nie działa. Kliknij, aby pobrać plik kopii.';
        }
        el.className = `backup-status ${cls}`;
        el.innerHTML = `<i class="fa-solid ${cls === 'ok' ? 'fa-shield-halved' : cls === 'bad' ? 'fa-circle-exclamation' : 'fa-triangle-exclamation'}"></i><span>${text}</span><span class="backup-usage" title="Zajęta pamięć przeglądarki">${usage}</span>`;
        el.title = tip;
        el.setAttribute('role', 'button'); el.tabIndex = 0;
        el.onclick = () => openBackups();
        el.onkeydown = (e) => { if (e.key === 'Enter') openBackups(); };
    }

    // ---------------------------------------------------------------
    // Menedżer kopii zapasowych
    // ---------------------------------------------------------------
    const STAT_LBL = [['kampanie', 'kampanii', ['kampania', 'kampanie']], ['bohaterowie', 'bohaterów', ['bohater', 'bohaterów']], ['npc', 'NPC', ['NPC', 'NPC']], ['sesje', 'sesji', ['sesja', 'sesje']],
        ['zadania', 'zadań', ['zadanie', 'zadania']], ['notatki', 'notatek', ['notatka', 'notatki']], ['lokacje', 'lokacji', ['lokacja', 'lokacje']], ['wlasne', 'własnych', ['własny wpis', 'własne wpisy']]];
    const plural = (n, [one, few], many) => n === 1 ? one : ([2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100)) ? few : many;
    const statChips = (st) => st ? STAT_LBL.filter(([k]) => st[k]).map(([k, l, f]) => `<span>${st[k]} ${plural(st[k], f, l)}</span>`).join('') || '<span class="muted">pusta</span>' : '<span class="muted">?</span>';
    const KIND = {
        auto: ['Autokopia — najnowszy stan', 'fa-bolt', 'auto'], manual: ['Kopia ręczna', 'fa-bookmark', 'manual'], daily: ['Koniec dnia', 'fa-calendar-day', 'daily'],
        hourly: ['Stan sprzed zmian o', 'fa-clock-rotate-left', 'hourly'], guard: ['Przed dużą zmianą', 'fa-shield-heart', 'guard']
    };
    const fmtSize = (b) => b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`;
    function titleOf(it) {
        if (it.kind === 'manual') return it.name ? esc(it.name) : 'Kopia ręczna';
        if (it.kind === 'daily') { const m = it.f.match(/(\d{4})-(\d{2})-(\d{2})/); return `Koniec dnia ${+m[3]}.${m[2]}.${m[1]}`; }
        if (it.kind === 'hourly') { const m = it.f.match(/_(\d{2})\.json$/); return `Stan sprzed zmian o ${m ? m[1] + ':00' : ''}`; }
        if (it.kind === 'guard') return `Przed dużą zmianą${it.note ? ` <small>(${esc(it.note)})</small>` : ''}`;
        return KIND[it.kind]?.[0] || it.f;
    }
    let bkFilter = 'all';
    async function openBackups() {
        const server = StorageManager.syncAvailable();
        App.showModal('Kopie zapasowe', `<div class="bk" id="bk"><div class="bk-loading"><i class="fa-solid fa-spinner fa-spin"></i> Wczytuję listę kopii…</div></div>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>`);
        document.getElementById('modal')?.classList.add('modal-wide');
        let list = null, dir = '', err = null;
        if (server) {
            try {
                const r = await fetch('api/backups', { cache: 'no-store' });
                if (!r.ok) throw new Error(r.status === 404 ? 'stara wersja serwera — uruchom panel ponownie ikoną' : `serwer odpowiedział ${r.status}`);
                const j = await r.json(); list = j.items || []; dir = j.dir || '';
            } catch (e) { err = e.message || 'serwer nie odpowiada'; }
        }
        const root = document.getElementById('bk'); if (!root) return;
        const S = StorageManager.syncState();
        const cur = StorageManager.statsOf(StorageManager.localMap());
        const statusHTML = !server
            ? `<div class="bk-status warn"><i class="fa-solid fa-triangle-exclamation"></i><div><b>Autokopia nie działa</b><p>Panel otwarto bez serwera (prosto z pliku). Uruchamiaj go ikoną <b>Panel Mistrza Gry</b> — wtedy każda zmiana trafia od razu do folderu <i>kopie</i>. Do tego czasu pobieraj plik kopii ręcznie.</p></div></div>`
            : err ? `<div class="bk-status bad"><i class="fa-solid fa-circle-exclamation"></i><div><b>Nie mogę połączyć się z serwerem kopii</b><p>${esc(err)}. Dane są bezpieczne w przeglądarce; pobierz plik kopii, a potem uruchom panel ponownie.</p></div></div>`
            : S.locked ? `<div class="bk-status warn"><i class="fa-solid fa-pause"></i><div><b>Autokopia wstrzymana</b><p>Na dysku jest więcej danych niż w przeglądarce. Przywróć kopię poniżej albo zostaw obecne dane — kopia z dysku i tak zostanie w historii.</p><button class="btn-secondary btn-small" id="bk-resume"><i class="fa-solid fa-play"></i> Zostaw dane z przeglądarki i wznów</button></div></div>`
            : S.ok === false ? `<div class="bk-status bad"><i class="fa-solid fa-circle-exclamation"></i><div><b>Ostatni zapis się nie udał</b><p>${esc(S.error || '')} — panel ponawia próbę automatycznie.</p></div></div>`
            : `<div class="bk-status ok"><i class="fa-solid fa-shield-halved"></i><div><b>Autokopia działa</b><p>Każda zmiana zapisuje się na dysku${S.last ? ` — ostatnio ${ago(S.last)} (${when(S.last)})` : ''}. Folder: <code>${esc(dir)}</code></p></div></div>`;
        const counts = list ? list.reduce((a, it) => (a[it.kind] = (a[it.kind] || 0) + 1, a), {}) : {};
        const tabs = [['all', 'Wszystkie'], ['manual', 'Ręczne'], ['daily', 'Dzienne'], ['hourly', 'Godzinowe'], ['guard', 'Przed zmianą']];
        const rows = (list || []).filter(it => bkFilter === 'all' || it.kind === bkFilter).map(it => `
            <div class="bk-row k-${it.kind}">
                <span class="bk-ico"><i class="fa-solid ${KIND[it.kind]?.[1] || 'fa-file'}"></i></span>
                <div class="bk-main"><b>${titleOf(it)}</b><small>${when(it.t)} · ${ago(it.t)} · ${fmtSize(it.size)}</small><div class="bk-chips">${statChips(it.stats)}</div></div>
                <div class="bk-btns"><button class="btn-secondary btn-small" data-bk-dl="${esc(it.f)}" title="Pobierz plik"><i class="fa-solid fa-download"></i></button><button class="btn-primary btn-small" data-bk-restore="${esc(it.f)}"><i class="fa-solid fa-rotate-left"></i> Przywróć</button></div>
            </div>`).join('');
        root.innerHTML = `${statusHTML}
            <div class="bk-now"><span>W przeglądarce teraz:</span><div class="bk-chips">${statChips(cur)}</div></div>
            <div class="bk-acts">
                ${server && !err ? `<div class="bk-snap"><input id="bk-name" maxlength="60" placeholder="Nazwa, np. Przed sesją 12"><button class="btn-primary" id="bk-snap"><i class="fa-solid fa-bookmark"></i> Zrób kopię teraz</button></div>` : ''}
                <button class="btn-secondary" id="bk-export"><i class="fa-solid fa-file-arrow-down"></i> Pobierz plik kopii</button>
                <button class="btn-secondary" id="bk-import"><i class="fa-solid fa-file-arrow-up"></i> Wczytaj z pliku…</button>
            </div>
            ${list ? `<div class="bk-tabs">${tabs.map(([k, l]) => `<button data-bk-tab="${k}" class="${bkFilter === k ? 'on' : ''}">${l}${k === 'all' ? ` (${list.length})` : counts[k] ? ` (${counts[k]})` : ''}</button>`).join('')}</div>
            <div class="bk-list">${rows || '<p class="bk-empty">Brak kopii tego rodzaju.</p>'}</div>
            <p class="bk-hint">Panel trzyma: autokopię po każdej zmianie, stan sprzed zmian z każdej godziny (2 ostatnie doby), stan z końca każdego dnia (30 dni), osobną kopię, gdy z danych nagle dużo ubędzie, oraz Twoje kopie ręczne. Przed każdym przywróceniem bieżący stan zapisuje się jako kopia „Przed przywróceniem”.</p>` : ''}`;
        root.onclick = async (e) => {
            const b = (q) => e.target.closest(q);
            if (b('[data-bk-tab]')) { bkFilter = b('[data-bk-tab]').dataset.bkTab; openBackups(); return; }
            if (b('[data-bk-dl]')) { location.href = `api/backups/file?f=${encodeURIComponent(b('[data-bk-dl]').dataset.bkDl)}&dl=1`; return; }
            if (b('#bk-export')) { App.exportData(); return; }
            if (b('#bk-resume')) { StorageManager.releaseSync(); renderBackupStatus(); openBackups(); return; }
            if (b('#bk-import')) { pickImportFile(); return; }
            if (b('#bk-snap')) {
                const btn = b('#bk-snap'); btn.disabled = true;
                const name = document.getElementById('bk-name')?.value.trim() || '';
                const ok = await snapshot(name);
                btn.disabled = false;
                if (ok) { App.showToast('Kopia zapisana na dysku', 'success'); openBackups(); }
                return;
            }
            if (b('[data-bk-restore]')) {
                const f = b('[data-bk-restore]').dataset.bkRestore;
                try {
                    const r = await fetch(`api/backups/file?f=${encodeURIComponent(f)}`, { cache: 'no-store' });
                    if (!r.ok) throw new Error('nie można odczytać pliku');
                    confirmRestore(await r.text(), titleOf((list || []).find(x => x.f === f) || { f, kind: 'auto' }).replace(/<[^>]+>/g, ''));
                } catch (er) { App.showToast(`Nie udało się otworzyć kopii: ${er.message}`, 'error'); }
            }
        };
    }
    async function snapshot(name) {
        try {
            const r = await fetch(`api/backups/snapshot?name=${encodeURIComponent(name)}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Panel': '1' }, body: StorageManager.exportAll(), cache: 'no-store' });
            const j = await r.json().catch(() => ({}));
            if (!r.ok || !j.ok) throw new Error(j.error || `serwer odpowiedział ${r.status}`);
            return true;
        } catch (e) { App.showToast(`Nie udało się zapisać kopii: ${e.message}`, 'error'); return false; }
    }
    function pickImportFile() {
        const inp = document.createElement('input');
        inp.type = 'file'; inp.accept = '.json,application/json';
        inp.onchange = () => { const f = inp.files[0]; if (f) importFile(f); };
        inp.click();
    }
    function importFile(file) {
        const rd = new FileReader();
        rd.onload = () => confirmRestore(String(rd.result), file.name);
        rd.onerror = () => App.showToast('Nie udało się odczytać pliku', 'error');
        rd.readAsText(file);
    }
    function confirmRestore(text, label) {
        let parsed;
        try { parsed = StorageManager.parseBackup(text); } catch (e) { App.showToast(e.message, 'error'); return; }
        const cur = StorageManager.statsOf(StorageManager.localMap());
        const lost = STAT_LBL.filter(([k]) => (cur[k] || 0) > (parsed.stats[k] || 0)).map(([k, l]) => `${(cur[k] || 0) - (parsed.stats[k] || 0)} ${l}`);
        App.showModal('Przywrócić tę kopię?', `
            <div class="bk-cmp">
                <div><h4>Teraz w panelu</h4><div class="bk-chips">${statChips(cur)}</div></div>
                <i class="fa-solid fa-arrow-right"></i>
                <div><h4>${esc(label)}</h4><div class="bk-chips">${statChips(parsed.stats)}</div></div>
            </div>
            ${lost.length ? `<p class="bk-warn"><i class="fa-solid fa-triangle-exclamation"></i> W tej kopii jest mniej danych niż teraz (mniej o: ${lost.join(', ')}).</p>` : ''}
            ${(() => { const cs = StorageManager.campaignsInBackup(parsed.data); return cs.length ? `<div class="bk-merge">
                <h4><i class="fa-solid fa-code-merge"></i> Albo dołącz tylko wybrane kampanie</h4>
                <p class="modal-hint">Np. z drugiego komputera — to, co już masz w panelu, zostaje.</p>
                ${cs.map(c => `<label class="bk-camp"><input type="checkbox" value="${esc(c.id)}" ${c.here ? '' : 'checked'}> <b>${esc(c.name)}</b> <small>${c.here ? 'już jest w panelu — zostanie zastąpiona wersją z pliku' : 'nowa'}</small></label>`).join('')}
                <button class="btn-secondary btn-small" id="bk-do-merge"><i class="fa-solid fa-plus"></i> Dołącz zaznaczone kampanie</button>
            </div>` : ''; })()}
            <p class="modal-hint"><b>Przywróć kopię</b> — obecne dane zostaną zastąpione kopią. Zanim to nastąpi, bieżący stan zapisze się jako kopia „Przed przywróceniem”${StorageManager.syncAvailable() ? '' : ' (pobierze się jako plik)'} — w razie pomyłki łatwo wrócić.</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="bk-do-restore"><i class="fa-solid fa-rotate-left"></i> Przywróć kopię</button>`);
        const mg = document.getElementById('bk-do-merge');
        if (mg) mg.onclick = async () => {
            const ids = [...document.querySelectorAll('.bk-camp input:checked')].map(i => i.value);
            if (!ids.length) { App.showToast('Zaznacz kampanie do dołączenia', 'warning'); return; }
            mg.disabled = true;
            if (StorageManager.syncAvailable()) await snapshot('Przed dołączeniem kampanii');
            const n = StorageManager.mergeCampaigns(parsed.data, ids);
            try { await StorageManager.flushSync(); } catch (er) {}
            App.closeModal();
            App.showToast(`Dołączono kampanie: ${n} — przeładowuję panel`, 'success');
            setTimeout(() => location.reload(), 600);
        };
        document.getElementById('bk-do-restore').onclick = async (e) => {
            e.target.disabled = true;
            const safe = StorageManager.syncAvailable() ? await snapshot('Przed przywróceniem') : (App.exportData(), true);
            if (!safe) { e.target.disabled = false; return; }
            try { StorageManager.restoreAll(parsed.data); } catch (er) { App.showToast(er.message, 'error'); e.target.disabled = false; return; }
            StorageManager.releaseSync();
            await StorageManager.flushSync();
            App.closeModal();
            App.showToast('Kopia przywrócona — przeładowuję panel', 'success');
            setTimeout(() => location.reload(), 500);
        };
    }

    // ---------------------------------------------------------------
    // Lokalny serwer (ikona „Panel Mistrza Gry” na pulpicie)
    // ---------------------------------------------------------------
    function connectLocalServer() {
        if (location.protocol === 'file:') {
            // otwarto index.html dwuklikiem — jeśli serwer działa, przejdź do pełnej wersji (kości 3D, autokopia)
            fetch('http://localhost:8080/api/ping', { mode: 'no-cors', cache: 'no-store' })
                .then(() => location.replace('http://localhost:8080/' + location.hash))
                .catch(() => showFileModeBanner());
            return;
        }
        // daj znać serwerowi, że panel jest otwarty (serwer z ikony wyłącza się po 15 min bez panelu)
        const ping = () => fetch('api/ping', { cache: 'no-store' }).catch(() => {});
        ping();
        setInterval(ping, 60 * 1000);
    }
    function showFileModeBanner() {
        if (lsGet('fileBannerHidden', false)) return;
        const bar = document.createElement('div');
        bar.className = 'file-mode-banner';
        bar.innerHTML = `<i class="fa-solid fa-circle-info"></i>
            <span>Panel otwarty prosto z pliku — kości 3D i automatyczna kopia są wyłączone. Uruchamiaj go ikoną <b>Panel Mistrza Gry</b> na pulpicie.</span>
            <button title="Nie pokazuj więcej">&times;</button>`;
        bar.querySelector('button').onclick = () => { lsSet('fileBannerHidden', true); bar.remove(); };
        document.body.appendChild(bar);
    }

    // ---------------------------------------------------------------
    // Start: porównaj dane przeglądarki z autokopią na dysku, zanim cokolwiek zostanie nadpisane
    // ---------------------------------------------------------------
    async function startupBackupCheck() {
        if (!StorageManager.syncAvailable()) { StorageManager.releaseSync(); return; }
        StorageManager.holdSync();
        const SM = StorageManager, S = SM._sync;
        let st = null, data = null, serverV = 0;
        try {
            const r0 = await fetch('api/status', { cache: 'no-store' });
            if (r0.status === 401) { location.href = '/logowanie'; return; }
            st = r0.ok ? await r0.json() : null;
            if (st?.last) serverLast = st.last;
            S.proto = st?.version || 2;
            const r = await fetch('api/sync', { cache: 'no-store' });
            if (r.ok) { data = await r.json(); serverV = +(r.headers.get('X-Wersja') || st?.stanWersja || 0); }
        } catch (e) { data = null; }
        if (!data) { SM.releaseSync(); renderBackupStatus(); return; }
        let disk;
        try { disk = SM.parseBackup(data); } catch (e) { disk = null; }
        const localMap = SM.localMap();
        const local = SM.statsOf(localMap);
        const ds = disk ? SM.score(disk.stats) : 0, ls = SM.score(local);

        // nowy serwer: wspólny stan z numerem wersji
        if (S.proto >= 3) {
            const localV = S.version;
            if (localV && localV === serverV) { SM.releaseSync(); renderBackupStatus(); return; }
            let recent = 0; try { recent = +sessionStorage.getItem('dnd5e_meta_adopted') || 0; } catch (e) {}
            if (localV && serverV > localV && disk && Date.now() - recent < 20000) {
                // dopiero co przeładowano — dociągnij zmiany bez kolejnego przeładowania
                SM.applyRemote(disk.data, 0);
                SM.setSyncVersion(serverV); SM.releaseSync(); renderBackupStatus(); return;
            }
            if (localV && serverV > localV && disk) {
                // w międzyczasie coś zmienili gracze albo drugi komputer MG — weź stan z serwera, zachowaj własne niewysłane zmiany
                const mine = {}; S.dirty.forEach(k => { if (k !== '*' && k in localMap) mine[k] = localMap[k]; });
                const keepDirty = new Set(Object.keys(mine));
                try { SM.restoreAll(disk.data); } catch (e) { SM.releaseSync(); return; }
                Object.entries(mine).forEach(([k, v]) => { try { localStorage.setItem(k, v); } catch (e) {} });
                S.dirty = keepDirty; SM._saveDirty(); SM.setSyncVersion(serverV);
                try { sessionStorage.setItem('dnd5e_meta_adopted', String(Date.now())); } catch (e) {}
                location.reload();
                return;
            }
            if (localV && serverV < localV) { S.dirty.add('*'); SM._saveDirty(); SM.releaseSync(); renderBackupStatus(); return; }
            // ta przeglądarka jeszcze nie pracowała z tym serwerem
            if (ds === 0) { S.dirty.add('*'); SM._saveDirty(); SM.releaseSync(); renderBackupStatus(); return; }
            if (ls === 0) {
                try { SM.restoreAll(disk.data); } catch (e) { SM.releaseSync(); return; }
                S.dirty.clear(); SM._saveDirty(); SM.setSyncVersion(serverV);
                location.reload();
                return;
            }
            if (ls >= ds && JSON.stringify(SM.statsOf(localMap)) === JSON.stringify(disk.stats)) {
                // te same dane (np. po aktualizacji panelu) — przyjmij wersję serwera i wyślij tylko różnice
                Object.keys(localMap).forEach(k => { if (!k.includes('srd_cache_') && disk.data[k] !== localMap[k]) S.dirty.add(k); });
                Object.keys(disk.data).forEach(k => { if (!(k in localMap)) S.dirty.add(k); });
                SM.setSyncVersion(serverV); SM._saveDirty(); SM.releaseSync(); renderBackupStatus(); return;
            }
            if (ls >= ds) { SM.setSyncVersion(serverV); S.dirty.add('*'); SM._saveDirty(); SM.releaseSync(); renderBackupStatus(); return; }
        } else {
            if (!disk || ds === 0 || ls >= ds) { SM.releaseSync(); renderBackupStatus(); return; }
        }
        renderBackupStatus();
        App.showModal('Na serwerze jest więcej danych', `
            <p>Kopia na serwerze (folder <b>kopie</b>) zawiera więcej danych niż ta przeglądarka. Tak bywa po wyczyszczeniu przeglądarki albo przy pierwszym uruchomieniu na innym komputerze.</p>
            <div class="bk-cmp">
                <div><h4>W przeglądarce</h4><div class="bk-chips">${statChips(local)}</div></div>
                <i class="fa-solid fa-arrow-left"></i>
                <div><h4>Na serwerze${serverLast ? ` <small>(${ago(serverLast)})</small>` : ''}</h4><div class="bk-chips">${statChips(disk.stats)}</div></div>
            </div>
            <p class="modal-hint">Zapisywanie jest wstrzymane, dopóki nie wybierzesz. Jeśli zostawisz dane z przeglądarki, dane z serwera i tak zostaną zachowane w historii kopii („Przed dużą zmianą”).</p>`,
            `<button class="btn-secondary" id="restore-no">Zostaw dane z przeglądarki</button>
             <button class="btn-primary" id="restore-yes"><i class="fa-solid fa-rotate-left"></i> Wczytaj dane z serwera</button>`);
        const modalClose = document.getElementById('modal-close');
        const keepLocal = () => { if (S.proto >= 3) { SM.setSyncVersion(serverV); S.dirty.add('*'); SM._saveDirty(); } SM.releaseSync(); renderBackupStatus(); };
        if (modalClose) modalClose.onclick = () => { App.closeModal(); keepLocal(); };
        document.getElementById('restore-no').onclick = () => { App.closeModal(); keepLocal(); };
        document.getElementById('restore-yes').onclick = () => {
            try { SM.restoreAll(disk.data); } catch (e) { App.showToast(e.message, 'error'); return; }
            S.pending = false; S.dirty.clear(); SM._saveDirty();
            if (S.proto >= 3) SM.setSyncVersion(serverV);
            SM.releaseSync();
            App.closeModal();
            location.reload();
        };
    }

    // ---------------------------------------------------------------
    // Command palette
    // ---------------------------------------------------------------
    let palette, input, list, results = [], sel = 0;

    function buildPalette() {
        palette = document.createElement('div');
        palette.className = 'cmdk-backdrop hidden';
        palette.innerHTML = `
            <div class="cmdk" role="dialog" aria-label="Szukaj">
                <div class="cmdk-input-row">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" class="cmdk-input" placeholder="Szukaj potwora, czaru, NPC, bohatera… albo wpisz rzut, np. 2d6+3" autocomplete="off" spellcheck="false">
                    <kbd>Esc</kbd>
                </div>
                <div class="cmdk-list" role="listbox"></div>
                <div class="cmdk-footer"><span><kbd>↑</kbd><kbd>↓</kbd> wybór</span><span><kbd>Enter</kbd> otwórz</span><span><kbd>Ctrl K</kbd> przełącz</span></div>
            </div>`;
        document.body.appendChild(palette);
        input = palette.querySelector('.cmdk-input');
        list = palette.querySelector('.cmdk-list');
        palette.addEventListener('mousedown', (e) => { if (e.target === palette) closePalette(); });
        input.addEventListener('input', () => { sel = 0; renderResults(); });
        input.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
            else if (e.key === 'Enter') { e.preventDefault(); run(results[sel]); }
            else if (e.key === 'Escape') { e.preventDefault(); closePalette(); }
        });
        list.addEventListener('mousemove', (e) => {
            const row = e.target.closest('.cmdk-item');
            if (row && +row.dataset.i !== sel) { sel = +row.dataset.i; highlight(); }
        });
        list.addEventListener('click', (e) => {
            const row = e.target.closest('.cmdk-item');
            if (row) run(results[+row.dataset.i]);
        });
    }

    function openPalette(prefill = '') {
        if (!palette) buildPalette();
        // warm up SRD lists so they are searchable
        [window.BestiaryModule, window.SpellsModule, window.EquipmentModule].forEach(m => {
            try { if (m && m.els && m.els.list && !m.loaded && !m.loading) m.activate(); } catch (e) {}
        });
        palette.classList.remove('hidden');
        input.value = prefill;
        sel = 0;
        renderResults();
        input.focus();
        requestAnimationFrame(() => input.focus());
    }
    function closePalette() { palette?.classList.add('hidden'); }
    function move(d) { if (!results.length) return; sel = (sel + d + results.length) % results.length; highlight(true); }
    function highlight(scroll) {
        list.querySelectorAll('.cmdk-item').forEach(el => el.classList.toggle('active', +el.dataset.i === sel));
        if (scroll) list.querySelector('.cmdk-item.active')?.scrollIntoView({ block: 'nearest' });
    }
    function run(item) {
        if (!item) return;
        closePalette();
        try { item.run(); } catch (e) { console.error(e); App.showToast('Nie udało się wykonać polecenia', 'error'); }
    }

    function collect() {
        const items = [];
        const cId = App.getActiveCampaignId();
        TABS.forEach((t, i) => items.push({ group: 'Przejdź do', icon: t.icon, label: t.label, hint: keyFor(i), run: () => goto(t.tab, t.sub) }));
        CAMPAIGN_SUBS.forEach(([sub, label, icon]) => items.push({ group: 'Przejdź do', icon, label: `Kampania — ${label}`, run: () => goto('campaign', sub) }));
        [
            ['new-note', 'Nowa notatka', 'fa-pen', 'N'], ['new-session', 'Nowa sesja', 'fa-calendar-plus'], ['new-quest', 'Nowe zadanie', 'fa-scroll'],
            ['new-location', 'Nowa lokacja', 'fa-map-location-dot'], ['new-npc', 'Nowy NPC', 'fa-user-plus'], ['new-enemy', 'Nowy przeciwnik', 'fa-skull'],
            ['new-hero', 'Nowy bohater', 'fa-hat-wizard'], ['add-combatant', 'Dodaj uczestnika walki', 'fa-khanda'], ['new-campaign', 'Nowa kampania', 'fa-book'],
            ['export', 'Eksportuj kopię zapasową', 'fa-floppy-disk'], ['import', 'Importuj dane', 'fa-folder-open'], ['backups', 'Kopie zapasowe — przywróć lub zrób kopię', 'fa-shield-halved'],
            ['short-rest', 'Krótki odpoczynek drużyny', 'fa-mug-hot'], ['long-rest', 'Długi odpoczynek drużyny', 'fa-bed'],
            ['group-hp', 'Obrażenia / leczenie grupy', 'fa-heart-crack'], ['award-xp', 'Przyznaj XP drużynie', 'fa-star'],
            ['toggle-dice', 'Kości', 'fa-dice-d20', 'D'],
            ['toggle-theme', 'Włącz / wyłącz motyw karczmy', 'fa-beer-mug-empty'],
            ['toggle-dice3d', 'Włącz / wyłącz kości 3D', 'fa-cube'],
            ['toggle-lang', window.LANG === 'en' ? 'Język: polski' : 'Language: English', 'fa-language'],
            ['toggle-sidebar', 'Zwiń / rozwiń menu', 'fa-table-columns', '['], ['shortcuts', 'Pokaż skróty klawiszowe', 'fa-keyboard', '?']
        ].forEach(([a, label, icon, hint]) => items.push({ group: 'Polecenia', icon, label, hint, run: () => ACTIONS[a]() }));

        StorageManager.getCampaigns().forEach(c => {
            if (c.id !== cId) items.push({ group: 'Kampanie', icon: 'fa-book-open', label: `Przełącz na: ${c.name}`, run: () => switchCampaign(c.id) });
        });

        if (cId) {
            StorageManager.getCharacters(cId).forEach(c => items.push({ group: 'Bohaterowie', icon: 'fa-hat-wizard', label: c.name, sub: `${c.race || ''} ${c.class || ''} · poz. ${c.level || 1}`, run: () => { goto('characters'); CharactersModule.showCharacterSheet(c.id); } }));
            StorageManager.getNPCs(cId).forEach(n => items.push({ group: 'NPC', icon: n.disposition === 'hostile' ? 'fa-skull' : 'fa-user', label: n.name, sub: [n.role, n.location].filter(Boolean).join(' · '), run: () => { goto('npcs'); NPCsModule.showDetail(n.id); } }));
            StorageManager.getLocations(cId).forEach(l => items.push({ group: 'Lokacje', icon: 'fa-location-dot', label: l.name, sub: l.type || '', run: () => (window.Atlas ? Atlas.focus(l.id) : goto('campaign', 'locations')) }));
            StorageManager.getQuests(cId).forEach(q => items.push({ group: 'Zadania', icon: 'fa-scroll', label: q.title || q.name || 'Zadanie', sub: q.status || '', run: () => goto('campaign', 'quests') }));
            StorageManager.getSessions(cId).forEach(s => items.push({ group: 'Sesje', icon: 'fa-calendar-days', label: s.title || 'Sesja', sub: s.date || '', run: () => goto('campaign', 'sessions') }));
        }

        (window.RulesModule ? RulesModule.all() : []).forEach(r => items.push({ group: 'Zasady', icon: r.icon, label: r.title, sub: r.en || '', run: () => RulesModule.open(r.title) }));

        const crOf = (m) => m.challenge_rating != null ? `CR ${APIClient.crDisplay(m.challenge_rating)}` : '';
        (window.BestiaryModule?.allMonsters || []).forEach(m => items.push({ group: 'Bestiariusz', icon: 'fa-dragon', label: m.name, sub: [crOf(m), APIClient.translateStatic('types', typeof m.type === 'string' ? m.type : m.type?.type || '')].filter(Boolean).join(' · '), lazy: true, run: () => { goto('bestiary'); BestiaryModule.showDetail(m.index || m._customId, !!m._custom); } }));
        (window.SpellsModule?.allSpells || []).forEach(s => items.push({ group: 'Magia', icon: 'fa-wand-magic-sparkles', label: s.name, sub: s.level === 0 ? 'Sztuczka' : s.level != null ? `Poziom ${s.level}` : '', lazy: true, run: () => { goto('spells'); SpellsModule.showDetail(s.index || s._customId, !!s._custom); } }));
        (window.EquipmentModule?.allEquipment || []).forEach(it => items.push({ group: 'Ekwipunek', icon: 'fa-shield-halved', label: it.name, sub: (typeof it.equipment_category === 'string' ? it.equipment_category : it.equipment_category?.name) || '', lazy: true, run: () => { goto('equipment'); if (it._db) EquipmentModule.showDbDetail(it.id); else EquipmentModule.showDetail(it.index || it._customId, !!it._custom, false); } }));
        (window.EquipmentModule?.allMagicItems || []).forEach(it => items.push({ group: 'Przedmioty magiczne', icon: 'fa-gem', label: it.name, sub: it.rarity?.name || '', lazy: true, run: () => { goto('equipment'); EquipmentModule.showDetail(it.index || it._customId, !!it._custom, true); } }));
        return items;
    }

    function switchCampaign(id) {
        StorageManager.setActiveCampaignId(id);
        const select = document.getElementById('campaign-select');
        if (select) select.value = id;
        App.onCampaignChange();
        App.showToast('Przełączono kampanię', 'success');
    }

    const DICE_RE = /^\s*(\d*d\d+|\d+)(\s*[+-]\s*(\d*d\d+|\d+))*\s*$/i;

    function renderResults() {
        const q = norm(input.value.trim());
        let items = collect();
        if (!q) {
            items = items.filter(i => !i.lazy && ['Przejdź do', 'Polecenia', 'Kampanie'].includes(i.group));
        } else {
            items = items.map(i => {
                const n = norm(i.label), s = norm(i.sub);
                let score = n === q ? 100 : n.startsWith(q) ? 80 : n.split(/\s+/).some(w => w.startsWith(q)) ? 60 : n.includes(q) ? 40 : s.includes(q) ? 15 : 0;
                if (score && !i.lazy) score += 5;
                return { ...i, score };
            }).filter(i => i.score > 0).sort((a, b) => b.score - a.score).slice(0, 60);
        }
        if (DICE_RE.test(input.value) && /d/i.test(input.value)) {
            const expr = input.value.replace(/\s+/g, '');
            items.unshift({ group: 'Rzut', icon: 'fa-dice-d20', label: `Rzuć ${expr}`, hint: 'Enter', run: () => DiceRoller.rollExpression(expr) });
        }
        results = items;
        if (sel >= results.length) sel = 0;

        if (!results.length) {
            const loading = [window.BestiaryModule, window.SpellsModule].some(m => m && m.loading);
            list.innerHTML = `<div class="cmdk-empty">${loading ? '<i class="fa-solid fa-spinner fa-spin"></i> Wczytuję dane SRD…' : 'Nic nie znaleziono'}</div>`;
            return;
        }
        let html = '', lastGroup = null;
        results.forEach((r, i) => {
            if (r.group !== lastGroup) { html += `<div class="cmdk-group">${esc(r.group)}</div>`; lastGroup = r.group; }
            html += `<div class="cmdk-item${i === sel ? ' active' : ''}" data-i="${i}" role="option">
                <i class="fa-solid ${r.icon}"></i>
                <span class="cmdk-label">${esc(r.label)}</span>
                ${r.sub ? `<span class="cmdk-sub">${esc(r.sub)}</span>` : ''}
                ${r.hint ? `<kbd>${esc(r.hint)}</kbd>` : ''}
            </div>`;
        });
        list.innerHTML = html;
    }

    // ---------------------------------------------------------------
    // Shortcuts help
    // ---------------------------------------------------------------
    function showShortcuts() {
        const row = (keys, desc) => `<div class="shortcut-row"><span>${desc}</span><span>${keys.map(k => `<kbd>${k}</kbd>`).join(' ')}</span></div>`;
        App.showModal('Skróty klawiszowe', `
            <div class="shortcuts-grid">
                ${row(['Ctrl', 'K'], 'Szukaj wszędzie / polecenia')}
                ${row(['/'], 'Szukaj wszędzie')}
                ${row(['1–9', '0'], 'Przejdź do sekcji (numery jak w menu)')}
                ${row(['Alt', '0–9'], 'To samo, także w polu tekstowym')}
                ${row(['D'], 'Otwórz / zamknij kości')}
                ${row(['N'], 'Nowa notatka')}
                ${row(['['], 'Zwiń / rozwiń menu')}
                ${row(['Esc'], 'Zamknij okno / panel szczegółów')}
                ${row(['?'], 'Ta ściągawka')}
            </div>
            <p class="shortcuts-tip">W wyszukiwarce wpisz wyrażenie, np. <b>2d6+3</b>, i naciśnij Enter, aby od razu rzucić.</p>
        `, `<button class="btn-primary" onclick="App.closeModal()">Jasne</button>`);
    }

    // ---------------------------------------------------------------
    // Detail panels (close on Esc)
    // ---------------------------------------------------------------
    function closeOpenDetail() {
        const map = [['bestiary-detail', () => BestiaryModule.closeDetail()], ['spells-detail', () => SpellsModule.closeDetail()],
                     ['equipment-detail', () => EquipmentModule.closeDetail()], ['npc-detail', () => NPCsModule.closeDetail()]];
        for (const [id, fn] of map) {
            const el = document.getElementById(id);
            if (el && !el.classList.contains('hidden') && el.closest('.tab-panel.active')) { fn(); return true; }
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Global key handling
    // ---------------------------------------------------------------
    function onKey(e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            palette && !palette.classList.contains('hidden') ? closePalette() : openPalette();
            return;
        }
        if (palette && !palette.classList.contains('hidden')) return;

        if (e.altKey && /^[0-9]$/.test(e.key)) {
            e.preventDefault();
            const t = tabForKey(e.key); if (t) goto(t.tab, t.sub);
            return;
        }
        if (e.key === 'Escape' && !modalOpen()) {
            if (diceOpen()) { toggleDice(false); e.preventDefault(); return; }
            if (closeOpenDetail()) e.preventDefault();
            return;
        }
        if (isTyping(e) || modalOpen() || e.ctrlKey || e.metaKey || e.altKey) return;

        if (/^[0-9]$/.test(e.key)) { const t = tabForKey(e.key); if (t) goto(t.tab, t.sub); }
        else if (e.key === '/') { e.preventDefault(); openPalette(); }
        else if (e.key === '?') { e.preventDefault(); showShortcuts(); }
        else if (e.key === '[') { toggleSidebar(); }
        else if (e.key.toLowerCase() === 'd') { e.preventDefault(); toggleDice(); }
        else if (e.key.toLowerCase() === 'n') { e.preventDefault(); ACTIONS['new-note'](); }
    }

    // ---------------------------------------------------------------
    // Init
    // ---------------------------------------------------------------
    function init() {
        document.body.classList.toggle('theme-tavern', lsGet('tavernTheme', true) !== false);
        const narrow = () => window.matchMedia('(max-width: 760px)').matches;
        setSidebar(narrow() ? true : !!lsGet('sidebarCollapsed', false));
        // On phones the menu is an overlay: close it after choosing a section
        document.querySelectorAll('.side-nav .nav-tab').forEach(t => t.addEventListener('click', () => { if (narrow()) setSidebar(true); }));
        document.getElementById('btn-toggle-sidebar')?.addEventListener('click', toggleSidebar);
        document.getElementById('btn-command-palette')?.addEventListener('click', () => openPalette());
        document.getElementById('btn-shortcuts')?.addEventListener('click', showShortcuts);
        document.addEventListener('keydown', onKey);

        // Delegated navigation used by the dashboard and elsewhere
        document.addEventListener('click', (e) => {
            const g = e.target.closest('[data-goto]');
            if (g) { e.preventDefault(); goto(g.dataset.goto, g.dataset.subtab); return; }
            const a = e.target.closest('[data-action]');
            if (a && ACTIONS[a.dataset.action]) { e.preventDefault(); ACTIONS[a.dataset.action](); return; }
            const p = e.target.closest('.party-row[data-char]');
            if (p) { goto('characters'); CharactersModule.showCharacterSheet(p.dataset.char); }
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target.matches && e.target.matches('.party-row[data-char]')) e.target.click();
        });

        // Keep the dashboard fresh after edits made elsewhere (e.g. HP changes)
        const origSet = StorageManager.set.bind(StorageManager);
        let t;
        StorageManager.set = function (key, value) {
            origSet(key, value);
            if (key.startsWith('srd_cache_')) return;
            clearTimeout(t);
            t = setTimeout(() => {
                if (App.currentTab === 'dashboard') App.updateDashboard();
                if (App.currentTab === 'characters' && key.startsWith('characters_') && window.PartyModule) PartyModule.render();
                renderBackupStatus();
            }, 250);
        };

        hookDiceFab();
        connectLocalServer();
        startupBackupCheck();
        renderBackupStatus();
        window.addEventListener('panel-sync', renderBackupStatus);
        setInterval(renderBackupStatus, 30000);
        App.updateDashboard();
    }

    return { init, openPalette, renderBackupStatus, openBackups, importFile, pickImportFile, toggleSidebar, showShortcuts, promptMonsterToCombat, partyToCombat };
})();

window.Enhancements = Enhancements;
document.addEventListener('DOMContentLoaded', () => {
    // App initialises after a 100 ms delay; run right after it.
    setTimeout(() => { try { Enhancements.init(); } catch (e) { console.error('[Enhancements]', e); } }, 160);
});
