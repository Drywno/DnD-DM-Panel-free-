/* ============================================
   Godła miejsc na mapach — rysunki „tuszem” w stylu starych map.
   Wspólne dla panelu MG (Atlas) i widoku gracza.
   ============================================ */
const MapEmblems = (() => {
    // k = kontur tuszem, f = wypełnienie tuszem, a = kolor kategorii, p = jasny pergamin, s = cień
    const E = {
        capital: `<path class="s" d="M10 54h44v4H10z"/>
            <path class="p" d="M12 54V30h8v-6h6v6h12v-6h6v6h8v24z"/>
            <path class="k" d="M12 54V30h8v-6h6v6h12v-6h6v6h8v24zM12 30l4-4 4 4M44 30l4-4 4 4M26 24l6-8 6 8"/>
            <path class="f" d="M28 54V44a4 4 0 0 1 8 0v10z"/>
            <path class="k" d="M32 16V6"/><path class="a" d="M32 6l10 3-10 3z"/>
            <path class="k" d="M16 38h2M46 38h2M30 34h4"/>
            <path class="a" d="M24 12l2-5 3 4 3-5 3 5 3-4 2 5z"/>`,
        city: `<path class="s" d="M8 54h48v4H8z"/>
            <path class="p" d="M10 54V34h6v-8h8v8h16v-8h8v8h6v20z"/>
            <path class="k" d="M10 54V34h6v-8h8v8h16v-8h8v8h6v20zM16 26l4-5 4 5M40 26l4-5 4 5M10 34h44"/>
            <path class="f" d="M28 54v-9a4 4 0 0 1 8 0v9z"/>
            <path class="k" d="M20 21V11M44 21V11"/><path class="a" d="M20 11l8 2.5-8 2.5zM44 11l8 2.5-8 2.5z"/>
            <path class="k" d="M14 40h2M48 40h2M18 46h2M44 46h2"/>`,
        town: `<path class="s" d="M6 54h52v4H6z"/>
            <path class="p" d="M8 54V38l8-8 8 8v16zM24 54V32l9-10 9 10v22zM42 54V40l7-7 7 7v14z"/>
            <path class="k" d="M8 54V38l8-8 8 8v16M24 54V32l9-10 9 10v22M42 54V40l7-7 7 7v14M6 54h52"/>
            <path class="a" d="M24 32l9-10 9 10zM8 38l8-8 8 8zM42 40l7-7 7 7z"/>
            <path class="f" d="M30 54v-8h6v8zM13 54v-6h5v6zM47 54v-6h4v6z"/>
            <path class="k" d="M29 38h3v3h-3zM34 38h3v3h-3z"/>`,
        village: `<path class="s" d="M6 54h52v4H6z"/>
            <path class="p" d="M10 54V38l11-10 11 10v16zM34 54V42l9-8 9 8v12z"/>
            <path class="a" d="M8 39l13-12 13 12zM32 43l11-10 11 10z"/>
            <path class="k" d="M8 39l13-12 13 12M32 43l11-10 11 10M10 54V38M32 54V38M34 54V42M52 54V42M6 54h52"/>
            <path class="f" d="M18 54v-8h6v8zM40 54v-6h5v6z"/>
            <path class="k" d="M26 30v-6h4v8"/><path class="k sm" d="M28 20c-3-3 3-5 0-8M31 18c-2-2 2-4 0-6"/>`,
        market: `<path class="k" d="M32 10v40M18 50h28M32 14H14M32 14h18"/>
            <path class="k" d="M14 14l-6 16M14 14l6 16M50 14l-6 16M50 14l6 16"/>
            <path class="a" d="M6 30h16a8 6 0 0 1-16 0zM42 30h16a8 6 0 0 1-16 0z"/>
            <path class="k" d="M6 30h16a8 6 0 0 1-16 0zM42 30h16a8 6 0 0 1-16 0z"/>
            <circle class="f" cx="32" cy="9" r="3"/><path class="p" d="M26 50l6-6 6 6z"/><path class="k" d="M26 50l6-6 6 6"/>`,
        tavern: `<path class="s" d="M14 56h32v3H14z"/>
            <path class="p" d="M14 22h28v34H14z"/>
            <path class="a" d="M14 30h28v4H14zM14 46h28v4H14z"/>
            <path class="k" d="M14 22h28v34H14zM42 28h6a6 6 0 0 1 6 6v8a6 6 0 0 1-6 6h-6M42 33h5a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-5"/>
            <path class="p" d="M12 22c-2-6 4-10 8-8 1-5 9-6 11-2 3-4 11-2 10 4 4 0 5 5 2 7H12z"/>
            <path class="k" d="M12 22c-2-6 4-10 8-8 1-5 9-6 11-2 3-4 11-2 10 4 4 0 5 5 2 7"/>
            <path class="k" d="M21 26v26M28 26v26M35 26v26"/>`,
        guild: `<path class="p" d="M14 10h36v18c0 14-10 22-18 26C24 50 14 42 14 28z"/>
            <path class="a" d="M14 10h18v44C24 50 14 42 14 28z"/>
            <path class="k" d="M14 10h36v18c0 14-10 22-18 26C24 50 14 42 14 28zM32 10v44"/>
            <path class="k thick" d="M22 20l20 20M42 20L22 40"/>
            <path class="f" d="M38 16l8 0 0 8zM18 16l8 0-8 8z"/>`,
        fortress: `<path class="s" d="M6 54h52v4H6z"/>
            <path class="p" d="M8 54V28h6v4h6v-4h6v4h12v-4h6v4h6v-4h6v26z"/>
            <path class="k" d="M8 54V28h6v4h6v-4h6v4h12v-4h6v4h6v-4h6v26zM6 54h52"/>
            <path class="p" d="M22 32V16h4v4h4v-4h4v4h4v-4h4v16z"/>
            <path class="k" d="M22 32V16h4v4h4v-4h4v4h4v-4h4v16"/>
            <path class="f" d="M27 54V44a5 5 0 0 1 10 0v10z"/>
            <path class="k" d="M29 46v8M32 44v10M35 46v8M27 49h10"/>
            <path class="a" d="M30 26h4v4h-4z"/>`,
        castle: `<path class="s" d="M6 54h52v4H6z"/>
            <path class="p" d="M10 54V24h8v30zM46 54V24h8v30zM18 54V34h28v20z"/>
            <path class="k" d="M10 54V24h8v30M46 54V24h8v30M18 34h28M6 54h52M10 24v-4h2v2h2v-2h2v2h2v-4M46 24v-4h2v2h2v-2h2v2h2v-4"/>
            <path class="a" d="M8 24l6-10 6 10zM44 24l6-10 6 10z"/>
            <path class="k" d="M8 24l6-10 6 10M44 24l6-10 6 10"/>
            <path class="f" d="M27 54v-9a5 5 0 0 1 10 0v9z"/>
            <path class="k" d="M14 32v4M50 32v4M22 40h2M40 40h2"/>`,
        ruin: `<path class="s" d="M6 54h52v4H6z"/>
            <path class="p" d="M10 54V22h8v32zM24 54V34l8-4v24zM40 54V18h8v8l-3 4 3 4v20z"/>
            <path class="k" d="M10 54V22h8v32M10 22l2-3h4l2 3M24 54V34l8-4v24M40 54V26M48 54V34l-3-4 3-4v-8h-8v8M6 54h52"/>
            <path class="k" d="M12 28h4M12 34h4M42 22h4M12 46h4"/>
            <path class="a" d="M52 54l-4-6 6 2zM22 54l-2-5 5 2z"/>
            <path class="k sm" d="M54 46c2-4 4-4 6-2M4 48c2-3 4-3 5-1"/>`,
        cave: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="p" d="M4 56l14-30 8 6 10-20 24 44z"/>
            <path class="k" d="M4 56l14-30 8 6 10-20 24 44zM30 24l6-12 5 10"/>
            <path class="f" d="M22 56c0-12 6-18 12-18s12 6 12 18z"/>
            <path class="a" d="M28 56c0-6 2-9 6-9s6 3 6 9z"/>
            <path class="k" d="M14 44l3-4M48 44l-2-4"/>`,
        hideout: `<path class="p" d="M6 26c8-8 20-10 26-4 6-6 18-4 26 4-4 12-14 18-26 14C20 44 10 38 6 26z"/>
            <path class="k" d="M6 26c8-8 20-10 26-4 6-6 18-4 26 4-4 12-14 18-26 14C20 44 10 38 6 26z"/>
            <path class="f" d="M14 28c4-3 9-3 12 1-4 4-9 4-12-1zM50 28c-4-3-9-3-12 1 4 4 9 4 12-1z"/>
            <path class="a" d="M6 26c-2 6-2 12 2 18l4-10zM58 26c2 6 2 12-2 18l-4-10z"/>
            <path class="k" d="M32 22v14"/>`,
        dungeon: `<path class="s" d="M6 56h52v3H6z"/>
            <path class="p" d="M8 56V26C8 14 20 6 32 6s24 8 24 20v30z"/>
            <path class="k" d="M8 56V26C8 14 20 6 32 6s24 8 24 20v30M8 56h48"/>
            <path class="f" d="M16 56V28c0-8 7-14 16-14s16 6 16 14v28z"/>
            <path class="a" d="M20 56V30M26 56V24M32 56V20M38 56V24M44 56V30" style="stroke-width:3"/>
            <path class="a" d="M17 36h30M17 46h30" style="stroke-width:3"/>
            <path class="k" d="M10 22l4 2M54 22l-4 2M32 6v6"/>`,
        forest: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="a" d="M14 52L4 52l10-14H7l9-12H11l9-14 9 14h-5l9 12h-7l10 14H24z"/>
            <path class="k" d="M14 52L4 52l10-14H7l9-12H11l9-14 9 14h-5l9 12h-7l10 14H24z"/>
            <path class="p" d="M38 52l-8 0 8-12h-5l7-10h-4l8-12 8 12h-4l7 10h-5l8 12h-8z"/>
            <path class="k" d="M38 52l-8 0 8-12h-5l7-10h-4l8-12 8 12h-4l7 10h-5l8 12h-8z"/>
            <path class="f" d="M18 52h4v5h-4zM42 52h4v5h-4z"/>`,
        mountain: `<path class="s" d="M2 56h60v3H2z"/>
            <path class="p" d="M2 56l20-34 10 14 8-12 22 32z"/>
            <path class="k" d="M2 56l20-34 10 14 8-12 22 32z"/>
            <path class="a" d="M22 22l-6 10 4-2 2 3 3-3 3 2zM40 24l-5 8 3-1 2 2 2-2 3 1z" style="fill:#f5efe0"/>
            <path class="k" d="M22 22l-6 10 4-2 2 3 3-3 3 2M40 24l-5 8 3-1 2 2 2-2 3 1"/>
            <path class="k sm" d="M14 46l4-6M30 48l4-8M46 46l3-5"/>`,
        sea: `<path class="a" d="M4 40c6-4 10-4 14 0s10 4 14 0 10-4 14 0 10 4 14 0v18H4z"/>
            <path class="k" d="M4 40c6-4 10-4 14 0s10 4 14 0 10-4 14 0 10 4 14 0M4 50c6-4 10-4 14 0s10 4 14 0 10-4 14 0 10 4 14 0"/>
            <path class="p" d="M18 34l28 0-4 6H22z"/><path class="k" d="M18 34h28l-4 6H22zM32 34V8"/>
            <path class="p" d="M32 10l12 10-12 4zM31 12L20 28h11z"/>
            <path class="k" d="M32 10l12 10-12 4M31 12L20 28h11"/>`,
        wilderness: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="a" d="M32 54C16 44 14 24 32 8c18 16 16 36 0 46z"/>
            <path class="k" d="M32 54C16 44 14 24 32 8c18 16 16 36 0 46zM32 56V16M32 26l-8-6M32 34l10-7M32 42l-10-6"/>
            <path class="k sm" d="M8 56c2-6 4-8 6-10M12 56c0-4 1-6 3-8M54 56c-2-6-4-8-6-10M50 56c0-4-1-6-3-8"/>`,
        temple: `<path class="s" d="M6 56h52v3H6z"/>
            <path class="p" d="M10 26C10 14 20 8 32 8s22 6 22 18z"/>
            <path class="a" d="M14 26c0-9 8-14 18-14s18 5 18 14z"/>
            <path class="k" d="M10 26C10 14 20 8 32 8s22 6 22 18zM32 8V2M29 4h6"/>
            <path class="p" d="M8 26h48v6H8zM10 50h44v6H10z"/>
            <path class="k" d="M8 26h48v6H8zM10 50h44v6H10zM14 32v18M22 32v18M30 32v18M34 32v18M42 32v18M50 32v18"/>`,
        plane: `<ellipse class="f" cx="32" cy="34" rx="20" ry="24"/>
            <ellipse class="a" cx="32" cy="34" rx="14" ry="18"/>
            <path class="p" d="M32 20c8 2 10 10 6 16s-12 6-14 0 2-10 8-10"/>
            <path class="k" d="M32 20c8 2 10 10 6 16s-12 6-14 0 2-10 8-10"/>
            <ellipse class="k" cx="32" cy="34" rx="20" ry="24"/>
            <path class="a" d="M10 10l2 5 5 2-5 2-2 5-2-5-5-2 5-2zM54 6l1.5 4 4 1.5-4 1.5L54 17l-1.5-4-4-1.5 4-1.5zM54 50l1.5 4 4 1.5-4 1.5-1.5 4-1.5-4-4-1.5 4-1.5z"/>`,
        house: `<path class="s" d="M8 56h48v3H8z"/>
            <path class="p" d="M14 56V32l18-16 18 16v24z"/><path class="a" d="M10 34l22-20 22 20-4 3-18-16-18 16z"/>
            <path class="k" d="M10 34l22-20 22 20M14 30v26h36V30M8 56h48"/>
            <path class="f" d="M27 56V44h10v12z"/><path class="k" d="M18 38h6v6h-6zM40 38h6v6h-6z"/>
            <path class="k" d="M40 22v-8h5v12"/><path class="k sm" d="M42 10c-2-2 2-4 0-6"/>`,
        manor: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="p" d="M8 56V30h14v-8h20v8h14v26z"/>
            <path class="a" d="M6 30l8-8h36l8 8zM20 22l12-10 12 10z"/>
            <path class="k" d="M6 30l8-8h36l8 8M20 22l12-10 12 10M8 30v26h48V30M4 56h56"/>
            <path class="f" d="M28 56V44a4 4 0 0 1 8 0v12z"/>
            <path class="k" d="M12 36h6v6h-6zM46 36h6v6h-6zM29 28h6v6h-6zM12 46h6v5h-6zM46 46h6v5h-6z"/>
            <path class="k" d="M32 12V5"/><path class="a" d="M32 5l7 2-7 2z"/>`,
        palace: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="p" d="M8 56V34h48v22zM22 34V24h20v10z"/>
            <path class="a" d="M22 24c0-8 4-14 10-14s10 6 10 14zM6 34c0-5 2-8 5-8s5 3 5 8zM48 34c0-5 2-8 5-8s5 3 5 8z"/>
            <path class="k" d="M22 24c0-8 4-14 10-14s10 6 10 14zM6 34c0-5 2-8 5-8s5 3 5 8zM48 34c0-5 2-8 5-8s5 3 5 8zM8 34h48v22H8zM22 24h20v10M4 56h56"/>
            <path class="k" d="M14 40v10M20 40v10M26 40v10M38 40v10M44 40v10M50 40v10M32 10V4"/>
            <path class="f" d="M29 56v-9a3 3 0 0 1 6 0v9z"/>`,
        tower: `<path class="s" d="M18 56h28v3H18z"/>
            <path class="p" d="M22 56V22h20v34z"/>
            <path class="k" d="M22 56V22h20v34M18 56h28M20 22v-6h4v3h4v-3h4v3h4v-3h4v6z"/>
            <path class="a" d="M20 16l12-12 12 12z"/><path class="k" d="M20 16l12-12 12 12"/>
            <path class="f" d="M29 56v-8a3 3 0 0 1 6 0v8zM30 28h4v6h-4zM30 38h4v5h-4z"/>`,
        gate: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="p" d="M6 56V20h14v6h24v-6h14v36z"/>
            <path class="k" d="M6 56V20h14v6h24v-6h14v36M6 20v-4h3v2h3v-2h3v2h3v-2h2v4M44 20v-4h3v2h3v-2h3v2h3v-2h2v4M4 56h56"/>
            <path class="f" d="M20 56V40c0-7 5-12 12-12s12 5 12 12v16z"/>
            <path class="a" d="M23 56V40M28 56V32M32 56V30M36 56V32M41 56V40M21 44h22M21 50h22" style="stroke-width:2.2"/>`,
        barracks: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="p" d="M8 56V34h48v22z"/><path class="a" d="M4 36l8-12h40l8 12z"/>
            <path class="k" d="M4 36l8-12h40l8 12M8 36v20h48V36M4 56h56"/>
            <path class="f" d="M28 56V46h8v10z"/><path class="k" d="M13 42h8v6h-8zM43 42h8v6h-8z"/>
            <path class="k thick" d="M24 10l16 16M40 10L24 26"/><circle class="a" cx="32" cy="18" r="4"/>`,
        smithy: `<path class="p" d="M10 38h30l4-6h12v8H46l-6 6H18l-4 6h22v4H8v-4l6-6z"/>
            <path class="a" d="M10 38h30l4-6h12v8H46l-6 6H18z"/>
            <path class="k" d="M10 38h30l4-6h12v8H46l-6 6H18l-4 6h22v4H8v-4l6-6zM10 38l4 8"/>
            <path class="k thick" d="M30 30L44 10"/><path class="f" d="M38 6l10 6-3 5-10-6z"/>
            <path class="k sm" d="M20 30l-2-6M26 28l1-6M14 32l-5-4"/>`,
        shop: `<path class="s" d="M6 56h52v3H6z"/>
            <path class="p" d="M10 56V30h44v26z"/>
            <path class="a" d="M8 30l4-10h40l4 10zM8 30c0 4 6 4 6 0 0 4 6 4 6 0 0 4 6 4 6 0 0 4 6 4 6 0 0 4 6 4 6 0 0 4 6 4 6 0 0 4 6 4 6 0"/>
            <path class="k" d="M8 30l4-10h40l4 10zM10 30v26h44V30M6 56h52"/>
            <path class="f" d="M34 56V40h12v16z"/><path class="k" d="M14 38h14v10H14zM21 38v10M14 43h14"/>
            <path class="k" d="M20 20V12h24v8"/><circle class="a" cx="32" cy="16" r="3"/>`,
        docks: `<path class="a" d="M2 46c5-3 9-3 13 0s9 3 13 0 9-3 13 0 9 3 13 0 5-2 8-1v16H2z"/>
            <path class="k" d="M2 46c5-3 9-3 13 0s9 3 13 0 9-3 13 0 9 3 13 0 5-2 8-1"/>
            <path class="p" d="M4 36h56v6H4z"/><path class="k" d="M4 36h56v6H4zM10 42v12M22 42v12M34 42v12M46 42v12M58 42v12"/>
            <path class="k thick" d="M32 6v24M24 14h16"/><path class="k" d="M24 26c0 6 16 6 16 0M32 30v6"/>`,
        mill: `<path class="s" d="M14 56h36v3H14z"/>
            <path class="p" d="M20 56l4-24h16l4 24z"/><path class="a" d="M22 32l10-10 10 10z"/>
            <path class="k" d="M20 56l4-24h16l4 24zM22 32l10-10 10 10M14 56h36"/>
            <path class="f" d="M29 56v-8h6v8z"/>
            <path class="k" d="M32 26L14 8M32 26L50 8M32 26L14 44M32 26L50 44"/>
            <path class="p" d="M16 10l8 0-6 6zM48 10l-8 0 6 6zM16 42l8 0-6-6zM48 42l-8 0 6-6z"/>
            <circle class="f" cx="32" cy="26" r="3"/>`,
        farm: `<path class="a" d="M4 56l10-16h36l10 16z"/>
            <path class="k" d="M4 56l10-16h36l10 16zM12 56l6-16M22 56l3-16M32 56V40M42 56l-3-16M52 56l-6-16"/>
            <path class="p" d="M36 40V24l10-8 10 8v16z"/><path class="k" d="M34 26l12-10 12 10M36 24v16h20V24"/>
            <path class="f" d="M43 40v-7h6v7z"/>
            <path class="k" d="M14 34c0-8 4-12 4-16M18 18c-3 1-5 4-4 7M18 18c3 1 5 4 4 7M10 34c0-5 2-8 2-10"/>`,
        well: `<path class="s" d="M10 56h44v3H10z"/>
            <path class="p" d="M14 40h36v16H14z"/><path class="k" d="M14 40h36v16H14zM14 46h36M24 40v6M38 40v6M20 46v10M32 46v10M44 46v10"/>
            <path class="k thick" d="M16 40V18M48 40V18"/><path class="a" d="M10 20l22-10 22 10z"/><path class="k" d="M10 20l22-10 22 10z"/>
            <path class="k" d="M16 26h32M32 26v8"/><path class="f" d="M28 34h8v5h-8z"/>`,
        shrine: `<path class="s" d="M14 56h36v3H14z"/>
            <path class="p" d="M18 56V30h28v26z"/><path class="a" d="M14 32l18-16 18 16z"/>
            <path class="k" d="M14 32l18-16 18 16zM18 32v24h28V32M14 56h36"/>
            <path class="k thick" d="M32 6v14M26 11h12"/>
            <path class="f" d="M28 56V44a4 4 0 0 1 8 0v12z"/><circle class="a" cx="32" cy="38" r="3"/>`,
        graveyard: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="p" d="M8 56V38a6 6 0 0 1 12 0v18zM26 56V28a6 6 0 0 1 12 0v28zM44 56V40a6 6 0 0 1 12 0v16z"/>
            <path class="k" d="M8 56V38a6 6 0 0 1 12 0v18M26 56V28a6 6 0 0 1 12 0v28M44 56V40a6 6 0 0 1 12 0v16M4 56h56"/>
            <path class="k thick" d="M32 32v12M27 36h10"/><path class="k" d="M14 42v6M11 44h6M50 44v6M47 46h6"/>
            <path class="a" d="M2 56c3-4 6-4 8 0zM22 56c3-4 6-4 8 0zM40 56c3-4 6-4 8 0z"/>`,
        bridge: `<path class="a" d="M2 50c5-3 9-3 13 0s9 3 13 0 9-3 13 0 9 3 13 0 5-2 8-1v12H2z"/>
            <path class="p" d="M2 34h60v8c-8 0-14 4-16 12H18C16 46 10 42 2 42z"/>
            <path class="k" d="M2 34h60v8c-8 0-14 4-16 12H18C16 46 10 42 2 42zM2 34v-6M14 34v-6M26 34v-6M38 34v-6M50 34v-6M62 34v-6M2 28h60"/>`,
        camp: `<path class="s" d="M4 56h56v3H4z"/>
            <path class="a" d="M6 56L24 18l18 38z"/><path class="p" d="M24 18l6 38H18z"/>
            <path class="k" d="M6 56L24 18l18 38zM24 18v38M22 14l4 8"/>
            <path class="k" d="M44 56l6-6 6 6M46 54l8-6M54 54l-8-6"/>
            <path class="a" d="M50 50c-3-4 0-8 0-10 3 3 4 6 0 10z"/>`,
        other: `<circle class="p" cx="32" cy="32" r="22"/>
            <path class="a" d="M32 6l5 21 21 5-21 5-5 21-5-21-21-5 21-5z"/>
            <path class="k" d="M32 6l5 21 21 5-21 5-5 21-5-21-21-5 21-5zM32 6v52M6 32h52"/>
            <circle class="f" cx="32" cy="32" r="3"/>
            <path class="k sm" d="M14 14l8 8M50 14l-8 8M14 50l8-8M50 50l-8-8"/>`
    };
    const CAT = {
        capital: 'settle', city: 'settle', town: 'settle', village: 'settle', market: 'settle', tavern: 'settle', guild: 'settle',
        fortress: 'war', castle: 'war', ruin: 'danger', cave: 'danger', hideout: 'danger', dungeon: 'danger',
        forest: 'nature', mountain: 'nature', sea: 'nature', wilderness: 'nature', temple: 'sacred', plane: 'sacred', other: 'other', region: 'region',
        house: 'settle', manor: 'war', palace: 'settle', tower: 'war', gate: 'war', barracks: 'war', smithy: 'settle', shop: 'settle',
        docks: 'settle', mill: 'settle', farm: 'nature', well: 'other', shrine: 'sacred', graveyard: 'danger', bridge: 'other', camp: 'danger'
    };
    // które znaczniki pasują do mapy świata, a które do mapy miasta / regionu
    const SCOPE = {
        world: ['capital', 'city', 'town', 'village', 'fortress', 'castle', 'tower', 'ruin', 'cave', 'hideout', 'dungeon', 'camp', 'bridge', 'forest', 'mountain', 'sea', 'wilderness', 'temple', 'shrine', 'plane', 'docks', 'other', 'region'],
        local: ['house', 'tavern', 'market', 'shop', 'smithy', 'guild', 'manor', 'palace', 'tower', 'gate', 'barracks', 'temple', 'shrine', 'docks', 'mill', 'farm', 'well', 'graveyard', 'bridge', 'dungeon', 'cave', 'camp', 'ruin', 'other', 'region']
    };
    const PALETTE = ['#6fa3d8', '#d0614f', '#b07ad8', '#6fbf73', '#f0c75a', '#c9a86a', '#e07b39', '#4fb5b0', '#d45d8e', '#8a8f99', '#2f4a7a', '#7a2a1f'];
    const MAJOR = ['capital', 'city'];
    const svg = (t, cls = '') => `<svg class="mem ${cls}" viewBox="0 0 64 64" aria-hidden="true">${E[t] || E.other}</svg>`;
    const typeOf = (t) => (E[t] ? t : 'other');

    // ---------- tarcza herbowa znacznika: metalowe obramowanie, emaliowane pole w kolorze kategorii, godło w kości słoniowej ----------
    const METAL = { settle: 'bronze', war: 'steel', danger: 'iron', nature: 'bronze', sacred: 'gold', other: 'bronze', region: 'bronze' };
    function ensureDefs() {
        if (typeof document === 'undefined' || document.getElementById('mp-defs')) return;
        const g = (id, a, b, c) => `<linearGradient id="mpm-${id}" x1="0" y1="0" x2=".35" y2="1"><stop offset="0" stop-color="${a}"/><stop offset=".45" stop-color="${b}"/><stop offset="1" stop-color="${c}"/></linearGradient>`;
        document.body.insertAdjacentHTML('beforeend', `<svg id="mp-defs" width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true"><defs>
            ${g('gold', '#fff4c2', '#e2b345', '#7a5216')}${g('steel', '#f4f6f8', '#a3acb6', '#454b53')}${g('bronze', '#f6d9a6', '#b8823f', '#5b3a17')}${g('iron', '#b9b1aa', '#5c5651', '#221e1b')}
            <radialGradient id="mp-shade" cx=".35" cy=".25" r=".9"><stop offset="0" stop-color="#fff" stop-opacity=".38"/><stop offset=".5" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".45"/></radialGradient>
            <pattern id="mp-tex" width="6" height="6" patternUnits="userSpaceOnUse"><path d="M0 6L6 0" stroke="#000" stroke-opacity=".07" stroke-width="1.2"/></pattern>
        </defs></svg>`);
    }
    const SH_OUT = 'M5 9Q32 1 59 9L59 34C59 55 45 67 32 74C19 67 5 55 5 34Z';
    const SH_IN = 'M10.5 13Q32 6.5 53.5 13L53.5 34C53.5 51.5 42 62 32 67.5C22 62 10.5 51.5 10.5 34Z';
    function shield(t, cat, major) {
        ensureDefs();
        const m = major ? 'gold' : (METAL[cat] || 'bronze');
        const rivets = [[12, 15], [52, 15], [12, 37], [52, 37], [32, 66]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="1.7" fill="url(#mpm-${m})" stroke="#2a1808" stroke-width=".6"/>`).join('');
        const crown = major ? `<path d="M17 4l5 6 5-8 5 8 5-8 5 8 5-6-2 9H19z" fill="url(#mpm-gold)" stroke="#2a1808" stroke-width="1.2" stroke-linejoin="round"/><circle cx="32" cy="2" r="2" fill="#c0392b" stroke="#2a1808" stroke-width=".8"/>` : '';
        return `<svg class="mp-shield" viewBox="0 -8 64 84" aria-hidden="true">
            <path d="${SH_OUT}" fill="url(#mpm-${m})" stroke="#2a1808" stroke-width="1.6"/>
            <path d="${SH_OUT}" fill="none" stroke="rgba(255,248,225,.55)" stroke-width=".8" transform="translate(32 38) scale(.94) translate(-32 -38)"/>
            <path class="mp-field" d="${SH_IN}"/>
            <path d="${SH_IN}" fill="url(#mp-tex)"/>
            <path d="${SH_IN}" fill="url(#mp-shade)"/>
            <path d="${SH_IN}" fill="none" stroke="#2a1808" stroke-width="1.2"/>
            <path d="M14 15.5Q32 10.5 50 15.5" fill="none" stroke="rgba(255,250,230,.45)" stroke-width="1.1"/>
            ${rivets}${crown}
            <svg class="mem mem-in" x="16" y="11" width="32" height="32" viewBox="0 0 64 64">${E[t] || E.other}</svg>
        </svg>`;
    }

    // znacznik na mapie: tarcza herbowa z godłem, igła wskazująca miejsce i wstęga z nazwą
    function pin(l, opts = {}) {
        const t = typeOf(l.type), cat = CAT[t] || 'other';
        const cls = ['atl-pin', 'mp', 'mp-sh', `cat-${cat}`, `t-${t}`, MAJOR.includes(t) ? 'major' : '', opts.mini ? 'with-mini' : '', opts.cls || ''].filter(Boolean).join(' ');
        const col = /^#[0-9a-f]{3,8}$/i.test(l.color || '') ? `;--cc:${l.color}` : '';
        return `<button class="${cls}" ${opts.attr || ''} style="left:${l.x}%;top:${l.y}%${col}" aria-label="${opts.label || ''}">
            <span class="mp-shadow"></span>
            ${opts.mini ? `<span class="mp-mini">${mini(t)}</span>` : ''}
            <span class="atl-pin-dot mp-medal">${shield(t, cat, MAJOR.includes(t))}</span>
            ${opts.badges || ''}
            <span class="atl-pin-label mp-ribbon"><span>${opts.name || ''}</span></span>
        </button>`;
    }
    // chorągiew drużyny
    const banner = `<svg class="mp-banner" viewBox="0 0 48 80" aria-hidden="true">
        <path class="mp-pole" d="M8 78V4"/><circle class="mp-finial" cx="8" cy="4" r="4"/>
        <path class="mp-cloth" d="M10 8h32l-6 12 6 12H10z"/>
        <path class="mp-sigil" d="M22 14l3 5 5 1-4 3 1 5-5-3-5 3 1-5-4-3 5-1z"/>
    </svg>`;


    // ---------- makiety 3D (rzut izometryczny, małe dioramy z prostych brył) ----------
    const U = 10, C = 0.866;
    const P = (x, y, z = 0) => [(x - y) * U * C, (x + y) * U * 0.5 - z * U];
    const f1 = (v) => +v.toFixed(1);
    const pts = (a) => a.map(([x, y, z]) => P(x, y, z).map(f1).join(',')).join(' ');
    const poly = (a, fill, extra = '') => `<polygon points="${pts(a)}" fill="${fill}" ${extra}/>`;
    const seg = (a, b, col, w = .6, extra = '') => { const [x1, y1] = P(...a), [x2, y2] = P(...b); return `<line x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}" stroke="${col}" stroke-width="${w}" ${extra}/>`; };
    const lerp = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
    let rnd = Math.random;
    const seedRnd = (s) => { let x = (s >>> 0) || 7; rnd = () => ((x = (Math.imul(x, 1664525) + 1013904223) >>> 0) / 4294967296); };
    const MAT = {
        stone: ['#ebe4d4', '#c8bca5', '#968870'], dark: ['#a29a8c', '#7c7565', '#575146'], wood: ['#dcb176', '#b48a55', '#82603a'],
        plaster: ['#f7efdc', '#e2d4b4', '#b3a17d'], red: ['#de6c50', '#bb4c36', '#863224'], slate: ['#8499b1', '#5f748c', '#405368'],
        thatch: ['#ebcb72', '#c6a14a', '#927330'], gold: ['#f8dc82', '#dcb140', '#a07a18'], grass: ['#a3c777', '#7ea457', '#5a7a3c'],
        dirt: ['#d2b583', '#ab8f60', '#7d6642'], rock: ['#aea89c', '#8a8378', '#635d53'], water: ['#86bde0', '#5f98c0', '#426f91'],
        sand: ['#efdda8', '#d0b980', '#a38d5a'], snow: ['#ffffff', '#e3ecf2', '#b9c8d4'], purple: ['#c197e6', '#9a6dc2', '#6a4590'],
        teal: ['#7fd0c9', '#4fb5b0', '#33807c'], cobble: ['#d9d2c2', '#b8ad97', '#8b806b']
    };
    const LINE = 'rgba(42,24,8,.28)';
    // prostopadłościan z detalami zależnymi od materiału (mur pruski, cegły, deski)
    function box(x, y, z, w, d, h, m) {
        const [t, l, r] = MAT[m] || MAT.stone;
        let o = '';
        if (z <= 0.01 && h > .3) o += poly([[x + .15, y + d, 0], [x + w + .3, y + d, 0], [x + w + .3, y + d + .3, 0], [x + .15, y + d + .3, 0]], 'rgba(30,18,6,.22)', 'stroke="none"')
            + poly([[x + w, y + .15, 0], [x + w + .3, y + .15, 0], [x + w + .3, y + d, 0], [x + w, y + d, 0]], 'rgba(30,18,6,.22)', 'stroke="none"');
        o += poly([[x, y + d, z], [x + w, y + d, z], [x + w, y + d, z + h], [x, y + d, z + h]], l)
            + poly([[x + w, y, z], [x + w, y + d, z], [x + w, y + d, z + h], [x + w, y, z + h]], r);
        const F = [], R2 = [];   // linie detali: ściana lewa (y+d) i prawa (x+w)
        if ((m === 'stone' || m === 'dark' || m === 'cobble') && h > .45) {
            for (let k = .35; k < h - .1; k += .35) {
                F.push(seg([x, y + d, z + k], [x + w, y + d, z + k], LINE, .5)); R2.push(seg([x + w, y, z + k], [x + w, y + d, z + k], LINE, .5));
                const off = (Math.round(k / .35) % 2) * .25;
                for (let i = .5 + off; i < w - .1; i += .5) F.push(seg([x + i, y + d, z + k - .35], [x + i, y + d, z + k], LINE, .4));
                for (let j = .5 + off; j < d - .1; j += .5) R2.push(seg([x + w, y + j, z + k - .35], [x + w, y + j, z + k], LINE, .4));
            }
        } else if (m === 'plaster' && h > .6 && w > .7) {
            const T = '#6e4a28', mid = z + h * .5;
            F.push(seg([x + .04, y + d, z], [x + .04, y + d, z + h], T, 1.3), seg([x + w - .04, y + d, z], [x + w - .04, y + d, z + h], T, 1.3), seg([x, y + d, mid], [x + w, y + d, mid], T, 1), seg([x, y + d, z + h - .05], [x + w, y + d, z + h - .05], T, 1.2));
            if (w > 1.4) F.push(seg([x + w * .5, y + d, z], [x + w * .5, y + d, z + h], T, 1), seg([x + w * .5, y + d, mid], [x + w * .75, y + d, z + h], T, .8));
            R2.push(seg([x + w, y + d - .04, z], [x + w, y + d - .04, z + h], T, 1.3), seg([x + w, y + .04, z], [x + w, y + .04, z + h], T, 1.3), seg([x + w, y, mid], [x + w, y + d, mid], T, 1), seg([x + w, y, z + h - .05], [x + w, y + d, z + h - .05], T, 1.2));
            if (d > 1.2) R2.push(seg([x + w, y + d * .5, z], [x + w, y + d * .5, z + h], T, 1), seg([x + w, y + d * .5, mid], [x + w, y + d * .25, z + h], T, .8));
        } else if (m === 'wood' && h > .3) {
            for (let k = .18; k < h; k += .18) { F.push(seg([x, y + d, z + k], [x + w, y + d, z + k], LINE, .45)); R2.push(seg([x + w, y, z + k], [x + w, y + d, z + k], LINE, .45)); }
        }
        o += F.join('') + R2.join('');
        o += poly([[x, y, z + h], [x + w, y, z + h], [x + w, y + d, z + h], [x, y + d, z + h]], t);
        return o;
    }
    function crenels(x, y, z, w, d, m) {   // blanki: małe zęby co 0.45 wzdłuż krawędzi
        let o = ''; const q = .18, hh = .24, st = .45;
        if (d > .5) for (let i = 0; i < w - .1; i += st) o += box(x + i, y, z, q, q, hh, m);
        if (w > .5) for (let j = st; j < d - .1; j += st) o += box(x, y + j, z, q, q, hh, m);
        for (let i = 0; i < w - .1; i += st) o += box(x + i, y + d - q, z, q, q, hh, m);
        for (let j = 0; j < d - q - .05; j += st) o += box(x + w - q, y + j, z, q, q, hh, m);
        return o;
    }
    function shingles(a, b, c, d2, n, col) {   // linie dachówek równoległe do okapu a-b, kalenica d2-c
        let o = '';
        for (let i = 1; i < n; i++) { const t = i / n; o += seg(lerp(a, d2, t), lerp(b, c, t), col, .55); }
        return o;
    }
    function pyramid(x, y, z, w, d, h, m) {
        const [t, l, r] = MAT[m] || MAT.red, ap = [x + w / 2, y + d / 2, z + h];
        const A = [x, y + d, z], B = [x + w, y + d, z], Cc = [x + w, y, z];
        return poly([A, B, ap], l) + poly([B, Cc, ap], r)
            + shingles(A, B, ap, ap, 4, 'rgba(0,0,0,.18)') + shingles(B, Cc, ap, ap, 4, 'rgba(0,0,0,.2)')
            + seg(B, ap, 'rgba(255,240,210,.45)', .8);
    }
    function gable(x, y, z, w, d, h, m, wall = 'plaster') {
        const [t, l, r] = MAT[m] || MAT.red;
        const A = [x - .08, y + d + .12, z - .05], B = [x + w + .08, y + d + .12, z - .05], Cr = [x + w + .08, y + d / 2, z + h], Dr = [x - .08, y + d / 2, z + h];
        const n = m === 'thatch' ? 3 : 5;
        return poly([[x + w, y, z], [x + w, y + d, z], [x + w, y + d / 2, z + h]], (MAT[wall] || MAT.plaster)[2])
            + (h > .6 ? winR(x + w, y + d / 2 - .12, z + h * .25, .24) : '')
            + poly([A, B, Cr, Dr], l) + shingles(A, B, Cr, Dr, n, 'rgba(0,0,0,.2)')
            + poly([[x + w + .08, y - .12, z - .05], [x + w + .08, y + d + .12, z - .05], Cr], 'none', `stroke="${r}" stroke-width="1.6"`)
            + seg(Dr, Cr, 'rgba(255,240,210,.55)', 1);
    }
    function tower(x, y, z, r, h, m, roof = 'slate', rh = 1.6) {
        const [cx, cy] = P(x, y, z), [, ty] = P(x, y, z + h), rx = r * U * 1.22, ry = rx * 0.5;
        const [t, l, rr] = MAT[m] || MAT.stone, [, rl, rrr] = MAT[roof] || MAT.slate, top = ty, apex = top - rh * U;
        const id = 'tg' + Math.floor(rnd() * 1e6);
        let o = `<defs><linearGradient id="${id}" x1="0" x2="1"><stop offset="0" stop-color="${t}"/><stop offset=".45" stop-color="${l}"/><stop offset="1" stop-color="${rr}"/></linearGradient></defs>
            <ellipse cx="${f1(cx + 3)}" cy="${f1(cy + 2)}" rx="${f1(rx * 1.1)}" ry="${f1(ry * 1.1)}" fill="rgba(30,18,6,.22)" stroke="none"/>
            <path d="M${f1(cx - rx)} ${f1(cy)} A${f1(rx)} ${f1(ry)} 0 0 0 ${f1(cx + rx)} ${f1(cy)} V${f1(top)} H${f1(cx - rx)} Z" fill="url(#${id})"/>`;
        if (m === 'stone' || m === 'dark') for (let k = .4; k < h - .1; k += .4) { const yy = cy - k * U; o += `<path d="M${f1(cx - rx)} ${f1(yy)} A${f1(rx)} ${f1(ry)} 0 0 0 ${f1(cx + rx)} ${f1(yy)}" fill="none" stroke="${LINE}" stroke-width=".5"/>`; }
        if (h > 1.4) o += `<rect x="${f1(cx - 1.2)}" y="${f1(top + 4)}" width="2.4" height="4" rx="1.2" fill="#ffd36b" stroke="#3a2412" stroke-width=".5"/>`;
        o += `<ellipse cx="${f1(cx)}" cy="${f1(top)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${t}"/>`;
        if (roof) o += `<path d="M${f1(cx - rx * 1.18)} ${f1(top)} L${f1(cx)} ${f1(apex)} L${f1(cx)} ${f1(top + ry * 1.15)} Z" fill="${rl}"/><path d="M${f1(cx)} ${f1(apex)} L${f1(cx + rx * 1.18)} ${f1(top)} L${f1(cx)} ${f1(top + ry * 1.15)} Z" fill="${rrr}"/>
            <path d="M${f1(cx - rx * .6)} ${f1(top - rh * U * .5 + ry * .3)} L${f1(cx)} ${f1(top - rh * U * .5 + ry * .6)} L${f1(cx + rx * .6)} ${f1(top - rh * U * .5 + ry * .3)}" fill="none" stroke="rgba(0,0,0,.2)" stroke-width=".6"/>
            <path d="M${f1(cx)} ${f1(apex)} v-3" stroke="#3a2412" stroke-width="1"/><circle cx="${f1(cx)}" cy="${f1(apex - 3.5)}" r="1.1" fill="#f6d77a"/>`;
        return o;
    }
    // drzewa: iglaste i liściaste, z cieniowaniem
    function tree(x, y, s = 1, kind) {
        const [cx, cy] = P(x, y, 0);
        kind = kind || (rnd() < .5 ? 'pine' : 'oak');
        const sh = `<ellipse cx="${f1(cx + 3 * s)}" cy="${f1(cy + 1)}" rx="${f1(7 * s)}" ry="${f1(3 * s)}" fill="rgba(30,18,6,.25)" stroke="none"/>`;
        if (kind === 'pine') {
            const h = 26 * s, w = 9 * s;
            return sh + `<rect x="${f1(cx - 1.2 * s)}" y="${f1(cy - 4 * s)}" width="${f1(2.4 * s)}" height="${f1(5 * s)}" fill="#6b4a2a"/>`
                + [[0, 1, 1], [.32, .82, .78], [.6, .62, .55]].map(([o, k, ww]) => `<path d="M${f1(cx)} ${f1(cy - h * (k + o * .25))} L${f1(cx - w * ww)} ${f1(cy - 3 * s - h * o * .55)} L${f1(cx)} ${f1(cy - 1 * s - h * o * .55)} Z" fill="#5e8b43"/><path d="M${f1(cx)} ${f1(cy - h * (k + o * .25))} L${f1(cx + w * ww)} ${f1(cy - 3 * s - h * o * .55)} L${f1(cx)} ${f1(cy - 1 * s - h * o * .55)} Z" fill="#3c6430"/>`).join('');
        }
        const r = 7.5 * s, top = cy - 12 * s;
        return sh + `<path d="M${f1(cx - 1.3 * s)} ${f1(cy)} L${f1(cx - .9 * s)} ${f1(top + 2)} H${f1(cx + .9 * s)} L${f1(cx + 1.3 * s)} ${f1(cy)} Z" fill="#6b4a2a"/>
            <circle cx="${f1(cx)}" cy="${f1(top)}" r="${f1(r)}" fill="#4f7c38"/>
            <circle cx="${f1(cx - r * .35)}" cy="${f1(top - r * .3)}" r="${f1(r * .7)}" fill="#6e9e4c" stroke="none"/>
            <circle cx="${f1(cx - r * .45)}" cy="${f1(top - r * .5)}" r="${f1(r * .32)}" fill="#8fbd62" stroke="none"/>
            <circle cx="${f1(cx + r * .5)}" cy="${f1(top + r * .3)}" r="${f1(r * .45)}" fill="#3f6a2e" stroke="none"/>`;
    }
    function bush(x, y, s = 1) { const [cx, cy] = P(x, y, 0); return `<ellipse cx="${f1(cx)}" cy="${f1(cy - 2 * s)}" rx="${f1(4 * s)}" ry="${f1(3 * s)}" fill="#5a8a40"/><ellipse cx="${f1(cx - s)}" cy="${f1(cy - 3 * s)}" rx="${f1(2 * s)}" ry="${f1(1.4 * s)}" fill="#86b65c" stroke="none"/>`; }
    function peak(x, y, h, w, snow = true) {
        const [cx, cy] = P(x, y, 0), top = cy - h * U, hw = w * U;
        const mx = cx - hw * .15;
        return `<path d="M${f1(cx - hw)} ${f1(cy)} L${f1(mx)} ${f1(top + h * U * .25)} L${f1(cx)} ${f1(top)} L${f1(cx)} ${f1(cy + hw * .3)} Z" fill="#a39d91"/>
            <path d="M${f1(cx)} ${f1(top)} L${f1(cx + hw * .45)} ${f1(top + h * U * .45)} L${f1(cx + hw)} ${f1(cy)} L${f1(cx)} ${f1(cy + hw * .3)} Z" fill="#6f695f"/>
            <path d="M${f1(cx)} ${f1(top + h * U * .3)} l${f1(-hw * .25)} ${f1(h * U * .35)} M${f1(cx + hw * .2)} ${f1(top + h * U * .4)} l${f1(hw * .15)} ${f1(h * U * .3)}" stroke="rgba(0,0,0,.22)" stroke-width=".7" fill="none"/>
            ${snow ? `<path d="M${f1(cx - hw * .3)} ${f1(top + h * U * .3)} l${f1(hw * .1)} ${f1(-h * U * .02)} l${f1(hw * .08)} ${f1(h * U * .06)} L${f1(cx)} ${f1(top + h * U * .26)} L${f1(cx)} ${f1(top)} Z" fill="#fff"/><path d="M${f1(cx)} ${f1(top)} L${f1(cx + hw * .3)} ${f1(top + h * U * .3)} l${f1(-hw * .1)} ${f1(h * U * .04)} L${f1(cx)} ${f1(top + h * U * .36)} Z" fill="#d8e3ec"/>` : ''}`;
    }
    const flag = (x, y, z, col = '#c0392b') => { const [cx, cy] = P(x, y, z); return `<path d="M${f1(cx)} ${f1(cy)} V${f1(cy - 15)}" stroke="#2a1808" stroke-width="1.2"/><path class="mm-flag" d="M${f1(cx)} ${f1(cy - 15)} q5 -1.5 10 1.5 q-5 1.5 -10 4.5z" fill="${col}"/><circle cx="${f1(cx)}" cy="${f1(cy - 15.5)}" r="1" fill="#f6d77a"/>`; };
    const door = (x, y, z = 0, h = 0.9, w = 0.5) => poly([[x, y, z], [x + w, y, z], [x + w, y, z + h], [x, y, z + h]], '#4a2d14') + seg([x + w / 2, y, z], [x + w / 2, y, z + h], 'rgba(0,0,0,.35)', .5) + poly([[x + w * .75, y, z + h * .45], [x + w * .85, y, z + h * .45], [x + w * .85, y, z + h * .52], [x + w * .75, y, z + h * .52]], '#f6d77a', 'stroke="none"');
    const doorR = (x, y, z = 0, h = 0.9, w = 0.5) => poly([[x, y, z], [x, y + w, z], [x, y + w, z + h], [x, y, z + h]], '#3a2412');
    const win = (x, y, z, s = 0.3) => poly([[x, y, z], [x + s, y, z], [x + s, y, z + s], [x, y, z + s]], '#ffd36b', 'class="mm-win"') + seg([x + s / 2, y, z], [x + s / 2, y, z + s], '#5a3a1c', .5) + seg([x, y, z + s / 2], [x + s, y, z + s / 2], '#5a3a1c', .5);
    const winR = (x, y, z, s = 0.3) => poly([[x, y, z], [x, y + s, z], [x, y + s, z + s], [x, y, z + s]], '#f0bf55', 'class="mm-win"') + seg([x, y + s / 2, z], [x, y + s / 2, z + s], '#5a3a1c', .5);
    // podstawa: organiczna wysepka z grubością, kępkami trawy i kamykami
    const SKIRT = { grass: ['#7a5a36', '#5c4228'], dirt: ['#7a5a36', '#5c4228'], sand: ['#b39462', '#8c7146'], stone: ['#8f826c', '#6a5f4e'], cobble: ['#8f826c', '#6a5f4e'], rock: ['#6f695f', '#4f4a42'], water: ['#3f6f91', '#2d5470'], purple: ['#5a3a7a', '#3e2758'], snow: ['#b9c8d4', '#93a5b3'] };
    function base(m = 'grass', r = 2) {
        const N = 22, top = [], low = [], th = .45;
        for (let i = 0; i < N; i++) {
            const a = i / N * Math.PI * 2, rr = r * (1.02 + (rnd() - .5) * .14);
            const x = Math.cos(a) * rr * 1.04, y = Math.sin(a) * rr * 1.04;
            top.push([x, y, 0]); low.push([x, y, -th - rnd() * .12]);
        }
        const [sk, sk2] = SKIRT[m] || SKIRT.grass, [t, , dk] = MAT[m] || MAT.grass;
        let o = `<ellipse cx="3" cy="${f1(r * U * .55 + 4)}" rx="${f1(r * U * 1.25)}" ry="${f1(r * U * .55)}" fill="rgba(20,10,0,.28)" stroke="none" filter="blur(0)"/>`;
        for (let i = 0; i < N; i++) {
            const j = (i + 1) % N, A = top[i], B = top[j];
            if ((A[0] + A[1]) + (B[0] + B[1]) < -.2) continue;   // tylna krawędź niewidoczna
            o += poly([A, B, low[j], low[i]], (A[0] - A[1] + B[0] - B[1]) > 0 ? sk2 : sk, 'stroke="none"');
        }
        o += `<polygon points="${pts(top)}" fill="${t}" stroke="#2a1808" stroke-width=".8"/>`;
        o += `<polygon points="${pts(low.map((p, i) => [p[0], p[1], 0]).map(([x, y]) => [x * .86, y * .86, 0]))}" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="1.2"/>`;
        const deco = [];
        for (let k = 0; k < 14; k++) {
            const a = rnd() * Math.PI * 2, d = r * (.35 + rnd() * .55), x = Math.cos(a) * d, y = Math.sin(a) * d, [cx, cy] = P(x, y, 0);
            if (m === 'grass') deco.push(rnd() < .75 ? `<path d="M${f1(cx - 1.5)} ${f1(cy)} l1 -2.6 M${f1(cx)} ${f1(cy)} l0 -3.2 M${f1(cx + 1.5)} ${f1(cy)} l-1 -2.6" stroke="${dk}" stroke-width=".7" fill="none"/>` : `<circle cx="${f1(cx)}" cy="${f1(cy - .6)}" r=".9" fill="${['#f6e27a', '#f2f2f2', '#e98bb0'][k % 3]}" stroke="none"/>`);
            else if (m === 'water') deco.push(`<path class="mm-wave" d="M${f1(cx - 4)} ${f1(cy)} q2 -1.6 4 0 t4 0" stroke="#e8f4fb" stroke-width=".8" fill="none" opacity=".8"/>`);
            else if (m === 'cobble' || m === 'stone') deco.push(`<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="1.6" ry=".8" fill="none" stroke="${LINE}" stroke-width=".5"/>`);
            else if (m === 'purple') deco.push(`<circle cx="${f1(cx)}" cy="${f1(cy - 1)}" r=".8" fill="#f0e4ff" stroke="none" opacity=".8"/>`);
            else deco.push(`<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="${f1(.8 + rnd())}" ry=".6" fill="${dk}" stroke="none" opacity=".6"/>`);
        }
        return o + deco.join('');
    }
    const smoke = (x, y, z) => { const [cx, cy] = P(x, y, z); return `<g class="mm-smoke" stroke="none"><circle cx="${f1(cx)}" cy="${f1(cy - 3)}" r="2.2" fill="#ece7dd" opacity=".75"/><circle cx="${f1(cx + 2)}" cy="${f1(cy - 8)}" r="3" fill="#ece7dd" opacity=".55"/><circle cx="${f1(cx + .5)}" cy="${f1(cy - 14)}" r="3.6" fill="#ece7dd" opacity=".35"/></g>`; };
    const house = (x, y, w = 1.6, d = 1.4, h = 1.1, wall = 'plaster', roof = 'red') => box(x, y, 0, w, d, h, wall) + door(x + w * .3, y + d, 0, .7, .4) + win(x + w * .7, y + d, .45) + (d > 1 ? winR(x + w, y + d * .35, .45) : '') + gable(x, y, h, w, d, .9, roof, wall);
    const fence = (x1, y1, x2, y2) => { let o = seg([x1, y1, .25], [x2, y2, .25], '#7d5a33', 1) + seg([x1, y1, .12], [x2, y2, .12], '#7d5a33', .8); const n = Math.max(2, Math.round(Math.hypot(x2 - x1, y2 - y1) / .4)); for (let i = 0; i <= n; i++) { const p = lerp([x1, y1, 0], [x2, y2, 0], i / n); o += seg(p, [p[0], p[1], .35], '#5a3a1c', 1.1); } return o; };
    const barrel = (x, y) => tower(x, y, 0, .18, .35, 'wood', null);
    const crate = (x, y) => box(x, y, 0, .3, .3, .3, 'wood');
    const chimney = (x, y, z, h = .7) => box(x, y, z, .3, .3, h, 'stone') + box(x - .03, y - .03, z + h, .36, .36, .08, 'dark');
    // dach dwuspadowy z kalenicą wzdłuż osi y (szczyt od frontu)
    function gableY(x, y, z, w, d, h, m, wall = 'plaster') {
        const [, l, r] = MAT[m] || MAT.red;
        const A = [x + w + .12, y - .08, z - .05], B = [x + w + .12, y + d + .08, z - .05], Cr = [x + w / 2, y + d + .08, z + h], Dr = [x + w / 2, y - .08, z + h];
        return poly([[x, y + d, z], [x + w, y + d, z], [x + w / 2, y + d, z + h]], (MAT[wall] || MAT.plaster)[1])
            + (h > .6 ? win(x + w / 2 - .12, y + d, z + h * .25, .24) : '')
            + poly([A, B, Cr, Dr], r) + shingles(A, B, Cr, Dr, m === 'thatch' ? 3 : 5, 'rgba(0,0,0,.22)')
            + poly([[x - .12, y + d + .08, z - .05], [x + w + .12, y + d + .08, z - .05], Cr], 'none', `stroke="${l}" stroke-width="1.6"`)
            + seg(Dr, Cr, 'rgba(255,240,210,.5)', 1);
    }
    // ---- scena: elementy [głębokość, svg] sortowane od tyłu do przodu ----
    const S = (...items) => { const out = []; const walk = (v) => { if (!Array.isArray(v)) return; if (typeof v[0] === 'number' && typeof v[1] === 'string') out.push(v); else v.forEach(walk); }; walk(items);
        return out.map((v, i) => [v[0], i, v[1]]).sort((a, b) => a[0] - b[0] || a[1] - b[1]).map(v => v[2]).join(''); };
    const at = (x, y, svg) => [x + y, svg];
    function H(x, y, w, d, h, wall = 'plaster', roof = 'red', o = {}) {
        let s = box(x, y, 0, w, d, h, wall);
        s += door(x + w * (o.ridge === 'y' ? .35 : .22), y + d, 0, Math.min(.8, h * .7), .4);
        if (w > 1.1) s += win(x + w * .68, y + d, h * .42, .3);
        if (d > .8) s += winR(x + w, y + d * .3, h * .42, .3);
        if (h > 1.5) { s += win(x + w * .22, y + d, h * .72, .28); if (d > .8) s += winR(x + w, y + d * .6, h * .72, .28); }
        s += o.ridge === 'y' ? gableY(x, y, h, w, d, o.rh || .85, roof, wall) : o.ridge === 'hip' ? pyramid(x - .08, y - .08, h, w + .16, d + .16, o.rh || .9, roof) : gable(x, y, h, w, d, o.rh || .85, roof, wall);
        if (o.chimney) { const cx = x + w * .72, cy = y + d * .3; s += chimney(cx, cy, h + .25, .85) + smoke(cx + .15, cy + .15, h + 1.2); }
        return at(x + w / 2, y + d / 2, s);
    }
    const T = (x, y, r, h, m = 'stone', roof = 'slate', rh = 1.4) => at(x, y, tower(x, y, 0, r, h, m, roof, rh));
    const TR = (x, y, s, k) => at(x, y, tree(x, y, s, k));
    const BU = (x, y, s) => at(x, y, bush(x, y, s));
    const BA = (x, y) => at(x, y, barrel(x, y));
    const CR = (x, y) => at(x + .15, y + .15, crate(x, y));
    const FE = (x1, y1, x2, y2) => at((x1 + x2) / 2, (y1 + y2) / 2, fence(x1, y1, x2, y2));
    const path = (pts2, col = '#c9ad7c') => `<polygon points="${pts(pts2.map(([x, y]) => [x, y, 0]))}" fill="${col}" stroke="none" opacity=".9"/>`;
    const arch = (x, y, z, w, h) => { const n = 8, ptsA = [[x, y, z], [x, y, z + h * .7]]; for (let i = 0; i <= n; i++) { const a = Math.PI - i / n * Math.PI; ptsA.push([x + w / 2 + Math.cos(a) * w / 2, y, z + h * .7 + Math.sin(a) * h * .3]); } ptsA.push([x + w, y, z]); return poly(ptsA, '#1a0f06'); };
    const portcullis = (x, y, z, w, h) => { let o = ''; for (let i = 1; i < 5; i++) o += seg([x + w * i / 5, y, z], [x + w * i / 5, y, z + h * .9], '#6b6455', .6); for (let k = 1; k < 4; k++) o += seg([x, y, z + h * k / 4.5], [x + w, y, z + h * k / 4.5], '#6b6455', .5); return o; };
    // mury obronne wokół dziedzińca: tył (rysowany przed środkiem) i przód (po)
    function ring(x0, y0, x1, y1, h, m, t = .3, gate = null) {
        const back = box(x0, y0, 0, x1 - x0, t, h, m) + crenels(x0, y0, h, x1 - x0, t, m) + box(x0, y0 + t, 0, t, y1 - y0 - t, h, m) + crenels(x0, y0 + t, h, t, y1 - y0 - t, m);
        let front = '';
        if (gate) {
            const g0 = gate[0], g1 = gate[1];
            front += box(x0 + t, y1 - t, 0, g0 - x0 - t, t, h, m) + crenels(x0 + t, y1 - t, h, g0 - x0 - t, t, m);
            front += box(g0, y1 - t - .15, 0, g1 - g0, t + .3, h + .5, m) + crenels(g0, y1 - t - .15, h + .5, g1 - g0, t + .3, m) + arch(g0 + (g1 - g0) * .22, y1 + .15, 0, (g1 - g0) * .56, h * .95) + portcullis(g0 + (g1 - g0) * .22, y1 + .15, 0, (g1 - g0) * .56, h * .95);
            front += box(g1, y1 - t, 0, x1 - t - g1, t, h, m) + crenels(g1, y1 - t, h, x1 - t - g1, t, m);
        } else front += box(x0 + t, y1 - t, 0, x1 - x0 - 2 * t, t, h, m) + crenels(x0 + t, y1 - t, h, x1 - x0 - 2 * t, t, m);
        front += box(x1 - t, y0 + t, 0, t, y1 - y0 - t, h, m) + crenels(x1 - t, y0 + t, h, t, y1 - y0 - t, m);
        return { back: [x0 + y0 - 9, back], front: [x1 + y1 - .5, front] };
    }
    const sqTower = (x, y, s, h, m, roof) => at(x + s / 2, y + s / 2, box(x, y, 0, s, s, h, m) + (roof ? pyramid(x - .06, y - .06, h, s + .12, s + .12, s * 1.1, roof) : crenels(x, y, h, s, s, m)) + win(x + s * .35, y + s, h * .65, .22) + winR(x + s, y + s * .4, h * .65, .22));
    const flagAt = (x, y, z, c) => at(x + .01, y + .01, flag(x, y, z, c));
    const stall = (x, y, col) => at(x + .5, y + .4, box(x, y, 0, 1, .75, .42, 'wood') + box(x + .1, y + .1, .42, .25, .25, .14, 'red') + box(x + .42, y + .12, .42, .22, .22, .18, 'gold') + box(x + .7, y + .1, .42, .2, .2, .12, 'grass')
        + [[x, y + .75], [x + 1, y + .75], [x + 1, y]].map(([px, py]) => seg([px, py, .42], [px, py, 1.05], '#5a3a1c', 1)).join('') + awning(x - .06, y - .06, 1.05, 1.12, .87, .35, col));
    function awning(x, y, z, w, d, h, col) {
        const A = [x, y + d, z], B = [x + w, y + d, z], Cr = [x + w, y + d / 2, z + h], Dr = [x, y + d / 2, z + h];
        let o = poly([[x + w, y, z], [x + w, y + d, z], Cr], (MAT[col] || MAT.red)[2]);
        for (let i = 0; i < 6; i++) { const t0 = i / 6, t1 = (i + 1) / 6; o += poly([lerp(A, B, t0), lerp(A, B, t1), lerp(Dr, Cr, t1), lerp(Dr, Cr, t0)], i % 2 ? '#f6efe0' : (MAT[col] || MAT.red)[1]); }
        return o + seg(Dr, Cr, 'rgba(255,240,210,.5)', .8);
    }
    const sailP = (x, y, s = 1) => { const [cx, cy] = P(x, y, 0); return sail(f1(cx), f1(cy), s); };
    const sail = (cx, cy, s = 1) => `<path d="M${cx - 12 * s} ${cy} h${24 * s} l${-5 * s} ${6 * s} h${-14 * s}z" fill="#8a6239"/><path d="M${cx - 12 * s} ${cy} h${24 * s}" stroke="#5a3a1c" stroke-width="1"/><path d="M${cx} ${cy} v${-22 * s}" stroke="#3a2412" stroke-width="1.4"/>
        <path d="M${cx + 1} ${cy - 20 * s} q${9 * s} ${7 * s} 0 ${16 * s}z" fill="#f6efe0"/><path d="M${cx - 1} ${cy - 19 * s} q${-8 * s} ${9 * s} 0 ${15 * s}z" fill="#e6dccb"/><path d="M${cx} ${cy - 22 * s} l5 1.5 -5 1.5z" fill="#c0392b"/>`;
    const hay = (x, y, s = 1) => { const [cx, cy] = P(x, y, 0); return at(x, y, `<path d="M${f1(cx - 6 * s)} ${f1(cy)} q${f1(6 * s)} ${f1(-16 * s)} ${f1(12 * s)} 0z" fill="#e5c46c"/><path d="M${f1(cx)} ${f1(cy - 8 * s)} q${f1(4 * s)} ${f1(3 * s)} ${f1(6 * s)} ${f1(8 * s)} l${f1(-6 * s)} ${f1(1 * s)}z" fill="#bf9b45" stroke="none"/>`); };
    const fountain = (x, y, r = .55) => at(x, y, tower(x, y, 0, r, .3, 'stone', null) + (() => { const [cx, cy] = P(x, y, .3); return `<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="${f1(r * U * 1.05)}" ry="${f1(r * U * .52)}" fill="#6aa8d0"/><path d="M${f1(cx)} ${f1(cy)} v-7" stroke="#8f826c" stroke-width="2"/><path class="mm-wave" d="M${f1(cx - 4)} ${f1(cy - 6)} q4 -5 8 0" stroke="#e8f4fb" stroke-width="1" fill="none"/>`; })());
    const torch = (x, y, z) => { const [a, b] = P(x, y, z); return `<path d="M${f1(a)} ${f1(b + 3)} v-3" stroke="#3a2412" stroke-width="1"/><circle class="mm-fire" cx="${f1(a)}" cy="${f1(b - 1.2)}" r="1.6" fill="#ff9a3c" stroke="none"/>`; };

    // ---- skały: fasetowana bryła (podstawa + wierzchołki), cieniowana światłem z lewej-góry ----
    const hex2 = (h) => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
    const shade = (h, k) => '#' + hex2(h).map(v => Math.max(0, Math.min(255, Math.round(v * k)))).map(v => v.toString(16).padStart(2, '0')).join('');
    const LIGHT = (() => { const v = [-.45, .35, .82], n = Math.hypot(...v); return v.map(a => a / n); })();
    function facet(a, b, c, col, extra = '') {
        const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
        let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
        const L = Math.hypot(...n) || 1; n = n.map(q => q / L); if (n[0] + n[1] + n[2] * 1.2 < 0) n = n.map(q => -q);
        const k = .52 + .78 * Math.max(0, n[0] * LIGHT[0] + n[1] * LIGHT[1] + n[2] * LIGHT[2]);
        return [(a[0] + b[0] + c[0]) / 3 + (a[1] + b[1] + c[1]) / 3 + (a[2] + b[2] + c[2]) * .02, poly([a, b, c], shade(col, k), `stroke="${shade(col, k)}" stroke-width=".45" ${extra}`)];
    }
    // crag: bryła o podstawie z n punktów wokół (cx,cy) i wierzchołku; snow = ułamek wysokości pokryty śniegiem
    function crag(cx, cy, rx, ry, h, col = '#9a948a', o = {}) {
        const n = o.n || 9, faces = [], basePts = [], ring = [];
        const ax = cx + (o.ax || 0), ay = cy + (o.ay || 0), apex = [ax, ay, h];
        for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2 + (o.rot || 0), j = .82 + rnd() * .3; basePts.push([cx + Math.cos(a) * rx * j, cy + Math.sin(a) * ry * j, 0]); }
        // pierścień pośredni nadaje bryle "ramiona" zamiast gładkiego stożka
        const mid = o.mid ?? .45;
        basePts.forEach(p => ring.push([lerp(p, apex, mid)[0] + (rnd() - .5) * .25, lerp(p, apex, mid)[1] + (rnd() - .5) * .25, h * mid * (.75 + rnd() * .4)]));
        for (let i = 0; i < n; i++) {
            const j = (i + 1) % n;
            faces.push(facet(basePts[i], basePts[j], ring[j], col), facet(basePts[i], ring[j], ring[i], col), facet(ring[i], ring[j], apex, col));
        }
        let out = faces.sort((p, q) => p[0] - q[0]).map(f => f[1]).join('');
        if (o.snow) {
            const sn = [];
            for (let i = 0; i < n; i++) { const j = (i + 1) % n, A = lerp(apex, ring[i], o.snow), B = lerp(apex, ring[j], o.snow); sn.push(facet(A, B, apex, '#ffffff')); }
            out += sn.sort((p, q) => p[0] - q[0]).map(f => f[1]).join('');
        }
        if (o.moss) for (let i = 0; i < 5; i++) { const p = lerp(basePts[(i * 2) % n], ring[(i * 2) % n], .3 + rnd() * .3); const [px, py] = P(...p); out += `<ellipse cx="${f1(px)}" cy="${f1(py)}" rx="${f1(1.4 + rnd() * 1.4)}" ry=".8" fill="#5f8a40" stroke="none" opacity=".7"/>`; }
        return out;
    }
    const pebble = (x, y, s = 1) => at(x, y, crag(x, y, .22 * s, .2 * s, .28 * s, '#8a8378', { n: 6, mid: .5 }));
    function tent(x, y, w, d, h, col = '#c9a86a') {   // namiot: kalenica wzdłuż x, wejście od prawej
        const [, l, r] = MAT[col] || [0, col, shade(col, .7)];
        const A = [x, y + d, 0], B = [x + w, y + d, 0], Cr = [x + w, y + d / 2, h], Dr = [x, y + d / 2, h];
        return poly([[x + w, y, 0], [x + w, y + d, 0], Cr], shade(l, .8)) + poly([[x + w, y + d * .32, 0], [x + w, y + d * .68, 0], [x + w, y + d / 2, h * .6]], '#1a0f06')
            + poly([A, B, Cr, Dr], l) + [.33, .66].map(t => seg(lerp(A, Dr, t), lerp(B, Cr, t), 'rgba(0,0,0,.18)', .5)).join('') + seg(Dr, Cr, '#5a3a1c', .9)
            + seg([x - .15, y + d / 2, h + .2], Dr, '#5a3a1c', 1) + seg([x + w + .15, y + d / 2, h + .2], Cr, '#5a3a1c', 1);
    }
    function campfire(x, y) {
        const [a, b] = P(x, y, 0);
        return at(x, y, [0, 1, 2, 3, 4, 5].map(i => { const t = i / 6 * Math.PI * 2; return `<ellipse cx="${f1(a + Math.cos(t) * 4.2)}" cy="${f1(b + Math.sin(t) * 2.1)}" rx="1.3" ry=".9" fill="#8a8378"/>`; }).join('')
            + `<path d="M${f1(a - 3)} ${f1(b + 1)} l6 -2 M${f1(a - 3)} ${f1(b - 1)} l6 2" stroke="#5a3a1c" stroke-width="1.4"/><path class="mm-fire" d="M${f1(a)} ${f1(b)} c-3 -3.5 -.5 -7 0 -9.5 2 2.5 4 5.5 0 9.5z" fill="#ff8a3a"/><path class="mm-fire" d="M${f1(a)} ${f1(b)} c-1.5 -2 -.5 -4 0 -5.5 1 1.5 2 3 0 5.5z" fill="#ffd36b" stroke="none"/>` + smoke(x, y, 1.2));
    }
    function ship(x, y, s = 1) {   // statek w rzucie izometrycznym, dziób w stronę +x
        const k = s, D = [[-1, -.32], [.55, -.32], [1.1, 0], [.55, .32], [-1, .32]].map(([u, v]) => [x + u * k, y + v * k]);
        const deck = D.map(([u, v]) => [u, v, .38 * k]), bot = D.map(([u, v]) => [x + (u - x) * .8, y + (v - y) * .55, 0]);
        let o = `<ellipse cx="${f1(P(x, y, 0)[0])}" cy="${f1(P(x, y, 0)[1] + 1)}" rx="${f1(16 * k)}" ry="${f1(5 * k)}" fill="rgba(20,50,80,.35)" stroke="none"/>`;
        [[2, 3], [3, 4], [1, 2]].forEach(([i, j]) => { o += poly([bot[i], bot[j], deck[j], deck[i]], i === 3 ? '#7a5230' : '#9a6a3c'); });
        o += poly([bot[4], bot[0], deck[0], deck[4]], '#6b4628');
        o += poly(deck, '#c9a06a') + seg(deck[3], deck[4], '#5a3a1c', .6) + seg(lerp(deck[3], deck[4], 0), lerp(deck[2], deck[2], 0), '#5a3a1c', .6);
        o += [[-.45, 2.2, .5], [.35, 2.6, .62]].map(([u, hh, sw]) => { const mx = x + u * k, my = y, top = hh * k, W = sw * k;
            const sailF = (z1, z2, w2) => poly([[mx, my - w2, z1], [mx, my + w2, z1], [mx + .12 * k, my + w2 * .95, (z1 + z2) / 2], [mx, my + w2, z2], [mx, my - w2, z2], [mx + .12 * k, my - w2 * .95, (z1 + z2) / 2]], '#f3ead6')
                + seg([mx, my - w2, z1], [mx, my + w2, z1], '#5a3a1c', .9);
            return seg([mx, my, .38 * k], [mx, my, top], '#3a2412', 1.4) + sailF(top * .9, top * .6, W) + sailF(top * .56, top * .3, W * 1.2)
                + poly([[mx, my, top], [mx + .45 * k, my, top - .1 * k], [mx, my, top - .22 * k]], '#c0392b'); }).join('');
        o += `<path class="mm-wave" d="M${f1(P(x - 1.1 * k, y, 0)[0])} ${f1(P(x - 1.1 * k, y, 0)[1] + 3)} q-4 2 -9 1 M${f1(P(x - 1.1 * k, y + .3, 0)[0])} ${f1(P(x - 1.1 * k, y + .3, 0)[1] + 3)} q-3 2 -7 2" stroke="#e8f4fb" stroke-width=".9" fill="none"/>`;
        return at(x, y, o);
    }
    const gull = (sx, sy) => `<path d="M${sx - 3} ${sy} q1.5 -2 3 0 q1.5 -2 3 0" stroke="#3a2412" stroke-width=".8" fill="none"/>`;
    // ---- jaskinia i loch: detale ----
    const path2 = (p2, col = '#b59a6c') => `<polygon points="${pts(p2.map(([x, y]) => [x, y, 0]))}" fill="${col}" stroke="none" opacity=".85"/>`;
    function caveHole(x, y, sc = 1) {   // otwór w zboczu: płaski dół na linii gruntu, łuk pochylony ku szczytowi, skalny okap
        const [a, b] = P(x, y, 0), id = 'ch' + Math.floor(rnd() * 1e6), W = 10 * sc, Hh = 15 * sc, lean = -2.5 * sc;
        const arc = (w, h, dy = 0) => `M${f1(a - w)} ${f1(b + dy)} C${f1(a - w * 1.02)} ${f1(b - h * .55)} ${f1(a - w * .6 + lean)} ${f1(b - h)} ${f1(a + lean)} ${f1(b - h)} C${f1(a + w * .6 + lean)} ${f1(b - h)} ${f1(a + w * 1.02)} ${f1(b - h * .5)} ${f1(a + w)} ${f1(b + 1.5 + dy)} Q${f1(a)} ${f1(b + 3.2 + dy)} ${f1(a - w)} ${f1(b + dy)} Z`;
        return `<defs><radialGradient id="${id}" cx=".55" cy=".9" r=".85"><stop offset="0" stop-color="#000"/><stop offset=".6" stop-color="#0e0906"/><stop offset="1" stop-color="#3b322a"/></radialGradient></defs>
            <path d="${arc(W + 3.2, Hh + 3.6, .4)}" fill="#7a746a" stroke="none"/>
            <path d="M${f1(a - W - 3.2)} ${f1(b + .4)} C${f1(a - W - 3.3)} ${f1(b - (Hh + 3.6) * .55)} ${f1(a - (W + 3.2) * .6 + lean)} ${f1(b - Hh - 3.6)} ${f1(a + lean)} ${f1(b - Hh - 3.6)} C${f1(a + (W + 3.2) * .6 + lean)} ${f1(b - Hh - 3.6)} ${f1(a + W + 3.3)} ${f1(b - (Hh + 3.6) * .5)} ${f1(a + W + 3.2)} ${f1(b + 1.9)}" fill="none" stroke="#b9b3a7" stroke-width="1.6" stroke-linecap="round"/>
            <path d="${arc(W, Hh)}" fill="url(#${id})" stroke="#2a1808" stroke-width=".7"/>
            <path d="M${f1(a - W + 1.5)} ${f1(b - Hh * .45)} C${f1(a - W * .55 + lean)} ${f1(b - Hh * .95)} ${f1(a + lean)} ${f1(b - Hh * .95)} ${f1(a + W * .35)} ${f1(b - Hh * .8)}" stroke="rgba(0,0,0,.55)" stroke-width="2.4" fill="none"/>
            <path d="M${f1(a - W - 2)} ${f1(b + 1)} l2.5 -2.6 3 .6 1 2.6z M${f1(a + W - 1.5)} ${f1(b + 2.4)} l2.2 -3 3.2 .8 .4 3z" fill="#8f897e" stroke="#2a1808" stroke-width=".5"/>`;
    }
    function crystal(x, y, s = 1, col = '#7fd8ff') {
        const [a, b] = P(x, y, 0), sh = [[-3, -11, 2.4, -.25], [0, -15, 2.8, 0], [3, -9, 2.2, .3], [-1, -7, 1.8, -.5]];
        let o = `<ellipse class="mm-glow2" cx="${f1(a)}" cy="${f1(b)}" rx="${f1(7 * s)}" ry="${f1(3 * s)}" fill="${col}" opacity=".35" stroke="none"/>`;
        sh.forEach(([dx, h, w, lean]) => { const bx = a + dx * s, tx = bx + lean * 6 * s, ty = b + h * s;
            o += `<path d="M${f1(bx - w * s)} ${f1(b)} L${f1(tx - w * .35 * s)} ${f1(ty + 2 * s)} L${f1(tx)} ${f1(ty)} L${f1(bx)} ${f1(b + .8 * s)} Z" fill="${shade(col, 1.12)}" stroke="#1f3a4a" stroke-width=".45"/>
                  <path d="M${f1(bx)} ${f1(b + .8 * s)} L${f1(tx)} ${f1(ty)} L${f1(tx + w * .45 * s)} ${f1(ty + 2.2 * s)} L${f1(bx + w * s)} ${f1(b)} Z" fill="${shade(col, .72)}" stroke="#1f3a4a" stroke-width=".45"/>`; });
        return at(x, y, o);
    }
    const stalag = (x, y, s = 1) => { const [a, b] = P(x, y, 0); return `<path d="M${f1(a - 2.4 * s)} ${f1(b)} L${f1(a)} ${f1(b - 9 * s)} L${f1(a)} ${f1(b + 1)} Z" fill="#a7a196"/><path d="M${f1(a)} ${f1(b - 9 * s)} L${f1(a + 2.4 * s)} ${f1(b)} L${f1(a)} ${f1(b + 1)} Z" fill="#6f695f"/>`; };
    const bats = (x, y) => `<g class="mm-bat"><path d="M${x} ${y} q-2 -2.5 -5 -1.5 q1.5 .5 1.8 2 q1.2 -1 3.2 -.5z M${x} ${y} q2 -2.5 5 -1.5 q-1.5 .5 -1.8 2 q-1.2 -1 -3.2 -.5z" fill="#1a0f06" stroke="none"/></g>`;
    // wejście do podziemi: zejście schodami w głąb, obramowane murkiem i bramą z kolumn
    // krypta wbudowana w skałę: schody, fasada z tympanonem i uchylone wrota z łuną
    function crypt(x, y, w, d, h) {
        const fy = y + d, cx = x + w / 2;
        let o = box(x - .35, y + .2, 0, w + .7, d + .55, .12, 'stone') + box(x - .2, y + .2, .12, w + .4, d + .38, .12, 'stone') + box(x - .05, y + .2, .24, w + .1, d + .2, .12, 'stone');
        const z0 = .36;
        o += box(x, y, z0, w, d, h, 'dark');
        o += arch(cx - .42, fy, z0, .84, 1.05).replace('#1a0f06', '#0d0805');
        const [ga, gb] = P(cx, fy, z0 + .35);
        o += `<ellipse class="mm-glow2" cx="${f1(ga)}" cy="${f1(gb)}" rx="4" ry="5.5" fill="#ff7a2a" opacity=".5" stroke="none"/>`;
        o += [[x + .08], [x + w - .32]].map(([px]) => box(px, fy, z0, .24, .2, h, 'stone') + box(px - .04, fy - .02, z0 + h - .1, .32, .26, .1, 'stone')).join('');
        o += box(x - .08, y - .04, z0 + h, w + .16, d + .3, .16, 'stone');
        const T0 = [x - .08, fy + .26, z0 + h + .16], T1 = [x + w + .08, fy + .26, z0 + h + .16], TA = [cx, fy + .26, z0 + h + .95];
        o += poly([[x + w + .08, y - .04, z0 + h + .16], T1, TA, [cx, y - .04, z0 + h + .95]], '#5f574b') + poly([T0, T1, TA], '#9a9284');
        const [sa, sb] = P(cx, fy + .26, z0 + h + .42);
        o += `<circle cx="${f1(sa)}" cy="${f1(sb)}" r="2.3" fill="#efe6d2"/><circle cx="${f1(sa - .85)}" cy="${f1(sb - .3)}" r=".55" fill="#2a1808" stroke="none"/><circle cx="${f1(sa + .85)}" cy="${f1(sb - .3)}" r=".55" fill="#2a1808" stroke="none"/><path d="M${f1(sa - 1)} ${f1(sb + 1.4)} h2" stroke="#2a1808" stroke-width=".5"/>`;
        o += torch(x - .2, fy + .45, .95) + torch(x + w + .2, fy + .45, .95) + seg([x - .2, fy + .45, 0], [x - .2, fy + .45, .9], '#3a2412', 1.2) + seg([x + w + .2, fy + .45, 0], [x + w + .2, fy + .45, .9], '#3a2412', 1.2);
        o += seg([x + .2, fy + .2, z0 + h - .15], [x + .45, fy + .2, z0 + .5], '#6b6455', .7) + seg([x + w - .2, fy + .2, z0 + h - .15], [x + w - .45, fy + .2, z0 + .5], '#6b6455', .7);
        return o;
    }
    const MINI = {
        capital: () => { const R = ring(-1.75, -1.75, 1.75, 1.75, 1.05, 'stone', .3, [-.45, .45]);
            return base('cobble', 2.4) + S(T(-1.75, -1.75, .5, 2, 'stone', 'slate'), R.back,
                at(-.2, -.2, box(-.85, -.85, 0, 1.4, 1.4, 2.5, 'plaster') + win(-.45, .55, 1.4) + win(.05, .55, 1.4) + winR(.55, -.5, 1.4) + winR(.55, 0, 1.4) + box(-.9, -.9, 2.5, 1.5, 1.5, .15, 'gold') + pyramid(-.9, -.9, 2.65, 1.5, 1.5, 1.5, 'gold') + flag(-.15, -.15, 4.15, '#d4a537')),
                T(.9, -1, .3, 2.2, 'plaster', 'slate', 1)) + R.front[1] + S(T(1.75, -1.75, .5, 2, 'stone', 'slate'), T(-1.75, 1.75, .5, 2, 'stone', 'slate'), T(1.75, 1.75, .5, 2, 'stone', 'slate')); },
        city: () => { const R = ring(-1.85, -1.85, 1.85, 1.85, .65, 'stone', .25, [-.4, .4]);
            return base('cobble', 2.35) + S(T(-1.85, -1.85, .42, 1.3, 'stone', 'red', 1), R.back,
                H(-1.45, -1.45, 1.15, .95, 1.3, 'plaster', 'red', { chimney: 1 }), H(.15, -1.5, 1.05, 1, 1.75, 'plaster', 'slate', { ridge: 'y' }), H(-1.45, .05, .95, 1.05, 1.05, 'wood', 'red', { ridge: 'y' }),
                T(.75, .7, .38, 2.4, 'stone', 'slate', 1.5), flagAt(.75, .7, 3.9)) + R.front[1] + S(T(1.85, -1.85, .42, 1.3, 'stone', 'red', 1), T(-1.85, 1.85, .42, 1.3, 'stone', 'red', 1), T(1.85, 1.85, .42, 1.3, 'stone', 'red', 1)); },
        town: () => base('grass', 2.1) + path([[-2, -.25], [2, -.25], [2, .2], [-2, .2]]) + path([[-.2, -2], [.2, -2], [.2, 2], [-.2, 2]])
            + S(H(-1.7, -1.6, 1.25, 1.05, 1, 'plaster', 'red', { chimney: 1 }), H(.45, -1.65, 1.15, 1.1, 1.25, 'wood', 'slate', { ridge: 'y' }), H(-1.6, .5, 1.1, 1, .95, 'plaster', 'thatch', { ridge: 'y' }),
                TR(1.15, 1, .75, 'oak'), BU(.6, .6, .8), BA(-.45, 1.5), BA(-.6, 1.75), TR(1.6, .35, .55, 'pine')),
        village: () => base('grass', 2.05) + path([[-.15, -2], [.25, -2], [.35, 2], [-.05, 2]])
            + S(H(-1.6, -1.45, 1.25, 1.05, .85, 'wood', 'thatch', { chimney: 1 }), H(.55, .1, 1.1, 1, .8, 'plaster', 'thatch', { ridge: 'y' }), TR(1.2, -1.3, .85, 'pine'), TR(.75, -.6, .6, 'oak'),
                FE(-1.7, .35, -.5, .35), FE(-1.7, .35, -1.7, 1.6), hay(-1.1, 1.05, .9), BU(-.8, 1.7, .7), TR(1.5, 1.5, .6, 'oak')),
        market: () => base('cobble', 2.1) + S(stall(-1.6, -1.55, 'red'), stall(.4, -1.6, 'teal'), stall(-1.6, .45, 'gold'), fountain(.6, .55), CR(1.45, -.35), CR(1.55, -.05), BA(-.3, 1.5), BA(-.05, 1.7), CR(-.6, -.4)),
        tavern: () => base('dirt', 2.15) + S(
                at(-.1, -.3, box(-1.45, -1.3, 0, 2.5, 1.9, 1, 'stone') + box(-1.45, -1.3, 1, 2.5, 1.9, .85, 'plaster') + door(-.5, .6, 0, .85, .55) + win(-1.15, .6, .4, .32) + win(.5, .6, .4, .32)
                    + win(-1.1, .6, 1.3, .3) + win(-.35, .6, 1.3, .3) + win(.5, .6, 1.3, .3) + winR(1.05, -1, .4, .32) + winR(1.05, -.2, .4, .32) + winR(1.05, -.9, 1.3, .3) + winR(1.05, -.1, 1.3, .3)
                    + gable(-1.45, -1.3, 1.85, 2.5, 1.9, 1.2, 'red', 'plaster') + chimney(.55, -1.05, 2.4, 1.4) + smoke(.7, -.9, 3.9)),
                BA(-1.75, .95), BA(-1.55, 1.25), TR(1.55, -1.2, .65, 'oak'),
                at(1.4, 1.1, seg([1.45, 1.05, 0], [1.45, 1.05, 1.35], '#3a2412', 1.3) + seg([1.45, 1.05, 1.3], [1.45, .65, 1.3], '#3a2412', 1) + poly([[1.45, .7, 1.25], [1.45, 1, 1.25], [1.45, 1, .85], [1.45, .7, .85]], '#e9c46a') + torch(1.2, .65, 1.1)),
                BU(.4, 1.5, .8)),
        guild: () => base('cobble', 2.1) + S(
                at(0, -.2, box(-1.2, -1.5, 0, 2.2, 2.4, 1.7, 'stone') + arch(-.35, .9, 0, .7, 1.1) + poly([[-.95, .9, .5], [-.65, .9, .5], [-.65, .9, 1.5], [-.95, .9, 1.5]], '#2e86c1') + poly([[.35, .9, .5], [.65, .9, .5], [.65, .9, 1.5], [.35, .9, 1.5]], '#2e86c1')
                    + winR(1, -1.2, .8, .32) + winR(1, -.5, .8, .32) + winR(1, .2, .8, .32) + gableY(-1.2, -1.5, 1.7, 2.2, 2.4, 1.3, 'slate', 'stone') + flag(-.1, .9, 3, '#2e86c1')),
                BU(-1.6, 1.3, .8), BU(1.5, 1.2, .8), BA(1.5, -1.5)),
        fortress: () => { const R = ring(-1.95, -1.95, 1.95, 1.95, 1.1, 'dark', .35, [-.45, .45]);
            return base('rock', 2.45) + S(sqTower(-2.2, -2.2, .8, 1.8, 'dark'), R.back,
                at(0, 0, box(-.85, -.85, 0, 1.7, 1.7, 2.6, 'stone') + crenels(-.85, -.85, 2.6, 1.7, 1.7, 'stone') + win(-.45, .85, 1.7, .25) + win(.25, .85, 1.7, .25) + winR(.85, -.4, 1.7, .25) + flag(0, 0, 2.9, '#7a2a1f')),
                ) + R.front[1] + S(sqTower(1.4, -2.2, .8, 1.8, 'dark'), sqTower(-2.2, 1.4, .8, 1.8, 'dark'), sqTower(1.4, 1.4, .8, 1.8, 'dark')); },
        castle: () => { const R = ring(-1.65, -1.65, 1.65, 1.65, 1, 'stone', .3, [-.4, .4]);
            return base('grass', 2.35) + S(T(-1.65, -1.65, .45, 1.8, 'stone', 'red', 1.1), R.back,
                at(-.4, -.5, box(-1.05, -1.15, 0, 1.3, 1.3, 2.3, 'stone') + win(-.6, .15, 1.5) + winR(.25, -.7, 1.5) + pyramid(-1.12, -1.22, 2.3, 1.44, 1.44, 1.2, 'slate') + flag(-.4, -.5, 3.5)),
                T(.75, .55, .36, 2.5, 'stone', 'red', 1.3),
                ) + R.front[1] + S(T(1.65, -1.65, .45, 1.8, 'stone', 'red', 1.1), T(-1.65, 1.65, .45, 1.8, 'stone', 'red', 1.1), T(1.65, 1.65, .45, 1.8, 'stone', 'red', 1.1), TR(2.05, -.3, .5, 'pine')); },
        ruin: () => base('dirt', 2.05) + S(at(-1.4, -1.2, box(-1.6, -1.6, 0, .4, 2.4, 1.5, 'dark') + box(-1.6, -1.6, 1.5, .4, .9, .45, 'dark') + box(-1.2, -1.6, 0, 1.9, .4, 1.1, 'dark') + box(-.3, -1.6, 1.1, .6, .4, .4, 'dark')),
                at(.75, -1.1, box(.6, -1.2, 0, .45, .45, 2, 'stone') + box(.55, -1.25, 2, .55, .55, .15, 'stone')), at(1.2, .3, box(1.05, .2, 0, .4, .4, .9, 'stone')),
                at(-.3, .4, box(-.5, .3, 0, .9, .3, .22, 'rock') + box(-.2, .1, 0, .35, .25, .15, 'rock')), BU(-.6, -.6, .9), TR(1.4, 1.3, .6, 'oak'), at(-1.2, 1.2, box(-1.4, 1, 0, .6, .4, .5, 'dark'))),
        hideout: () => base('dirt', 2.15) + S(TR(-1.7, -1.1, .85, 'pine'), TR(-.9, -1.75, .8, 'pine'), TR(.4, -1.85, .75, 'pine'),
                [[-1.5, .3], [-1.55, .6], [-1.58, .9], [-1.55, 1.2], [-1.45, 1.5]].map(([x, y]) => at(x - .01, y, seg([x, y, 0], [x, y, .75 + rnd() * .2], '#7d5a33', 2.2) + seg([x, y, .85], [x, y, 1.02], '#e3c48e', 1.4))),
                at(-.5, -.6, box(-1.1, -1.1, 0, 1.1, 1, .7, 'wood') + door(-.75, -.1, 0, .6, .35) + gable(-1.1, -1.1, .7, 1.1, 1, .55, 'thatch', 'wood')),
                at(.95, -.55, tent(.35, -.95, 1.15, .8, .85, 'red')), campfire(.35, .75), CR(1.4, .55), CR(1.55, .85), BA(-.6, .55),
                TR(1.6, 1.2, .7, 'oak'), BU(-.9, 1.5, .8), BU(.5, 1.75, .7), at(1.1, -1.3, seg([1.1, -1.3, 0], [1.1, -1.3, 1.6], '#5a3a1c', 1) + (() => { const [a, b] = P(1.1, -1.3, 1.6); return `<path class="mm-flag" d="M${f1(a)} ${f1(b)} q5 -1 9 1 q-4 1.5 -9 4z" fill="#2a1808"/><circle cx="${f1(a + 4)}" cy="${f1(b + 1.6)}" r="1" fill="#e9e4da" stroke="none"/>`; })())),
        mountain: () => base('rock', 2.2) + S(at(-1.1, -1.2, crag(-.55, -.6, 1.55, 1.35, 4.3, '#a39d91', { snow: .55, ax: .1 })), at(.9, -.6, crag(1.05, -.25, 1.05, 1, 2.9, '#968f83', { snow: .5 })), at(-.7, .7, crag(-1.1, .6, .85, .8, 1.7, '#8a8378')),
                TR(.9, 1.35, .5, 'pine'), TR(1.4, .95, .45, 'pine'), TR(.4, 1.75, .42, 'pine'),
                at(5, 5, gull(-18, -50) + gull(-8, -56))),
        sea: () => base('water', 2.2) + S(at(-1.3, -1.3, crag(-1.3, -1.2, .6, .55, 1.1, '#8a8378', { n: 7, moss: 1 }) + crag(-.75, -1.55, .35, .3, .55, '#8a8378', { n: 6 })),
                ship(.35, .15, 1.12),
                at(1.2, 1.3, (() => { const [a, b] = P(-1, 1.2, 0); return `<path d="M${f1(a - 6)} ${f1(b)} q3 -7 6 0 M${f1(a + 2)} ${f1(b + 1)} q3 -6 6 0" stroke="#3f7a5a" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M${f1(a + 10)} ${f1(b + 1)} q2 -6 5 -6 q2 0 2 2" stroke="#3f7a5a" stroke-width="2.2" fill="none" stroke-linecap="round"/><circle cx="${f1(a + 16)}" cy="${f1(b - 4.6)}" r=".55" fill="#ffd36b" stroke="none"/>`; })()),
                at(1.5, 1.5, `<path class="mm-wave" d="M6 12 q3 -2 6 0 t6 0 M-24 -4 q3 -2 6 0 t6 0" stroke="#e8f4fb" stroke-width="1" fill="none"/>`), at(5, 5, gull(-14, -44) + gull(-6, -48))),
        cave: () => base('rock', 2.2) + S(
                at(-.4, -2.2, crag(1, -1.3, 1, .9, 2.7, '#8f897e', { snow: .4 })), at(-.5, -.5, crag(-.45, -.35, 1.75, 1.5, 3.7, '#9a948a', { ax: -.3, ay: -.4, mid: .4, snow: .32 }) + caveHole(.62, .62, .85)),
                pebble(1.55, .55, .9), pebble(-1.35, 1.05, .8), pebble(1.05, 1.45, .55)),
        dungeon: () => base('grass', 2.15) + path([[-.4, .9], [.4, .9], [.55, 2.2], [-.55, 2.2]], '#b8ad97') + S(at(0, 0, crypt(-1, -1, 2, 1.25, 1.6)), BU(-1.55, .8, .7), BU(1.5, .9, .7)),
        forest: () => base('grass', 2.1) + S([[-1, -1.3, 1, 'pine'], [.7, -1.2, .95, 'oak'], [-.2, -.5, 1.1, 'pine'], [-1.5, .3, .85, 'oak'], [1.3, .1, .8, 'pine'], [.3, .5, 1.15, 'oak'], [-.7, 1.2, .8, 'pine'], [1.2, 1.3, .7, 'oak'], [-1.6, -.6, .7, 'pine']].map(([x, y, s2, k]) => TR(x, y, s2, k)), BU(.9, -.4, .7), BU(-.1, 1.6, .7)),
        wilderness: () => base('grass', 2.05) + S(TR(-1.2, -1.2, .75, 'pine'), at(1, -.8, box(.8, -1, 0, .5, .4, .25, 'rock')), BU(.1, -.6), at(-.6, .55, box(-.9, .3, 0, .6, .5, .35, 'rock')), BU(-1.4, 1), TR(1.3, .7, .65, 'oak'), BU(.4, 1.3, .9),
                at(-3, -3, (() => { const [a, b] = P(.3, .2, 0); return `<path d="M${f1(a - 14)} ${f1(b - 4)} q6 -3 10 0 t10 1 t12 -2" stroke="#86bde0" stroke-width="2.4" fill="none" stroke-linecap="round"/>`; })())),
        temple: () => base('stone', 2.3) + S(at(-9, -9, box(-1.95, -1.95, 0, 3.9, 3.9, .25, 'stone') + box(-1.75, -1.75, .25, 3.5, 3.5, .2, 'stone') + box(-1.25, -1.25, .45, 2.3, 2.3, 1.4, 'plaster') + door(-.3, 1.05, .45, .8, .6)),
                [-1.5, -.65, .2, 1.05].map(i => [at(i + 1.4, i, box(i, 1.3, .45, .26, .26, 1.4, 'stone')), at(1.4 + i, i - .01, box(1.3, i, .45, .26, .26, 1.4, 'stone'))]).flat(), at(1.4, 1.4, box(1.3, 1.3, .45, .26, .26, 1.4, 'stone')),
                at(9, 9, box(-1.6, -1.6, 1.85, 3.2, 3.2, .25, 'plaster') + pyramid(-1.65, -1.65, 2.1, 3.3, 3.3, 1.15, 'gold') + (() => { const [a, b] = P(0, 0, 3.25); return `<circle cx="${f1(a)}" cy="${f1(b - 3)}" r="3" fill="#f6d77a"/><circle class="mm-glow2" cx="${f1(a)}" cy="${f1(b - 3)}" r="5" fill="none" stroke="#f6d77a" stroke-width=".6" opacity=".7"/>`; })())),
        plane: () => base('purple', 1.95) + S(at(-.8, 0, box(-1.3, -.3, 0, .5, .5, .3, 'stone')), at(1.1, .2, box(.8, -.3, 0, .5, .5, .3, 'stone')), at(0, 0, `<ellipse cx="0" cy="-19" rx="14" ry="20" fill="none" stroke="#5a3a7a" stroke-width="5"/><ellipse cx="0" cy="-19" rx="14" ry="20" fill="none" stroke="#c9a6ff" stroke-width="2.6"/>
            <ellipse class="mm-glow" cx="0" cy="-19" rx="10" ry="15.5" fill="#3a1f63"/><ellipse cx="0" cy="-19" rx="6" ry="10" fill="#6a3fa8" opacity=".7" stroke="none"/>
            <g class="mm-spin"><path d="M0 -27 c7 2 7 12 0 14 s-7 -10 0 -7" fill="none" stroke="#f0e4ff" stroke-width="1.6"/></g>
            <path d="M-18 -38 l2 4 4 2 -4 2 -2 4 -2 -4 -4 -2 4 -2zM18 -32 l1.5 3 3 1.5 -3 1.5 -1.5 3 -1.5 -3 -3 -1.5 3 -1.5z" fill="#f6d77a"/>`)),
        other: () => base('grass', 1.95) + S(at(-1.2, .8, box(-1.4, .6, 0, .4, .4, .9, 'rock')), at(0, 0, box(-.35, -.35, 0, .7, .7, 2.4, 'stone') + pyramid(-.35, -.35, 2.4, .7, .7, .55, 'stone')), at(1.1, -1.1, box(.9, -1.3, 0, .4, .4, 1.1, 'rock')), at(-1, -1, box(-1.2, -1.2, 0, .4, .4, 1.3, 'rock')), at(1.05, .9, box(.85, .7, 0, .4, .4, .8, 'rock')), BU(.9, -.2, .7)),
        // ---- mapa miasta / regionu ----
        house: () => base('grass', 1.85) + path([[-.15, .7], [.25, .7], [.5, 1.9], [.1, 1.9]]) + S(TR(-1.3, -1.45, .7, 'oak'), H(-1.15, -1.05, 1.9, 1.7, 1.15, 'plaster', 'red', { chimney: 1 }), FE(-1.55, 1.2, -.2, 1.2), FE(.6, 1.2, 1.35, 1.2), BU(1.4, .3, .75), BA(1, .9)),
        manor: () => base('grass', 2.35) + path([[-.3, .9], [.3, .9], [.4, 2.2], [-.2, 2.2]]) + S(TR(-1.9, -1.7, .7, 'pine'), TR(1.6, -1.8, .65, 'oak'),
                H(-1.75, -1.35, 3.3, 1.7, 1.55, 'plaster', 'slate', { ridge: 'hip', rh: 1.1 }), at(-.9, -.6, chimney(-1.25, -1, 2.3, .9)), at(1.3, -.6, chimney(1.05, -1, 2.3, .9)),
                at(.05, .65, box(-.5, .35, 0, 1, .55, 1.75, 'stone') + door(-.2, .9, 0, .85, .4) + win(-.15, .9, 1.1, .3) + gableY(-.5, .35, 1.75, 1, .55, .6, 'slate', 'stone')),
                BU(-1.2, .8, .8), BU(1.3, .8, .8), TR(-1.95, 1.4, .55, 'oak'), TR(1.95, 1.2, .55, 'oak')),
        palace: () => base('cobble', 2.45) + path([[-.35, 1.2], [.35, 1.2], [.35, 2.3], [-.35, 2.3]], '#ece4d2') + S(
                at(0, -.2, box(-1.9, -1.4, 0, 3.8, 2.2, 1.35, 'plaster') + [-1.6, -1, .6, 1.2].map(x => win(x, .8, .35, .28) + win(x, .8, .85, .28)).join('') + [-1.1, -.4, .3].map(y => winR(1.9, y, .6, .28)).join('') + door(-.35, .8, 0, 1, .7)
                    + box(-1.95, -1.45, 1.35, 3.9, 2.3, .18, 'gold') + box(-.8, -.85, 1.53, 1.6, 1.6, 1, 'plaster') + win(-.3, .75, 1.8) + tower(0, -.05, 2.53, .72, .45, 'plaster', 'gold', 1.6)),
                T(-1.9, .8, .42, 2.3, 'plaster', 'gold', 1.3), T(1.9, .8, .42, 2.3, 'plaster', 'gold', 1.3), fountain(0, 1.75, .4), BU(-1.2, 1.7, .7), BU(1.2, 1.7, .7)),
        tower: () => base('grass', 1.75) + S(at(-.8, -.6, box(-1.35, -.9, 0, .8, .9, .8, 'stone') + gable(-1.35, -.9, .8, .8, .9, .5, 'slate', 'stone')), at(0, 0, tower(0, 0, 0, .8, 3.8, 'stone', 'slate', 2.1) + door(.35, .72, 0, .8, .4)), BU(1, 1, .8), at(-1, 1, box(-1.2, .8, 0, .4, .3, .2, 'rock'))),
        gate: () => base('cobble', 2.25) + path([[-.45, -2.2], [.45, -2.2], [.45, 2.2], [-.45, 2.2]], '#c9ad7c') + S(
                at(-1.75, 0, box(-2.15, -.3, 0, .9, .6, 1.05, 'stone') + crenels(-2.15, -.3, 1.05, .9, .6, 'stone')),
                sqTower(-1.25, -.5, .65, 2, 'stone', 'red'),
                at(0, 0, box(-.6, -.38, 0, 1.2, .76, 1.55, 'stone') + crenels(-.6, -.38, 1.55, 1.2, .76, 'stone') + arch(-.36, .38, 0, .72, 1.1) + portcullis(-.36, .38, 0, .72, 1.1)),
                sqTower(.6, -.5, .65, 2, 'stone', 'red'),
                at(1.75, 0, box(1.25, -.3, 0, .9, .6, 1.05, 'stone') + crenels(1.25, -.3, 1.05, .9, .6, 'stone')),
                flagAt(-.92, -.17, 2.75, '#c0392b'), flagAt(.93, -.17, 2.75, '#c0392b'), at(-.5, 1.2, torch(-.5, .55, .9) + torch(.5, .55, .9))),
        barracks: () => base('dirt', 2.35) + S(H(-1.85, -1.5, 3.3, 1.3, 1, 'wood', 'slate', { chimney: 1 }),
                at(-.9, .9, box(-1.3, .55, 0, .9, .2, .1, 'wood') + seg([-1.25, .65, 0], [-1.25, .65, .7], '#5a3a1c', 1) + seg([-.45, .65, 0], [-.45, .65, .7], '#5a3a1c', 1) + seg([-1.3, .65, .7], [-.4, .65, .7], '#5a3a1c', 1)
                    + [-1.1, -.9, -.7].map(x => seg([x, .66, .05], [x + .08, .64, .85], '#9aa3ad', .9)).join('')),
                at(.9, .9, (() => { const [a, b] = P(.9, .9, 0); return `<path d="M${f1(a)} ${f1(b)} v-13 M${f1(a - 4)} ${f1(b - 9)} h8" stroke="#5a3a1c" stroke-width="1.4"/><ellipse cx="${f1(a)}" cy="${f1(b - 11)}" rx="2.6" ry="3.2" fill="#c9a86a"/><circle cx="${f1(a)}" cy="${f1(b - 15.5)}" r="1.8" fill="#c9a86a"/>`; })()),
                FE(-2, 1.45, 1.6, 1.45), CR(1.5, .2)),
        smithy: () => base('dirt', 2.05) + S(
                at(-.6, -.5, box(-1.6, -1.4, 0, 1.9, 1.7, 1.1, 'stone') + door(-1.2, .3, 0, .8, .5) + win(-.4, .3, .45, .3) + gable(-1.6, -1.4, 1.1, 1.9, 1.7, .75, 'slate', 'stone') + chimney(-.3, -1.1, 1.3, 1.5) + smoke(-.15, -.95, 2.9)),
                at(.9, -.3, [[.4, .45], [1.5, .45], [1.5, -1.1]].map(([x, y]) => seg([x, y, 0], [x, y, 1], '#5a3a1c', 1.2)).join('') + poly([[.3, -1.2, 1.15], [1.6, -1.2, .95], [1.6, .55, .95], [.3, .55, 1.15]], '#7d6c58') + shingles([1.6, .55, .95], [.3, .55, 1.15], [.3, -1.2, 1.15], [1.6, -1.2, .95], 4, 'rgba(0,0,0,.2)')
                    + box(.5, -.9, 0, .6, .6, .5, 'stone') + (() => { const [a, b] = P(.8, -.3, .5); return `<ellipse class="mm-fire" cx="${f1(a)}" cy="${f1(b)}" rx="3" ry="1.5" fill="#ff8a3a" stroke="none"/>`; })()),
                at(.8, 1.1, box(.65, .95, 0, .3, .3, .35, 'dark') + box(.55, 1, .35, .5, .2, .12, 'dark')), BA(-1.3, 1.1), CR(1.4, 1.1)),
        shop: () => base('cobble', 1.9) + S(at(0, 0, box(-1.2, -1.1, 0, 2.1, 1.8, 1.3, 'plaster') + gable(-1.2, -1.1, 1.3, 2.1, 1.8, .8, 'red', 'plaster') + door(.3, .7, 0, .8, .45) + win(-.95, .7, .3, .55) + winR(.9, -.6, .55, .35)
                    + awning(-1.25, .7, 1.02, 1.35, .45, -.3, 'teal')), CR(1.25, 1), BA(-1.45, 1.1), BU(1.3, -1.1, .7)),
        docks: () => base('water', 2.2) + S(at(-9, -9, box(-1.4, -1.95, -.25, 2.6, 1.05, .45, 'sand')), CR(-1.25, -1.2), BA(.75, -1.25), at(-.4, -1.5, box(-.5, -1.85, .2, 1, .6, .7, 'wood') + door(-.2, -1.25, .2, .5, .3) + gable(-.5, -1.85, .9, 1, .6, .4, 'red', 'wood')),
                at(0, 0, box(-.35, -.9, 0, .7, 2.5, .15, 'wood') + [-.5, .3, 1.1, 1.5].map(y => seg([-.35, y, -.35], [-.35, y, .15], '#5a3a1c', 1.2) + seg([.35, y, -.35], [.35, y, .15], '#5a3a1c', 1.2)).join('')),
                at(1.6, .4, sailP(1.6, .1, .75)), at(-1.2, 1, `<path class="mm-wave" d="M-26 10 q3 -2 6 0 t6 0" stroke="#e8f4fb" stroke-width="1" fill="none"/>`)),
        mill: () => base('grass', 2) + S(at(-1.3, -1.3, box(-2, -2, 0, 1.5, 1.4, .1, 'thatch') + [0, 1, 2].map(i => seg([-2, -1.75 + i * .45, .11], [-.5, -1.75 + i * .45, .11], '#8c6f2c', .7)).join('')),
                at(0, 0, tower(0, 0, 0, .8, 2.1, 'stone', 'thatch', 1.1) + door(.3, .73, 0, .7, .38) + (() => { const [a, b] = P(.55, .55, 1.85);
                    return `<g transform="translate(${f1(a)} ${f1(b)})"><g class="mm-spin"><path d="M0 0 L-15 -15 M0 0 L15 -15 M0 0 L-15 15 M0 0 L15 15" stroke="#3a2412" stroke-width="1.8"/><path d="M-15 -15 l4 -1 7 9z M15 -15 l1 4 -9 7z M15 15 l-4 1 -7 -9z M-15 15 l-1 -4 9 -7z" fill="#f3ead6"/></g><circle r="2" fill="#5a3a1c"/></g>`; })()),
                FE(-1.7, 1.2, -.6, 1.6), at(1.2, 1, box(1, .9, 0, .3, .25, .3, 'thatch') + box(1.35, 1.05, 0, .3, .25, .25, 'thatch')), BU(1.5, -.6, .7)),
        farm: () => base('grass', 2.25) + S(at(-1.2, -1.2, box(-2, -2, 0, 1.7, 1.7, .1, 'thatch') + Array.from({ length: 4 }, (_, i) => seg([-2, -1.8 + i * .42, .11], [-.3, -1.8 + i * .42, .11], '#8c6f2c', .8)).join('')),
                H(.2, -1.8, 1.4, 1.1, 1, 'wood', 'red', { ridge: 'y', rh: .8 }), H(-1.6, .2, 1.5, 1.1, .95, 'plaster', 'thatch', { chimney: 1 }), hay(.75, .55, .9),
                FE(-1.9, 1.75, .9, 1.75), TR(1.6, 1.3, .6, 'oak'), at(.5, 1.1, (() => { const [a, b] = P(.4, 1.1, 0); return `<ellipse cx="${f1(a)}" cy="${f1(b - 2)}" rx="3" ry="2" fill="#f2f2f2"/><circle cx="${f1(a + 3)}" cy="${f1(b - 3)}" r="1.3" fill="#3a2412"/>`; })())),
        well: () => base('cobble', 1.6) + S(BA(-1.1, -.6), at(0, 0, tower(0, 0, 0, .8, .7, 'stone', null) + `<ellipse cx="0" cy="-7" rx="7" ry="3.5" fill="#3f6f91"/><path d="M-9 -6 v-15 M9 -6 v-15" stroke="#5a3a1c" stroke-width="2"/><path d="M-9 -16 h18" stroke="#5a3a1c" stroke-width="1.2"/><path d="M0 -16 v6" stroke="#3a2412" stroke-width=".6"/><rect x="-1.8" y="-11" width="3.6" height="3" fill="#8a6239"/><path d="M-13 -20 L0 -28 L13 -20 L0 -17 Z" fill="#b44a35"/><path d="M0 -28 L13 -20 L0 -17 Z" fill="#863224"/>`), BU(1.1, .9, .7), CR(-1.2, .7)),
        shrine: () => base('grass', 1.7) + S(TR(-1.2, -1.3, .7, 'oak'), at(0, 0, box(-.8, -.8, 0, 1.6, 1.6, .2, 'stone') + box(-.6, -.6, .2, 1.2, 1.2, 1.05, 'plaster') + pyramid(-.75, -.75, 1.25, 1.5, 1.5, .95, 'gold') + door(-.2, .6, .2, .7, .4)
                    + (() => { const [cx, cy] = P(0, 0, 2.2); return `<path d="M${f1(cx)} ${f1(cy)} v-9 M${f1(cx - 3)} ${f1(cy - 6)} h6" stroke="#9c7616" stroke-width="1.6"/>`; })()),
                at(1, 1.1, (() => { const [a, b] = P(1, 1.1, 0); return `<rect x="${f1(a - 1)}" y="${f1(b - 4)}" width="2" height="3" fill="#f6efe0"/><circle class="mm-fire" cx="${f1(a)}" cy="${f1(b - 5)}" r="1.1" fill="#ffb347" stroke="none"/>`; })()), BU(-1.1, 1, .7)),
        graveyard: () => base('grass', 2.1) + S(TR(-1.5, -1.5, .8, 'oak'), [[-1.1, -.9], [.3, -1.3], [-1.2, .3], [.3, -.1], [1.2, -.7], [-.4, .9]].map(([x, y], k) => at(x, y, k % 2 ? box(x, y, 0, .45, .18, .7, 'rock') + poly([[x, y + .18, .7], [x + .45, y + .18, .7], [x + .225, y + .18, .85]], '#8a8378') : box(x + .18, y, 0, .1, .1, .8, 'rock') + box(x, y, .5, .45, .1, .1, 'rock'))),
                FE(-1.9, 1.65, 1.65, 1.65), FE(1.65, -1.6, 1.65, 1.65), at(1, 1, (() => { const [a, b] = P(.9, .9, 0); return `<path d="M${f1(a)} ${f1(b)} c-2 -6 2 -8 0 -12" stroke="#cfd8dc" stroke-width="1.5" fill="none" opacity=".5"/>`; })())),
        bridge: () => base('water', 2.15) + S(at(-1.8, 0, box(-2.15, -.6, -.3, .55, 1.2, .7, 'grass')), at(-.05, -.05, box(-.25, -.5, -.45, .5, 1, .75, 'stone')),
                at(0, 0, box(-2, -.5, .3, 4, 1, .15, 'stone') + box(-2, -.5, .45, 4, .12, .25, 'stone')), at(1.85, 0, box(1.6, -.6, -.3, .55, 1.2, .7, 'grass')), at(.1, .5, box(-2, .38, .45, 4, .12, .25, 'stone')),
                at(1.5, 1.5, `<path class="mm-wave" d="M-20 12 q3 -2 6 0 t6 0 M8 -8 q3 -2 6 0 t6 0" stroke="#e8f4fb" stroke-width="1" fill="none"/>`)),
        camp: () => base('dirt', 1.95) + S(TR(1.3, -1.4, .7, 'pine'), at(-.5, -.5, `<path d="M-24 4 L-9 -19 L4 4 Z" fill="#d6b77a"/><path d="M-9 -19 L4 4 L-6 9 Z" fill="#9c7d3d"/><path d="M-11 4 L-8 -6 L-5 4 Z" fill="#3a2412"/>`), at(.6, -.3, `<path d="M5 1 L15 -13 L24 1 Z" fill="#a85a32"/><path d="M15 -13 L24 1 L15 6 Z" fill="#6b3218"/>`),
                at(.8, .8, `<path d="M6 12 l10 -4 M6 8 l10 4" stroke="#5a3a1c" stroke-width="1.6"/><path class="mm-fire" d="M11 9 c-4 -4 -1 -9 0 -12 2 3 5 6 0 12z" fill="#ff8a3a"/><path class="mm-fire" d="M11 9 c-2 -2 -1 -5 0 -7 1 2 3 4 0 7z" fill="#ffd36b" stroke="none"/>` + smoke(.6, .55, 1.6)), CR(-1.2, 1.1), at(-.2, 1.5, box(-.6, 1.3, 0, .8, .25, .2, 'wood')))
    };
    function miniSvg(k) {
        const f = MINI[k] || MINI.other;
        seedRnd(hash('mm' + k));
        return `<svg class="mm" viewBox="-48 -82 96 110" aria-hidden="true"><g stroke="#2a1808" stroke-width=".6" stroke-linejoin="round">${f()}</g></svg>`;
    }
    // makiety: modele 3D (js/models3d.js) — dopóki model się renderuje, widać rysunek SVG
    const models3d = () => window.Models3D && Models3D.supported();   // rysunki tylko gdy przeglądarka nie obsługuje 3D
    function mini(t) {
        const k = typeOf(t);
        if (models3d()) {
            const h = Models3D.cached(k);
            if (h) return h;
            Models3D.enqueue(k);
            return `<span class="mm-wait" data-m3="${k}">${miniSvg(k)}</span>`;
        }
        return miniSvg(k);
    }

    // ---------- trakty: łagodnie wygięte, z obramowaniem jak na starych mapach ----------
    function hash(s) { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return h; }
    function routes(list) {
        let casing = '', inner = '';
        list.forEach(({ a, b, style, key }) => {
            const dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy) || 1;
            const bend = (hash(key || `${a.x}${a.y}${b.x}${b.y}`) % 2 ? 1 : -1) * Math.min(6, len * 0.12);
            const mx = (a.x + b.x) / 2 - dy / len * bend, my = (a.y + b.y) / 2 + dx / len * bend;
            const d = `M${a.x} ${a.y} Q${mx.toFixed(2)} ${my.toFixed(2)} ${b.x} ${b.y}`;
            casing += `<path class="rt-case rc-${style}" d="${d}" vector-effect="non-scaling-stroke"/>`;
            inner += `<path class="atl-route rt r-${style}" d="${d}" vector-effect="non-scaling-stroke"/>`;
        });
        return casing + inner;
    }

    // ping na mapie: rozchodzące się kręgi w kolorze gracza + podpis (x, y w % mapy)
    function ping(mapEl, p) {
        if (!mapEl || !p) return;
        const el = document.createElement('div');
        el.className = `map-ping ${p.rola === 'mg' ? 'by-mg' : ''}`;
        el.style.cssText = `left:${p.x}%;top:${p.y}%;--pc:${p.color || '#e9c46a'}`;
        const who = String(p.kto || '').replace(/[&<>"']/g, '');
        el.innerHTML = `<i></i><i></i><i></i><span class="map-ping-dot"></span>${who ? `<b>${who}</b>` : ''}`;
        mapEl.appendChild(el);
        setTimeout(() => el.classList.add('out'), 2800);
        setTimeout(() => el.remove(), 3300);
    }
    return { svg, pin, banner, mini, shield, routes, ping, CAT, SCOPE, PALETTE, typeOf, MAJOR };
})();
window.MapEmblems = MapEmblems;
