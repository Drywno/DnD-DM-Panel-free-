/* ============================================
   Obrazki postaci: wybór pliku, przycięcie do kwadratu, zmniejszenie
   i wspólny znacznik (obrazek albo litera, gdy go nie ma).
   ============================================ */
const Portrait = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const SIZE = 256;
    // plik → kwadrat 256×256 JPEG (środek obrazka), ~20–40 KB
    function fromFile(file) {
        return new Promise((resolve, reject) => {
            if (!file || !/^image\//.test(file.type)) return reject(new Error('To nie jest obrazek.'));
            const rd = new FileReader();
            rd.onerror = () => reject(new Error('Nie udało się wczytać pliku.'));
            rd.onload = () => {
                const img = new Image();
                img.onerror = () => reject(new Error('Nie udało się odczytać obrazka.'));
                img.onload = () => {
                    const s = Math.min(img.naturalWidth, img.naturalHeight);
                    const cv = document.createElement('canvas'); cv.width = cv.height = SIZE;
                    const g = cv.getContext('2d');
                    g.fillStyle = '#1a120b'; g.fillRect(0, 0, SIZE, SIZE);
                    // lekko wyżej niż środek — twarze są zwykle w górnej części
                    const sx = (img.naturalWidth - s) / 2, sy = Math.max(0, (img.naturalHeight - s) * 0.3);
                    g.drawImage(img, sx, sy, s, s, 0, 0, SIZE, SIZE);
                    resolve(cv.toDataURL('image/jpeg', 0.86));
                };
                img.src = rd.result;
            };
            rd.readAsDataURL(file);
        });
    }
    function pick() {
        return new Promise((resolve) => {
            const inp = document.createElement('input');
            inp.type = 'file'; inp.accept = 'image/*';
            inp.onchange = async () => {
                try { resolve(await fromFile(inp.files[0])); }
                catch (e) { window.App?.showToast?.(e.message, 'error'); resolve(null); }
            };
            inp.click();
        });
    }
    const letter = (name) => esc(String(name || '?').replace(/\s*\d+$/, '').trim().charAt(0).toUpperCase() || '?');
    const initials = (name) => esc(String(name || '?').replace(/\s*\d+$/, '').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase() || '?');
    // obrazek nad literą: jeśli się nie wczyta, zostaje litera
    const img = (src) => src ? `<img class="pt-img" src="${esc(src)}" alt="" loading="lazy" draggable="false" onerror="this.remove()">` : '';
    // adres obrazka z serwera (dla gracza i dla wpisów w dzienniku)
    const url = (charId, v, campaign) => charId ? `/api/portret?c=${encodeURIComponent(charId)}${campaign ? `&k=${encodeURIComponent(campaign)}` : ''}${v ? `&v=${encodeURIComponent(v)}` : ''}` : '';
    const fromAv = (av) => { if (!av) return ''; const [k, c, v] = String(av).split('|'); return url(c, v, window.PANEL_ROLA === 'gracz' ? null : k); };
    return { fromFile, pick, letter, initials, img, url, fromAv, SIZE };
})();
window.Portrait = Portrait;
