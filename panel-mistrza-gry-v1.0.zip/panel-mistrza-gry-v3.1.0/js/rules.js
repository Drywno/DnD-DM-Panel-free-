/* ============================================
   D&D 5e DM Panel — Ściągawka zasad (SRD 5.1, skrót po polsku)
   ============================================ */

const RulesModule = (() => {
    // Każdy wpis: { id, cat, title, icon, tags, body (HTML) }
    const CATS = [
        { id: 'all', label: 'Wszystko', icon: 'fa-border-all' },
        { id: 'conditions', label: 'Stany', icon: 'fa-skull-crossbones' },
        { id: 'combat', label: 'Walka', icon: 'fa-khanda' },
        { id: 'checks', label: 'Testy', icon: 'fa-dice-d20' },
        { id: 'health', label: 'Zdrowie i odpoczynek', icon: 'fa-heart-pulse' },
        { id: 'magic', label: 'Magia', icon: 'fa-wand-magic-sparkles' },
        { id: 'explore', label: 'Eksploracja', icon: 'fa-compass' }
    ];

    const ul = (items) => `<ul>${items.map(i => `<li>${i}</li>`).join('')}</ul>`;
    const table = (head, rows) => `<table class="rules-table"><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`;

    const RULES = [
        // ---------------- STANY ----------------
        { cat: 'conditions', title: 'Oślepiony', en: 'Blinded', icon: 'fa-eye-slash', body: ul([
            'Automatycznie oblewa testy wymagające wzroku.',
            'Ataki <b>przeciw</b> niemu mają ułatwienie, jego ataki mają utrudnienie.'
        ]) },
        { cat: 'conditions', title: 'Zauroczony', en: 'Charmed', icon: 'fa-heart', body: ul([
            'Nie może atakować zauroczającego ani celować w niego szkodliwymi zdolnościami i czarami.',
            'Zauroczający ma ułatwienie w testach interakcji społecznych z nim.'
        ]) },
        { cat: 'conditions', title: 'Głuchy', en: 'Deafened', icon: 'fa-ear-deaf', body: ul([
            'Nie słyszy; automatycznie oblewa testy wymagające słuchu.'
        ]) },
        { cat: 'conditions', title: 'Przestraszony', en: 'Frightened', icon: 'fa-ghost', body: ul([
            'Utrudnienie do testów i ataków, dopóki źródło strachu jest w zasięgu wzroku.',
            'Nie może dobrowolnie zbliżyć się do źródła strachu.'
        ]) },
        { cat: 'conditions', title: 'Pochwycony', en: 'Grappled', icon: 'fa-hand-fist', body: ul([
            'Prędkość 0 i nie korzysta z premii do prędkości.',
            'Kończy się, gdy chwytający jest obezwładniony albo gdy efekt odsunie cel poza jego zasięg.'
        ]) },
        { cat: 'conditions', title: 'Obezwładniony', en: 'Incapacitated', icon: 'fa-ban', body: ul([
            'Nie może wykonywać akcji ani reakcji.'
        ]) },
        { cat: 'conditions', title: 'Niewidzialny', en: 'Invisible', icon: 'fa-user-secret', body: ul([
            'Niemożliwy do zobaczenia bez magii lub zmysłu specjalnego; do ukrywania traktowany jak mocno zasłonięty.',
            'Jego ataki mają ułatwienie, ataki przeciw niemu — utrudnienie.'
        ]) },
        { cat: 'conditions', title: 'Sparaliżowany', en: 'Paralyzed', icon: 'fa-person', body: ul([
            'Obezwładniony; nie może się ruszać ani mówić.',
            'Automatycznie oblewa rzuty obronne na SIŁ i ZRĘ.',
            'Ataki przeciw niemu mają ułatwienie; trafienie z 1,5 m (5 stóp) to <b>trafienie krytyczne</b>.'
        ]) },
        { cat: 'conditions', title: 'Spetryfikowany', en: 'Petrified', icon: 'fa-gem', body: ul([
            'Zamieniony w nieożywioną substancję (zwykle kamień); waga ×10, nie starzeje się.',
            'Obezwładniony, nie rusza się, nie mówi, nie jest świadomy otoczenia.',
            'Ataki przeciw niemu z ułatwieniem; oblewa rzuty na SIŁ i ZRĘ.',
            'Odporność na wszystkie obrażenia; odporny na trucizny i choroby (istniejące są zawieszone).'
        ]) },
        { cat: 'conditions', title: 'Zatruty', en: 'Poisoned', icon: 'fa-flask', body: ul([
            'Utrudnienie do rzutów ataku i testów atrybutów.'
        ]) },
        { cat: 'conditions', title: 'Powalony (leżący)', en: 'Prone', icon: 'fa-person-falling', body: ul([
            'Może się tylko czołgać (każdy metr kosztuje dodatkowy metr), chyba że wstanie — wstanie kosztuje połowę prędkości.',
            'Jego ataki mają utrudnienie.',
            'Ataki z 1,5 m przeciw niemu — ułatwienie; z większej odległości — utrudnienie.'
        ]) },
        { cat: 'conditions', title: 'Skrępowany', en: 'Restrained', icon: 'fa-link', body: ul([
            'Prędkość 0.',
            'Ataki przeciw niemu z ułatwieniem, jego ataki z utrudnieniem.',
            'Utrudnienie do rzutów obronnych na ZRĘ.'
        ]) },
        { cat: 'conditions', title: 'Ogłuszony (oszołomiony)', en: 'Stunned', icon: 'fa-star', body: ul([
            'Obezwładniony, nie rusza się, mówi z trudem.',
            'Oblewa rzuty obronne na SIŁ i ZRĘ; ataki przeciw niemu z ułatwieniem.'
        ]) },
        { cat: 'conditions', title: 'Nieprzytomny', en: 'Unconscious', icon: 'fa-bed', body: ul([
            'Obezwładniony, nie rusza się, nie mówi, nie wie, co się dzieje; upuszcza trzymane przedmioty i pada powalony.',
            'Oblewa rzuty na SIŁ i ZRĘ; ataki przeciw niemu z ułatwieniem.',
            'Trafienie z 1,5 m to trafienie krytyczne.'
        ]) },
        { cat: 'conditions', title: 'Wyczerpanie', en: 'Exhaustion', icon: 'fa-battery-quarter', body: table(['Poz.', 'Efekt (kumuluje się)'], [
            ['1', 'Utrudnienie do testów atrybutów'], ['2', 'Prędkość o połowę'], ['3', 'Utrudnienie do ataków i rzutów obronnych'],
            ['4', 'Maks. PW o połowę'], ['5', 'Prędkość 0'], ['6', 'Śmierć']
        ]) + '<p>Długi odpoczynek (z jedzeniem i piciem) zmniejsza wyczerpanie o 1 poziom.</p>' },

        // ---------------- WALKA ----------------
        { cat: 'combat', title: 'Przebieg tury', icon: 'fa-hourglass-half', body: ul([
            '<b>Ruch</b> do wysokości prędkości — można go dzielić przed i po akcji.',
            '<b>Akcja</b> — jedna na turę.',
            '<b>Akcja dodatkowa</b> — tylko jeśli daje ją zdolność lub czar.',
            '<b>Reakcja</b> — jedna na rundę, odnawia się na początku twojej tury.',
            '<b>Darmowa interakcja</b> z jednym przedmiotem (dobycie broni, otwarcie drzwi).',
            'Runda trwa ok. 6 sekund.'
        ]) },
        { cat: 'combat', title: 'Akcje w walce', icon: 'fa-list-check', body: table(['Akcja', 'Efekt'], [
            ['Atak', 'Jeden atak bronią (więcej przy Dodatkowym Ataku); można zamiast niego chwycić lub pchnąć'],
            ['Rzucenie czaru', 'Czar o czasie rzucania 1 akcja'],
            ['Sprint', 'Dodatkowy ruch równy prędkości'],
            ['Odstąpienie', 'Twój ruch nie prowokuje ataków okazyjnych w tej turze'],
            ['Unik', 'Ataki przeciw tobie z utrudnieniem, rzuty na ZRĘ z ułatwieniem (do twojej następnej tury)'],
            ['Pomoc', 'Sojusznik ma ułatwienie do następnego testu lub ataku na cel w 1,5 m od ciebie'],
            ['Ukrycie', 'Test Zręczności (Skradanie) — musisz być niewidoczny dla przeciwnika'],
            ['Przygotowanie', 'Określasz wyzwalacz i działanie; wykonujesz je reakcją'],
            ['Szukanie', 'Test Mądrości (Percepcja) lub Inteligencji (Śledztwo)'],
            ['Użycie przedmiotu', 'Druga interakcja z przedmiotem lub użycie przedmiotu wymagającego akcji']
        ]) },
        { cat: 'combat', title: 'Atak okazyjny', icon: 'fa-person-running', body: ul([
            'Gdy wrogie stworzenie, które widzisz, opuszcza twój zasięg — możesz reakcją wykonać jeden atak wręcz.',
            'Nie prowokuje: Odstąpienie, teleportacja, ruch wymuszony (np. pchnięcie).'
        ]) },
        { cat: 'combat', title: 'Osłona', icon: 'fa-shield', body: table(['Osłona', 'Premia', 'Przykład'], [
            ['½', '+2 KP i rzuty na ZRĘ', 'Niski mur, inne stworzenie, mebel'],
            ['¾', '+5 KP i rzuty na ZRĘ', 'Strzelnica, gruby pień'],
            ['Całkowita', 'Nie można wycelować', 'Pełna ściana']
        ]) },
        { cat: 'combat', title: 'Ułatwienie i utrudnienie', icon: 'fa-scale-balanced', body: ul([
            'Rzucasz 2k20: ułatwienie — bierzesz wyższy, utrudnienie — niższy.',
            'Kilka źródeł nie kumuluje się; jeśli masz oba — znoszą się (rzucasz 1k20).',
            'Atak na dystans, gdy wróg jest w 1,5 m — utrudnienie.',
            'Atak na cel niewidoczny — utrudnienie; atak przez niewidocznego napastnika — ułatwienie.'
        ]) },
        { cat: 'combat', title: 'Trafienie krytyczne', icon: 'fa-bullseye', body: ul([
            'Naturalne 20 na k20 ataku — zawsze trafia i jest krytykiem; naturalne 1 — zawsze pudło.',
            'Krytyk: rzucasz <b>podwójną liczbę kości obrażeń</b> (modyfikatory dodajesz raz).'
        ]) },
        { cat: 'combat', title: 'Chwyt i pchnięcie', icon: 'fa-hand-back-fist', body: ul([
            'Zastępuje jeden atak w akcji Ataku; cel najwyżej o 1 rozmiar większy.',
            '<b>Chwyt:</b> twój test SIŁ (Atletyka) vs. jego SIŁ (Atletyka) lub ZRĘ (Akrobatyka). Sukces — cel pochwycony.',
            'Ucieczka z chwytu: akcja, ten sam przeciwny test.',
            '<b>Pchnięcie:</b> ten sam test — powalasz cel albo odpychasz go o 1,5 m.',
            'Przenoszenie pochwyconego — twoja prędkość o połowę.'
        ]) },
        { cat: 'combat', title: 'Walka dwiema broniami', icon: 'fa-khanda', body: ul([
            'Atakując lekką bronią, możesz akcją dodatkową zaatakować drugą lekką bronią.',
            'Do obrażeń drugiego ataku nie dodajesz modyfikatora atrybutu (chyba że jest ujemny).'
        ]) },
        { cat: 'combat', title: 'Zaskoczenie i inicjatywa', icon: 'fa-bolt', body: ul([
            'Inicjatywa: test Zręczności (1k20 + mod ZRĘ). Remis — decyduje MG/gracze.',
            'Zaskoczony nie może się ruszać ani działać w swojej pierwszej turze i nie ma reakcji do jej końca.',
            'Zaskoczenie ustala MG — zwykle Skradanie ukrywających się vs. pasywna Percepcja.'
        ]) },
        { cat: 'combat', title: 'Walka konna i pod wodą', icon: 'fa-water', body: ul([
            'Dosiadanie / zsiadanie kosztuje połowę prędkości.',
            'Pod wodą: atak wręcz bez miecza krótkiego, sztyletu, oszczepu, włóczni lub trójzęba — utrudnienie.',
            'Atak dystansowy pod wodą poza normalnym zasięgiem — automatyczne pudło; w zasięgu — utrudnienie (poza kuszami, sieciami i bronią miotaną jak oszczep).',
            'Stworzenia zanurzone mają odporność na obrażenia od ognia.'
        ]) },

        // ---------------- TESTY ----------------
        { cat: 'checks', title: 'Stopień trudności (ST)', icon: 'fa-stairs', body: table(['Zadanie', 'ST'], [
            ['Bardzo łatwe', '5'], ['Łatwe', '10'], ['Średnie', '15'], ['Trudne', '20'], ['Bardzo trudne', '25'], ['Prawie niemożliwe', '30']
        ]) },
        { cat: 'checks', title: 'Testy pasywne', icon: 'fa-eye', body: ul([
            'Wynik = <b>10 + wszystkie modyfikatory</b> testu.',
            'Ułatwienie: +5, utrudnienie: −5.',
            'Najczęściej: pasywna Percepcja (zauważanie ukrytych wrogów i pułapek).',
            'Wartości całej drużyny są w zakładce <b>Drużyna</b>.'
        ]) },
        { cat: 'checks', title: 'Testy grupowe i przeciwne', icon: 'fa-people-group', body: ul([
            '<b>Grupowy:</b> sukces, jeśli co najmniej połowa grupy zda test.',
            '<b>Przeciwny:</b> obie strony rzucają; wyższy wynik wygrywa, remis — utrzymuje się dotychczasowa sytuacja.',
            '<b>Pomoc:</b> pomagający daje ułatwienie, jeśli sam mógłby wykonać zadanie.'
        ]) },
        { cat: 'checks', title: 'Umiejętności i atrybuty', icon: 'fa-list', body: table(['Atrybut', 'Umiejętności'], [
            ['SIŁ', 'Atletyka'], ['ZRĘ', 'Akrobatyka, Zwinne dłonie, Skradanie'],
            ['INT', 'Wiedza mistyczna, Historia, Śledztwo, Natura, Religia'],
            ['MĄD', 'Opieka nad zwierzętami, Wgląd, Medycyna, Percepcja, Sztuka przetrwania'],
            ['CHA', 'Oszustwo, Zastraszanie, Występy, Perswazja'], ['KON', '— (rzuty obronne, koncentracja)']
        ]) },
        { cat: 'checks', title: 'Modyfikator i premia z biegłości', icon: 'fa-calculator', body: table(['Wartość', 'Mod.', 'Poziom', 'Biegłość'], [
            ['1', '−5', '1–4', '+2'], ['2–3', '−4', '5–8', '+3'], ['4–5', '−3', '9–12', '+4'], ['6–7', '−2', '13–16', '+5'],
            ['8–9', '−1', '17–20', '+6'], ['10–11', '+0', '', ''], ['12–13', '+1', '', ''], ['14–15', '+2', '', ''], ['16–17', '+3', '', ''], ['18–19', '+4', '', ''], ['20', '+5', '', '']
        ]) },

        // ---------------- ZDROWIE ----------------
        { cat: 'health', title: 'Krótki odpoczynek', icon: 'fa-mug-hot', body: ul([
            'Co najmniej <b>1 godzina</b> spokojnej aktywności.',
            'Można wydać dowolną liczbę Kości Wytrzymałości: każda leczy kość + mod KON.',
            'Odnawiają się zdolności „na krótki odpoczynek” (np. Ki, Przypływ Działania, Kanał Boskości, sloty Czarnoksiężnika).',
            'W zakładce <b>Drużyna</b> jest przycisk krótkiego odpoczynku dla wszystkich.'
        ]) },
        { cat: 'health', title: 'Długi odpoczynek', icon: 'fa-bed', body: ul([
            'Co najmniej <b>8 godzin</b>, w tym najwyżej 2 h lekkiej aktywności (warta, czytanie).',
            'Przerwany przez min. 1 h walki, marszu lub rzucania czarów — trzeba zacząć od nowa.',
            'Odzyskujesz <b>wszystkie PW</b> i <b>połowę</b> maks. Kości Wytrzymałości (min. 1).',
            'Odnawiają się wszystkie komórki czarów i zdolności; wyczerpanie −1.',
            'Tylko jeden długi odpoczynek na 24 h; trzeba mieć co najmniej 1 PW.'
        ]) },
        { cat: 'health', title: 'Umieranie i rzuty przeciw śmierci', icon: 'fa-skull', body: ul([
            'Przy 0 PW postać pada nieprzytomna. Na początku każdej swojej tury rzuca k20 (bez modyfikatorów).',
            '<b>10+</b> sukces, <b>9−</b> porażka. 3 sukcesy — stabilna, 3 porażki — śmierć.',
            'Naturalne <b>20</b>: odzyskuje 1 PW. Naturalne <b>1</b>: dwie porażki.',
            'Obrażenia przy 0 PW — 1 porażka (krytyk — 2).',
            '<b>Śmierć natychmiastowa:</b> jeśli pozostałe obrażenia ≥ maks. PW.',
            'Stabilizacja: test Mądrości (Medycyna) ST 10 lub zestaw uzdrowiciela. Stabilna odzyskuje 1 PW po 1k4 godzinach.'
        ]) },
        { cat: 'health', title: 'Tymczasowe PW i leczenie', icon: 'fa-heart-circle-plus', body: ul([
            'Tymczasowe PW nie kumulują się — wybierasz wyższą wartość.',
            'Obrażenia najpierw zdejmują tymczasowe PW.',
            'Leczenie nie podnosi PW powyżej maksimum i nie przywraca tymczasowych PW.',
            '<b>Odporność</b> — połowa obrażeń, <b>podatność</b> — podwójne.'
        ]) },
        { cat: 'health', title: 'Jedzenie, picie, duszenie', icon: 'fa-utensils', body: ul([
            'Jedzenie: 0,5 kg dziennie. Bez jedzenia można przetrwać 3 + mod KON dni (min. 1), potem 1 poziom wyczerpania dziennie.',
            'Woda: ok. 4 l dziennie (8 l w upale). Połowa porcji — rzut na KON ST 15 albo wyczerpanie.',
            'Wstrzymanie oddechu: 1 + mod KON minut (min. 30 s). Potem: mod KON rund (min. 1) i spada do 0 PW.'
        ]) },

        // ---------------- MAGIA ----------------
        { cat: 'magic', title: 'Koncentracja', icon: 'fa-brain', body: ul([
            'Można utrzymywać tylko <b>jeden</b> czar z koncentracją naraz.',
            'Po otrzymaniu obrażeń: rzut obronny na KON, <b>ST = 10 lub połowa obrażeń</b> (wyższa wartość). Osobno za każde źródło.',
            'Koncentrację przerywa też: obezwładnienie, śmierć, rzucenie innego czaru z koncentracją.',
            'Możesz zakończyć koncentrację w dowolnym momencie (bez akcji).'
        ]) },
        { cat: 'magic', title: 'ST czarów i atak czarem', icon: 'fa-wand-sparkles', body: ul([
            '<b>ST rzutu obronnego</b> = 8 + premia z biegłości + mod atrybutu magicznego.',
            '<b>Modyfikator ataku czarem</b> = premia z biegłości + mod atrybutu magicznego.',
            'Atrybut: Inteligencja (Czarodziej), Mądrość (Kleryk, Druid, Łowca), Charyzma (Bard, Paladyn, Zaklinacz, Czarnoksiężnik).'
        ]) },
        { cat: 'magic', title: 'Komponenty i rytuały', icon: 'fa-feather', body: ul([
            '<b>W</b> (werbalny) — trzeba mówić; <b>S</b> (somatyczny) — wolna ręka; <b>M</b> (materialny) — sakiewka lub skupienie zamiast składników bez ceny.',
            'Czar z akcją dodatkową: w tej samej turze możesz rzucić tylko sztuczkę o czasie 1 akcji.',
            '<b>Rytuał:</b> +10 minut rzucania, nie zużywa komórki czaru.'
        ]) },
        { cat: 'magic', title: 'Obszary działania', icon: 'fa-circle-dot', body: table(['Kształt', 'Jak mierzyć'], [
            ['Stożek', 'Szerokość na końcu = długość'], ['Sześcian', 'Punkt początkowy na krawędzi'],
            ['Walec / Kula', 'Promień od punktu'], ['Linia', 'Długość i szerokość od punktu']
        ]) + '<p>Szablony obszarów (kula, stożek, linia) są w narzędziach mapy w zakładce <b>Walka</b>.</p>' },

        // ---------------- EKSPLORACJA ----------------
        { cat: 'explore', title: 'Tempo podróży', icon: 'fa-person-hiking', body: table(['Tempo', 'Minuta', 'Godzina', 'Dzień', 'Efekt'], [
            ['Szybkie', '120 m', '6 km', '45 km', '−5 do pasywnej Percepcji'],
            ['Normalne', '90 m', '4,5 km', '36 km', '—'],
            ['Wolne', '60 m', '3 km', '27 km', 'Można się skradać']
        ]) + '<p>Trudny teren: każdy metr kosztuje dwa. Marsz forsowny ponad 8 h: rzut na KON ST 10 + 1 za każdą dodatkową godzinę, porażka — wyczerpanie.</p>' },
        { cat: 'explore', title: 'Widoczność i światło', icon: 'fa-lightbulb', body: ul([
            '<b>Lekko zasłonięte</b> (półmrok, mgła, listowie): utrudnienie do Percepcji opartej na wzroku.',
            '<b>Mocno zasłonięte</b> (ciemność, gęsta mgła): praktycznie oślepiony w tym obszarze.',
            '<b>Widzenie w ciemności:</b> ciemność widzi jak półmrok, półmrok jak jasne światło (tylko odcienie szarości).',
            'Pochodnia: 6 m jasnego + 6 m przyćmionego. Latarnia z kapturem: 9 m + 9 m.'
        ]) },
        { cat: 'explore', title: 'Skakanie i upadek', icon: 'fa-person-falling-burst', body: ul([
            '<b>Skok w dal</b> z rozbiegu (3 m): tyle stóp, ile wynosi wartość SIŁ; z miejsca — połowa.',
            '<b>Skok wzwyż</b> z rozbiegu: 3 + mod SIŁ stóp; z miejsca — połowa.',
            '<b>Upadek:</b> 1k6 obrażeń obuchowych za każde 3 m (10 stóp), maks. 20k6; ląduje powalony.',
            'Wspinaczka i pływanie: każdy metr kosztuje dodatkowy metr (chyba że masz prędkość wspinaczki/pływania).'
        ]) },
        { cat: 'explore', title: 'Rozmiary stworzeń', icon: 'fa-up-right-and-down-left-from-center', body: table(['Rozmiar', 'Przestrzeń'], [
            ['Filigranowy', '0,75 × 0,75 m'], ['Mały', '1,5 × 1,5 m'], ['Średni', '1,5 × 1,5 m'], ['Duży', '3 × 3 m'], ['Ogromny', '4,5 × 4,5 m'], ['Gigantyczny', '6 × 6 m lub więcej']
        ]) },
        { cat: 'explore', title: 'Monety', icon: 'fa-coins', body: table(['Moneta', 'mm', 'ms', 'me', 'mz', 'mp'], [
            ['Miedziana (mm)', '1', '1/10', '1/50', '1/100', '1/1000'], ['Srebrna (ms)', '10', '1', '1/5', '1/10', '1/100'],
            ['Elektrum (me)', '50', '5', '1', '1/2', '1/20'], ['Złota (mz)', '100', '10', '2', '1', '1/10'], ['Platynowa (mp)', '1000', '100', '20', '10', '1']
        ]) + '<p>50 monet waży ok. 0,5 kg.</p>' }
    ];

    let activeCat = 'all';
    let inited = false;
    const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l');

    function init() {
        if (inited) return; inited = true;
        const chips = document.getElementById('rules-chips');
        if (chips) {
            chips.innerHTML = CATS.map(c => `<button class="chip${c.id === activeCat ? ' active' : ''}" data-cat="${c.id}"><i class="fa-solid ${c.icon}"></i> ${c.label}</button>`).join('');
            chips.addEventListener('click', (e) => {
                const b = e.target.closest('.chip'); if (!b) return;
                activeCat = b.dataset.cat;
                chips.querySelectorAll('.chip').forEach(x => x.classList.toggle('active', x === b));
                render();
            });
        }
        document.getElementById('rules-search')?.addEventListener('input', render);
    }

    function render() {
        const box = document.getElementById('rules-content');
        if (!box) return;
        const q = norm(document.getElementById('rules-search')?.value.trim());
        const list = RULES.filter(r => (activeCat === 'all' || r.cat === activeCat) &&
            (!q || norm(r.title + ' ' + (r.en || '') + ' ' + r.body.replace(/<[^>]+>/g, ' ')).includes(q)));
        if (!list.length) {
            box.innerHTML = `<div class="empty-state empty-state-wide"><i class="fa-solid fa-book"></i><span>Nic nie znaleziono</span></div>`;
            return;
        }
        const catLabel = (id) => CATS.find(c => c.id === id)?.label || '';
        box.innerHTML = list.map(r => `
            <article class="rule-card" data-cat="${r.cat}" id="rule-${norm(r.title).replace(/[^a-z0-9]+/g, '-')}">
                <header><i class="fa-solid ${r.icon}"></i><h3>${r.title}${r.en ? ` <span class="rule-en">${r.en}</span>` : ''}</h3><span class="rule-cat">${catLabel(r.cat)}</span></header>
                <div class="rule-body">${r.body}</div>
            </article>`).join('');
    }

    function activate() { init(); render(); }

    function open(query) {
        App.switchTab('rules');
        const s = document.getElementById('rules-search');
        if (s) { s.value = query || ''; render(); }
    }

    return { init, activate, open, all: () => RULES };
})();

window.RulesModule = RulesModule;
