/* ============================================
   Ozdoby karczmy: belka pod sufitem z latarniami, kute okucia w rogach,
   półka z kuflami i świecą, iskry z paleniska.
   Wszystko jest tylko ozdobą (pointer-events: none) — nic nie zasłania przycisków.
   Iskry i migotanie można wyłączyć (przycisk z płomieniem), a przy
   „ogranicz ruch” w systemie są wyłączone same.
   ============================================ */
const Decor = (() => {
    const reduce = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
    const fxOn = () => { try { return localStorage.getItem('decor_fx') !== '0'; } catch (e) { return true; } };

    // kute okucie narożne (lewy górny róg; pozostałe obracamy)
    const CORNER = `<svg viewBox="0 0 40 40" aria-hidden="true"><defs><linearGradient id="dcIron" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5a5048"/><stop offset=".5" stop-color="#2a2420"/><stop offset="1" stop-color="#14100d"/></linearGradient><radialGradient id="dcRiv" cx=".35" cy=".35" r=".7"><stop offset="0" stop-color="#f0d79a"/><stop offset=".5" stop-color="#a67c3a"/><stop offset="1" stop-color="#3a2410"/></radialGradient></defs>
        <path d="M3 3H34Q38 3 36 7Q33 10 27 9H11Q9 9 9 11V27Q10 33 7 36Q3 38 3 34Z" fill="url(#dcIron)" stroke="#0b0806" stroke-width="1.2"/>
        <path d="M5.5 5.5H30M5.5 5.5V30" stroke="rgba(255,240,210,.18)" stroke-width="1"/>
        <path d="M27 9Q31 13 27 16Q24 18 22 15M9 27Q13 31 16 27Q18 24 15 22" fill="none" stroke="#2a2420" stroke-width="2.2" stroke-linecap="round"/>
        <circle cx="7" cy="7" r="2.6" fill="url(#dcRiv)" stroke="#1a0f06" stroke-width=".6"/><circle cx="22" cy="6" r="1.7" fill="url(#dcRiv)"/><circle cx="6" cy="22" r="1.7" fill="url(#dcRiv)"/></svg>`;

    // latarnia na łańcuchu
    const LANTERN = `<svg viewBox="0 0 30 74" aria-hidden="true"><defs><radialGradient id="dcFlame" cx=".5" cy=".6" r=".6"><stop offset="0" stop-color="#fff6c8"/><stop offset=".45" stop-color="#ffc152"/><stop offset="1" stop-color="#ff7a1a" stop-opacity="0"/></radialGradient><linearGradient id="dcGlass" x1="0" x2="1"><stop offset="0" stop-color="rgba(255,190,90,.55)"/><stop offset=".5" stop-color="rgba(255,225,150,.85)"/><stop offset="1" stop-color="rgba(255,170,70,.5)"/></linearGradient><linearGradient id="dcBrass" x1="0" x2="1"><stop offset="0" stop-color="#5c3f17"/><stop offset=".45" stop-color="#d9b264"/><stop offset="1" stop-color="#5c3f17"/></linearGradient></defs>
        <g stroke="#2a1c0c" stroke-width="1.1" fill="none">${Array.from({ length: 5 }, (_, i) => `<ellipse cx="15" cy="${3 + i * 4.2}" rx="1.6" ry="2.4"/>`).join('')}</g>
        <circle cx="15" cy="24" r="3" fill="none" stroke="url(#dcBrass)" stroke-width="1.6"/>
        <path d="M7 32L15 26L23 32Z" fill="url(#dcBrass)" stroke="#2a1c0c" stroke-width=".8"/>
        <rect x="8" y="32" width="14" height="26" rx="1.5" fill="url(#dcGlass)"/>
        <ellipse class="dc-flame" cx="15" cy="46" rx="4" ry="7" fill="url(#dcFlame)"/>
        <g stroke="url(#dcBrass)" stroke-width="1.6"><path d="M8 32V58M22 32V58M15 32V58" stroke-width="1"/><path d="M7 32H23M7 58H23"/></g>
        <path d="M6 58H24L22 63H8Z" fill="url(#dcBrass)" stroke="#2a1c0c" stroke-width=".8"/>
        <path d="M13 63L15 69L17 63" fill="#7a5a2c"/></svg>`;

    // półka: kufel z pianą, butelka, świeca, sakiewka, księgi
    const SHELF = `<svg viewBox="0 0 220 70" preserveAspectRatio="xMidYMax meet" aria-hidden="true"><defs>
        <linearGradient id="dcPlank" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7a5230"/><stop offset=".5" stop-color="#4a2f18"/><stop offset="1" stop-color="#2a180b"/></linearGradient>
        <linearGradient id="dcMug" x1="0" x2="1"><stop offset="0" stop-color="#4a2c14"/><stop offset=".5" stop-color="#8a5a2e"/><stop offset="1" stop-color="#3a220f"/></linearGradient>
        <linearGradient id="dcBottle" x1="0" x2="1"><stop offset="0" stop-color="#1d3a22"/><stop offset=".45" stop-color="#3f7a48"/><stop offset="1" stop-color="#14261a"/></linearGradient>
        <linearGradient id="dcWax" x1="0" x2="1"><stop offset="0" stop-color="#cdb98f"/><stop offset=".5" stop-color="#f3e6c3"/><stop offset="1" stop-color="#b7a074"/></linearGradient>
        <radialGradient id="dcCandle" cx=".5" cy=".65" r=".6"><stop offset="0" stop-color="#fffbe0"/><stop offset=".5" stop-color="#ffc657"/><stop offset="1" stop-color="#ff7a1a" stop-opacity="0"/></radialGradient>
        <radialGradient id="dcHalo" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="rgba(255,170,70,.45)"/><stop offset="1" stop-color="rgba(255,140,40,0)"/></radialGradient></defs>
        <!-- księgi -->
        <g transform="translate(14 30)"><rect x="0" y="6" width="9" height="28" fill="#6b1f16" stroke="#1e0905"/><rect x="9" y="2" width="8" height="32" fill="#28405e" stroke="#0b1320"/><rect x="17" y="9" width="10" height="25" fill="#5a4a1c" stroke="#1e1806" transform="rotate(8 22 34)"/><path d="M1 12H8M1 28H8M10 8H16M10 28H16" stroke="#d9b264" stroke-width="1"/></g>
        <!-- butelka -->
        <g transform="translate(52 14)"><rect x="8" y="0" width="6" height="5" fill="#6b4a22"/><path d="M8 5H14V16Q22 20 22 28V50H0V28Q0 20 8 16Z" fill="url(#dcBottle)" stroke="#0d1a10"/><rect x="3" y="30" width="16" height="11" rx="1.5" fill="#e8d6a6" stroke="#6b5530" stroke-width=".7"/><path d="M6 35H16M7 38H15" stroke="#6b5530" stroke-width=".8"/><path d="M4 26Q5 22 9 20" stroke="rgba(255,255,255,.35)" stroke-width="1.5" fill="none"/></g>
        <!-- świeca z płomieniem -->
        <circle class="dc-candle-halo" cx="98" cy="22" r="20" fill="url(#dcHalo)"/>
        <g transform="translate(90 26)"><rect x="3" y="8" width="10" height="30" rx="1.5" fill="url(#dcWax)"/><path d="M3 12Q5 18 6 12Q8 20 9 12" fill="#f3e6c3"/><path d="M8 8V4" stroke="#2a1a0a" stroke-width="1"/><ellipse class="dc-flame" cx="8" cy="0" rx="3.2" ry="6" fill="url(#dcCandle)"/><rect x="-1" y="36" width="18" height="4" rx="2" fill="#7a5a2c" stroke="#2a1a0a" stroke-width=".6"/></g>
        <!-- kufel z pianą -->
        <g transform="translate(122 24)"><path d="M0 8H26V40Q26 44 22 44H4Q0 44 0 40Z" fill="url(#dcMug)" stroke="#1e1006"/><path d="M0 16H26M0 34H26" stroke="#c9a35c" stroke-width="2.2"/><path d="M26 14Q36 14 36 24Q36 34 26 34" fill="none" stroke="#3a220f" stroke-width="4"/><path d="M-2 8Q0 0 7 3Q11 -2 16 2Q22 -1 25 4Q30 5 27 10Q24 12 20 10H2Q-3 11 -2 8Z" fill="#fbf3dc" stroke="#cdbb8f" stroke-width=".7"/><path d="M6 10Q6 16 4 18" stroke="#fbf3dc" stroke-width="3" stroke-linecap="round"/></g>
        <!-- sakiewka z monetami -->
        <g transform="translate(168 38)"><path d="M6 6Q0 18 6 28H26Q32 18 26 6Z" fill="#6e4523" stroke="#2a1608"/><path d="M6 6Q16 0 26 6" fill="none" stroke="#c9a35c" stroke-width="2"/><circle cx="35" cy="27" r="4" fill="#e3b54a" stroke="#7a5a1a"/><circle cx="41" cy="28" r="3.6" fill="#d4a63f" stroke="#7a5a1a"/><ellipse cx="38" cy="22" rx="4" ry="1.6" fill="#f0c95c" stroke="#7a5a1a"/></g>
        <!-- deska i wsporniki -->
        <rect x="2" y="64" width="216" height="6" rx="1.5" fill="url(#dcPlank)" stroke="#170c04"/>
        <path d="M20 70L28 70L24 78Z M192 70L200 70L196 78Z" fill="#2a2420"/>
        <circle cx="8" cy="67" r="1.4" fill="#c9a35c"/><circle cx="212" cy="67" r="1.4" fill="#c9a35c"/></svg>`;


    // tła szyldów (wzory b, c, d)
    const SIGN_BG = {
        b: `<svg class="dc-sign-bg" viewBox="0 0 220 160" preserveAspectRatio="none" aria-hidden="true"><defs>
            <linearGradient id="sbStave" x1="0" x2="1"><stop offset="0" stop-color="#3a220f"/><stop offset=".08" stop-color="#6e4422"/><stop offset=".5" stop-color="#8a5a2e"/><stop offset=".92" stop-color="#6e4422"/><stop offset="1" stop-color="#3a220f"/></linearGradient>
            <linearGradient id="sbHoop" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3d996"/><stop offset=".5" stop-color="#b8893c"/><stop offset="1" stop-color="#5a3c14"/></linearGradient>
            <radialGradient id="sbFoam" cx=".5" cy=".3" r=".8"><stop offset="0" stop-color="#fffdf2"/><stop offset="1" stop-color="#e3d2a6"/></radialGradient></defs>
            <path d="M172 52Q212 52 212 90Q212 128 172 128" fill="none" stroke="#2a180a" stroke-width="20"/><path d="M172 52Q206 52 206 90Q206 128 172 128" fill="none" stroke="url(#sbStave)" stroke-width="12"/>
            <path d="M10 30H176V146Q176 156 166 156H20Q10 156 10 146Z" fill="url(#sbStave)" stroke="#1e1006" stroke-width="2"/>
            <g stroke="rgba(0,0,0,.35)" stroke-width="1.2">${[38, 66, 94, 122, 150].map(x => `<path d="M${x} 32V154"/>`).join('')}</g>
            <rect x="8" y="40" width="170" height="8" rx="2" fill="url(#sbHoop)" stroke="#2a1806"/><rect x="8" y="134" width="170" height="8" rx="2" fill="url(#sbHoop)" stroke="#2a1806"/>
            <path d="M4 34Q2 16 22 18Q30 4 50 12Q64 0 86 10Q104 0 122 10Q142 2 156 14Q178 8 182 26Q190 36 178 40H8Q0 40 4 34Z" fill="url(#sbFoam)" stroke="#c9b68a" stroke-width="1.2"/>
            <path d="M30 40Q30 56 24 62Q20 66 22 58Q24 48 24 40Z" fill="url(#sbFoam)"/><path d="M140 40Q142 50 138 54Q135 56 136 50Z" fill="url(#sbFoam)"/>
            <ellipse cx="60" cy="24" rx="5" ry="3" fill="rgba(255,255,255,.7)"/><ellipse cx="120" cy="20" rx="4" ry="2.5" fill="rgba(255,255,255,.6)"/></svg>`,
        c: `<svg class="dc-sign-bg" viewBox="0 0 200 180" preserveAspectRatio="none" aria-hidden="true"><defs>
            <linearGradient id="scCloth" x1="0" x2="1"><stop offset="0" stop-color="#3e0b08"/><stop offset=".18" stop-color="#7a1a12"/><stop offset=".5" stop-color="#9c2418"/><stop offset=".82" stop-color="#7a1a12"/><stop offset="1" stop-color="#3e0b08"/></linearGradient>
            <linearGradient id="scShade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(0,0,0,.45)"/><stop offset=".12" stop-color="rgba(0,0,0,0)"/><stop offset=".85" stop-color="rgba(0,0,0,0)"/><stop offset="1" stop-color="rgba(0,0,0,.35)"/></linearGradient></defs>
            <path d="M4 0H196V176L100 140L4 176Z" fill="url(#scCloth)"/><path d="M4 0H196V176L100 140L4 176Z" fill="url(#scShade)"/>
            <g fill="none" stroke="#e3b95c" stroke-width="2"><path d="M14 8H186V158L100 126L14 158Z"/></g>
            <g fill="none" stroke="#f3d38a" stroke-width="1" stroke-dasharray="3 3"><path d="M20 14H180V149L100 119L20 149Z"/></g>
            <g stroke="rgba(0,0,0,.18)" stroke-width="6">${[40, 80, 120, 160].map(x => `<path d="M${x} 0V150"/>`).join('')}</g>
            <g fill="#e3b95c">${[20, 60, 100, 140, 180].map(x => `<circle cx="${x}" cy="4" r="3.5" stroke="#5a3c14"/>`).join('')}</g></svg>`,
        d: `<svg class="dc-sign-bg" viewBox="0 0 220 160" preserveAspectRatio="none" aria-hidden="true"><defs>
            <radialGradient id="sdWood" cx=".5" cy=".45" r=".6"><stop offset="0" stop-color="#7a4e28"/><stop offset=".7" stop-color="#4a2c14"/><stop offset="1" stop-color="#24140a"/></radialGradient>
            <linearGradient id="sdRim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6dc9a"/><stop offset=".4" stop-color="#b8893c"/><stop offset=".7" stop-color="#5a3c14"/><stop offset="1" stop-color="#d9b264"/></linearGradient>
            <pattern id="sdGrain" width="220" height="12" patternUnits="userSpaceOnUse"><path d="M0 6Q55 2 110 6T220 6" fill="none" stroke="rgba(0,0,0,.18)" stroke-width="1.2"/></pattern></defs>
            <ellipse cx="110" cy="80" rx="106" ry="76" fill="url(#sdRim)" stroke="#1a0e04" stroke-width="2"/>
            <ellipse cx="110" cy="80" rx="97" ry="67" fill="url(#sdWood)" stroke="#1a0e04" stroke-width="1.5"/>
            <ellipse cx="110" cy="80" rx="97" ry="67" fill="url(#sdGrain)"/>
            <ellipse cx="110" cy="80" rx="89" ry="59" fill="none" stroke="rgba(233,196,106,.55)" stroke-width="1.3" stroke-dasharray="1 4" stroke-linecap="round"/>
            ${[[12, 80], [208, 80], [110, 6], [110, 154]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3.2" fill="#f3dc9e" stroke="#3a2410"/>`).join('')}</svg>`
    };

    Object.assign(SIGN_BG, {
        // E — kuta, żelazna rama z wyciętymi sylwetkami kufla i kości
        e: `<svg class="dc-sign-bg" viewBox="0 0 220 170" preserveAspectRatio="none" aria-hidden="true"><defs>
            <linearGradient id="seIron" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5e554c"/><stop offset=".45" stop-color="#2a2420"/><stop offset="1" stop-color="#0e0b09"/></linearGradient>
            <linearGradient id="sePlank" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7a5230"/><stop offset="1" stop-color="#3a220f"/></linearGradient></defs>
            <g fill="none" stroke="url(#seIron)" stroke-width="5" stroke-linecap="round">
                <path d="M12 8H208V118"/><path d="M12 8V118"/>
                <path d="M30 8Q22 26 36 30Q48 32 44 20"/><path d="M190 8Q198 26 184 30Q172 32 176 20"/>
                <path d="M12 60Q30 56 34 70Q36 80 26 80"/><path d="M208 60Q190 56 186 70Q184 80 194 80"/></g>
            <g fill="url(#seIron)" stroke="#0a0705" stroke-width="1">
                <path d="M62 22H98V62Q98 68 92 68H68Q62 68 62 62Z"/><path d="M98 30Q114 30 114 45Q114 60 98 60V54Q108 54 108 45Q108 36 98 36Z"/>
                <path d="M58 22Q58 12 68 14Q74 6 82 12Q90 6 96 14Q104 14 102 22Z"/>
                <path d="M150 14L170 26V50L150 62L130 50V26Z"/></g>
            <g fill="none" stroke="#c9a35c" stroke-width="1.2"><path d="M150 14L158 30H142Z M142 30L130 26M158 30L170 26M142 30L150 50L158 30M150 50L130 50M150 50L170 50M150 50V62"/></g>
            <rect x="8" y="104" width="204" height="60" rx="5" fill="url(#sePlank)" stroke="#120a04" stroke-width="2"/>
            <rect x="13" y="109" width="194" height="50" rx="3" fill="none" stroke="rgba(233,196,106,.45)" stroke-width="1"/>
            ${[[16, 112], [204, 112], [16, 156], [204, 156]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="2.6" fill="#d9b264" stroke="#3a2410"/>`).join('')}</svg>`,
        // F — dno beczki z obręczą
        f: `<svg class="dc-sign-bg" viewBox="0 0 200 200" preserveAspectRatio="none" aria-hidden="true"><defs>
            <radialGradient id="sfWood" cx=".45" cy=".4" r=".65"><stop offset="0" stop-color="#9a6a38"/><stop offset=".7" stop-color="#5e3a1a"/><stop offset="1" stop-color="#2e1a0a"/></radialGradient>
            <linearGradient id="sfHoop" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6a6158"/><stop offset=".5" stop-color="#2a2420"/><stop offset="1" stop-color="#575049"/></linearGradient></defs>
            <circle cx="100" cy="100" r="96" fill="url(#sfHoop)" stroke="#0a0705" stroke-width="2"/>
            <circle cx="100" cy="100" r="84" fill="url(#sfWood)" stroke="#1a0e04" stroke-width="2"/>
            <g stroke="rgba(0,0,0,.45)" stroke-width="1.6">${[44, 72, 100, 128, 156].map(x => `<path d="M${x} ${100 - Math.sqrt(84 * 84 - (x - 100) ** 2)}V${100 + Math.sqrt(84 * 84 - (x - 100) ** 2)}"/>`).join('')}</g>
            <circle cx="100" cy="100" r="84" fill="none" stroke="rgba(255,210,150,.12)" stroke-width="6"/>
            ${Array.from({ length: 10 }, (_, i) => { const a = i / 10 * 6.283; return `<circle cx="${(100 + Math.cos(a) * 90).toFixed(1)}" cy="${(100 + Math.sin(a) * 90).toFixed(1)}" r="2.4" fill="#c9a35c" stroke="#2a1806"/>`; }).join('')}
            <rect x="92" y="150" width="16" height="22" rx="3" fill="#3a220f" stroke="#120a04"/><rect x="88" y="168" width="24" height="6" rx="2" fill="#c9a35c" stroke="#3a2410"/></svg>`,
        // G — zwój pergaminu przybity sztyletem
        g: `<svg class="dc-sign-bg" viewBox="0 0 220 170" preserveAspectRatio="none" aria-hidden="true"><defs>
            <linearGradient id="sgPar" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4e6c0"/><stop offset=".5" stop-color="#e6cf98"/><stop offset="1" stop-color="#c9a866"/></linearGradient>
            <linearGradient id="sgRoll" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b9955a"/><stop offset=".5" stop-color="#f1e0b4"/><stop offset="1" stop-color="#9c7840"/></linearGradient>
            <radialGradient id="sgBurn" cx=".5" cy=".5" r=".75"><stop offset=".7" stop-color="rgba(90,50,10,0)"/><stop offset="1" stop-color="rgba(90,50,10,.45)"/></radialGradient>
            <linearGradient id="sgBlade" x1="0" x2="1"><stop offset="0" stop-color="#8a8f96"/><stop offset=".5" stop-color="#eef1f4"/><stop offset="1" stop-color="#7a7f86"/></linearGradient></defs>
            <path d="M16 22Q60 16 110 22T204 20V150Q160 156 110 150T16 152Z" fill="url(#sgPar)" stroke="#8a6a3a" stroke-width="1.2"/>
            <path d="M16 22Q60 16 110 22T204 20V150Q160 156 110 150T16 152Z" fill="url(#sgBurn)"/>
            <rect x="6" y="12" width="208" height="14" rx="7" fill="url(#sgRoll)" stroke="#6b4a22"/>
            <rect x="6" y="146" width="208" height="14" rx="7" fill="url(#sgRoll)" stroke="#6b4a22"/>
            <g transform="translate(176 -4) rotate(28)"><rect x="-3" y="0" width="6" height="14" rx="2" fill="#4a2c14"/><rect x="-10" y="13" width="20" height="4" rx="2" fill="#c9a35c" stroke="#5a3c14"/><path d="M-3 17H3L1 44L0 48L-1 44Z" fill="url(#sgBlade)" stroke="#555" stroke-width=".6"/><circle cx="0" cy="-2" r="3.5" fill="#c9a35c" stroke="#5a3c14"/></g></svg>`,
        // H — tarcza herbowa ze wstęgą
        h: `<svg class="dc-sign-bg" viewBox="0 0 220 200" preserveAspectRatio="none" aria-hidden="true"><defs>
            <linearGradient id="shL" x1="0" x2="1"><stop offset="0" stop-color="#5a1410"/><stop offset="1" stop-color="#8e2418"/></linearGradient>
            <linearGradient id="shR" x1="0" x2="1"><stop offset="0" stop-color="#d4a84a"/><stop offset="1" stop-color="#9c7428"/></linearGradient>
            <linearGradient id="shRim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6dc9a"/><stop offset=".5" stop-color="#9c7428"/><stop offset="1" stop-color="#e8c87a"/></linearGradient>
            <linearGradient id="shRib" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a3d5c"/><stop offset="1" stop-color="#16213a"/></linearGradient></defs>
            <path d="M40 8H180V86Q180 150 110 182Q40 150 40 86Z" fill="url(#shRim)" stroke="#1a0e04" stroke-width="2"/>
            <path d="M48 16H110V172Q48 144 48 86Z" fill="url(#shL)"/><path d="M110 16H172V86Q172 144 110 172Z" fill="url(#shR)"/>
            <path d="M48 16H172V86Q172 144 110 172Q48 144 48 86Z" fill="none" stroke="#1a0e04" stroke-width="1.2"/>
            <path d="M4 104H40L46 96H174L180 104H216L206 122L216 140H176L170 132H50L44 140H4L14 122Z" fill="url(#shRib)" stroke="#0a0f1a" stroke-width="1.5"/>
            <path d="M50 100H170V128H50Z" fill="none" stroke="#c9a35c" stroke-width="1" stroke-dasharray="2 3"/></svg>`
    });
    function signVariant() {
        let v = 'b'; try { v = localStorage.getItem('decor_sign') || 'b'; } catch (e) {}
        const sign = document.querySelector('#sidebar .premium-logo.dc-sign'); if (!sign) return;
        ['b', 'c', 'd', 'e', 'f', 'g', 'h'].forEach(k => document.body.classList.toggle('dc-sign-' + k, v === k));
        sign.querySelector('.dc-sign-bg')?.remove();
        if (SIGN_BG[v]) sign.insertAdjacentHTML('afterbegin', SIGN_BG[v]);
        // kufel wisi na łańcuchach przypiętych do wysięgnika
        sign.querySelector(':scope > .dc-hang')?.remove();
        if (v === 'b') sign.insertAdjacentHTML('afterbegin', '<span class="dc-hang" aria-hidden="true"></span>');
    }
    function setSign(v) { try { localStorage.setItem('decor_sign', v); } catch (e) {} signVariant(); }

    let beam = null, lights = null, lightsW = 0, lanterns = [], glows = [], canvas = null, raf = 0, sparks = [], onResize = null;

    function corners(el) {
        if (!el || el.querySelector(':scope > .dc-corner')) return;
        ['tl', 'tr', 'bl', 'br'].forEach(p => { const d = document.createElement('span'); d.className = `dc-corner dc-${p}`; d.innerHTML = CORNER; el.appendChild(d); });
    }
    function shelf() {
        const sb = document.getElementById('sidebar'), nav = sb?.querySelector('.side-nav');
        if (!nav || sb.querySelector('.dc-shelf')) return;
        const d = document.createElement('div'); d.className = 'dc-shelf'; d.innerHTML = SHELF;
        nav.after(d);
    }
    // belka u sufitu i dwie latarnie: między menu a treścią oraz przy prawej krawędzi
    function ceiling() {
        if (!beam) {
            beam = document.createElement('div'); beam.className = 'dc-beam'; document.body.appendChild(beam);
            lights = document.createElement('div'); lights.className = 'dc-lights'; lights.setAttribute('aria-hidden', 'true'); document.body.appendChild(lights);
            for (let i = 0; i < 2; i++) {
                const g = document.createElement('div'); g.className = 'dc-glow'; document.body.appendChild(g); glows.push(g);
                const l = document.createElement('div'); l.className = 'dc-lantern'; l.innerHTML = LANTERN; l.style.animationDelay = `${-i * 1.7}s`; document.body.appendChild(l); lanterns.push(l);
            }
        }
        place();
    }
    // sznur ciepłych lampek: łuki drutu zwisające spod belki, na nich żarówki migoczące każda w swoim rytmie
    const SPRIG = `<svg viewBox="0 0 26 16" class="dc-sprig"><g fill="#5f7a34" stroke="#2c3a16" stroke-width=".6"><path d="M13 3Q5 1 2 7Q8 9 13 3Z"/><path d="M13 3Q21 1 24 7Q18 9 13 3Z"/><path d="M13 3Q10 10 13 15Q16 10 13 3Z" fill="#6f8a3a"/></g><circle cx="13" cy="3" r="2" fill="#8a3a2a" stroke="#3a120a" stroke-width=".6"/></svg>`;
    function stringLights() {
        if (!lights) return;
        const W = innerWidth; if (Math.abs(W - lightsW) < 4 && lights.childElementCount) return;
        lightsW = W;
        const span = 150, n = Math.ceil(W / span) + 1, sag = 8, y0 = 2;
        let d = '', bulbs = '', sprigs = '';
        let seed = 7; const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
        const warm = ['#ff9d3a', '#ffb347', '#ff8a2a', '#ffc35c'];
        for (let i = 0; i < n; i++) {
            const x0 = i * span, x1 = x0 + span;
            d += `M${x0} ${y0}Q${x0 + span / 2} ${y0 + sag * 2} ${x1} ${y0}`;
            sprigs += `<div style="left:${x0}px;top:${y0}px">${SPRIG}</div>`;
            [0.25, 0.5, 0.75].forEach((t) => {
                const x = x0 + span * t, y = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * (y0 + sag * 2) + t * t * y0;
                bulbs += `<span class="dc-bulb" style="left:${x.toFixed(1)}px;top:${y.toFixed(1)}px;--bc:${warm[Math.floor(rnd() * warm.length)]};--bd:${(2.6 + rnd() * 3.2).toFixed(2)}s;--bl:${(-rnd() * 5).toFixed(2)}s;--sw:${(5 + rnd() * 3).toFixed(2)}s;--sd:${(-rnd() * 6).toFixed(2)}s"><i></i><b></b></span>`;
            });
        }
        lights.innerHTML = `<svg width="${W}" height="40" viewBox="0 0 ${W} 40" preserveAspectRatio="none"><path d="${d}" fill="none" stroke="#3a2c1c" stroke-width="1.6"/><path d="${d}" fill="none" stroke="rgba(201,163,92,.35)" stroke-width=".6"/></svg>`
            + sprigs.replace(/<div style="([^"]+)">/g, (m, st) => `<div class="dc-sprig-at" style="position:absolute;${st}">`) + bulbs;
    }
    function place() {
        stringLights();
        const sb = document.getElementById('sidebar'), mc = document.getElementById('main-content');
        if (!sb || !mc || !lanterns.length) return;
        const a = sb.getBoundingClientRect(), b = mc.getBoundingClientRect();
        const xs = [(a.right + b.left) / 2, (b.right + innerWidth) / 2];
        const show = innerWidth > 900 && a.width > 0 && b.left - a.right >= 8;
        lanterns.forEach((l, i) => { l.style.left = `${xs[i]}px`; l.hidden = !show; });
        glows.forEach((g, i) => { g.style.left = `${xs[i]}px`; g.hidden = !show; });
    }

    // iskry unoszące się znad paleniska
    function embers(on) {
        if (!on || reduce()) { if (canvas) { cancelAnimationFrame(raf); removeEventListener('resize', onResize); canvas.remove(); canvas = null; sparks = []; } return; }
        if (canvas) return;
        canvas = document.createElement('canvas'); canvas.className = 'dc-embers'; document.body.appendChild(canvas);
        const ctx = canvas.getContext('2d');
        // gotowy „duszek” iskry — rysowany raz, potem tylko kopiowany (bez gradientu w każdej klatce)
        const spr = document.createElement('canvas'); spr.width = spr.height = 32;
        const sx = spr.getContext('2d'), g = sx.createRadialGradient(16, 16, 0, 16, 16, 16);
        g.addColorStop(0, 'rgba(255,220,140,.85)'); g.addColorStop(0.4, 'rgba(255,140,40,.45)'); g.addColorStop(1, 'rgba(255,90,20,0)');
        sx.fillStyle = g; sx.fillRect(0, 0, 32, 32);
        onResize = () => { const r = Math.min(2, devicePixelRatio || 1); canvas.width = innerWidth * r; canvas.height = innerHeight * r; ctx.setTransform(r, 0, 0, r, 0, 0); ctx.globalCompositeOperation = 'lighter'; };
        onResize(); addEventListener('resize', onResize);
        const spawn = () => ({ x: Math.random() * innerWidth, y: innerHeight + 10, vx: (Math.random() - 0.5) * 0.25, vy: -(0.25 + Math.random() * 0.55), r: 0.6 + Math.random() * 1.6, life: 0, max: 380 + Math.random() * 420, ph: Math.random() * 6.28 });
        sparks = Array.from({ length: 26 }, () => { const s = spawn(); s.y = Math.random() * innerHeight; s.life = Math.random() * s.max; return s; });
        let last = 0;
        const tick = (t) => {
            raf = requestAnimationFrame(tick);
            if (document.hidden || t - last < 33) return;      // ~30 kl./s wystarczy
            last = t;
            ctx.clearRect(0, 0, innerWidth, innerHeight);
            for (let i = 0; i < sparks.length; i++) {
                const s = sparks[i];
                s.life++; s.ph += 0.03; s.x += s.vx + Math.sin(s.ph) * 0.25; s.y += s.vy;
                const k = s.life / s.max;
                if (k >= 1 || s.y < -10) { sparks[i] = spawn(); continue; }
                const d = s.r * 8;
                ctx.globalAlpha = Math.max(0, Math.sin(Math.PI * k));
                ctx.drawImage(spr, s.x - d / 2, s.y - d / 2, d, d);
            }
            ctx.globalAlpha = 1;
        };
        raf = requestAnimationFrame(tick);
    }
    function applyFx() {
        const on = fxOn();
        document.body.classList.toggle('dc-still', !on);
        embers(on);
        document.querySelectorAll('[data-decor-fx]').forEach(b => { b.classList.toggle('on', on); b.title = on ? 'Wyłącz iskry i migotanie świateł' : 'Włącz iskry i migotanie świateł'; });
    }
    function toggleButton() {
        const row = document.querySelector('#sidebar .sidebar-actions-row'); if (!row || row.querySelector('[data-decor-fx]')) return;
        const b = document.createElement('button'); b.className = 'btn-action dc-fx-btn'; b.type = 'button'; b.dataset.decorFx = '1';
        b.innerHTML = '<i class="fa-solid fa-fire-flame-curved"></i>';
        b.onclick = () => { try { localStorage.setItem('decor_fx', fxOn() ? '0' : '1'); } catch (e) {} applyFx(); };
        row.insertBefore(b, row.lastElementChild);
    }

    function init() {
        if (!document.body.classList.contains('theme-tavern')) document.body.classList.add('theme-tavern');
        document.body.classList.add('dc-on');
        corners(document.getElementById('sidebar'));
        corners(document.getElementById('main-content'));
        const hdr = document.querySelector('#sidebar .sidebar-header');
        if (hdr && !hdr.querySelector('.dc-chains')) { const c = document.createElement('span'); c.className = 'dc-chains'; hdr.prepend(c); }
        shelf(); ceiling(); toggleButton(); applyFx(); signVariant();
        addEventListener('resize', place);
        new MutationObserver(() => setTimeout(place, 260)).observe(document.body, { attributes: true, attributeFilter: ['class'] });
        setTimeout(place, 600);
    }
    // sama scenografia (belka, lampki, iskry) — dla stron bez menu, np. ekranu logowania
    function scene() {
        if (!beam) {
            beam = document.createElement('div'); beam.className = 'dc-beam'; document.body.appendChild(beam);
            lights = document.createElement('div'); lights.className = 'dc-lights'; lights.setAttribute('aria-hidden', 'true'); document.body.appendChild(lights);
        }
        stringLights(); addEventListener('resize', stringLights);
        embers(fxOn());
    }
    return { init, place, setSign, scene, SIGN_BG, LANTERN, SHELF };
})();
window.Decor = Decor;
document.addEventListener('DOMContentLoaded', () => setTimeout(() => { if (document.body.dataset.decor === 'off') return; try { Decor.init(); } catch (e) { console.warn('[ozdoby]', e); } }, 200));
