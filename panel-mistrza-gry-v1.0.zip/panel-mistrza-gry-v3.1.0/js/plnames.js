/* ============================================
   Polskie nazwy dla danych z podręcznika (SRD po angielsku):
   czary, klasy, cechy klas i ras, biegłości, języki, rasy,
   czas rzucania / zasięg / czas trwania.
   Tłumaczymy tylko to, co się wyświetla — zapisane dane zostają bez zmian,
   więc wyszukiwanie po angielskiej nazwie nadal działa.
   ============================================ */
const PL = (() => {
    const SPELLS = {
        'Acid Arrow': 'Kwasowa strzała', 'Acid Splash': 'Kwasowy rozprysk', 'Aid': 'Pomoc', 'Alarm': 'Alarm', 'Alter Self': 'Zmiana wyglądu',
        'Animal Friendship': 'Przyjaźń ze zwierzętami', 'Animal Messenger': 'Zwierzęcy posłaniec', 'Animal Shapes': 'Zwierzęce kształty', 'Animate Dead': 'Ożywienie zmarłych',
        'Animate Objects': 'Ożywienie przedmiotów', 'Antilife Shell': 'Powłoka antyżycia', 'Antimagic Field': 'Pole antymagii', 'Antipathy/Sympathy': 'Antypatia/sympatia',
        'Arcane Eye': 'Magiczne oko', 'Arcane Hand': 'Magiczna dłoń', 'Arcane Lock': 'Magiczny zamek', 'Arcane Sword': 'Magiczny miecz', "Arcanist's Magic Aura": 'Magiczna aura arkanisty',
        'Astral Projection': 'Projekcja astralna', 'Augury': 'Wróżba', 'Awaken': 'Przebudzenie', 'Bane': 'Zguba', 'Banishment': 'Wygnanie', 'Barkskin': 'Kora',
        'Beacon of Hope': 'Promień nadziei', 'Bestow Curse': 'Rzucenie klątwy', 'Black Tentacles': 'Czarne macki', 'Blade Barrier': 'Bariera ostrzy', 'Bless': 'Błogosławieństwo',
        'Blight': 'Uwiąd', 'Blindness/Deafness': 'Ślepota/głuchota', 'Blink': 'Mrugnięcie', 'Blur': 'Rozmycie', 'Branding Smite': 'Piętnujące uderzenie', 'Burning Hands': 'Płonące dłonie',
        'Call Lightning': 'Przywołanie błyskawic', 'Calm Emotions': 'Uspokojenie emocji', 'Chain Lightning': 'Łańcuch błyskawic', 'Charm Person': 'Zauroczenie osoby', 'Chill Touch': 'Mroźny dotyk',
        'Circle of Death': 'Krąg śmierci', 'Clairvoyance': 'Jasnowidzenie', 'Clone': 'Klon', 'Cloudkill': 'Zabójcza chmura', 'Color Spray': 'Barwny rozprysk', 'Command': 'Rozkaz',
        'Commune': 'Obcowanie', 'Commune with Nature': 'Obcowanie z naturą', 'Comprehend Languages': 'Zrozumienie języków', 'Compulsion': 'Przymus', 'Cone of Cold': 'Stożek zimna',
        'Confusion': 'Dezorientacja', 'Conjure Animals': 'Przywołanie zwierząt', 'Conjure Celestial': 'Przywołanie niebianina', 'Conjure Elemental': 'Przywołanie żywiołaka',
        'Conjure Fey': 'Przywołanie istoty fey', 'Conjure Minor Elementals': 'Przywołanie pomniejszych żywiołaków', 'Conjure Woodland Beings': 'Przywołanie leśnych istot',
        'Contact Other Plane': 'Kontakt z innym planem', 'Contagion': 'Zaraza', 'Contingency': 'Zabezpieczenie', 'Continual Flame': 'Wieczny płomień', 'Control Water': 'Kontrola wody',
        'Control Weather': 'Kontrola pogody', 'Counterspell': 'Kontrczar', 'Create Food and Water': 'Stworzenie jedzenia i wody', 'Create or Destroy Water': 'Stworzenie lub zniszczenie wody',
        'Create Undead': 'Stworzenie nieumarłego', 'Creation': 'Kreacja', 'Cure Wounds': 'Leczenie ran', 'Dancing Lights': 'Tańczące światła', 'Darkness': 'Ciemność',
        'Darkvision': 'Widzenie w ciemności', 'Daylight': 'Światło dnia', 'Death Ward': 'Ochrona przed śmiercią', 'Delayed Blast Fireball': 'Opóźniona kula ognia', 'Demiplane': 'Półplan',
        'Detect Evil and Good': 'Wykrycie zła i dobra', 'Detect Magic': 'Wykrycie magii', 'Detect Poison and Disease': 'Wykrycie trucizn i chorób', 'Detect Thoughts': 'Wykrycie myśli',
        'Dimension Door': 'Drzwi wymiarowe', 'Disguise Self': 'Przebranie', 'Disintegrate': 'Dezintegracja', 'Dispel Evil and Good': 'Rozproszenie zła i dobra', 'Dispel Magic': 'Rozproszenie magii',
        'Divination': 'Wieszczenie', 'Divine Favor': 'Boska łaska', 'Divine Word': 'Boskie słowo', 'Dominate Beast': 'Dominacja nad bestią', 'Dominate Monster': 'Dominacja nad potworem',
        'Dominate Person': 'Dominacja nad osobą', 'Dream': 'Senna wizja', 'Druidcraft': 'Druidzka sztuczka', 'Earthquake': 'Trzęsienie ziemi', 'Eldritch Blast': 'Mistyczny pocisk',
        'Enhance Ability': 'Wzmocnienie atrybutu', 'Enlarge/Reduce': 'Powiększenie/pomniejszenie', 'Entangle': 'Splątanie', 'Enthrall': 'Oczarowanie', 'Etherealness': 'Eteryczność',
        'Expeditious Retreat': 'Szybki odwrót', 'Eyebite': 'Złe oko', 'Fabricate': 'Wytworzenie', 'Faerie Fire': 'Ogień faerie', 'Faithful Hound': 'Wierny ogar', 'False Life': 'Fałszywe życie',
        'Fear': 'Strach', 'Feather Fall': 'Spadanie piórka', 'Feeblemind': 'Otępienie', 'Find Familiar': 'Znalezienie chowańca', 'Find Steed': 'Znalezienie wierzchowca',
        'Find the Path': 'Znalezienie ścieżki', 'Find Traps': 'Znalezienie pułapek', 'Finger of Death': 'Palec śmierci', 'Fire Bolt': 'Ognisty pocisk', 'Fire Shield': 'Ognista tarcza',
        'Fire Storm': 'Burza ognia', 'Fireball': 'Kula ognia', 'Flame Blade': 'Płomienne ostrze', 'Flame Strike': 'Słup ognia', 'Flaming Sphere': 'Płonąca kula', 'Flesh to Stone': 'Ciało w kamień',
        'Floating Disk': 'Unoszący się dysk', 'Fly': 'Lot', 'Fog Cloud': 'Mgła', 'Forbiddance': 'Zakazany teren', 'Forcecage': 'Klatka mocy', 'Foresight': 'Przewidywanie',
        'Freedom of Movement': 'Swoboda ruchu', 'Freezing Sphere': 'Lodowa kula', 'Gaseous Form': 'Gazowa postać', 'Gate': 'Wrota', 'Geas': 'Zobowiązanie', 'Gentle Repose': 'Spokojny spoczynek',
        'Giant Insect': 'Olbrzymi owad', 'Glibness': 'Wygadanie', 'Globe of Invulnerability': 'Kula niewrażliwości', 'Glyph of Warding': 'Glif ochronny', 'Goodberry': 'Dobrojagoda',
        'Grease': 'Smar', 'Greater Invisibility': 'Większa niewidzialność', 'Greater Restoration': 'Większe przywrócenie', 'Guardian of Faith': 'Strażnik wiary', 'Guards and Wards': 'Straże i osłony',
        'Guidance': 'Wskazówka', 'Guiding Bolt': 'Prowadzący pocisk', 'Gust of Wind': 'Podmuch wiatru', 'Hallow': 'Uświęcenie', 'Hallucinatory Terrain': 'Iluzoryczny teren', 'Harm': 'Krzywda',
        'Haste': 'Przyspieszenie', 'Heal': 'Uzdrowienie', 'Healing Word': 'Słowo leczenia', 'Heat Metal': 'Rozgrzanie metalu', 'Hellish Rebuke': 'Piekielna odpłata', "Heroes' Feast": 'Uczta bohaterów',
        'Heroism': 'Heroizm', 'Hideous Laughter': 'Ohydny śmiech', 'Hold Monster': 'Unieruchomienie potwora', 'Hold Person': 'Unieruchomienie osoby', 'Holy Aura': 'Święta aura',
        "Hunter's Mark": 'Znak łowcy', 'Hypnotic Pattern': 'Hipnotyczny wzór', 'Ice Storm': 'Burza lodowa', 'Identify': 'Identyfikacja', 'Illusory Script': 'Iluzoryczne pismo',
        'Imprisonment': 'Uwięzienie', 'Incendiary Cloud': 'Zapalająca chmura', 'Inflict Wounds': 'Zadanie ran', 'Insect Plague': 'Plaga owadów', 'Instant Summons': 'Natychmiastowe przywołanie',
        'Invisibility': 'Niewidzialność', 'Irresistible Dance': 'Nieodparty taniec', 'Jump': 'Skok', 'Knock': 'Otwarcie', 'Legend Lore': 'Wiedza legend', 'Lesser Restoration': 'Pomniejsze przywrócenie',
        'Levitate': 'Lewitacja', 'Light': 'Światło', 'Lightning Bolt': 'Błyskawica', 'Locate Animals or Plants': 'Odnalezienie zwierząt lub roślin', 'Locate Creature': 'Odnalezienie istoty',
        'Locate Object': 'Odnalezienie przedmiotu', 'Longstrider': 'Długi krok', 'Mage Armor': 'Zbroja maga', 'Mage Hand': 'Dłoń maga', 'Magic Circle': 'Magiczny krąg', 'Magic Jar': 'Magiczne naczynie',
        'Magic Missile': 'Magiczny pocisk', 'Magic Mouth': 'Magiczne usta', 'Magic Weapon': 'Magiczna broń', 'Magnificent Mansion': 'Wspaniała rezydencja', 'Major Image': 'Wielka iluzja',
        'Mass Cure Wounds': 'Masowe leczenie ran', 'Mass Heal': 'Masowe uzdrowienie', 'Mass Healing Word': 'Masowe słowo leczenia', 'Mass Suggestion': 'Masowa sugestia', 'Maze': 'Labirynt',
        'Meld into Stone': 'Stopienie z kamieniem', 'Mending': 'Naprawa', 'Message': 'Wiadomość', 'Meteor Swarm': 'Deszcz meteorów', 'Mind Blank': 'Pusty umysł', 'Minor Illusion': 'Pomniejsza iluzja',
        'Mirage Arcane': 'Magiczny miraż', 'Mirror Image': 'Lustrzane odbicia', 'Mislead': 'Zmylenie', 'Misty Step': 'Mglisty krok', 'Modify Memory': 'Modyfikacja pamięci', 'Moonbeam': 'Promień księżyca',
        'Move Earth': 'Przesunięcie ziemi', 'Nondetection': 'Niewykrywalność', 'Pass without Trace': 'Przejście bez śladu', 'Passwall': 'Przejście przez ścianę', 'Phantasmal Killer': 'Fantazmatyczny zabójca',
        'Phantom Steed': 'Widmowy wierzchowiec', 'Planar Ally': 'Sojusznik z innego planu', 'Planar Binding': 'Planarne spętanie', 'Plane Shift': 'Zmiana planu', 'Plant Growth': 'Wzrost roślin',
        'Poison Spray': 'Trujący rozprysk', 'Polymorph': 'Przemiana', 'Power Word Heal': 'Słowo mocy: uzdrowienie', 'Power Word Kill': 'Słowo mocy: śmierć', 'Power Word Stun': 'Słowo mocy: ogłuszenie',
        'Prayer of Healing': 'Modlitwa leczenia', 'Prestidigitation': 'Prestidigitacja', 'Prismatic Spray': 'Pryzmatyczny rozprysk', 'Prismatic Wall': 'Pryzmatyczna ściana', 'Private Sanctum': 'Prywatne sanktuarium',
        'Produce Flame': 'Wytworzenie płomienia', 'Programmed Illusion': 'Zaprogramowana iluzja', 'Project Image': 'Projekcja obrazu', 'Protection from Energy': 'Ochrona przed energią',
        'Protection from Evil and Good': 'Ochrona przed złem i dobrem', 'Protection from Poison': 'Ochrona przed trucizną', 'Purify Food and Drink': 'Oczyszczenie jedzenia i napoju',
        'Raise Dead': 'Wskrzeszenie zmarłego', 'Ray of Enfeeblement': 'Promień osłabienia', 'Ray of Frost': 'Promień mrozu', 'Regenerate': 'Regeneracja', 'Reincarnate': 'Reinkarnacja',
        'Remove Curse': 'Zdjęcie klątwy', 'Resilient Sphere': 'Odporna kula', 'Resistance': 'Odporność', 'Resurrection': 'Zmartwychwstanie', 'Reverse Gravity': 'Odwrócenie grawitacji',
        'Revivify': 'Ożywienie', 'Rope Trick': 'Sztuczka z liną', 'Sacred Flame': 'Święty płomień', 'Sanctuary': 'Sanktuarium', 'Scorching Ray': 'Palący promień', 'Scrying': 'Podglądanie',
        'Secret Chest': 'Sekretna skrzynia', 'See Invisibility': 'Widzenie niewidzialnego', 'Seeming': 'Pozór', 'Sending': 'Przesłanie', 'Sequester': 'Ukrycie', 'Shapechange': 'Zmiana kształtu',
        'Shatter': 'Roztrzaskanie', 'Shield': 'Tarcza', 'Shield of Faith': 'Tarcza wiary', 'Shillelagh': 'Pałka druida', 'Shocking Grasp': 'Porażający dotyk', 'Silence': 'Cisza',
        'Silent Image': 'Bezgłośna iluzja', 'Simulacrum': 'Symulakrum', 'Sleep': 'Uśpienie', 'Sleet Storm': 'Burza śnieżna', 'Slow': 'Spowolnienie', 'Spare the Dying': 'Oszczędzenie umierającego',
        'Speak with Animals': 'Mowa ze zwierzętami', 'Speak with Dead': 'Mowa z umarłymi', 'Speak with Plants': 'Mowa z roślinami', 'Spider Climb': 'Pajęcza wspinaczka', 'Spike Growth': 'Kolczasty gąszcz',
        'Spirit Guardians': 'Duchowi strażnicy', 'Spiritual Weapon': 'Duchowa broń', 'Stinking Cloud': 'Cuchnąca chmura', 'Stone Shape': 'Kształtowanie kamienia', 'Stoneskin': 'Kamienna skóra',
        'Storm of Vengeance': 'Burza zemsty', 'Suggestion': 'Sugestia', 'Sunbeam': 'Promień słońca', 'Sunburst': 'Rozbłysk słońca', 'Symbol': 'Symbol', 'Telekinesis': 'Telekineza',
        'Telepathic Bond': 'Więź telepatyczna', 'Teleport': 'Teleportacja', 'Teleportation Circle': 'Krąg teleportacji', 'Thaumaturgy': 'Taumaturgia', 'Thunderwave': 'Fala grzmotu',
        'Time Stop': 'Zatrzymanie czasu', 'Tiny Hut': 'Mała chatka', 'Tongues': 'Języki', 'Transport via Plants': 'Podróż przez rośliny', 'Tree Stride': 'Krok przez drzewa',
        'True Polymorph': 'Prawdziwa przemiana', 'True Resurrection': 'Prawdziwe zmartwychwstanie', 'True Seeing': 'Prawdziwe widzenie', 'True Strike': 'Pewne trafienie',
        'Unseen Servant': 'Niewidzialny sługa', 'Vampiric Touch': 'Wampiryczny dotyk', 'Vicious Mockery': 'Złośliwa kpina', 'Wall of Fire': 'Ściana ognia', 'Wall of Force': 'Ściana mocy',
        'Wall of Ice': 'Ściana lodu', 'Wall of Stone': 'Ściana kamienia', 'Wall of Thorns': 'Ściana cierni', 'Warding Bond': 'Więź ochronna', 'Water Breathing': 'Oddychanie pod wodą',
        'Water Walk': 'Chodzenie po wodzie', 'Web': 'Pajęczyna', 'Weird': 'Upiorny koszmar', 'Wind Walk': 'Wędrówka z wiatrem', 'Wind Wall': 'Ściana wiatru', 'Wish': 'Życzenie',
        'Word of Recall': 'Słowo powrotu', 'Zone of Truth': 'Strefa prawdy'
    };
    const CLASSES = { barbarian: 'Barbarzyńca', bard: 'Bard', cleric: 'Kleryk', druid: 'Druid', fighter: 'Wojownik', monk: 'Mnich', paladin: 'Paladyn', ranger: 'Łowca', rogue: 'Łotrzyk', sorcerer: 'Zaklinacz', warlock: 'Czarnoksiężnik', wizard: 'Czarodziej' };
    const RACES = { human: 'Człowiek', elf: 'Elf', dwarf: 'Krasnolud', halfling: 'Niziołek', gnome: 'Gnom', 'half-elf': 'Półelf', 'half-orc': 'Półork', tiefling: 'Tiefling', dragonborn: 'Smokowiec',
        'high elf': 'Wysoki elf', 'wood elf': 'Leśny elf', 'hill dwarf': 'Krasnolud wzgórzowy', 'mountain dwarf': 'Krasnolud górski', 'lightfoot halfling': 'Niziołek lekkostopy', 'stout halfling': 'Niziołek krzepki', 'rock gnome': 'Gnom skalny', 'forest gnome': 'Gnom leśny' };
    const FEATS = {
        'Expertise': 'Specjalizacja', 'Sneak Attack': 'Atak z ukrycia', "Thieves' Cant": 'Złodziejska gwara', 'Cunning Action': 'Sprytna akcja', 'Uncanny Dodge': 'Niesamowity unik', 'Evasion': 'Unik',
        'Reliable Talent': 'Niezawodny talent', 'Blindsense': 'Ślepowidzenie', 'Slippery Mind': 'Śliski umysł', 'Elusive': 'Nieuchwytny', 'Stroke of Luck': 'Uśmiech losu',
        'Spellcasting': 'Rzucanie czarów', 'Sorcerous Origin': 'Źródło magii', 'Font of Magic': 'Źródło mocy', 'Metamagic': 'Metamagia', 'Sorcerous Restoration': 'Odnowa magii',
        'Fighting Style': 'Styl walki', 'Second Wind': 'Drugi oddech', 'Action Surge': 'Przypływ działania', 'Extra Attack': 'Dodatkowy atak', 'Indomitable': 'Niezłomność', 'Martial Archetype': 'Archetyp wojownika',
        'Rage': 'Szał', 'Unarmored Defense': 'Obrona bez pancerza', 'Reckless Attack': 'Lekkomyślny atak', 'Danger Sense': 'Wyczucie zagrożenia', 'Primal Path': 'Ścieżka pierwotna',
        'Fast Movement': 'Szybki ruch', 'Feral Instinct': 'Zwierzęcy instynkt', 'Brutal Critical': 'Brutalne trafienie', 'Relentless Rage': 'Nieustępliwy szał',
        'Bardic Inspiration': 'Bardowska inspiracja', 'Jack of All Trades': 'Złota rączka', 'Song of Rest': 'Pieśń odpoczynku', 'Bard College': 'Kolegium bardów', 'Font of Inspiration': 'Źródło inspiracji',
        'Countercharm': 'Przeciwurok', 'Magical Secrets': 'Magiczne sekrety',
        'Divine Domain': 'Boska domena', 'Channel Divinity': 'Kanał boskości', 'Turn Undead': 'Odpędzenie nieumarłych', 'Destroy Undead': 'Zniszczenie nieumarłych', 'Divine Intervention': 'Boska interwencja',
        'Druidic': 'Druidzki', 'Wild Shape': 'Dzika postać', 'Druid Circle': 'Krąg druidów', 'Timeless Body': 'Ponadczasowe ciało', 'Beast Spells': 'Czary w zwierzęcej postaci', 'Archdruid': 'Arcydruid',
        'Martial Arts': 'Sztuki walki', 'Ki': 'Ki', 'Unarmored Movement': 'Ruch bez pancerza', 'Monastic Tradition': 'Tradycja klasztorna', 'Deflect Missiles': 'Odbijanie pocisków',
        'Slow Fall': 'Powolny upadek', 'Stunning Strike': 'Ogłuszający cios', 'Ki-Empowered Strikes': 'Ciosy wzmocnione ki', 'Stillness of Mind': 'Spokój umysłu', 'Purity of Body': 'Czystość ciała',
        'Divine Sense': 'Boski zmysł', 'Lay on Hands': 'Nałożenie rąk', 'Divine Smite': 'Boskie uderzenie', 'Divine Health': 'Boskie zdrowie', 'Sacred Oath': 'Święta przysięga',
        'Aura of Protection': 'Aura ochrony', 'Aura of Courage': 'Aura odwagi', 'Improved Divine Smite': 'Ulepszone boskie uderzenie', 'Cleansing Touch': 'Oczyszczający dotyk',
        'Favored Enemy': 'Ulubiony wróg', 'Natural Explorer': 'Naturalny odkrywca', 'Ranger Archetype': 'Archetyp łowcy', 'Primeval Awareness': 'Pierwotna świadomość',
        "Land's Stride": 'Krok przez teren', 'Hide in Plain Sight': 'Ukrycie na widoku', 'Vanish': 'Zniknięcie', 'Feral Senses': 'Dzikie zmysły', 'Foe Slayer': 'Pogromca wrogów',
        'Otherworldly Patron': 'Patron z innego świata', 'Pact Magic': 'Magia paktu', 'Eldritch Invocations': 'Mistyczne inwokacje', 'Pact Boon': 'Dar paktu', 'Mystic Arcanum': 'Mistyczne arkanum', 'Eldritch Master': 'Mistrz mistyki',
        'Arcane Recovery': 'Magiczna regeneracja', 'Arcane Tradition': 'Tradycja magiczna', 'Spell Mastery': 'Mistrzostwo czarów', 'Signature Spells': 'Popisowe czary',
        'Ability Score Improvement': 'Zwiększenie wartości atrybutów',
        // cechy ras
        'Darkvision': 'Widzenie w ciemności', 'Superior Darkvision': 'Lepsze widzenie w ciemności', 'Fey Ancestry': 'Dziedzictwo fey', 'Trance': 'Trans', 'Keen Senses': 'Wyostrzone zmysły',
        'Elf Weapon Training': 'Elfie szkolenie bojowe', 'Cantrip': 'Sztuczka', 'Extra Language': 'Dodatkowy język', 'Dwarven Resilience': 'Krasnoludzka odporność',
        'Dwarven Combat Training': 'Krasnoludzkie szkolenie bojowe', 'Stonecunning': 'Znawstwo kamienia', 'Tool Proficiency': 'Biegłość w narzędziach', 'Dwarven Toughness': 'Krasnoludzka wytrzymałość',
        'Dwarven Armor Training': 'Krasnoludzkie szkolenie w pancerzach', 'Lucky': 'Szczęściarz', 'Brave': 'Odwaga', 'Halfling Nimbleness': 'Niziołcza zwinność', 'Naturally Stealthy': 'Wrodzona skrytość',
        'Stout Resilience': 'Krzepka odporność', 'Draconic Ancestry': 'Smocze pochodzenie', 'Breath Weapon': 'Zionięcie', 'Damage Resistance': 'Odporność na obrażenia', 'Gnome Cunning': 'Gnomi spryt',
        "Artificer's Lore": 'Wiedza wynalazcy', 'Tinker': 'Majsterkowicz', 'Skill Versatility': 'Wszechstronność', 'Menacing': 'Groźny wygląd', 'Relentless Endurance': 'Nieustępliwa wytrzymałość',
        'Savage Attacks': 'Dzikie ataki', 'Hellish Resistance': 'Piekielna odporność', 'Infernal Legacy': 'Piekielne dziedzictwo', 'Mask of the Wild': 'Maska dziczy', 'Fleet of Foot': 'Chyży',
        'Age': 'Wiek', 'Size': 'Rozmiar', 'Speed': 'Szybkość', 'Languages': 'Języki', 'Alignment': 'Charakter', 'Ability Score Increase': 'Zwiększenie atrybutów',
        'Resourceful': 'Zaradny', 'Skillful': 'Utalentowany', 'Versatile': 'Wszechstronny', 'Alert': 'Czujny'
    };
    const PROFS = {
        'simple weapons': 'Broń prosta', 'martial weapons': 'Broń żołnierska', 'light armor': 'Lekki pancerz', 'medium armor': 'Średni pancerz', 'heavy armor': 'Ciężki pancerz', 'all armor': 'Wszystkie pancerze',
        'shields': 'Tarcze', 'simple': 'Broń prosta', 'martial': 'Broń żołnierska', 'light': 'Lekki pancerz',
        'daggers': 'Sztylety', 'dagger': 'Sztylet', 'darts': 'Strzałki', 'slings': 'Proce', 'quarterstaffs': 'Kije', 'light crossbows': 'Lekkie kusze', 'light crossbow': 'Lekka kusza', 'hand crossbows': 'Ręczne kusze',
        'hand crossbow': 'Ręczna kusza', 'longswords': 'Miecze długie', 'longsword': 'Miecz długi', 'rapiers': 'Rapiery', 'rapier': 'Rapier', 'shortswords': 'Miecze krótkie', 'shortsword': 'Miecz krótki',
        'clubs': 'Pałki', 'maces': 'Buzdygany', 'scimitars': 'Sejmitary', 'sickles': 'Sierpy', 'spears': 'Włócznie', 'javelins': 'Oszczepy', 'handaxes': 'Toporki', 'light hammers': 'Lekkie młoty',
        'greatclubs': 'Maczugi', 'battleaxes': 'Topory bojowe', 'warhammers': 'Młoty bojowe', 'longbows': 'Łuki długie', 'shortbows': 'Łuki krótkie',
        "thieves' tools": 'Narzędzia złodziejskie', "thieves tools": 'Narzędzia złodziejskie', 'gaming set': 'Zestaw do gier', 'disguise kit': 'Zestaw do przebieranek', 'forgery kit': 'Zestaw fałszerza',
        'herbalism kit': 'Zestaw zielarza', "poisoner's kit": 'Zestaw truciciela', "artisan's tools": 'Narzędzia rzemieślnicze', 'vehicles (land)': 'Pojazdy lądowe', 'vehicles (water)': 'Pojazdy wodne',
        "navigator's tools": 'Narzędzia nawigatora', 'musical instrument': 'Instrument muzyczny', "smith's tools": 'Narzędzia kowalskie', "brewer's supplies": 'Przybory piwowara', "mason's tools": 'Narzędzia kamieniarskie'
    };
    const LANGS = { common: 'Wspólny', dwarvish: 'Krasnoludzki', elvish: 'Elfi', giant: 'Olbrzymi', gnomish: 'Gnomi', goblin: 'Gobliński', halfling: 'Niziołczy', orc: 'Orczy', abyssal: 'Otchłani',
        celestial: 'Niebiański', draconic: 'Smoczy', 'deep speech': 'Mowa głębin', infernal: 'Piekielny', primordial: 'Pierwotny', sylvan: 'Sylwański', undercommon: 'Wspólny Podmroku',
        "thieves' cant": 'Złodziejska gwara', 'common sign language': 'Wspólny język migowy', druidic: 'Druidzki' };

    const cap = (s) => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
    const low = (s) => String(s ?? '').trim().toLowerCase();
    const spell = (n) => SPELLS[String(n ?? '').trim()] || n;
    const cls = (n) => CLASSES[low(n)] || n;
    const classes = (list) => (list || []).map(cls);
    const race = (n) => RACES[low(n)] || n;
    // cecha klasy/rasy: „Spellcasting: Sorcerer”, „Action Surge (1 use)”, „Bardic Inspiration (d6)”…
    function feat(n) {
        const s = String(n ?? '').trim(); if (!s) return s;
        if (FEATS[s]) return FEATS[s];
        let m = /^(.+?):\s*(.+)$/.exec(s);
        if (m && FEATS[m[1]]) return `${FEATS[m[1]]}: ${cls(m[2])}`;
        m = /^(.+?)\s*\((.+)\)$/.exec(s);
        if (m && FEATS[m[1]]) {
            const inner = m[2].replace(/(\d+)\s*uses?/i, (x, k) => `${k} ${+k === 1 ? 'użycie' : 'użycia'}`).replace(/\/\s*rest/i, '/odpoczynek').replace(/(\d+)\s*type/i, '$1 typ').replace(/(\d+)\s*terrain types?/i, '$1 teren').replace(/\bd(\d+)\b/g, 'k$1');
            return `${FEATS[m[1]]} (${inner})`;
        }
        return s;
    }
    const prof = (n) => PROFS[low(n)] || n;
    const profs = (list) => [...new Set((list || []).map(prof))];
    const lang = (n) => LANGS[low(n)] || n;
    const langs = (list) => (list || []).map(lang);
    // czas rzucania, zasięg, czas trwania
    const unit = (n, one, few, many) => { n = +n; const d = n % 10, h = n % 100; return n === 1 ? one : (d >= 2 && d <= 4 && !(h >= 12 && h <= 14)) ? few : many; };
    function time(t) {
        const s = String(t ?? '').trim(); if (!s) return s;
        return s.replace(/(\d+)\s+bonus actions?/i, (x, n) => `${n} akcja dodatkowa`).replace(/(\d+)\s+actions?/i, (x, n) => `${n} ${unit(n, 'akcja', 'akcje', 'akcji')}`)
            .replace(/(\d+)\s+reactions?/i, (x, n) => `${n} reakcja`).replace(/(\d+)\s+minutes?/i, (x, n) => `${n} ${unit(n, 'minuta', 'minuty', 'minut')}`)
            .replace(/(\d+)\s+hours?/i, (x, n) => `${n} ${unit(n, 'godzina', 'godziny', 'godzin')}`).replace(/^Action$/i, '1 akcja').replace(/^Reaction$/i, '1 reakcja').replace(/^Bonus Action$/i, '1 akcja dodatkowa')
            .replace(/, which you take when (.+)$/i, ' (gdy $1)');
    }
    function range(r) {
        const s = String(r ?? '').trim(); if (!s) return s;
        const M = { self: 'Na siebie', touch: 'Dotyk', sight: 'W zasięgu wzroku', unlimited: 'Nieograniczony', special: 'Specjalny' };
        if (M[low(s)]) return M[low(s)];
        return s.replace(/(\d+)\s*(feet|foot|ft\.?)/i, (x, n) => `${n} stóp`).replace(/(\d+)\s*miles?/i, (x, n) => `${n} ${unit(n, 'mila', 'mile', 'mil')}`).replace(/^Self\s*\((.+)\)$/i, 'Na siebie ($1)')
            .replace(/-foot-radius/i, ' stóp — promień').replace(/-foot cone/i, ' stóp — stożek').replace(/-foot line/i, ' stóp — linia').replace(/-foot cube/i, ' stóp — sześcian').replace(/-foot-radius sphere/i, ' stóp — kula');
    }
    function duration(d) {
        const s = String(d ?? '').trim(); if (!s) return s;
        const M = { instantaneous: 'Natychmiast', 'until dispelled': 'Do rozproszenia', 'until dispelled or triggered': 'Do rozproszenia lub uruchomienia', special: 'Specjalny', permanent: 'Stały' };
        if (M[low(s)]) return M[low(s)];
        return s.replace(/^Concentration,\s*/i, 'Koncentracja, ').replace(/up to\s+/i, 'do ')
            .replace(/(\d+)\s+rounds?/i, (x, n) => `${n} ${unit(n, 'runda', 'rundy', 'rund')}`).replace(/(\d+)\s+minutes?/i, (x, n) => `${n} ${unit(n, 'minuta', 'minuty', 'minut')}`)
            .replace(/(\d+)\s+hours?/i, (x, n) => `${n} ${unit(n, 'godzina', 'godziny', 'godzin')}`).replace(/(\d+)\s+days?/i, (x, n) => `${n} ${+n === 1 ? 'dzień' : 'dni'}`);
    }
    // nazwa po polsku + mały dopisek z oryginałem (do tytułów)
    const withEn = (pl, en, esc = (x) => x) => pl && en && pl !== en ? `${esc(pl)} <small class="pl-en">${esc(en)}</small>` : esc(pl || en || '');
    const MAPS = { SPELLS, CLASSES, RACES, FEATS, PROFS, LANGS };
    // tryb angielski: dane z podręcznika zostają w oryginale
    if (window.LANG === 'en') {
        const id = (x) => x, idl = (l) => (l || []).slice();
        return { spell: id, cls: (n) => cap(String(n ?? '')), classes: (l) => (l || []).map((n) => cap(String(n ?? ''))), race: (n) => cap(String(n ?? '')), feat: id, prof: id, profs: (l) => [...new Set(l || [])], lang: (n) => cap(String(n ?? '')), langs: (l) => (l || []).map((n) => cap(String(n ?? ''))), time: id, range: id, duration: id,
            withEn: (pl, en, esc = (x) => x) => esc(en || pl || ''), SPELLS: {}, MAPS, cap };
    }
    return { spell, cls, classes, race, feat, prof, profs, lang, langs, time, range, duration, withEn, SPELLS, MAPS, cap };
})();
window.PL = PL;
