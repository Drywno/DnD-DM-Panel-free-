/* ============================================
   D&D 5e DM Panel — Zarządzanie drużyną
   Odpoczynki, obrażenia/leczenie grupowe, XP,
   pasywne testy całej drużyny w jednej tabeli.
   ============================================ */

const PartyModule = (() => {
    const XP_TABLE = [0, 300, 900, 2700, 6500, 14000, 23000, 34000, 48000, 64000, 85000, 100000, 120000, 140000, 165000, 195000, 225000, 265000, 305000, 355000];
    const CLASS_KEYS = {
        barbarzyńca: 'barbarian', bard: 'bard', kleryk: 'cleric', druid: 'druid', wojownik: 'fighter', mnich: 'monk',
        paladyn: 'paladin', łowca: 'ranger', tropiciel: 'ranger', łotrzyk: 'rogue', zaklinacz: 'sorcerer',
        czarnoksiężnik: 'warlock', czarodziej: 'wizard'
    };
    const esc = (s) => App.esc(s);
    const mod = (score) => Math.floor(((score ?? 10) - 10) / 2);
    const fmt = (n) => (n >= 0 ? `+${n}` : `${n}`);

    const cid = () => App.getActiveCampaignId();
    const getChars = () => (cid() ? StorageManager.getCharacters(cid()) : []);
    const saveChars = (chars) => StorageManager.saveCharacters(cid(), chars);

    function classKey(c) {
        const k = String(c.class || '').toLowerCase().trim();
        return CLASS_KEYS[k] || k;
    }

    function passive(c, skill) {
        const attr = (APIClient.SKILLS[skill] || 'WIS').toLowerCase();
        const prof = (c.proficiencies || []).includes(skill) ? APIClient.proficiencyBonus(c.level || 1) : 0;
        const expertise = (c.expertise || []).includes(skill) ? APIClient.proficiencyBonus(c.level || 1) : 0;
        return 10 + mod(c.abilityScores?.[attr]) + prof + expertise;
    }

    function ensureHitDice(c) {
        if (!c.hitDicePool || !c.hitDicePool.max) {
            const lvl = c.level || 1;
            c.hitDicePool = { current: c.hitDicePool?.current ?? lvl, max: lvl, die: c.hitDicePool?.die || c.hitDie || 8 };
        }
        return c.hitDicePool;
    }

    function restTypes(c) {
        const map = {};
        try {
            if (window.ClassData && ClassData.getResourcesForLevel) {
                ClassData.getResourcesForLevel(classKey(c), c.level || 1, c).forEach(r => { map[r.key] = typeof r.restType === 'function' ? r.restType(c.level || 1) : r.restType; });
            }
        } catch (e) {}
        return map;
    }

    function hpClass(cur, max) {
        const p = max ? cur / max : 1;
        return p > 0.5 ? 'hp-high' : p > 0.25 ? 'hp-mid' : 'hp-low';
    }

    // ---------------------------------------------------------------
    // Render
    // ---------------------------------------------------------------
    function render() {
        const box = document.getElementById('party-panel');
        if (!box) return;
        const chars = getChars();
        if (!cid() || chars.length === 0) { box.innerHTML = ''; return; }

        const avgLevel = Math.round(chars.reduce((s, c) => s + (c.level || 1), 0) / chars.length);
        const minPP = Math.min(...chars.map(c => passive(c, 'Percepcja')));
        const maxPP = Math.max(...chars.map(c => passive(c, 'Percepcja')));
        document.getElementById('tab-characters')?.classList.remove('party-view-table');
        box.innerHTML = `
            <div class="party-toolbar">
                <div class="party-summary">
                    <span><b>${chars.length}</b> bohaterów</span>
                    <span>śr. poziom <b>${avgLevel}</b></span>
                    <span>pasywna Percepcja <b>${minPP === maxPP ? minPP : `${minPP}–${maxPP}`}</b></span>
                </div>
                <div class="party-actions">
                    <button class="btn-secondary btn-small" data-party="short"><i class="fa-solid fa-mug-hot"></i> Krótki odpoczynek</button>
                    <button class="btn-secondary btn-small" data-party="long"><i class="fa-solid fa-bed"></i> Długi odpoczynek</button>
                    <button class="btn-secondary btn-small" data-party="group-hp"><i class="fa-solid fa-heart-crack"></i> Obrażenia / leczenie grupy</button>
                    <button class="btn-primary btn-small" data-party="xp"><i class="fa-solid fa-star"></i> Przyznaj XP</button>
                </div>
            </div>
            ${window.Companions ? Companions.sectionHTML() : ''}`;
    }

    // ---------------------------------------------------------------
    // HP
    // ---------------------------------------------------------------
    function applyHP(chars, id, amount) {
        const c = chars.find(x => x.id === id);
        if (!c || !c.hp) return null;
        if (amount < 0) {
            let dmg = -amount;
            const fromTemp = Math.min(c.hp.temp || 0, dmg);
            c.hp.temp = (c.hp.temp || 0) - fromTemp;
            dmg -= fromTemp;
            c.hp.current = Math.max(0, c.hp.current - dmg);
        } else {
            const wasDown = c.hp.current <= 0;
            c.hp.current = Math.min(c.hp.max, c.hp.current + amount);
            if (wasDown && c.hp.current > 0 && c.deathSaves) c.deathSaves = { successes: 0, failures: 0 };
        }
        return c;
    }

    function refreshCards() {
        if (window.CharactersModule && document.getElementById('characters-list')) CharactersModule.activate();
    }

    function quickHP(id, sign) {
        const input = document.querySelector(`.pt-hp-input[data-hpin="${CSS.escape(id)}"]`);
        const val = Math.abs(parseInt(input?.value, 10) || 0) || 1;
        const chars = getChars();
        const c = applyHP(chars, id, sign * val);
        if (!c) return;
        saveChars(chars);
        refreshCards();
        App.showToast(`${c.name}: ${sign < 0 ? `−${val} PW` : `+${val} PW`} (${c.hp.current}/${c.hp.max})`, sign < 0 ? 'warning' : 'success');
    }

    function showGroupHP() {
        const chars = getChars();
        const list = chars.map(c => `<label class="pick-row"><input type="checkbox" value="${esc(c.id)}" checked> <span>${esc(c.name)}</span><small>${c.hp?.current ?? 0}/${c.hp?.max ?? 0} PW</small></label>`).join('');
        App.showModal('Obrażenia / leczenie grupy', `
            <div class="form-row">
                <div class="form-group"><label>Ile PW</label><input type="number" id="grp-hp" min="1" value="" placeholder="np. 14"></div>
                <div class="form-group"><label>Udany rzut obronny</label>
                    <label class="pick-row"><input type="checkbox" id="grp-half"> <span>połowa obrażeń dla zaznaczonych niżej</span></label></div>
            </div>
            <div class="form-group"><label>Kogo dotyczy</label><div class="pick-list">${list}</div></div>
            <p class="modal-hint">Obrażenia najpierw zdejmują tymczasowe PW. Leczenie postaci z 0 PW zeruje rzuty przeciw śmierci.</p>
        `, `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-secondary" id="grp-heal"><i class="fa-solid fa-heart"></i> Ulecz</button>
            <button class="btn-danger" id="grp-dmg"><i class="fa-solid fa-burst"></i> Zadaj obrażenia</button>`);
        const go = (sign) => {
            const amt = Math.abs(parseInt(document.getElementById('grp-hp').value, 10) || 0);
            if (!amt) { App.showToast('Podaj liczbę PW', 'warning'); return; }
            const half = document.getElementById('grp-half').checked && sign < 0;
            const ids = [...document.querySelectorAll('.pick-list input:checked')].map(i => i.value);
            const all = getChars();
            ids.forEach(id => applyHP(all, id, sign * (half ? Math.floor(amt / 2) : amt)));
            saveChars(all);
            App.closeModal();
            App.showToast(`${sign < 0 ? 'Obrażenia' : 'Leczenie'}: ${half ? Math.floor(amt / 2) : amt} PW × ${ids.length}`, sign < 0 ? 'warning' : 'success');
            refreshCards();
        };
        document.getElementById('grp-dmg').onclick = () => go(-1);
        document.getElementById('grp-heal').onclick = () => go(1);
    }

    // ---------------------------------------------------------------
    // Rests
    // ---------------------------------------------------------------
    function showShortRest() {
        const renderBody = () => getChars().map(c => {
            const hd = ensureHitDice(c);
            const conMod = mod(c.abilityScores?.con);
            return `<div class="rest-row">
                <div><b>${esc(c.name)}</b><small>${c.hp?.current ?? 0}/${c.hp?.max ?? 0} PW · KW ${hd.current}/${hd.max} (k${hd.die}${fmt(conMod)})</small></div>
                <button class="btn-secondary btn-small" data-hd="${esc(c.id)}" ${hd.current <= 0 || (c.hp?.current ?? 0) >= (c.hp?.max ?? 0) ? 'disabled' : ''}><i class="fa-solid fa-dice"></i> Wydaj KW</button>
            </div>`;
        }).join('');
        App.showModal('Krótki odpoczynek (1 godzina)', `
            <p class="modal-hint">Każda wydana Kość Wytrzymałości leczy wynik kości + mod. KON. Po zakończeniu odnowią się zdolności „na krótki odpoczynek” i komórki czarów Czarnoksiężnika.</p>
            <div id="rest-list" class="rest-list">${renderBody()}</div>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="short-done"><i class="fa-solid fa-check"></i> Zakończ odpoczynek</button>`);
        const listEl = document.getElementById('rest-list');
        listEl.addEventListener('click', (e) => {
            const b = e.target.closest('[data-hd]'); if (!b) return;
            const chars = getChars();
            const c = chars.find(x => x.id === b.dataset.hd); if (!c) return;
            const hd = ensureHitDice(c);
            if (hd.current <= 0) return;
            hd.current--;
            const roll = Math.floor(Math.random() * hd.die) + 1;
            const heal = Math.max(1, roll + mod(c.abilityScores?.con));
            c.hp.current = Math.min(c.hp.max, c.hp.current + heal);
            saveChars(chars);
            App.showToast(`${c.name}: k${hd.die} = ${roll} → +${heal} PW`, 'success');
            listEl.innerHTML = renderBody();
            refreshCards();
        });
        document.getElementById('short-done').onclick = () => {
            const chars = getChars();
            let restored = 0;
            chars.forEach(c => {
                const types = restTypes(c);
                Object.entries(c.classResources || {}).forEach(([k, r]) => {
                    if (types[k] === 'short' && r.current < r.max) { r.current = r.max; restored++; }
                });
                if (classKey(c) === 'warlock' && c.spellSlots) {
                    Object.values(c.spellSlots).forEach(s => { if (s.used) { s.used = 0; restored++; } });
                }
            });
            saveChars(chars);
            App.closeModal();
            App.showToast(`Krótki odpoczynek zakończony${restored ? ` — odnowiono ${restored} zasobów` : ''}`, 'success');
            refreshCards();
        };
    }

    function showLongRest() {
        App.showModal('Długi odpoczynek (8 godzin)', `
            <p>Cała drużyna:</p>
            <ul class="modal-list">
                <li>odzyskuje <b>wszystkie PW</b> (tymczasowe PW znikają),</li>
                <li>odzyskuje <b>połowę</b> maksymalnych Kości Wytrzymałości,</li>
                <li>odnawia <b>wszystkie komórki czarów i zdolności klasowe</b>,</li>
                <li>zeruje rzuty przeciw śmierci i zmniejsza wyczerpanie o 1.</li>
                <li class="modal-hint">Bohater z 0 PW na początku odpoczynku nie dostaje jego korzyści (PHB).</li>
            </ul>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="long-done"><i class="fa-solid fa-bed"></i> Odpocznij</button>`);
        document.getElementById('long-done').onclick = () => {
            const chars = getChars();
            // PHB: z długiego odpoczynku korzysta tylko ten, kto zaczyna go z co najmniej 1 PW
            const out = chars.filter(c => c.hp && (c.hp.current ?? 0) <= 0);
            chars.filter(c => !out.includes(c)).forEach(c => {
                if (c.hp) { c.hp.current = c.hp.max; c.hp.temp = 0; }
                const hd = ensureHitDice(c);
                hd.current = Math.min(hd.max, hd.current + Math.max(1, Math.floor(hd.max / 2)));
                Object.values(c.spellSlots || {}).forEach(s => { s.used = 0; });
                Object.values(c.classResources || {}).forEach(r => { if (typeof r.max === 'number') r.current = r.max; });
                c.deathSaves = { successes: 0, failures: 0 };
                if (c.exhaustion) c.exhaustion = Math.max(0, c.exhaustion - 1);
            });
            saveChars(chars);
            App.closeModal();
            App.showToast('Drużyna wypoczęta — PW, czary i zdolności odnowione', 'success');
            if (out.length) App.showToast(`Bez korzyści z odpoczynku (0 PW na początku): ${out.map(c => c.name).join(', ')}`, 'warning');
            refreshCards();
        };
    }

    // ---------------------------------------------------------------
    // XP
    // ---------------------------------------------------------------
    function showXP() {
        const chars = getChars();
        const list = chars.map(c => `<label class="pick-row"><input type="checkbox" value="${esc(c.id)}" checked> <span>${esc(c.name)}</span><small>poz. ${c.level || 1} · ${(c.xp || 0).toLocaleString(window.LOC || 'pl-PL')} XP</small></label>`).join('');
        App.showModal('Przyznaj doświadczenie', `
            <div class="form-row">
                <div class="form-group"><label>Ilość XP</label><input type="number" id="xp-amount" min="1" placeholder="np. 1100"></div>
                <div class="form-group"><label>Sposób</label>
                    <select id="xp-mode"><option value="split">Podziel po równo</option><option value="each">Każdy dostaje całość</option></select></div>
            </div>
            <div class="form-group"><label>Kto dostaje</label><div class="pick-list">${list}</div></div>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="xp-go"><i class="fa-solid fa-star"></i> Przyznaj</button>`);
        document.getElementById('xp-go').onclick = () => {
            const amt = Math.abs(parseInt(document.getElementById('xp-amount').value, 10) || 0);
            const ids = [...document.querySelectorAll('.pick-list input:checked')].map(i => i.value);
            if (!amt || !ids.length) { App.showToast('Podaj ilość XP i wybierz bohaterów', 'warning'); return; }
            const share = document.getElementById('xp-mode').value === 'split' ? Math.floor(amt / ids.length) : amt;
            const all = getChars();
            const ready = [];
            all.filter(c => ids.includes(c.id)).forEach(c => {
                c.xp = (c.xp || 0) + share;
                const next = XP_TABLE[c.level || 1];
                if (next !== undefined && c.xp >= next) ready.push(c.name);
            });
            saveChars(all);
            App.closeModal();
            App.showToast(`+${share} XP dla ${ids.length} bohaterów${ready.length ? ` · gotowi do awansu: ${ready.join(', ')}` : ''}`, 'success');
            refreshCards();
        };
    }

    // ---------------------------------------------------------------
    // Events
    // ---------------------------------------------------------------
    function bind() {
        const box = document.getElementById('party-panel');
        if (!box || box._bound) return;
        box._bound = true;
        box.addEventListener('change', (e) => { if (window.Companions?.onChange(e)) return; });
        box.addEventListener('click', (e) => {
            if (window.Companions?.onClick(e)) return;
            const a = e.target.closest('[data-party]');
            if (a) {
                ({ short: showShortRest, long: showLongRest, 'group-hp': showGroupHP, xp: showXP })[a.dataset.party]?.();
                return;
            }
            const h = e.target.closest('[data-hp]');
            if (h) { quickHP(h.dataset.hp, +h.dataset.sign); return; }
            const o = e.target.closest('[data-open]');
            if (o) CharactersModule.showCharacterSheet(o.dataset.open);
        });
        box.addEventListener('keydown', (e) => {
            const inp = e.target.closest('.pt-hp-input');
            if (inp && e.key === 'Enter') { e.preventDefault(); quickHP(inp.dataset.hpin, e.shiftKey ? 1 : -1); }
        });
    }

    // Re-render the panel every time the Characters view is activated
    if (window.CharactersModule) {
        const orig = CharactersModule.activate;
        CharactersModule.activate = function () {
            orig.apply(this, arguments);
            bind();
            render();
        };
    }

    return { render, showShortRest, showLongRest, showGroupHP, showXP, passive, XP_TABLE };
})();

window.PartyModule = PartyModule;
