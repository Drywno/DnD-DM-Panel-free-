/* ============================================
   D&D 5e — makiety 3D (modele low-poly)
   Prawdziwe bryły 3D składane z prostych kształtów (prostopadłościany, walce,
   stożki, dachy, skały…), renderowane w przeglądarce własnym małym silnikiem:
   bufor głębokości, światło z cieniami rzucanymi, faktury proceduralne
   (trawa, bruk, cegły, dachówka, deski, woda) i kontur jak na figurkach.
   Każdy typ miejsca renderuje się raz — wynik (obrazek) trafia do pamięci.
   Rzut ten sam co w dawnych makietach SVG (izometria), więc rozmiary się zgadzają.
   ============================================ */
const Models3D = (() => {
    // ---------- obraz: viewBox makiety -48 -82 96 110, punkt (0,0,0) świata = (48, 82) ----------
    const VB_W = 96, VB_H = 110, OX = 48, OY = 82;
    const OUT = 3;              // piksele obrazka na jednostkę viewBox
    const SS = 2;               // nadpróbkowanie (wygładzanie krawędzi)
    const PX = OUT * SS;        // piksele roboczego bufora na jednostkę
    const W = VB_W * PX, H = VB_H * PX;
    const U = 10, C = 0.8660254;
    const proj = (x, y, z) => [OX * PX + (x - y) * U * C * PX, OY * PX + ((x + y) * U * 0.5 - z * U) * PX, x + y + z];
    const VIEW = norm([1, 1, 1]);
    const LIGHT = norm([-0.62, 0.38, 0.78]);           // kierunek DO światła (z lewej, z przodu, z góry)
    const HALF = norm([LIGHT[0] + VIEW[0], LIGHT[1] + VIEW[1], LIGHT[2] + VIEW[2]]);

    function norm(v) { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
    const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
    const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    const hex = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
    const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

    // ---------- szum (faktury) ----------
    const ih = (x, y, z) => { let h = (x * 374761393 + y * 668265263 + z * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
    function vnoise(x, y, z) {
        const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z), xf = x - xi, yf = y - yi, zf = z - zi;
        const s = (t) => t * t * (3 - 2 * t), u = s(xf), v = s(yf), w = s(zf);
        const L = (a, b, t) => a + (b - a) * t;
        return L(L(L(ih(xi, yi, zi), ih(xi + 1, yi, zi), u), L(ih(xi, yi + 1, zi), ih(xi + 1, yi + 1, zi), u), v),
                 L(L(ih(xi, yi, zi + 1), ih(xi + 1, yi, zi + 1), u), L(ih(xi, yi + 1, zi + 1), ih(xi + 1, yi + 1, zi + 1), u), v), w);
    }
    const fbm = (x, y, z) => vnoise(x, y, z) * .6 + vnoise(x * 2.3, y * 2.3, z * 2.3) * .3 + vnoise(x * 5.1, y * 5.1, z * 5.1) * .1;

    // ---------- materiały: kolor zależny od miejsca na powierzchni ----------
    // f(p, n) → [r,g,b]; opcje: spec (połysk), glow (świeci samo), rough
    const C_ = (h) => hex(h);
    const vertUV = (p, n) => Math.abs(n[0]) > Math.abs(n[1]) ? [p[1], p[2]] : [p[0], p[2]];   // współrzędne na ścianie pionowej
    const MATS = {
        grass: { f: (p) => { const t = fbm(p[0] * 2.2, p[1] * 2.2, 0); const c = mix(C_('#5f8a34'), C_('#94b85a'), t); return vnoise(p[0] * 14, p[1] * 14, 1) > .82 ? mix(c, C_('#c9d68a'), .45) : c; } },
        meadow: { f: (p) => { const t = fbm(p[0] * 2, p[1] * 2, 3); let c = mix(C_('#6d9a3d'), C_('#a3c463'), t); if (vnoise(p[0] * 9, p[1] * 9, 7) > .86) c = mix(c, C_(vnoise(p[0], p[1], 2) > .5 ? '#e6d36a' : '#e8e2f0'), .7); return c; } },
        dirt: { f: (p) => mix(C_('#8f6a41'), C_('#b89463'), fbm(p[0] * 3, p[1] * 3, 5)) },
        path: { f: (p) => mix(C_('#a88a5e'), C_('#cbb084'), fbm(p[0] * 4, p[1] * 4, 9)) },
        sand: { f: (p) => mix(C_('#cdb37b'), C_('#ead7a4'), fbm(p[0] * 3, p[1] * 3, 2)) },
        snow: { f: (p) => mix(C_('#d9e3ec'), C_('#ffffff'), fbm(p[0] * 3, p[1] * 3, p[2] * 3)) },
        cobble: { f: (p) => { const s = 3.2, x = p[0] * s, y = p[1] * s + (Math.floor(p[0] * s) % 2) * .5; const fx = x - Math.floor(x), fy = y - Math.floor(y);
            const edge = Math.min(fx, 1 - fx, fy, 1 - fy); const base = mix(C_('#8e8576'), C_('#bdb3a0'), ih(Math.floor(x), Math.floor(y), 3));
            return edge < .09 ? mix(base, C_('#4f4639'), .6) : base; } },
        stone: { f: (p, n) => { if (n[2] > .7) return mix(C_('#a79e8c'), C_('#c9c0ad'), fbm(p[0] * 3, p[1] * 3, 1));
            const [u, v] = vertUV(p, n); const row = Math.floor(v * 4.2), x = u * 2.6 + (row % 2) * .5, fx = x - Math.floor(x), fy = v * 4.2 - row;
            const base = mix(C_('#a59c8a'), C_('#cfc6b2'), ih(Math.floor(x), row, 5) * .7 + fbm(u * 6, v * 6, 2) * .3);
            return (fy < .1 || fx < .05) ? mix(base, C_('#5e5547'), .55) : base; } },
        darkstone: { f: (p, n) => { const [u, v] = n[2] > .7 ? [p[0], p[1]] : vertUV(p, n); const row = Math.floor(v * 4), x = u * 2.4 + (row % 2) * .5, fx = x - Math.floor(x), fy = v * 4 - row;
            const base = mix(C_('#5d5a55'), C_('#7f7b73'), ih(Math.floor(x), row, 8)); return (fy < .1 || fx < .06) ? mix(base, C_('#2e2b27'), .55) : base; } },
        rock: { f: (p) => mix(C_('#77706a'), C_('#a9a296'), fbm(p[0] * 2.5, p[1] * 2.5, p[2] * 2.5)) },
        mountain: { f: (p, n) => { const r = mix(C_('#6e675f'), C_('#a39b8e'), fbm(p[0] * 2, p[1] * 2, p[2] * 2)); const sn = p[2] + (fbm(p[0] * 3, p[1] * 3, 4) - .5) * .9;
            return sn > 3.1 && n[2] > .2 ? C_('#f4f7fb') : sn > 1.3 && n[2] > .55 ? mix(r, C_('#7f9a52'), .25) : r; } },
        plaster: { f: (p, n) => mix(C_('#e3d5b6'), C_('#f6eedb'), fbm(p[0] * 4, p[1] * 4, p[2] * 4)) },
        timber: { f: (p, n) => { const [u, v] = vertUV(p, n); const fu = ((u * 1.6) % 1 + 1) % 1, fv = ((v * 1.25) % 1 + 1) % 1;
            const beam = fu < .09 || fv < .1 || Math.abs(fu - fv) < .06; return beam ? mix(C_('#4a2f1a'), C_('#5e3c22'), fbm(u * 8, v * 8, 1)) : mix(C_('#e8dcc0'), C_('#f6eedb'), fbm(u * 5, v * 5, 2)); } },
        wood: { f: (p, n) => { const [u, v] = n[2] > .7 ? [p[0] + p[1] * .1, p[1]] : vertUV(p, n); const plank = Math.floor(u * 5); const g = fbm(u * 2, v * 9 + plank, plank);
            const c = mix(C_('#6f4627'), C_('#a9764a'), g * .8 + ih(plank, 1, 1) * .2); return (u * 5 - plank) < .08 ? mix(c, C_('#3a2412'), .6) : c; } },
        darkwood: { f: (p, n) => { const [u, v] = vertUV(p, n); return mix(C_('#3e2716'), C_('#5c3b22'), fbm(u * 3, v * 12, 4)); } },
        roof: { f: (p) => { const r = Math.floor(p[2] * 5.5), x = (p[0] - p[1]) * 3 + (r % 2) * .5, fz = p[2] * 5.5 - r, fx = x - Math.floor(x);
            const base = mix(C_('#9b3b28'), C_('#c4573c'), ih(Math.floor(x), r, 4) * .6 + .2); return fz < .14 ? mix(base, C_('#5a1d12'), .55) : fx < .06 ? mix(base, C_('#6b2414'), .35) : base; } },
        slate: { f: (p) => { const r = Math.floor(p[2] * 6), x = (p[0] - p[1]) * 3.5 + (r % 2) * .5, fz = p[2] * 6 - r;
            const base = mix(C_('#4a5869'), C_('#6f8197'), ih(Math.floor(x), r, 6)); return fz < .14 ? mix(base, C_('#232b35'), .55) : base; } },
        bluetile: { f: (p) => { const r = Math.floor(p[2] * 6); const base = mix(C_('#2f5f9a'), C_('#4c80bd'), ih(Math.floor((p[0] - p[1]) * 3), r, 6)); return p[2] * 6 - r < .14 ? mix(base, C_('#16304f'), .5) : base; } },
        thatch: { f: (p) => { const s = fbm((p[0] - p[1]) * 9, p[2] * 1.5, 1); const r = p[2] * 4 - Math.floor(p[2] * 4); const c = mix(C_('#a77f37'), C_('#dcb866'), s); return r < .12 ? mix(c, C_('#6e4f1c'), .45) : c; } },
        gold: { f: (p, n) => mix(C_('#8a6418'), C_('#e8c25a'), Math.max(0, Math.min(1, .35 + n[2] * .45 + (fbm(p[0] * 6, p[1] * 6, p[2] * 6) - .5) * .5))), spec: 2.2 },
        brass: { f: () => C_('#b8862e'), spec: .8 },
        iron: { f: (p) => mix(C_('#3a3d42'), C_('#5b6068'), fbm(p[0] * 6, p[1] * 6, p[2] * 6)), spec: .5 },
        water: { f: (p) => { const w = fbm(p[0] * 2.2 + p[1] * .6, p[1] * 3.4, 2); let c = mix(C_('#2e6c9a'), C_('#4f95c4'), w); if (vnoise(p[0] * 7 + p[1] * 2, p[1] * 11, 3) > .8) c = mix(c, C_('#d8eef8'), .55); return c; }, spec: .9 },
        leaves: { f: (p) => mix(C_('#2f5f2a'), C_('#5f9440'), fbm(p[0] * 4, p[1] * 4, p[2] * 4)) },
        pine: { f: (p) => mix(C_('#1f4a30'), C_('#3e7349'), fbm(p[0] * 5, p[1] * 5, p[2] * 5)) },
        deadwood: { f: (p) => mix(C_('#4b4038'), C_('#6d6157'), fbm(p[0] * 6, p[1] * 6, p[2] * 6)) },
        trunk: { f: (p) => mix(C_('#4e3420'), C_('#6f4b2d'), fbm(p[0] * 9, p[1] * 9, p[2] * 2)) },
        red: { f: () => C_('#b53a2a') }, blue: { f: () => C_('#2f5d9e') }, green: { f: () => C_('#3d7a3e') }, teal: { f: () => C_('#3b9b94') },
        yellow: { f: () => C_('#e0b93e') }, purple: { f: () => C_('#7b4aa6') }, white: { f: () => C_('#efe9dc') }, black: { f: () => C_('#211a14') },
        cloth: { f: (p) => mix(C_('#d9c79f'), C_('#efe2c2'), fbm(p[0] * 6, p[1] * 6, p[2] * 6)) },
        hay: { f: (p) => mix(C_('#b88f37'), C_('#e6c768'), fbm(p[0] * 10, p[1] * 10, p[2] * 3)) },
        crop: { f: (p) => { const row = ((p[0] * 3.2) % 1 + 1) % 1; return row < .5 ? mix(C_('#5a3e22'), C_('#7a5532'), fbm(p[0] * 5, p[1] * 5, 1)) : mix(C_('#6a9a35'), C_('#a7c45a'), fbm(p[0] * 7, p[1] * 7, 2)); } },
        earth: { f: (p) => { const b = p[2] < -.22 ? C_('#5a3f26') : C_('#7a5636'); return mix(b, C_('#3e2a18'), fbm(p[0] * 3, p[1] * 3, p[2] * 8) * .5); } },
        window: { f: () => C_('#2a2018') },
        lit: { f: () => C_('#ffd77a'), glow: 1 },
        fire: { f: (p) => mix(C_('#ff8a2a'), C_('#ffe37a'), Math.min(1, Math.max(0, p[2] * 2.2 - .6))), glow: 1 },
        magic: { f: (p) => mix(C_('#7f4dff'), C_('#b8f0ff'), fbm(p[0] * 3, p[1] * 3, p[2] * 3)), glow: 1 },
        crystal: { f: (p) => mix(C_('#69c3e6'), C_('#d6f6ff'), fbm(p[0] * 4, p[1] * 4, p[2] * 4)), spec: 1.4, glow: .35 },
        lava: { f: (p) => mix(C_('#c2350f'), C_('#ffb34a'), fbm(p[0] * 4, p[1] * 4, 0)), glow: 1 },
        bone: { f: () => C_('#e8dfc8') },
        sail: { f: (p) => { const c = mix(C_('#e4d6b4'), C_('#f6eedb'), fbm(p[0] * 5, p[1] * 5, p[2] * 5)); return p[2] > 1.22 && p[2] < 1.44 ? mix(c, C_('#a8322a'), .85) : c; } },
        cavemouth: { f: (p) => { const u = (p[0] + .2) * .7071 - (p[1] + .35) * .7071, d = Math.min(1, Math.hypot(u / .36, (p[2] - .3) / .46)); return mix(C_('#050403'), C_('#3b2c20'), d * d * d); }, glow: 1 }
    };

    // ---------- scena: wielokąty (wypukłe ściany brył) ----------
    let faces = [], fx = [], objId = 0, rnd = Math.random;
    const seed = (s) => { let x = (s >>> 0) || 7; rnd = () => ((x = (Math.imul(x, 1664525) + 1013904223) >>> 0) / 4294967296); };
    const R = (a, b) => a + rnd() * (b - a);
    // dodaj bryłę wypukłą: lista ścian (wielokątów) — normalne wyliczane i kierowane na zewnątrz
    function solid(polys, mat, opt = {}) {
        const id = ++objId;
        const all = polys.flat(); const ctr = all.reduce((a, p) => [a[0] + p[0], a[1] + p[1], a[2] + p[2]], [0, 0, 0]).map(v => v / all.length);
        polys.forEach(pl => {
            let n = [0, 0, 0];
            for (let i = 0; i < pl.length; i++) { const a = pl[i], b = pl[(i + 1) % pl.length]; n[0] += (a[1] - b[1]) * (a[2] + b[2]); n[1] += (a[2] - b[2]) * (a[0] + b[0]); n[2] += (a[0] - b[0]) * (a[1] + b[1]); }
            n = norm(n);
            const fc = pl.reduce((a, p) => [a[0] + p[0], a[1] + p[1], a[2] + p[2]], [0, 0, 0]).map(v => v / pl.length);
            if (!opt.thin && dot(n, sub(fc, ctr)) < 0) n = n.map(v => -v);
            faces.push({ pts: pl, n, mat: MATS[mat] ? mat : 'stone', obj: id, thin: !!opt.thin });
        });
        return id;
    }
    // prostopadłościan (x,y,z róg; w wzdłuż x, d wzdłuż y, h w górę)
    function box(x, y, z, w, d, h, mat, top = mat) {
        const a = [x, y, z], b = [x + w, y, z], c = [x + w, y + d, z], e = [x, y + d, z];
        const A = [x, y, z + h], B = [x + w, y, z + h], Cc = [x + w, y + d, z + h], E = [x, y + d, z + h];
        const id = solid([[a, b, c, e], [A, B, Cc, E], [a, b, B, A], [b, c, Cc, B], [c, e, E, Cc], [e, a, A, E]], mat);
        if (top !== mat) faces.forEach(f => { if (f.obj === id && f.n[2] > .99) f.mat = top; });
        return id;
    }
    // walec / ostrosłup ścięty (n boków); r2 = promień u góry (0 → stożek)
    function cyl(cx, cy, z, r, h, mat, n = 12, r2 = r, topMat = mat, rot = 0) {
        const lo = [], hi = [];
        for (let i = 0; i < n; i++) { const a = rot + i / n * Math.PI * 2; lo.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r, z]); hi.push([cx + Math.cos(a) * r2, cy + Math.sin(a) * r2, z + h]); }
        const polys = [lo.slice().reverse()];
        if (r2 > 0.001) polys.push(hi);
        for (let i = 0; i < n; i++) { const j = (i + 1) % n; polys.push(r2 > 0.001 ? [lo[i], lo[j], hi[j], hi[i]] : [lo[i], lo[j], [cx, cy, z + h]]); }
        const id = solid(polys, mat);
        if (topMat !== mat && r2 > 0.001) faces.forEach(f => { if (f.obj === id && f.n[2] > .99) f.mat = topMat; });
        return id;
    }
    const cone = (cx, cy, z, r, h, mat, n = 12, rot = 0) => cyl(cx, cy, z, r, h, mat, n, 0, mat, rot);
    // dach dwuspadowy: kalenica wzdłuż x (axis 'x') albo y; okap wystaje o o
    function gable(x, y, z, w, d, h, mat, axis = 'x', o = .12, wallMat = null) {
        let id;
        if (axis === 'x') {
            const x0 = x - o, x1 = x + w + o, y0 = y - o, y1 = y + d + o, ym = y + d / 2;
            id = solid([[[x0, y0, z], [x1, y0, z], [x1, ym, z + h], [x0, ym, z + h]], [[x0, y1, z], [x1, y1, z], [x1, ym, z + h], [x0, ym, z + h]],
                [[x0, y0, z], [x0, y1, z], [x0, ym, z + h]], [[x1, y0, z], [x1, y1, z], [x1, ym, z + h]], [[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]]], mat);
            if (wallMat) faces.forEach(f => { if (f.obj === id && Math.abs(f.n[0]) > .9) f.mat = wallMat; });
        } else {
            const x0 = x - o, x1 = x + w + o, y0 = y - o, y1 = y + d + o, xm = x + w / 2;
            id = solid([[[x0, y0, z], [x0, y1, z], [xm, y1, z + h], [xm, y0, z + h]], [[x1, y0, z], [x1, y1, z], [xm, y1, z + h], [xm, y0, z + h]],
                [[x0, y0, z], [x1, y0, z], [xm, y0, z + h]], [[x0, y1, z], [x1, y1, z], [xm, y1, z + h]], [[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]]], mat);
            if (wallMat) faces.forEach(f => { if (f.obj === id && Math.abs(f.n[1]) > .9) f.mat = wallMat; });
        }
        return id;
    }
    // dach kopertowy / ostrosłup
    function hip(x, y, z, w, d, h, mat, o = .12) {
        const x0 = x - o, x1 = x + w + o, y0 = y - o, y1 = y + d + o;
        if (Math.abs(w - d) < .05) { const t = [x + w / 2, y + d / 2, z + h]; return solid([[[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]], [[x0, y0, z], [x1, y0, z], t], [[x1, y0, z], [x1, y1, z], t], [[x1, y1, z], [x0, y1, z], t], [[x0, y1, z], [x0, y0, z], t]], mat); }
        if (w > d) { const a = [x + d / 2, y + d / 2, z + h], b = [x + w - d / 2, y + d / 2, z + h];
            return solid([[[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]], [[x0, y0, z], [x1, y0, z], b, a], [[x0, y1, z], [x1, y1, z], b, a], [[x0, y0, z], [x0, y1, z], a], [[x1, y0, z], [x1, y1, z], b]], mat); }
        const a = [x + w / 2, y + w / 2, z + h], b = [x + w / 2, y + d - w / 2, z + h];
        return solid([[[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]], [[x0, y0, z], [x0, y1, z], b, a], [[x1, y0, z], [x1, y1, z], b, a], [[x0, y0, z], [x1, y0, z], a], [[x0, y1, z], [x1, y1, z], b]], mat);
    }
    // bryła z ikosaedru z poszarpaniem (skały, korony drzew, krzaki, kopuły)
    const ICO = (() => { const t = (1 + Math.sqrt(5)) / 2; const v = [[-1, t, 0], [1, t, 0], [-1, -t, 0], [1, -t, 0], [0, -1, t], [0, 1, t], [0, -1, -t], [0, 1, -t], [t, 0, -1], [t, 0, 1], [-t, 0, -1], [-t, 0, 1]].map(norm);
        const f = [[0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11], [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8], [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9], [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1]];
        // jeden podział — 80 trójkątów
        const vs = v.slice(), cache = {}; const mid = (a, b) => { const k = a < b ? a + '_' + b : b + '_' + a; if (cache[k] != null) return cache[k]; vs.push(norm([(vs[a][0] + vs[b][0]) / 2, (vs[a][1] + vs[b][1]) / 2, (vs[a][2] + vs[b][2]) / 2])); return (cache[k] = vs.length - 1); };
        const f2 = []; f.forEach(([a, b, c]) => { const ab = mid(a, b), bc = mid(b, c), ca = mid(c, a); f2.push([a, ab, ca], [b, bc, ab], [c, ca, bc], [ab, bc, ca]); });
        return { v: vs, f: f2, v0: v, f0: f };
    })();
    function blob(cx, cy, cz, rx, ry, rz, mat, jit = .15, fine = true, flatBottom = true) {
        const src = fine ? ICO : { v: ICO.v0, f: ICO.f0 };
        const vv = src.v.map(p => { const k = 1 + (rnd() - .5) * 2 * jit; let z = p[2] * rz * k; if (flatBottom && z < -rz * .35) z = -rz * .35; return [cx + p[0] * rx * k, cy + p[1] * ry * k, cz + z]; });
        return solid(src.f.map(([a, b, c]) => [vv[a], vv[b], vv[c]]), mat);
    }
    // płaska płyta z wielokąta (ostrosłup ścięty z dowolnej podstawy) — kadłuby, kamienie nagrobne itp.
    function prism(pts2, z, h, mat, topMat = mat) {
        const lo = pts2.map(([x, y]) => [x, y, z]), hi = pts2.map(([x, y]) => [x, y, z + h]);
        const polys = [lo.slice().reverse(), hi]; for (let i = 0; i < lo.length; i++) { const j = (i + 1) % lo.length; polys.push([lo[i], lo[j], hi[j], hi[i]]); }
        const id = solid(polys, mat);
        if (topMat !== mat) faces.forEach(f => { if (f.obj === id && f.n[2] > .99) f.mat = topMat; });
        return id;
    }
    // cienka płaszczyzna (żagiel, flaga, szyld) — dwustronna
    function plane(pts, mat) { const id = ++objId; let n = norm(cross(sub(pts[1], pts[0]), sub(pts[2], pts[0]))); faces.push({ pts, n, mat, obj: id, thin: true }); return id; }

    // ---------- klocki budowlane ----------
    // podstawka: nieregularny krążek z ziemią po bokach
    let baseR = 2.1;
    function base(top = 'grass', r = 2.15, th = .42) {
        baseR = r;
        const n = 20, pts = [];
        for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, rr = r * (1 + (rnd() - .5) * .1); pts.push([Math.cos(a) * rr * 1.03, Math.sin(a) * rr * 1.03]); }
        prism(pts, -th, th, 'earth', top);
    }
    // płaska łata na podstawce (ścieżka, pole) — przycięta do krawędzi podstawki
    function patch(pts2, mat, z = .004) {
        const lim = baseR * .96, out = [];
        for (let i = 0; i < pts2.length; i++) {
            const a = pts2[i], b = pts2[(i + 1) % pts2.length];
            for (let k = 0; k < 8; k++) { const t = k / 8, x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t, r = Math.hypot(x, y); out.push(r > lim ? [x / r * lim, y / r * lim] : [x, y]); }
        }
        const id = ++objId;
        // wielokąt może być wklęsły po przycięciu — dzielimy na wachlarz od środka ciężkości
        const c = out.reduce((p, q) => [p[0] + q[0] / out.length, p[1] + q[1] / out.length], [0, 0]);
        for (let i = 0; i < out.length; i++) { const q = out[i], r = out[(i + 1) % out.length]; faces.push({ pts: [[c[0], c[1], z], [q[0], q[1], z], [r[0], r[1], z]], n: [0, 0, 1], mat, obj: id, flat: true }); }
    }
    function disc(cx, cy, r, mat, z = .006, n = 14) { const p = []; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; p.push([cx + Math.cos(a) * r * (1 + (rnd() - .5) * .25), cy + Math.sin(a) * r * (1 + (rnd() - .5) * .25)]); } patch(p, mat, z); }
    // okno / drzwi na ścianie: side 'y' = ściana o normalnej +y (lewa przednia), 'x' = +x (prawa przednia)
    function win(side, a, b, z, w = .26, h = .34, mat = 'window') {
        if (side === 'y') box(a - w / 2, b, z, w, .04, h, mat); else box(b, a - w / 2, z, .04, w, h, mat);
    }
    function house(x, y, w, d, h, wall, roofMat, opt = {}) {
        box(x, y, 0, w, d, h, wall);
        const axis = opt.axis || (w >= d ? 'x' : 'y');
        const rh = opt.rh || Math.min(w, d) * .62;
        if (opt.hip) hip(x, y, h, w, d, rh, roofMat); else gable(x, y, h, w, d, rh, roofMat, axis, .13, wall === 'timber' || wall === 'plaster' ? wall : 'plaster');
        // drzwi i okna od frontu (+y i +x)
        if (opt.door !== false) win('y', x + w * (opt.doorAt ?? .3), y + d, 0, .3, Math.min(.62, h * .7), 'darkwood');
        const fl = Math.max(1, Math.floor(h / .85));
        for (let k = 0; k < fl; k++) {
            const zz = .3 + k * .8;
            if (zz + .3 > h) break;
            if (w > .9) win('y', x + w * .72, y + d, zz, .24, .28, opt.lit ? 'lit' : 'window');
            if (k > 0 && w > 1.2) win('y', x + w * .3, y + d, zz, .24, .28, opt.lit ? 'lit' : 'window');
            if (d > .7) win('x', y + d * .35, x + w, zz, .24, .28, opt.lit && k === 0 ? 'lit' : 'window');
            if (d > 1.3) win('x', y + d * .72, x + w, zz, .24, .28, 'window');
        }
        if (opt.chimney) { const cx = x + w * (opt.chimney > 0 ? .75 : .25), cy = y + d * .35; box(cx - .1, cy - .1, h, .22, .22, rh + .25, 'stone'); fx.push({ k: 'smoke', p: [cx, cy, h + rh + .3] }); }
    }
    function tower(cx, cy, r, h, wall, roofMat, opt = {}) {
        cyl(cx, cy, 0, r, h, wall, opt.n || 12);
        if (opt.cren) { cyl(cx, cy, h, r * 1.12, .12, wall, opt.n || 12); for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; box(cx + Math.cos(a) * r * .98 - .07, cy + Math.sin(a) * r * .98 - .07, h + .12, .14, .14, .16, wall); } }
        if (roofMat) cone(cx, cy, h + (opt.cren ? .12 : 0), r * (opt.cren ? .95 : 1.18), opt.rh || r * 2.2, roofMat, opt.n || 12);
        for (let k = 0; k < Math.floor(h / .9); k++) { const zz = .45 + k * .9; if (zz + .3 < h) { win('y', cx, cy + r * .97, zz, .16, .28, opt.lit && k % 2 ? 'lit' : 'window'); win('x', cy, cx + r * .97, zz + .2, .16, .28); } }
        if (opt.flag) flag(cx, cy, h + (opt.rh || r * 2.2) + (opt.cren ? .12 : 0), opt.flag);
    }
    function sqTower(x, y, s, h, wall, roofMat, opt = {}) {
        box(x, y, 0, s, s, h, wall);
        if (opt.cren !== false) { box(x - .06, y - .06, h, s + .12, s + .12, .1, wall); const n = Math.max(2, Math.round(s / .3));
            for (let i = 0; i < n; i++) { const t = (i + .5) / n * (s + .12) - .06; [[x + t - .06, y - .06], [x + t - .06, y + s - .06], [x - .06, y + t - .06], [x + s - .06, y + t - .06]].forEach(([a, b]) => box(a, b, h + .1, .12, .12, .16, wall)); } }
        if (roofMat) hip(x, y, h + .1, s, s, s * .9, roofMat);
        win('y', x + s / 2, y + s, h * .55, .16, .3); win('x', y + s / 2, x + s, h * .55, .16, .3);
        if (opt.flag) flag(x + s / 2, y + s / 2, h + .1 + (roofMat ? s * .9 : .2), opt.flag);
    }
    function wall(x0, y0, x1, y1, h, t, mat, cren = true) {
        const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy);
        if (Math.abs(dy) < 1e-6) box(Math.min(x0, x1), y0 - t / 2, 0, Math.abs(dx), t, h, mat); else box(x0 - t / 2, Math.min(y0, y1), 0, t, Math.abs(dy), h, mat);
        if (cren) { const n = Math.floor(len / .32); for (let i = 0; i < n; i++) { const s = (i + .5) / n; if (i % 2) continue; const px = x0 + dx * s, py = y0 + dy * s; box(px - .08, py - .08, h, .16, .16, .15, mat); } }
    }
    function flag(x, y, z, color = 'red') {
        cyl(x, y, z - .05, .025, .75, 'iron', 5);
        plane([[x, y, z + .7], [x + .45, y - .2, z + .62], [x + .45, y - .2, z + .38], [x, y, z + .42]], color);
    }
    function tree(x, y, s = 1, kind = 'oak') {
        if (kind === 'pine') { cyl(x, y, 0, .07 * s, .35 * s, 'trunk', 6); cone(x, y, .25 * s, .5 * s, .75 * s, 'pine', 8, rnd()); cone(x, y, .65 * s, .4 * s, .7 * s, 'pine', 8, rnd()); cone(x, y, 1.05 * s, .28 * s, .6 * s, 'pine', 8, rnd()); return; }
        if (kind === 'dead') { cyl(x, y, 0, .08 * s, 1 * s, 'deadwood', 6, .04 * s); box(x, y - .02, .6 * s, .45 * s, .05, .05, 'deadwood'); box(x - .35 * s, y - .02, .8 * s, .35 * s, .05, .05, 'deadwood'); return; }
        cyl(x, y, 0, .08 * s, .55 * s, 'trunk', 6, .06 * s);
        blob(x, y, .85 * s, .5 * s, .5 * s, .45 * s, 'leaves', .14, false, false);
        if (s > .8) blob(x + .2 * s, y - .15 * s, 1.1 * s, .32 * s, .32 * s, .3 * s, 'leaves', .14, false, false);
    }
    const bush = (x, y, s = .5) => blob(x, y, s * .45, s * .55, s * .55, s * .5, 'leaves', .2, false);
    const rock = (x, y, s = .4, mat = 'rock') => blob(x, y, s * .2, s, s * .85, s * .7, mat, .28, false);
    const barrel = (x, y) => { cyl(x, y, 0, .14, .34, 'wood', 8, .14, 'darkwood'); cyl(x, y, .08, .145, .04, 'iron', 8); cyl(x, y, .24, .145, .04, 'iron', 8); };
    const crate = (x, y, s = .3) => box(x - s / 2, y - s / 2, 0, s, s, s, 'wood');
    const hay = (x, y, s = .5) => cyl(x, y, 0, s * .6, s * .5, 'hay', 10, s * .25);
    function fire(x, y) { for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; box(x + Math.cos(a) * .2 - .05, y + Math.sin(a) * .2 - .05, 0, .1, .1, .08, 'rock'); } cone(x, y, .02, .14, .35, 'fire', 6); fx.push({ k: 'fire', p: [x, y, .2] }, { k: 'smoke', p: [x, y, .5] }); }
    function fence(x0, y0, x1, y1, mat = 'wood') {
        const n = Math.max(2, Math.round(Math.hypot(x1 - x0, y1 - y0) / .3));
        for (let i = 0; i <= n; i++) { const t = i / n; box(x0 + (x1 - x0) * t - .03, y0 + (y1 - y0) * t - .03, 0, .06, .06, .32, mat); }
        const t = .04; if (Math.abs(y1 - y0) < 1e-6) box(Math.min(x0, x1), y0 - t / 2, .18, Math.abs(x1 - x0), t, .05, mat); else box(x0 - t / 2, Math.min(y0, y1), .18, t, Math.abs(y1 - y0), .05, mat);
    }
    function tent(x, y, w, d, h, mat = 'cloth') { gable(x, y, 0, w, d, h, mat, 'x', 0); win('x', y + d / 2, x + w + .01, 0, .22, h * .55, 'black'); }
    function grave(x, y, k = 0) { if (k) { box(x - .03, y - .03, 0, .06, .06, .42, 'darkstone'); box(x - .13, y - .03, .26, .26, .06, .06, 'darkstone'); } else { prism([[x - .14, y - .04], [x + .14, y - .04], [x + .14, y + .04], [x - .14, y + .04]], 0, .32, 'darkstone'); cyl(x, y, .32, .14, .04, 'darkstone', 8); } disc(x, y + .22, .15, 'dirt', .008, 8); }

    // ---------- modele miejsc ----------
    const MODELS = {
        capital: () => { base('cobble', 2.35);
            const s = 1.7; wall(-s, -s, s, -s, .95, .26, 'stone'); wall(-s, -s, -s, s, .95, .26, 'stone'); wall(-s, s, s, s, .95, .26, 'stone'); wall(s, -s, s, s, .95, .26, 'stone');
            box(-.25, s - .13, 0, .5, .3, .62, 'darkwood');
            [[-s, -s], [s, -s], [-s, s], [s, s]].forEach(([x, y]) => tower(x, y, .38, 1.55, 'stone', 'slate', { n: 10 }));
            box(-.8, -.9, 0, 1.4, 1.4, 2.2, 'plaster'); box(-.84, -.94, 2.2, 1.48, 1.48, .08, 'stone'); hip(-.8, -.9, 2.28, 1.4, 1.4, 1.25, 'bluetile'); cyl(-.1, -.2, 3.5, .05, .35, 'gold', 6); blob(-.1, -.2, 3.88, .07, .07, .07, 'gold', 0, false, false);
            for (const [a, b] of [[-.5, .5], [.2, .5]]) win('y', a, b, 1.3, .22, .4, 'lit');
            win('x', -.5, .6, 1.3, .22, .4); win('x', .1, .6, 1.3, .22, .4);
            tower(.95, -.95, .32, 2.6, 'plaster', 'slate', { flag: 'yellow' });
            house(-1.35, .35, .7, .7, .6, 'timber', 'roof'); house(.55, .65, .75, .6, .55, 'plaster', 'roof', { axis: 'y' }); },
        city: () => { base('cobble', 2.3);
            const s = 1.8; wall(-s, -s, s, -s, .62, .2, 'stone'); wall(-s, -s, -s, s, .62, .2, 'stone');
            tower(-s, -s, .34, 1.15, 'stone', 'roof', { n: 10 });
            house(-1.45, -1.4, 1.1, .9, 1.25, 'timber', 'roof', { chimney: 1 }); house(.1, -1.45, 1.05, 1, 1.6, 'plaster', 'slate', { axis: 'y' });
            house(-1.45, .15, .9, 1, .95, 'plaster', 'roof', { axis: 'y' }); house(.2, .35, .75, .75, .8, 'timber', 'roof');
            sqTower(.95, .75, .55, 2.3, 'stone', 'slate', { cren: false, flag: 'blue' }); },
        town: () => { base('grass', 2.1); patch([[-2, -.25], [2, -.25], [2, .22], [-2, .22]], 'path'); patch([[-.2, -2], [.22, -2], [.22, 2], [-.2, 2]], 'path');
            house(-1.7, -1.6, 1.2, 1, 1, 'plaster', 'roof', { chimney: 1 }); house(.45, -1.65, 1.1, 1.1, 1.25, 'timber', 'slate', { axis: 'y' }); house(-1.6, .5, 1.05, .95, .9, 'plaster', 'thatch', { axis: 'y' });
            tree(1.15, 1.05, .85); bush(.6, .65, .5); barrel(-.45, 1.5); barrel(-.62, 1.72); tree(1.65, .4, .7, 'pine'); },
        village: () => { base('meadow', 2.05); patch([[-.15, -2], [.25, -2], [.35, 2], [-.05, 2]], 'path');
            house(-1.55, -1.4, 1.15, 1, .78, 'timber', 'thatch', { chimney: 1 }); house(.55, .15, 1.05, .95, .74, 'plaster', 'thatch', { axis: 'y' });
            tree(1.2, -1.3, .95, 'pine'); tree(.75, -.6, .7); fence(-1.7, .35, -.5, .35); fence(-1.7, .35, -1.7, 1.6); hay(-1.1, 1.05, .8); bush(-.8, 1.7, .55); tree(1.5, 1.5, .65); },
        market: () => { base('cobble', 2.1);
            const stall = (x, y, c) => { [[0, 0], [.9, 0], [0, .7], [.9, .7]].forEach(([a, b]) => box(x + a, y + b, 0, .06, .06, .75, 'wood')); box(x, y + .45, 0, .96, .3, .35, 'wood');
                const id = solid([[[x - .08, y - .1, .75], [x + 1.04, y - .1, .75], [x + 1.04, y + .86, .62], [x - .08, y + .86, .62]], [[x - .08, y - .1, .8], [x + 1.04, y - .1, .8], [x + 1.04, y + .86, .67], [x - .08, y + .86, .67]],
                    [[x - .08, y - .1, .75], [x - .08, y - .1, .8], [x - .08, y + .86, .67], [x - .08, y + .86, .62]], [[x + 1.04, y - .1, .75], [x + 1.04, y - .1, .8], [x + 1.04, y + .86, .67], [x + 1.04, y + .86, .62]],
                    [[x - .08, y - .1, .75], [x + 1.04, y - .1, .75], [x + 1.04, y - .1, .8], [x - .08, y - .1, .8]], [[x - .08, y + .86, .62], [x + 1.04, y + .86, .62], [x + 1.04, y + .86, .67], [x - .08, y + .86, .67]]], c);
                crate(x + .3, y + .6, .16); crate(x + .6, y + .58, .14); };
            stall(-1.6, -1.55, 'red'); stall(.4, -1.6, 'teal'); stall(-1.6, .45, 'blue');
            cyl(.75, .7, 0, .45, .25, 'stone', 12, .45, 'water'); cyl(.75, .7, 0, .12, .7, 'stone', 8); cyl(.75, .7, .7, .22, .08, 'stone', 8, .22, 'water');
            crate(1.45, -.3); crate(1.55, -.02, .24); barrel(-.3, 1.5); barrel(-.05, 1.7); },
        tavern: () => { base('dirt', 2.15);
            box(-1.45, -1.5, 0, 2.5, 1.9, .95, 'stone'); box(-1.45, -1.5, .95, 2.5, 1.9, .85, 'timber'); gable(-1.45, -1.5, 1.8, 2.5, 1.9, 1.1, 'roof', 'x', .15, 'timber');
            win('y', -.7, .4, 0, .38, .62, 'darkwood'); [[-1.1, .35], [.5, .35], [-1.1, 1.25], [-.3, 1.25], [.5, 1.25]].forEach(([a, z]) => win('y', a, .4, z, .3, .3, z < 1 ? 'lit' : 'window'));
            [[-1.1, .35], [-.4, .35], [-1.1, 1.25], [-.4, 1.25]].forEach(([a, z]) => win('x', a, 1.05, z, .3, .3, z < 1 ? 'lit' : 'window'));
            box(.45, -1.2, 1.8, .26, .26, 1.35, 'stone'); fx.push({ k: 'smoke', p: [.58, -1.07, 3.25] });
            cyl(1.45, 1.05, 0, .04, 1.3, 'darkwood', 5); box(1.43, .6, 1.25, .04, .48, .04, 'darkwood'); plane([[1.45, .66, 1.2], [1.45, 1.02, 1.2], [1.45, 1.02, .88], [1.45, .66, .88]], 'yellow');
            barrel(-1.75, .95); barrel(-1.5, 1.25); barrel(-1.78, 1.32); tree(1.55, -1.2, .7); bush(.35, 1.45, .55); },
        guild: () => { base('cobble', 2.1);
            box(-1.2, -1.6, 0, 2.2, 2.3, 1.7, 'stone'); gable(-1.2, -1.6, 1.7, 2.2, 2.3, 1.25, 'slate', 'y', .14, 'stone');
            [-.85, -.35, .15, .65].forEach(a => cyl(a, .82, 0, .1, 1.5, 'white', 8)); box(-1.05, .7, 1.48, 1.9, .2, .12, 'white');
            win('y', -.1, .7, 0, .4, .8, 'darkwood'); [-1.25, -.55, .15].forEach(a => win('x', a, 1, .75, .28, .45, 'lit'));
            flag(-.1, .8, 1.9, 'blue'); bush(-1.6, 1.3, .55); bush(1.5, 1.2, .55); barrel(1.5, -1.5); },
        fortress: () => { base('dirt', 2.35);
            const s = 1.65; wall(-s, -s, s, -s, 1.15, .32, 'darkstone'); wall(-s, -s, -s, s, 1.15, .32, 'darkstone'); wall(s, -s, s, s, 1.15, .32, 'darkstone'); wall(-s, s, -.4, s, 1.15, .32, 'darkstone'); wall(.4, s, s, s, 1.15, .32, 'darkstone');
            [[-s, -s], [s, -s], [-s, s], [s, s]].forEach(([x, y]) => sqTower(x - .35, y - .35, .7, 1.75, 'darkstone', null));
            sqTower(-.5, s - .3, .35, 1.45, 'darkstone', null); sqTower(.15, s - .3, .35, 1.45, 'darkstone', null); box(-.18, s - .1, 0, .36, .1, .6, 'iron');
            sqTower(-.6, -.75, 1.2, 2.4, 'darkstone', null, { flag: 'red' }); fx.push({ k: 'glow', p: [-.6, .45, 1.6] }); },
        castle: () => { base('grass', 2.3);
            const s = 1.55; wall(-s, -s, s, -s, .95, .26, 'stone'); wall(-s, -s, -s, s, .95, .26, 'stone'); wall(s, -s, s, s, .95, .26, 'stone'); wall(-s, s, -.35, s, .95, .26, 'stone'); wall(.35, s, s, s, .95, .26, 'stone');
            box(-.3, s - .14, 0, .6, .3, .66, 'darkwood');
            [[-s, -s], [s, -s], [-s, s], [s, s]].forEach(([x, y]) => tower(x, y, .36, 1.55, 'stone', 'bluetile', { n: 10, rh: .85 }));
            box(-.75, -.85, 0, 1.4, 1.2, 2.0, 'stone'); gable(-.75, -.85, 2.0, 1.4, 1.2, .7, 'bluetile', 'x', .1, 'stone');
            win('y', -.35, .35, 1.2, .2, .36, 'lit'); win('y', .25, .35, 1.2, .2, .36, 'lit'); win('x', -.55, .65, 1.2, .2, .36);
            tower(.62, -.6, .3, 2.9, 'stone', 'bluetile', { n: 10, rh: 1, flag: 'red' }); tree(-1.95, 1.2, .6, 'pine'); },
        ruin: () => { base('grass', 2.1);
            box(-1.4, -1.3, 0, 2.2, .3, 1.25, 'stone'); box(-1.4, -1.3, 1.25, .9, .3, .45, 'stone'); box(-1.4, -1.3, 0, .3, 2.1, .9, 'stone'); box(-1.4, -1.3, .9, .3, .7, .55, 'stone');
            box(.4, -1.3, 1.25, .5, .3, .2, 'stone'); [[-.2, .55, 1.1], [.5, .3, .6], [1.1, .7, .35]].forEach(([x, y, h]) => cyl(x, y, 0, .14, h, 'white', 8));
            box(.9, .9, 0, .5, .3, .25, 'stone'); box(-.5, .9, 0, .3, .5, .2, 'stone'); rock(1.3, -.3, .3); rock(-.6, 1.5, .25);
            disc(-.1, .1, .5, 'dirt'); bush(-1.1, .9, .5); bush(1.5, 1.3, .45); tree(1.5, -1.3, .75, 'dead'); },
        hideout: () => { base('dirt', 2.05);
            for (let i = 0; i < 13; i++) { const a = Math.PI * .95 + i / 12 * Math.PI * 1.15, r = 1.75; cyl(Math.cos(a) * r, Math.sin(a) * r, 0, .08, R(.7, .95), 'darkwood', 6, .02); }
            box(-1.3, -1.25, 0, 1.2, .9, .6, 'darkwood'); gable(-1.3, -1.25, .6, 1.2, .9, .5, 'thatch', 'x', .12, 'darkwood'); win('y', -.95, -.35, 0, .26, .42, 'black');
            tent(.25, -1.1, 1, .8, .7, 'cloth'); fire(.2, .45); box(-.25, .7, 0, .5, .12, .12, 'trunk'); box(.55, .3, 0, .12, .5, .12, 'trunk');
            crate(-1.1, .85); crate(-.85, 1.05, .24); barrel(1.3, .9); tree(1.45, -.25, .75, 'pine'); },
        mountain: () => { base('rock', 2.25);
            const peak = (x, y, r, h, n = 9) => { const pts = []; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2 + R(-.2, .2); pts.push([x + Math.cos(a) * r * R(.75, 1.15), y + Math.sin(a) * r * R(.75, 1.15), 0]); }
                const mids = pts.map((p, i) => { const k = R(.45, .6); return [x + (p[0] - x) * k + R(-.1, .1), y + (p[1] - y) * k + R(-.1, .1), h * R(.42, .55)]; });
                const top = [x + R(-.1, .1), y + R(-.1, .1), h];
                const polys = []; for (let i = 0; i < n; i++) { const j = (i + 1) % n; polys.push([pts[i], pts[j], mids[j]], [pts[i], mids[j], mids[i]], [mids[i], mids[j], top]); }
                polys.push(pts.slice().reverse()); solid(polys, 'mountain'); };
            peak(-.55, -.6, 1.45, 4.2); peak(.95, -.2, 1.05, 3.0); peak(-.2, .95, .9, 2.1); rock(1.4, 1.1, .35); rock(-1.5, .9, .3); tree(.9, 1.5, .55, 'pine'); tree(1.4, .55, .5, 'pine'); },
        sea: () => { base('water', 2.25, .32);
            prism([[-.85, -.2], [.55, -.4], [.95, -.25], [.6, .05], [-.75, .25]], .02, .32, 'darkwood', 'wood');
            box(-.6, -.15, .34, 1.1, .3, .05, 'wood'); cyl(-.05, -.1, .3, .05, 1.9, 'trunk', 6);
            const sy0 = -.64, sy1 = .44, sz0 = .82, sz1 = 1.9, NS = 5, NT = 4;
            const sp = (i, j) => { const s = i / NS, t = j / NT; return [-.05 + .26 * Math.sin(Math.PI * s) * (.55 + .45 * Math.sin(Math.PI * (.25 + .75 * t))), sy0 + (sy1 - sy0) * s, sz0 + (sz1 - sz0) * t]; };
            for (let i = 0; i < NS; i++) for (let j = 0; j < NT; j++) plane([sp(i, j), sp(i + 1, j), sp(i + 1, j + 1), sp(i, j + 1)], 'sail');
            box(-.08, sy0 - .08, sz1, .06, sy1 - sy0 + .16, .06, 'trunk'); box(-.08, sy0 - .06, sz0 - .06, .06, sy1 - sy0 + .12, .05, 'trunk');
            plane([[0, -.12, 1.78], [.93, -.25, .42], [.3, -.16, .42]], 'sail');
            flag(-.05, -.1, 2.15, 'red');
            for (let i = 0; i < 3; i++) blob(.6 + i * .42, 1.15 - i * .15, .05, .2, .2, .22, 'green', .1, false, false);
            cone(1.75, .6, 0, .18, .45, 'green', 6); rock(-1.4, 1.1, .38); rock(-1.65, .7, .25); rock(1.4, -1.35, .3); },
        cave: () => { base('rock', 2.2);
            // u — wzdłuż zbocza, v — od środka góry w stronę patrzącego
            const W_ = (u, v, z) => [-.2 + .7071 * u + .7071 * v, -.35 - .7071 * u + .7071 * v, z];
            const n = 11, pts = [], mids = [];
            for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; pts.push([-.2 + Math.cos(a) * 1.75 * R(.85, 1.1), -.35 + Math.sin(a) * 1.5 * R(.85, 1.1), 0]); mids.push([-.2 + Math.cos(a) * .95 * R(.85, 1.1), -.35 + Math.sin(a) * .82 * R(.85, 1.1), R(1.25, 1.6)]); }
            // od frontu: stroma skalna ściana (prawie pionowa), w której jest wejście
            pts[1] = W_(.78, 1.3, 0); pts[2] = W_(-.78, 1.3, 0);
            mids[1] = W_(.6, 1.16, 1.4); mids[2] = W_(-.6, 1.16, 1.42);
            const top = [-.3, -.45, 2.6];
            const polys = []; for (let i = 0; i < n; i++) { const j = (i + 1) % n; polys.push([pts[i], pts[j], mids[j]], [pts[i], mids[j], mids[i]], [mids[i], mids[j], top]); } polys.push(pts.slice().reverse());
            solid(polys, 'mountain');
            // czeluść dopasowana do pochylenia ściany (ciemniej w głąb)
            const vAt = (z) => 1.3 - .14 * z / 1.4 + .014;
            const mouth = [W_(-.38, vAt(0), 0), W_(.38, vAt(0), 0)];
            for (let i = 0; i <= 14; i++) { const th = Math.PI * i / 14, z = .3 + .5 * Math.sin(th); mouth.push(W_(.38 * Math.cos(th), vAt(z), z)); }
            plane(mouth, 'cavemouth');
            // kamienne obramowanie łuku i rumowisko u wejścia
            [[-.47, .1, .16], [.47, .12, .15], [-.45, .48, .13], [.45, .5, .13], [-.27, .76, .12], [.27, .78, .12], [0, .86, .14]].forEach(([u, z, r]) => { const p = W_(u, vAt(z) + .03, z); blob(p[0], p[1], p[2], r, r * .8, r * .85, 'rock', .3, false, false); });
            const fr = W_(0, 1.75, 0); disc(fr[0], fr[1], .4, 'dirt');
            [[.55, 1.62, .14], [-.6, 1.58, .12], [.15, 2.0, .1]].forEach(([u, v, r]) => { const p = W_(u, v, 0); rock(p[0], p[1], r); });
            rock(1.4, .3, .3); rock(-.8, 1.35, .26); rock(1.6, -.4, .22);
            fx.push({ k: 'eyes', p: W_(0, vAt(.38) + .01, .38) }); },
        dungeon: () => { base('grass', 2.1);
            box(-1.1, -1.2, 0, 2.2, 1.9, .2, 'stone'); box(-.9, -1.05, .2, 1.8, 1.6, 1.35, 'stone'); gable(-.9, -1.05, 1.55, 1.8, 1.6, .75, 'darkstone', 'y', .14, 'stone');
            [-.75, .75].forEach(a => cyl(a, .62, .2, .1, 1.3, 'white', 8)); box(-.9, .5, 1.45, 1.8, .2, .14, 'white');
            box(-.32, .52, .2, .64, .06, .95, 'black');
            for (let i = 0; i < 3; i++) box(-.45, .7 + i * .15, 0, .9, .16, .18 - i * .06, 'stone');
            fx.push({ k: 'glow', p: [0, .55, .5] });
            grave(1.35, 1.0); grave(1.55, .45, 1); grave(-1.45, .95); tree(1.5, -1.3, .8, 'dead'); bush(-1.5, -.4, .45); },
        forest: () => { base('meadow', 2.1);
            [[-1.1, -1.2, 1.1, 'pine'], [.2, -1.5, 1.25, 'pine'], [1.2, -.7, 1, 'oak'], [-1.5, .1, .9, 'oak'], [-.3, -.3, 1.2, 'pine'], [.75, .55, .95, 'pine'], [-.65, 1.1, .85, 'oak'], [1.4, 1.1, .7, 'pine']].forEach(([x, y, s, k]) => tree(x, y, s, k));
            bush(.1, 1.4, .5); rock(-1.5, 1.2, .25); },
        wilderness: () => { base('meadow', 2.1); patch([[-2, .3], [-.5, .1], [.6, .5], [2, .2], [2, .55], [.6, .85], [-.5, .45], [-2, .65]], 'path');
            rock(-1.1, -.9, .45); rock(-.6, -1.3, .3); tree(1.1, -1.1, 1, 'oak'); bush(.3, -.6, .5); bush(-1.4, 1.3, .55); tree(1.4, 1.4, .7, 'pine'); rock(.6, 1.4, .25); },
        temple: () => { base('grass', 2.15);
            for (let i = 0; i < 3; i++) box(-1.5 + i * .12, -1.4 + i * .12, i * .14, 2.9 - i * .24, 2.7 - i * .24, .14, 'white');
            const cols = [-1.05, -.35, .35, 1.05]; cols.forEach(a => { cyl(a, .85, .42, .12, 1.4, 'white', 10); cyl(a, -.95, .42, .12, 1.4, 'white', 10); });
            [-.25, .3].forEach(b => cyl(1.05, b, .42, .12, 1.4, 'white', 10));
            box(-1.25, -1.15, 1.82, 2.5, 2.25, .2, 'white'); gable(-1.25, -1.15, 2.02, 2.5, 2.25, .62, 'white', 'y', .08);
            box(-.6, -.6, .42, 1.2, 1.1, 1.4, 'plaster'); win('y', 0, .5, .42, .45, .8, 'lit'); fx.push({ k: 'glow', p: [0, .55, .8] }); fx.push({ k: 'sparkle', p: [0, .1, 2.9] }); },
        plane: () => { base('darkstone', 2.05);
            const n = 14, rr = 1.05; for (let i = 0; i <= n; i++) { const a = Math.PI * i / n; const x = Math.cos(a) * rr, z = Math.sin(a) * rr * 1.25 + .1; box(x - .14, -.14, z - .14, .28, .28, .3, 'darkstone'); }
            box(-1.2, -.2, 0, .3, .4, .3, 'darkstone'); box(.9, -.2, 0, .3, .4, .3, 'darkstone');
            const pts = []; for (let i = 0; i <= 16; i++) { const a = Math.PI * i / 16; pts.push([Math.cos(a) * .9, .02, .12 + Math.sin(a) * 1.15]); } plane(pts, 'magic');
            [[1.4, .9, .9], [-1.45, 1, .7], [1.2, -1.2, 1.2]].forEach(([x, y, z]) => blob(x, y, z, .13, .13, .3, 'crystal', 0, false, false));
            fx.push({ k: 'portal', p: [0, .05, .8] }); },
        other: () => { base('grass', 1.95);
            cyl(0, 0, 0, .07, 1.5, 'trunk', 6); plane([[.05, 0, 1.35], [.8, -.15, 1.35], [.9, -.17, 1.2], [.8, -.15, 1.05], [.05, 0, 1.05]], 'wood'); plane([[-.05, 0, 1.0], [-.7, .25, 1.0], [-.8, .28, .87], [-.7, .25, .74], [-.05, 0, .74]], 'wood');
            box(.6, .6, 0, .55, .4, .32, 'wood'); box(.58, .58, .32, .59, .44, .06, 'brass'); rock(-1, -.7, .3); bush(-1, .9, .5); tree(1.1, -1, .8); },
        house: () => { base('meadow', 1.95); house(-.9, -.9, 1.6, 1.25, 1, 'timber', 'roof', { chimney: 1, lit: true }); fence(-1.4, .75, .5, .75); bush(1.1, .7, .5); tree(1.2, -1, .7); disc(-.2, 1.2, .35, 'path'); },
        manor: () => { base('meadow', 2.2);
            house(-1.4, -1.2, 2.6, 1.15, 1.45, 'plaster', 'slate', { hip: true, lit: true }); house(-1.4, -.05, .9, 1.1, 1.2, 'plaster', 'slate', { hip: true, door: false }); house(.3, -.05, .9, 1.1, 1.2, 'plaster', 'slate', { hip: true, door: false });
            box(-.35, -.05, 0, .55, .25, .7, 'darkwood'); patch([[-.3, .2], [.15, .2], [.15, 2], [-.3, 2]], 'path');
            [[-1.5, 1.4], [-1, 1.4], [.6, 1.4], [1.1, 1.4]].forEach(([x, y]) => blob(x, y, .25, .22, .22, .3, 'leaves', .08, false)); tree(1.6, -.8, .8); },
        palace: () => { base('cobble', 2.35);
            box(-1.5, -1.3, 0, 3, 2, 1.3, 'white'); box(-1.55, -1.35, 1.3, 3.1, 2.1, .12, 'stone'); box(-1.56, .74, 1.24, 3.12, .04, .06, 'gold');
            cyl(0, -.3, 1.42, .62, .25, 'white', 14); blob(0, -.3, 1.67, .66, .66, .8, 'bluetile', 0, true, true); cyl(0, -.3, 2.4, .05, .4, 'gold', 6); blob(0, -.3, 2.82, .06, .06, .06, 'gold', 0, false, false);
            [[-1.5, -1.3], [1.5, -1.3], [-1.5, .7], [1.5, .7]].forEach(([x, y]) => { cyl(x, y, 0, .3, 2.1, 'white', 10); blob(x, y, 2.1, .32, .32, .4, 'bluetile', 0, true, true); cyl(x, y, 2.45, .04, .3, 'gold', 5); });
            [-1, -.5, .5, 1].forEach(a => win('y', a, .7, .4, .22, .5, 'lit')); win('y', 0, .7, 0, .5, .8, 'darkwood'); [-.9, -.2].forEach(a => win('x', a, 1.5, .5, .22, .45, 'lit'));
            patch([[-.35, .7], [.35, .7], [.4, 2.2], [-.4, 2.2]], 'path'); },
        tower: () => { base('meadow', 1.9);
            tower(0, -.1, .62, 3.4, 'stone', 'purple', { n: 12, rh: 1.4, lit: true }); box(-.25, .5, 0, .5, .1, .7, 'darkwood');
            cyl(0, -.1, 2.3, .72, .1, 'darkwood', 12); fx.push({ k: 'sparkle', p: [0, -.1, 5.2] }); rock(1.1, .9, .3); bush(-1.1, .8, .5); tree(1.1, -1.1, .7, 'pine'); },
        gate: () => { base('cobble', 2.1); patch([[-.4, -2], [.4, -2], [.4, 2], [-.4, 2]], 'path');
            sqTower(-1.3, -.45, .85, 2.1, 'stone', 'roof'); sqTower(.45, -.45, .85, 2.1, 'stone', 'roof');
            box(-.45, -.45, 1.15, .9, .85, .75, 'stone'); for (let i = 0; i < 3; i++) box(-.45 + i * .3 + .05, .35, 1.9, .14, .1, .16, 'stone');
            box(-.45, .38, .02, .9, .04, 1.1, 'iron'); wall(-2, 0, -1.3, 0, .9, .3, 'stone'); wall(1.3, 0, 2, 0, .9, .3, 'stone'); flag(-.87, -.02, 2.95, 'blue'); },
        barracks: () => { base('dirt', 2.15);
            house(-1.6, -1.45, 2.8, 1.1, 1, 'timber', 'roof', { chimney: -1 }); flag(1.4, -1.2, 0, 'red');
            for (let i = 0; i < 3; i++) { const x = -.9 + i * .7; cyl(x, .8, 0, .05, .7, 'darkwood', 5); blob(x, .8, .85, .14, .14, .2, 'hay', .1, false, false); box(x - .25, .78, .6, .5, .04, .05, 'darkwood'); }
            box(.9, .5, 0, .5, .3, .5, 'wood'); [.95, 1.1, 1.25].forEach(a => cyl(a, .6, .5, .02, .5, 'iron', 4)); barrel(-1.5, 1.2); },
        smithy: () => { base('dirt', 2.05);
            box(-1.4, -1.3, 0, 1.9, 1.5, 1.05, 'stone'); gable(-1.4, -1.3, 1.05, 1.9, 1.5, .8, 'slate', 'x', .14, 'stone');
            box(.5, -1.1, 0, .9, 1.4, .08, 'stone'); [[.55, -1.05], [1.3, -1.05], [.55, .2], [1.3, .2]].forEach(([x, y]) => box(x, y, 0, .08, .08, 1, 'darkwood'));
            solid([[[.45, -1.15, 1.05], [1.45, -1.15, .85], [1.45, .35, .85], [.45, .35, 1.05]], [[.45, -1.15, 1.1], [1.45, -1.15, .9], [1.45, .35, .9], [.45, .35, 1.1]], [[.45, -1.15, 1.05], [.45, -1.15, 1.1], [.45, .35, 1.1], [.45, .35, 1.05]], [[1.45, -1.15, .85], [1.45, -1.15, .9], [1.45, .35, .9], [1.45, .35, .85]], [[.45, -1.15, 1.05], [1.45, -1.15, .85], [1.45, -1.15, .9], [.45, -1.15, 1.1]], [[.45, .35, 1.05], [1.45, .35, .85], [1.45, .35, .9], [.45, .35, 1.1]]], 'roof');
            box(.65, -.9, 0, .55, .55, .45, 'stone'); box(.75, -.8, .45, .35, .35, .06, 'lava'); box(-.9, -1, 1.05, .3, .3, 1.3, 'stone'); fx.push({ k: 'smoke', p: [-.75, -.85, 2.4] }, { k: 'glow', p: [.92, -.62, .5] });
            box(.85, .55, 0, .14, .14, .32, 'iron'); box(.72, .52, .32, .42, .2, .1, 'iron'); win('y', -.7, .2, 0, .4, .62, 'darkwood'); barrel(-1.5, .8); crate(-1.05, 1.05); },
        shop: () => { base('cobble', 2);
            house(-1.2, -1.3, 1.9, 1.5, 1.35, 'timber', 'roof', { lit: true });
            solid([[[-1.25, .2, 1.0], [.75, .2, 1.0], [.75, .7, .75], [-1.25, .7, .75]], [[-1.25, .2, 1.05], [.75, .2, 1.05], [.75, .7, .8], [-1.25, .7, .8]], [[-1.25, .2, 1.0], [-1.25, .2, 1.05], [-1.25, .7, .8], [-1.25, .7, .75]], [[.75, .2, 1.0], [.75, .2, 1.05], [.75, .7, .8], [.75, .7, .75]], [[-1.25, .2, 1.0], [.75, .2, 1.0], [.75, .2, 1.05], [-1.25, .2, 1.05]], [[-1.25, .7, .75], [.75, .7, .75], [.75, .7, .8], [-1.25, .7, .8]]], 'red');
            box(-1, .25, 0, 1.5, .35, .4, 'wood'); crate(-.7, .9, .22); crate(.2, 1, .26); barrel(1.1, .6); barrel(1.3, .9); plane([[.72, .25, 1.3], [.72, .65, 1.3], [.72, .65, 1.05], [.72, .25, 1.05]], 'yellow'); },
        docks: () => { base('water', 2.2, .32); patch([[-2.2, -2.2], [2.2, -2.2], [2.2, -.75], [.9, -.95], [-.6, -1.15], [-2.2, -1.25]], 'meadow', .03); patch([[-2.2, -1.25], [-.6, -1.15], [.9, -.95], [2.2, -.75], [2.2, -.55], [.9, -.75], [-.6, -.95], [-2.2, -1.05]], 'sand', .02);
            box(-.4, -1.1, .08, .8, 2.6, .1, 'wood'); for (let i = 0; i < 4; i++) { cyl(-.38, -1 + i * .8, -.3, .06, .55, 'trunk', 6); cyl(.38, -1 + i * .8, -.3, .06, .55, 'trunk', 6); }
            box(-1.6, -1.95, .05, 1.1, .9, .9, 'wood'); gable(-1.6, -1.95, .95, 1.1, .9, .5, 'slate', 'x', .1, 'wood');
            prism([[.7, .3], [1.5, .2], [1.75, .45], [1.5, .7], [.7, .6]], .02, .22, 'darkwood', 'wood'); cyl(1.2, .45, .2, .03, 1, 'trunk', 5); plane([[1.2, .45, 1.15], [1.65, .4, .85], [1.65, .4, .3], [1.2, .45, .3]], 'cloth');
            crate(-.15, -.6, .24); barrel(.15, -.35); crate(.1, .2, .2); },
        mill: () => { base('meadow', 2);
            cyl(-.1, -.2, 0, .7, 2.1, 'plaster', 10, .5); cone(-.1, -.2, 2.1, .62, .75, 'thatch', 10); win('y', -.1, .45, 0, .3, .55, 'darkwood'); win('y', -.1, .38, 1.1, .2, .3);
            const hx = .25, hy = .38, hz = 1.8; box(hx - .05, hy - .05, hz - .05, .1, .25, .1, 'darkwood');
            for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + .35; const dx = Math.cos(a), dz = Math.sin(a);
                const q = (t, s) => [hx + dx * t + (-dz) * s * .5, hy + .22, hz + dz * t + dx * s * .5];
                plane([q(.15, -.16), q(1.3, -.2), q(1.3, .2), q(.15, .16)], 'cloth'); }
            box(.6, .6, 0, .3, .3, .3, 'cloth'); box(.95, .5, 0, .28, .28, .28, 'cloth'); patch([[-1.9, .9], [-.6, .7], [-.4, 1.8], [-1.6, 1.9]], 'crop'); },
        farm: () => { base('meadow', 2.15);
            box(-1.6, -1.6, 0, 1.6, 1.1, .95, 'red'); gable(-1.6, -1.6, .95, 1.6, 1.1, .75, 'slate', 'x', .12, 'red'); win('y', -.8, -.5, 0, .5, .7, 'darkwood');
            patch([[.1, -1.8], [1.9, -1.8], [1.9, -.1], [.1, -.1]], 'crop'); patch([[.2, .2], [1.9, .1], [1.8, 1.4], [.3, 1.5]], 'crop');
            hay(-1.2, .5, .7); hay(-.6, .85, .6); fence(-1.9, 1.3, -.2, 1.3); tree(-1.5, 1.6, .55); },
        well: () => { base('cobble', 1.85);
            cyl(0, 0, 0, .55, .55, 'stone', 12, .55, 'water'); cyl(0, 0, .5, .58, .08, 'stone', 12);
            box(-.6, -.05, .55, .08, .1, .9, 'darkwood'); box(.52, -.05, .55, .08, .1, .9, 'darkwood'); box(-.62, -.03, 1.35, 1.24, .06, .06, 'darkwood');
            gable(-.75, -.45, 1.45, 1.5, .9, .45, 'thatch', 'x', .06); cyl(0, 0, .85, .1, .18, 'wood', 6); bush(1.1, .6, .45); barrel(-1, .7); },
        shrine: () => { base('grass', 1.9);
            for (let i = 0; i < 2; i++) box(-.8 + i * .12, -.8 + i * .12, i * .14, 1.6 - i * .24, 1.6 - i * .24, .14, 'stone');
            box(-.35, -.35, .28, .7, .7, .45, 'white'); prism([[-.15, -.15], [.15, -.15], [.15, .15], [-.15, .15]], .73, .9, 'white'); cone(0, 0, 1.63, .17, .25, 'gold', 4, Math.PI / 4);
            [[-.55, .55], [.55, .55], [.55, -.55], [-.55, -.55]].forEach(([x, y]) => { cyl(x, y, .28, .05, .16, 'white', 6); cone(x, y, .44, .025, .08, 'fire', 4); });
            fx.push({ k: 'glow', p: [0, .4, .6] }, { k: 'sparkle', p: [0, 0, 2.1] }); bush(1.1, .6, .45); tree(-1.1, -.9, .7); },
        graveyard: () => { base('grass', 2.1);
            [[-1.1, -1.1, 0], [-.4, -1.2, 1], [.4, -1.15, 0], [1.1, -.9, 1], [-1.1, -.2, 1], [-.3, -.25, 0], [.5, -.2, 0], [-.8, .65, 0], [.2, .55, 1]].forEach(([x, y, k]) => grave(x, y, k));
            for (const [a, b, c, d] of [[-1.8, 1.4, 1.8, 1.4], [-1.8, -1.6, -1.8, 1.4], [1.8, -1.6, 1.8, 1.4]]) fence(a, b, c, d, 'iron');
            tree(1.3, .7, 1.1, 'dead'); box(-1.5, -1.6, 0, .8, .7, .9, 'darkstone'); gable(-1.5, -1.6, .9, .8, .7, .45, 'darkstone', 'y', .06); fx.push({ k: 'wisp', p: [.6, .6, .9] }); },
        bridge: () => { base('water', 2.15, .32);
            prism([[-2.15, -.9], [-1.15, -.75], [-1.05, .8], [-2.15, .9]], 0, .32, 'earth', 'grass'); prism([[1.15, -.85], [2.15, -.9], [2.15, .9], [1.1, .75]], 0, .32, 'earth', 'grass');
            box(-.25, -.5, -.3, .5, 1, .7, 'stone');
            for (let i = 0; i < 8; i++) { const t0 = i / 8, t1 = (i + 1) / 8; const x0 = -1.5 + t0 * 3, z0 = .3 + Math.sin(t0 * Math.PI) * .35, x1 = -1.5 + t1 * 3, z1 = .3 + Math.sin(t1 * Math.PI) * .35;
                solid([[[x0, -.5, z0], [x1, -.5, z1], [x1, .5, z1], [x0, .5, z0]], [[x0, -.5, z0 + .15], [x1, -.5, z1 + .15], [x1, .5, z1 + .15], [x0, .5, z0 + .15]], [[x0, -.5, z0], [x1, -.5, z1], [x1, -.5, z1 + .15], [x0, -.5, z0 + .15]], [[x0, .5, z0], [x1, .5, z1], [x1, .5, z1 + .15], [x0, .5, z0 + .15]], [[x0, -.5, z0], [x0, .5, z0], [x0, .5, z0 + .15], [x0, -.5, z0 + .15]], [[x1, -.5, z1], [x1, .5, z1], [x1, .5, z1 + .15], [x1, -.5, z1 + .15]]], 'stone');
                box(x0, .42, z0 + .15, x1 - x0, .08, .2, 'stone'); box(x0, -.5, z0 + .15, x1 - x0, .08, .2, 'stone'); }
            tree(-1.7, -.6, .6, 'pine'); bush(1.6, .55, .4); },
        camp: () => { base('dirt', 1.95);
            tent(-1.3, -1.2, 1.05, .85, .75, 'cloth'); tent(.4, -1.3, .9, .75, .65, 'red'); fire(.25, .45);
            box(-.25, .75, 0, .55, .14, .14, 'trunk'); box(.75, .2, 0, .14, .55, .14, 'trunk'); crate(-1.2, .6); tree(1.25, -.2, .8, 'pine'); bush(-.9, 1.3, .45); }
    };

    // ---------- renderer: bufor głębokości + cienie + kontur ----------
    function render(type) {
        faces = []; fx = []; objId = 0;
        let h = 0; for (const ch of 'm3' + type) h = (h * 31 + ch.charCodeAt(0)) | 0; seed(h);
        (MODELS[type] || MODELS.other)();
        // trójkąty
        const tris = [];
        faces.forEach((f, fi) => { for (let i = 1; i < f.pts.length - 1; i++) tris.push([f.pts[0], f.pts[i], f.pts[i + 1], fi]); });
        // --- mapa cieni (rzut ortogonalny wzdłuż światła) ---
        const SM = 640, lz = LIGHT, lx = norm(cross([0, 0, 1], lz)), ly = cross(lz, lx);
        const toL = (p) => [dot(p, lx), dot(p, ly), dot(p, lz)];
        let mnx = 1e9, mxx = -1e9, mny = 1e9, mxy = -1e9;
        tris.forEach(t => t.slice(0, 3).forEach(p => { const q = toL(p); mnx = Math.min(mnx, q[0]); mxx = Math.max(mxx, q[0]); mny = Math.min(mny, q[1]); mxy = Math.max(mxy, q[1]); }));
        const ssx = (SM - 4) / (mxx - mnx || 1), ssy = (SM - 4) / (mxy - mny || 1), ss = Math.min(ssx, ssy);
        const shadow = new Float32Array(SM * SM).fill(-1e9);
        const toS = (p) => { const q = toL(p); return [(q[0] - mnx) * ss + 2, (q[1] - mny) * ss + 2, q[2]]; };
        tris.forEach(t => rast(t.slice(0, 3).map(toS), SM, SM, (i, z) => { if (z > shadow[i]) shadow[i] = z; }));
        // --- obraz ---
        const N = W * H, depth = new Float32Array(N).fill(-1e9), fid = new Int32Array(N).fill(-1), wx = new Float32Array(N), wy = new Float32Array(N), wz = new Float32Array(N);
        tris.forEach(t => {
            const f = faces[t[3]];
            if (!f.thin && dot(f.n, VIEW) < -1e-4) return;          // tylne ściany
            const s = t.slice(0, 3).map(p => proj(...p)), P = t.slice(0, 3);
            rastBary(s, W, H, (i, z, b0, b1, b2) => {
                const bias = f.flat ? .002 : 0;
                if (z + bias > depth[i]) { depth[i] = z + bias; fid[i] = t[3];
                    wx[i] = P[0][0] * b0 + P[1][0] * b1 + P[2][0] * b2; wy[i] = P[0][1] * b0 + P[1][1] * b1 + P[2][1] * b2; wz[i] = P[0][2] * b0 + P[1][2] * b1 + P[2][2] * b2; }
            });
        });
        // --- cieniowanie ---
        const img = new Uint8ClampedArray(N * 4);
        for (let i = 0; i < N; i++) {
            const fi = fid[i]; if (fi < 0) continue;
            const f = faces[fi], M = MATS[f.mat] || MATS.stone, p = [wx[i], wy[i], wz[i]];
            let n = f.n; if (f.thin && dot(n, VIEW) < 0) n = n.map(v => -v);
            let col = M.f(p, n);
            if (!M.glow || M.glow < 1) {
                // cień: sprawdź mapę cieni (PCF 3×3)
                const q = toS(p); let lit = 0;
                for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const sx = Math.round(q[0]) + dx, sy = Math.round(q[1]) + dy; if (sx < 0 || sy < 0 || sx >= SM || sy >= SM) { lit++; continue; } lit += shadow[sy * SM + sx] <= q[2] + .045 ? 1 : 0; }
                lit /= 9;
                const nl = Math.max(0, dot(n, LIGHT));
                const sky = .5 + .2 * n[2] + .06 * n[1];                // światło nieba (góra jaśniejsza)
                let k = sky + nl * .78 * lit;
                // przyciemnienie przy ziemi (okluzja otoczenia „na oko”)
                if (p[2] > .01 && p[2] < .35 && n[2] < .5) k *= .8 + .2 * p[2] / .35;
                col = [col[0] * k, col[1] * k, col[2] * k];
                if (M.spec && lit > .5) { const sp = Math.pow(Math.max(0, dot(n, HALF)), 40) * M.spec * 255; col = [col[0] + sp, col[1] + sp, col[2] + sp]; }
                if (M.glow) col = mix(col, M.f(p, n), M.glow);
            }
            const o = i * 4; img[o] = col[0]; img[o + 1] = col[1]; img[o + 2] = col[2]; img[o + 3] = 255;
        }
        // --- kontur: krawędzie brył (mocny) i załamania ścian (delikatny) ---
        const out = new Uint8ClampedArray(img);
        for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
            const i = y * W + x, a = fid[i];
            let strong = false, soft = false;
            for (const j of [i + 1, i + W, i - 1, i - W]) {
                const b = fid[j]; if (b === a) continue;
                if (a < 0) { if (depth[j] > -1e8) { strong = true; } continue; }
                if (b < 0) { strong = true; continue; }
                const fa = faces[a], fb = faces[b];
                if (fa.obj !== fb.obj) { if (depth[i] < depth[j] - .02 || Math.abs(depth[i] - depth[j]) > .02) strong = true; else soft = true; }
                else if (dot(fa.n, fb.n) < .92) soft = true;
            }
            const o = i * 4;
            if (a < 0 && strong) { out[o] = 52; out[o + 1] = 30; out[o + 2] = 12; out[o + 3] = 235; }
            else if (strong && a >= 0) { out[o] = img[o] * .35 + 20; out[o + 1] = img[o + 1] * .3 + 12; out[o + 2] = img[o + 2] * .25 + 5; }
            else if (soft) { out[o] = img[o] * .78; out[o + 1] = img[o + 1] * .76; out[o + 2] = img[o + 2] * .72; }
        }
        // --- pomniejszenie 2×2 (wygładzanie) i obrazek ---
        const ow = W / SS, oh = H / SS, fin = new Uint8ClampedArray(ow * oh * 4);
        for (let y = 0; y < oh; y++) for (let x = 0; x < ow; x++) {
            let r = 0, g = 0, b = 0, al = 0;
            for (let dy = 0; dy < SS; dy++) for (let dx = 0; dx < SS; dx++) { const o = ((y * SS + dy) * W + x * SS + dx) * 4, A = out[o + 3]; r += out[o] * A; g += out[o + 1] * A; b += out[o + 2] * A; al += A; }
            const o = (y * ow + x) * 4; if (al) { fin[o] = r / al; fin[o + 1] = g / al; fin[o + 2] = b / al; fin[o + 3] = al / (SS * SS); }
        }
        const cv = document.createElement('canvas'); cv.width = ow; cv.height = oh;
        cv.getContext('2d').putImageData(new ImageData(fin, ow, oh), 0, 0);
        const fxOut = fx.map(e => { const [sx, sy] = proj(...e.p); return { k: e.k, x: sx / W * 100, y: sy / H * 100 }; });
        return { url: cv.toDataURL('image/png'), fx: fxOut };
    }
    // wypełnianie trójkąta (s: [[x,y,z]×3]) — cb(indeks, z)
    function rast(s, w, h, cb) { rastBary(s, w, h, (i, z) => cb(i, z)); }
    function rastBary(s, w, h, cb) {
        const [a, b, c] = s;
        const area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
        if (Math.abs(area) < 1e-9) return;
        const x0 = Math.max(0, Math.floor(Math.min(a[0], b[0], c[0]))), x1 = Math.min(w - 1, Math.ceil(Math.max(a[0], b[0], c[0])));
        const y0 = Math.max(0, Math.floor(Math.min(a[1], b[1], c[1]))), y1 = Math.min(h - 1, Math.ceil(Math.max(a[1], b[1], c[1])));
        const inv = 1 / area;
        for (let y = y0; y <= y1; y++) {
            const py = y + .5;
            for (let x = x0; x <= x1; x++) {
                const px = x + .5;
                const w0 = ((b[0] - px) * (c[1] - py) - (b[1] - py) * (c[0] - px)) * inv;
                const w1 = ((c[0] - px) * (a[1] - py) - (c[1] - py) * (a[0] - px)) * inv;
                const w2 = 1 - w0 - w1;
                if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
                cb(y * w + x, a[2] * w0 + b[2] * w1 + c[2] * w2, w0, w1, w2);
            }
        }
    }

    // ---------- pamięć podręczna ----------
    const cache = {};
    function get(type) {
        if (!cache[type]) { try { cache[type] = render(type); } catch (e) { console.warn('[makieta 3D]', type, e); cache[type] = null; } }
        return cache[type];
    }
    function html(type) {
        const m = get(type); if (!m) return null;
        return `<span class="mm mm3d" aria-hidden="true"><img src="${m.url}" alt="" draggable="false">${m.fx.map(e => `<i class="m3-${e.k}" style="left:${e.x.toFixed(1)}%;top:${e.y.toFixed(1)}%"></i>`).join('')}</span>`;
    }
    // renderowanie w tle: najpierw zwracamy rysunek SVG, a gotowy model podmieniamy w miejscu
    const queue = [], queued = new Set();
    let busy = false;
    function cached(type) { return cache[type] !== undefined ? html(type) : null; }
    function enqueue(type) {
        if (cache[type] !== undefined || queued.has(type)) return;
        queued.add(type); queue.push(type); pump();
    }
    function pump() {
        if (busy || !queue.length) return;
        busy = true;
        const go = () => {
            const t = queue.shift(); queued.delete(t);
            const h = html(t);
            if (h) document.querySelectorAll(`[data-m3="${t}"]`).forEach(el => { el.outerHTML = h; });
            busy = false;
            if (queue.length) setTimeout(pump, 30);
        };
        if ('requestIdleCallback' in window) requestIdleCallback(go, { timeout: 400 }); else setTimeout(go, 16);
    }
    const supported = () => { try { const c = document.createElement('canvas'); return !!(c.getContext && c.getContext('2d')); } catch (e) { return false; } };
    return { html, get, cached, enqueue, types: () => Object.keys(MODELS), supported, _render: render };
})();
window.Models3D = Models3D;
