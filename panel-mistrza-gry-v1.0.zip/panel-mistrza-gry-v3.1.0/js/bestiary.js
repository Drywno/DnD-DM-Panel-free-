/* =========================================================
   BestiaryModule — Monster browsing, filtering & stat blocks
   ========================================================= */
const BestiaryModule = {

    /* ── state ───────────────────────────────────────────── */
    allMonsters: [],
    filteredMonsters: [],
    loaded: false,
    loading: false,
    detailVisible: false,

    /* ── DOM refs (cached on init) ───────────────────────── */
    els: {},

    /* ── lifecycle ───────────────────────────────────────── */
    init() {
        this.els = {
            search:     document.getElementById('bestiary-search'),
            crFilter:   document.getElementById('bestiary-cr-filter'),
            typeFilter: document.getElementById('bestiary-type-filter'),
            sizeFilter: document.getElementById('bestiary-size-filter'),
            customOnly: document.getElementById('bestiary-custom-only'),
            list:       document.getElementById('bestiary-list'),
            detail:     document.getElementById('bestiary-detail'),
            btnAdd:     document.getElementById('btn-add-monster'),
        };

        /* search & filter events */
        this.els.search.addEventListener('input', () => this.renderList());
        this.els.crFilter.addEventListener('change', () => this.renderList());
        this.els.typeFilter.addEventListener('change', () => this.renderList());
        this.els.sizeFilter.addEventListener('change', () => this.renderList());
        this.els.customOnly.addEventListener('change', () => this.renderList());

        /* add monster */
        this.els.btnAdd.addEventListener('click', () => this.showAddMonsterModal());

        this.loadMonsters();
    },

    activate() {
        if (!this.loaded && !this.loading) this.loadMonsters();
    },

    /* ── data loading ────────────────────────────────────── */
    async loadMonsters() {
        this.loading = true;
        this._showLoading();

        let srdFailed = false;
        const srdSafe = (p) => p.catch(err => { console.warn('SRD offline:', err); srdFailed = true; return []; });
        try {
            const apiMonsters = await srdSafe(APIClient.getMonsterList());
            const custom = StorageManager.getCustomMonsters() || [];
            const customTagged = custom.map(m => ({ ...m, _custom: true }));

            this.allMonsters = [...apiMonsters, ...customTagged];
            this.loaded = !srdFailed; // retry SRD on next visit if offline
            if (srdFailed) App.showToast('Brak połączenia z SRD — widoczne są tylko własne potwory', 'warning');
            this._populateFilterOptions();
            this.renderList();
        } catch (err) {
            console.error('[Bestiary] load error:', err);
            App.showToast('Nie udało się pobrać potworów z SRD — pokazuję tylko własne', 'error');
            this.els.list.innerHTML = this._emptyState('Nie udało się pobrać danych potworów.');
        } finally {
            this.loading = false;
        }
    },

    /* ── filter dropdowns population ─────────────────────── */
    _populateFilterOptions() {
        const types = new Set();
        const sizes = new Set();
        const crs   = new Set();

        this.allMonsters.forEach(m => {
            if (m.type)             types.add(typeof m.type === 'string' ? m.type : m.type.type || m.type);
            if (m.size)             sizes.add(m.size);
            if (m.challenge_rating != null) crs.add(m.challenge_rating);
        });

        this._fillSelect(this.els.typeFilter, [...types].sort().map(t => ({value: t, label: APIClient.translateStatic('types', t)})), 'Wszystkie Typy');
        this._fillSelect(this.els.sizeFilter, [...sizes].sort().map(s => ({value: s, label: APIClient.translateStatic('sizes', s)})), 'Wszystkie Rozmiary');

        /* CR sort numerically */
        const crSorted = [...crs].sort((a, b) => {
            const na = typeof a === 'string' && a.includes('/') ? eval(a) : Number(a);
            const nb = typeof b === 'string' && b.includes('/') ? eval(b) : Number(b);
            return na - nb;
        });
        this._fillSelect(this.els.crFilter, crSorted.map(c => ({ value: c, label: 'CR ' + APIClient.crDisplay(c) })), 'Wszystkie CR');
    },

    _fillSelect(select, items, defaultLabel) {
        const current = select.value;
        select.innerHTML = `<option value="">${defaultLabel}</option>`;
        items.forEach(item => {
            const opt = document.createElement('option');
            if (typeof item === 'object') { opt.value = item.value; opt.textContent = item.label; }
            else { opt.value = item; opt.textContent = item; }
            select.appendChild(opt);
        });
        select.value = current;
    },

    /* ── rendering ───────────────────────────────────────── */
    renderList() {
        const search     = (this.els.search.value || '').toLowerCase().trim();
        const crVal      = this.els.crFilter.value;
        const typeVal    = this.els.typeFilter.value.toLowerCase();
        const sizeVal    = this.els.sizeFilter.value.toLowerCase();
        const customOnly = this.els.customOnly.checked;

        this.filteredMonsters = this.allMonsters.filter(m => {
            if (customOnly && !m._custom) return false;
            if (crVal !== '' && String(m.challenge_rating) !== crVal) return false;
            
            const mType = typeof m.type === 'string' ? m.type : (m.type && m.type.type) || '';
            if (typeVal && mType.toLowerCase() !== typeVal) return false;
            if (sizeVal && (m.size || '').toLowerCase() !== sizeVal) return false;

            if (search) {
                const searchMatch = 
                    (m.name || '').toLowerCase().includes(search) || 
                    (APIClient.translateStatic('types', mType) || '').toLowerCase().includes(search) ||
                    (APIClient.translateStatic('sizes', m.size) || '').toLowerCase().includes(search);
                if (!searchMatch) return false;
            }

            return true;
        });

        if (this.filteredMonsters.length === 0) {
            this.els.list.innerHTML = this._emptyState('Żaden potwór nie pasuje do filtrów.');
            return;
        }

        const frag = document.createDocumentFragment();
        this.filteredMonsters.forEach(m => frag.appendChild(this._renderCard(m)));
        this.els.list.innerHTML = '';
        this.els.list.appendChild(frag);
    },

    _renderCard(monster) {
        const card = document.createElement('div');
        card.className = 'data-card';
        if (monster._custom) card.classList.add('custom-card');

        const mType = typeof monster.type === 'string' ? monster.type : (monster.type && monster.type.type) || '—';
        const cr = monster.challenge_rating != null ? APIClient.crDisplay(monster.challenge_rating) : '—';
        const ac = this._extractAC(monster);
        const hp = this._extractHP(monster);
        
        const sizePl = APIClient.translateStatic('sizes', monster.size || '');
        const typePl = APIClient.translateStatic('types', mType);

        card.innerHTML = `
            <div class="card-name">${this._esc(monster.name)}</div>
            <div class="card-subtitle">${this._esc(sizePl)} ${this._esc(typePl)}</div>
            <div class="card-tags">
                <span class="card-tag tag-cr">CR ${cr}</span>
                <span class="card-tag tag-type">${this._esc(typePl)}</span>
                <span class="card-tag tag-size">${this._esc(sizePl)}</span>
                ${monster._custom ? '<span class="card-tag tag-custom">Własny</span>' : ''}
            </div>
            <div class="card-stats">
                <span class="card-stat">AC ${ac}</span>
                <span class="card-stat">HP ${hp}</span>
            </div>
        `;

        card.addEventListener('click', () => {
            this.showDetail(monster.index || monster._customId, !!monster._custom);
        });

        return card;
    },

    /* ── detail / stat block ─────────────────────────────── */
    async showDetail(index, isCustom) {
        this.els.detail.classList.remove('hidden');
        this.els.detail.innerHTML = this._spinnerHtml();
        this.detailVisible = true;

        try {
            let m;
            if (isCustom) {
                const customs = StorageManager.getCustomMonsters() || [];
                m = customs.find(c => c._customId === index);
                if (m) m._custom = true;
            } else {
                m = await APIClient.getMonster(index);
            }
            if (!m) { this.els.detail.innerHTML = this._emptyState('Nie znaleziono potwora.'); return; }

            // tłumaczenie: z pamięci od razu; nowe teksty — najpierw wersja angielska, polska podmienia się sama
            const tok = this._detTok = (this._detTok || 0) + 1;
            const slots = this._trSlots(m);
            const draw = () => { this.els.detail.innerHTML = this._buildStatBlock(m); this._bindDetailEvents(m); };
            if (!m._translated && slots.some(([o, k]) => !APIClient.isTranslated(o[k]))) {
                draw();
                this.els.detail.querySelector('.cx-title h2, .stat-block-header')?.insertAdjacentHTML('beforeend', '<span class="tr-badge"><i class="fa-solid fa-spinner fa-spin"></i> tłumaczę…</span>');
                await this._translateMonster(m);
                if (tok !== this._detTok || !this.detailVisible) return;
            } else await this._translateMonster(m);
            draw();
        } catch (err) {
            console.error('[Bestiary] detail error:', err);
            this.els.detail.innerHTML = this._emptyState('Nie udało się wczytać szczegółów potwora.');
        }
    },

    _trSlots(m) {
        const slots = [];
        ['special_abilities', 'actions', 'legendary_actions', 'reactions'].forEach(g => (m[g] || []).forEach(it => {
            if (it && it.name) slots.push([it, 'name']);
            if (it && typeof it.desc === 'string') slots.push([it, 'desc']);
        }));
        if (m.legendary_desc) slots.push([m, 'legendary_desc']);
        return slots;
    },
    // wszystkie teksty potwora jednym zapytaniem (zamiast kilkunastu po kolei)
    async _translateMonster(m) {
        if (!m || m._translated) return;
        const slots = this._trSlots(m);
        const out = await APIClient.translateMany(slots.map(([o, k]) => o[k]));
        slots.forEach(([o, k], i) => { o[k] = out[i]; });
        m._translated = true;
    },

    _buildStatBlock(m) {
        const mType = typeof m.type === 'string' ? m.type : (m.type && m.type.type) || '';
        const align = m.alignment || '';
        const ac = this._extractAC(m);
        const hp = this._extractHP(m);
        const hitDice = m.hit_dice || m.hit_points_roll || '';
        const speed = this._formatSpeed(m.speed);
        const cr = m.challenge_rating != null ? APIClient.crDisplay(m.challenge_rating) : '—';
        const xp = m.challenge_rating != null ? APIClient.crToXP(m.challenge_rating) : '—';

        const sizePl = APIClient.translateStatic('sizes', m.size || '');
        const typePl = APIClient.translateStatic('types', mType);

        /* abilities */
        const abilityMap = {
            str: 'strength',
            dex: 'dexterity',
            con: 'constitution',
            int: 'intelligence',
            wis: 'wisdom',
            cha: 'charisma'
        };
        const abilityHtml = Object.keys(abilityMap).map(ab => {
            const fullKey = abilityMap[ab];
            const score = m[fullKey] || m[ab] || m[ab.toUpperCase()] || 10;
            const mod = APIClient.modifierString(score);
            const plAttr = APIClient.ABILITY_NAMES_PL[APIClient.ABILITY_NAMES.indexOf(ab.toUpperCase())] || ab.toUpperCase();
            return `<div class="ability-score">
                <span class="ability-name">${plAttr}</span>
                <span class="ability-value">${score}</span>
                <span class="ability-mod">(${mod})</span>
            </div>`;
        }).join('');

        const dmgImmunities = this._joinArray(m.damage_immunities);
        const dmgResistances = this._joinArray(m.damage_resistances);
        const dmgVulnerabilities = this._joinArray(m.damage_vulnerabilities);
        const condImmunities = this._joinConditions(m.condition_immunities);
        const senses = this._formatSenses(m.senses);
        const langs = m.languages || '—';
        /* rzuty obronne i umiejętności — klikalne */
        const C = window.Codex;
        const SAVE_PL = { STR: 'SIŁ', DEX: 'ZRĘ', CON: 'KON', INT: 'INT', WIS: 'MĄD', CHA: 'CHA' };
        const saves = [], skills = [];
        (m.proficiencies || []).forEach(p => {
            const name = (p.proficiency && p.proficiency.name) || p.name || '';
            const val = +p.value || 0;
            if (name.startsWith('Saving Throw:')) { const k = name.replace('Saving Throw: ', '').trim(); saves.push(C.btn(`1d20+${val}`, `${m.name}: rzut obronny ${SAVE_PL[k] || k}`, `${SAVE_PL[k] || k} +${val}`)); }
            else if (name.startsWith('Skill:')) { const k = name.replace('Skill: ', '').trim(); skills.push(C.btn(`1d20+${val}`, `${m.name}: ${k}`, `${this._esc(k)} +${val}`)); }
        });
        const abil = `<div class="cx-abil">${Object.keys(abilityMap).map(ab => {
            const score = m[abilityMap[ab]] || m[ab] || 10, md = Math.floor((score - 10) / 2);
            const pl = APIClient.ABILITY_NAMES_PL[APIClient.ABILITY_NAMES.indexOf(ab.toUpperCase())] || ab.toUpperCase();
            return `<button type="button" class="cx-ab" data-roll="1d20${md >= 0 ? '+' : ''}${md}" data-lbl="${this._esc(m.name)}: test (${pl})"><small>${pl}</small><b>${score}</b><span>${C.sgn(md)}</span></button>`;
        }).join('')}</div>`;
        const dex = Math.floor(((m.dexterity || 10) - 10) / 2);
        const legendary = m.legendary_actions && m.legendary_actions.length ? `<p class="cx-intro">${this._esc(m.legendary_desc || `${m.name} może wykonać 3 akcje legendarne, wybierając z poniższych. Naraz tylko jedną, zawsze pod koniec tury innego stworzenia. Wykorzystane akcje odzyskuje na początku swojej tury.`)}</p>${C.entries(m.legendary_actions, m.name)}` : '';
        return C.panel({
            kind: 'monster', icon: 'fa-dragon', title: m.name,
            meta: `${this._esc(sizePl)} ${this._esc(typePl)}${align ? ', ' + this._esc(align) : ''}`,
            tags: m._custom ? [{ t: 'własny', cls: 'own' }] : [],
            actions: `<button class="btn-primary btn-small btn-monster-combat" title="Dodaj do walki"><i class="fa-solid fa-khanda"></i> Do walki</button>
                <button class="btn-secondary btn-small btn-pin-monster" title="Przypnij na ekranie"><i class="fa-solid fa-thumbtack"></i> Przypnij</button>
                ${m._custom ? '<button class="btn-danger btn-small btn-delete-monster" title="Usuń własnego potwora"><i class="fa-solid fa-trash"></i></button>' : ''}`,
            tiles: [
                ['Klasa pancerza', String(ac)],
                ['Punkty wytrzymałości', String(hp), hitDice ? C.btn(String(hitDice).replace(/\s/g, ''), `${m.name}: punkty wytrzymałości`, this._esc(String(hitDice).replace(/d/g, 'k'))) : ''],
                ['Szybkość', this._esc(speed)],
                ['Wyzwanie', cr, `${xp} PD · inicjatywa ${C.btn(`1d20${dex >= 0 ? '+' : ''}${dex}`, `${m.name}: inicjatywa`, C.sgn(dex))}`]
            ],
            abil,
            lines: [
                ['Rzuty obronne', saves.join(' ')], ['Umiejętności', skills.join(' ')],
                ['Podatność', this._esc(dmgVulnerabilities)], ['Odporność', this._esc(dmgResistances)],
                ['Niewrażliwość', this._esc(dmgImmunities)], ['Niewrażliwość na stany', this._esc(condImmunities)],
                ['Zmysły', this._esc(senses)], ['Języki', this._esc(langs)]
            ],
            sections: [
                { title: 'Zdolności specjalne', icon: 'fa-star', html: C.entries(m.special_abilities, m.name) },
                { title: 'Akcje', icon: 'fa-hand-fist', html: C.entries(m.actions, m.name) },
                { title: 'Akcje dodatkowe', icon: 'fa-bolt', html: C.entries(m.bonus_actions, m.name) },
                { title: 'Reakcje', icon: 'fa-shield-halved', html: C.entries(m.reactions, m.name) },
                { title: 'Akcje legendarne', icon: 'fa-crown', html: legendary }
            ]
        });
    },

    _bindDetailEvents(monster) {
        const closeBtn = this.els.detail.querySelector('.detail-close');
        if (closeBtn) closeBtn.addEventListener('click', () => this.closeDetail());

        const pinBtn = this.els.detail.querySelector('.btn-pin-monster');
        if (pinBtn) {
            pinBtn.addEventListener('click', () => {
                const cr = monster.challenge_rating != null ? APIClient.crDisplay(monster.challenge_rating) : '—';
                const lines = [`KP ${this._extractAC(monster)} · PW ${this._extractHP(monster)} · CR ${cr}`];
                (monster.actions || []).slice(0, 4).forEach(a => lines.push(`• ${a.name}: ${(a.desc || '').replace(/\s+/g, ' ').slice(0, 140)}`));
                NotesModule.newNote({ title: monster.name, content: lines.join('\n'), color: 'rose', type: 'monster' });
                App.showToast(`Przypięto: ${monster.name}`, 'success');
            });
        }

        const combatBtn = this.els.detail.querySelector('.btn-monster-combat');
        if (combatBtn) combatBtn.addEventListener('click', () => Enhancements.promptMonsterToCombat(monster));

        const delBtn = this.els.detail.querySelector('.btn-delete-monster');
        if (delBtn) {
            delBtn.addEventListener('click', async () => {
                if (await Ask.confirm('Tej operacji nie da się cofnąć.', { title: `Usunąć potwora „${monster.name}”?`, ok: 'Usuń', danger: true })) {
                    StorageManager.deleteCustomMonster(monster._customId);
                    App.showToast(`Usunięto: ${monster.name}`, 'info');
                    this.closeDetail();
                    this.loadMonsters();
                }
            });
        }
    },

    _buildPinSummary(m) {
        const cr = m.challenge_rating != null ? APIClient.crDisplay(m.challenge_rating) : '—';
        const ac = this._extractAC(m);
        const hp = this._extractHP(m);
        return `<strong>${this._esc(m.name)}</strong><br>AC ${ac} | HP ${hp} | CR ${cr}`;
    },

    closeDetail() {
        this.els.detail.classList.add('hidden');
        this.els.detail.innerHTML = '';
        this.detailVisible = false;
    },

    /* ── add custom monster modal ────────────────────────── */
    showAddMonsterModal() {
        const body = `
        <form id="form-add-monster" autocomplete="off">
            <div class="form-row">
                <div class="form-group">
                    <label for="monster-name">Name *</label>
                    <input id="monster-name" type="text" required placeholder="e.g. Shadow Drake">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="monster-size">Size</label>
                    <select id="monster-size">
                        <option value="Tiny">Tiny</option>
                        <option value="Small">Small</option>
                        <option value="Medium" selected>Medium</option>
                        <option value="Large">Large</option>
                        <option value="Huge">Huge</option>
                        <option value="Gargantuan">Gargantuan</option>
                    </select>
                </div>
                <div class="form-group form-row-6">
                    <label for="monster-type">Type</label>
                    <input id="monster-type" type="text" placeholder="e.g. Dragon">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="monster-alignment">Alignment</label>
                    <input id="monster-alignment" type="text" placeholder="e.g. Chaotic Evil">
                </div>
                <div class="form-group form-row-6">
                    <label for="monster-cr">Challenge Rating</label>
                    <input id="monster-cr" type="text" placeholder="e.g. 5 or 1/4">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="monster-ac">Armor Class</label>
                    <input id="monster-ac" type="number" placeholder="15">
                </div>
                <div class="form-group form-row-6">
                    <label for="monster-hp">Hit Points</label>
                    <input id="monster-hp" type="number" placeholder="65">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="monster-hit-dice">Hit Dice</label>
                    <input id="monster-hit-dice" type="text" placeholder="e.g. 10d8+20">
                </div>
                <div class="form-group form-row-6">
                    <label for="monster-speed">Speed</label>
                    <input id="monster-speed" type="text" placeholder="e.g. 30 ft., fly 60 ft.">
                </div>
            </div>
            <h4 class="form-section-title">Atrybuty</h4>
            <div class="form-row">
                <div class="form-group form-row-6"><label for="monster-str">STR</label><input id="monster-str" type="number" value="10"></div>
                <div class="form-group form-row-6"><label for="monster-dex">DEX</label><input id="monster-dex" type="number" value="10"></div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6"><label for="monster-con">CON</label><input id="monster-con" type="number" value="10"></div>
                <div class="form-group form-row-6"><label for="monster-int">INT</label><input id="monster-int" type="number" value="10"></div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6"><label for="monster-wis">WIS</label><input id="monster-wis" type="number" value="10"></div>
                <div class="form-group form-row-6"><label for="monster-cha">CHA</label><input id="monster-cha" type="number" value="10"></div>
            </div>
            <div class="form-group">
                <label for="monster-special">Special Abilities (one per line — "Name: Description")</label>
                <textarea id="monster-special" rows="4" placeholder="Pack Tactics: The creature has advantage on..."></textarea>
            </div>
            <div class="form-group">
                <label for="monster-actions">Actions (one per line — "Name: Description")</label>
                <textarea id="monster-actions" rows="4" placeholder="Bite: Melee Weapon Attack: +7 to hit..."></textarea>
            </div>
        </form>`;

        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Cancel</button>
            <button class="btn-primary" id="btn-save-monster">Save Monster</button>`;

        App.showModal('Add Custom Monster', body, footer);

        /* save handler — bind after modal is in DOM */
        setTimeout(() => {
            const saveBtn = document.getElementById('btn-save-monster');
            if (saveBtn) saveBtn.addEventListener('click', () => this._saveCustomMonster());
        }, 50);
    },

    _saveCustomMonster() {
        const name = document.getElementById('monster-name').value.trim();
        if (!name) { App.showToast('Podaj nazwę potwora', 'error'); return; }

        const parseEntries = (raw) => {
            if (!raw.trim()) return [];
            return raw.split('\n').filter(l => l.trim()).map(line => {
                const idx = line.indexOf(':');
                if (idx === -1) return { name: line.trim(), desc: '' };
                return { name: line.substring(0, idx).trim(), desc: line.substring(idx + 1).trim() };
            });
        };

        const monster = {
            _customId: StorageManager.generateId(),
            _custom: true,
            name,
            size: document.getElementById('monster-size').value,
            type: document.getElementById('monster-type').value.trim() || 'Unknown',
            alignment: document.getElementById('monster-alignment').value.trim(),
            armor_class: [{ type: 'custom', value: parseInt(document.getElementById('monster-ac').value) || 10 }],
            hit_points: parseInt(document.getElementById('monster-hp').value) || 1,
            hit_dice: document.getElementById('monster-hit-dice').value.trim(),
            speed: { walk: document.getElementById('monster-speed').value.trim() || '30 ft.' },
            strength:     parseInt(document.getElementById('monster-str').value) || 10,
            dexterity:    parseInt(document.getElementById('monster-dex').value) || 10,
            constitution: parseInt(document.getElementById('monster-con').value) || 10,
            intelligence: parseInt(document.getElementById('monster-int').value) || 10,
            wisdom:       parseInt(document.getElementById('monster-wis').value) || 10,
            charisma:     parseInt(document.getElementById('monster-cha').value) || 10,
            /* shorthand aliases used by stat block renderer */
            str: parseInt(document.getElementById('monster-str').value) || 10,
            dex: parseInt(document.getElementById('monster-dex').value) || 10,
            con: parseInt(document.getElementById('monster-con').value) || 10,
            int: parseInt(document.getElementById('monster-int').value) || 10,
            wis: parseInt(document.getElementById('monster-wis').value) || 10,
            cha: parseInt(document.getElementById('monster-cha').value) || 10,
            challenge_rating: document.getElementById('monster-cr').value.trim() || '0',
            special_abilities: parseEntries(document.getElementById('monster-special').value),
            actions: parseEntries(document.getElementById('monster-actions').value),
            proficiencies: [],
            damage_immunities: [],
            damage_resistances: [],
            damage_vulnerabilities: [],
            condition_immunities: [],
            senses: {},
            languages: '—',
        };

        StorageManager.saveCustomMonster(monster);
        App.closeModal();
        App.showToast(`${name} added to bestiary`, 'success');
        this.loadMonsters();
    },

    /* ── helpers ──────────────────────────────────────────── */
    _extractAC(m) {
        if (m.armor_class == null) return '—';
        if (typeof m.armor_class === 'number') return m.armor_class;
        if (Array.isArray(m.armor_class)) {
            const first = m.armor_class[0];
            return first ? (first.value != null ? first.value : first) : '—';
        }
        return m.armor_class;
    },

    _extractHP(m) {
        if (m.hit_points != null) return m.hit_points;
        return '—';
    },

    _formatSpeed(speed) {
        if (!speed) return '—';
        if (typeof speed === 'string') return speed;
        return Object.entries(speed)
            .map(([k, v]) => k === 'walk' ? v : `${k} ${v}`)
            .join(', ');
    },

    _joinArray(arr) {
        if (!arr || !arr.length) return '';
        return arr.map(i => typeof i === 'string' ? i : (i.name || i)).join(', ');
    },

    _joinConditions(arr) {
        if (!arr || !arr.length) return '';
        return arr.map(c => typeof c === 'string' ? c : (c.name || c)).join(', ');
    },

    _formatSenses(senses) {
        if (!senses) return '';
        if (typeof senses === 'string') return senses;
        return Object.entries(senses)
            .filter(([, v]) => v)
            .map(([k, v]) => `${k.replace(/_/g,' ')} ${v}`)
            .join(', ');
    },

    _formatEntries(entries, title) {
        if (!entries || !entries.length) return '';
        const items = entries.map(e => `
            <div class="action-entry">
                <span class="action-name">${this._esc(e.name || '')}.</span>
                ${this._esc(e.desc || '')}
            </div>`).join('');
        return `<h3 class="detail-section-title">${title}</h3>${items}`;
    },

    _formatLegendaryActions(m) {
        if (!m.legendary_actions || !m.legendary_actions.length) return '';
        const preamble = m.legendary_desc
            ? `<p>${this._esc(m.legendary_desc)}</p>`
            : `<p>${this._esc(m.name)} can take 3 legendary actions, choosing from the options below. Only one legendary action option can be used at a time and only at the end of another creature's turn. ${this._esc(m.name)} regains spent legendary actions at the start of its turn.</p>`;

        const items = m.legendary_actions.map(e => `
            <div class="action-entry">
                <span class="action-name">${this._esc(e.name || '')}.</span>
                ${this._esc(e.desc || '')}
            </div>`).join('');

        return `<h3 class="legendary-title">Legendarne Akcje</h3>${preamble}${items}`;
    },

    _showLoading() {
        this.els.list.innerHTML = `<div class="loading-spinner"><div class="spinner"></div><p>Wczytuję bestiariusz…</p></div>`;
    },

    _spinnerHtml() {
        return `<div class="loading-spinner"><div class="spinner"></div></div>`;
    },

    _emptyState(msg) {
        return `<div class="empty-state empty-state-wide"><i class="fa-solid fa-feather"></i><span>${this._esc(msg)}</span></div>`;
    },

    _esc(str) {
        if (str == null) return '';
        const d = document.createElement('div');
        d.textContent = String(str);
        return d.innerHTML;
    },
};

window.BestiaryModule = BestiaryModule;
