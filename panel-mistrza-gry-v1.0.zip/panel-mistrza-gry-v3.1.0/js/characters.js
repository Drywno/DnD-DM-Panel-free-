/* ============================================
   D&D 5e DM Panel — Characters Module (PC)
   ============================================ */

const CharactersModule = (function() {
    let characters = [];
    let currentCharacterId = null;

    // Helper to escape HTML to prevent XSS
    function _esc(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function init() {
        // Bind Add Character button
        const btnAdd = document.getElementById('btn-add-character');
        if (btnAdd) {
            btnAdd.addEventListener('click', () => showAddCharacterModal());
        }

        // Bind Back button
        const btnBack = document.getElementById('btn-back-characters');
        if (btnBack) {
            btnBack.addEventListener('click', () => hideCharacterSheet());
        }

        // Bind Sheet Tabs
        document.querySelectorAll('.sheet-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                document.querySelectorAll('.sheet-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                renderSheetTab(tab.dataset.sheetTab);
            });
        });

        // Bind Delete button
        const btnDelete = document.getElementById('btn-delete-character');
        if (btnDelete) {
            btnDelete.addEventListener('click', async () => {
                if (!currentCharacterId) return;
                if (await Ask.confirm('Karta bohatera zniknie z kampanii. Tego nie da się cofnąć.', { title: 'Usunąć bohatera?', ok: 'Usuń', danger: true })) {
                    const campaignId = App.getActiveCampaignId();
                    StorageManager.deleteCharacter(campaignId, currentCharacterId);
                    hideCharacterSheet();
                    activate();
                    App.showToast('Bohater usunięty', 'info');
                }
            });
        }

        // Bind Pin button
        const btnPin = document.getElementById('btn-pin-character');
        if (btnPin) {
            btnPin.addEventListener('click', () => {
                if (currentCharacterId) pinCharacter(currentCharacterId);
            });
        }
        
        // Bind Export button
        const btnExport = document.getElementById('btn-export-character');
        if (btnExport) {
            btnExport.addEventListener('click', () => {
                if (currentCharacterId) exportCharacter(currentCharacterId);
            });
        }

        // Bind Export PDF button
        const btnExportPdf = document.getElementById('btn-export-pdf');
        if (btnExportPdf) {
            btnExportPdf.addEventListener('click', () => {
                if (currentCharacterId) exportToPDF(currentCharacterId);
            });
        }

        // Bind Import button
        const inputImport = document.getElementById('btn-import-character');
        if (inputImport) {
            inputImport.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    importCharacter(e.target.files[0]);
                    e.target.value = ''; // Reset
                }
            });
        }
    }

    function activate() {
        const campaignId = App.getActiveCampaignId();
        if (!campaignId) {
            const list = document.getElementById('characters-list');
            if (list) list.innerHTML = '<p class="empty-state">Wybierz kampanię, aby zarządzać bohaterami.</p>';
            return;
        }
        loadCharacters();
        renderList();
    }

    function loadCharacters() {
        const campaignId = App.getActiveCampaignId();
        characters = (StorageManager.getCharacters(campaignId) || []).map(normalizeCharacter);
    }

    // ---------- Karty bohaterów (widok listy) ----------
    const ABIL = [['str', 'SIŁ'], ['dex', 'ZRĘ'], ['con', 'KON'], ['int', 'INT'], ['wis', 'MDR'], ['cha', 'CHA']];
    const CAST_BY_CLASS = { wizard: 'int', cleric: 'wis', druid: 'wis', ranger: 'wis', bard: 'cha', sorcerer: 'cha', warlock: 'cha', paladin: 'cha' };
    const _mod = (s) => Math.floor(((s ?? 10) - 10) / 2);
    const _sign = (n) => (n >= 0 ? `+${n}` : `−${Math.abs(n)}`);

    function castAbility(char) {
        const raw = String(char.spellcastingAbility || '').toLowerCase().slice(0, 3);
        const map = { int: 'int', wis: 'wis', mdr: 'wis', cha: 'cha', cha_: 'cha' };
        if (map[raw]) return map[raw];
        const hasSlots = Object.values(char.spellSlots || {}).some(s => (s?.total || 0) > 0);
        const ck = window.Kits ? Kits.classKey(char.class) : '';
        return hasSlots ? (CAST_BY_CLASS[ck] || null) : null;
    }

    // o.view — tylko podgląd (panel gracza: karty kolegów): bez przycisków PW i awansu, klik otwiera podgląd karty
    function heroCard(char, o = {}) {
        const V = !!o.view;
        const ck = window.Kits ? Kits.classKey(char.class) : '';
        const meta = (window.Kits && Kits.CLASS_META[ck]) || { icon: 'fa-user', color: '#b08a4a', pl: char.class };
        const lvl = char.level || 1;
        const prof = APIClient.proficiencyBonus(lvl);
        const sc = char.abilityScores || {};
        const hpMax = char.hp?.max || 0, hpCur = char.hp?.current || 0, hpTmp = char.hp?.temp || 0;
        const hpPct = hpMax > 0 ? Math.max(0, Math.min(100, Math.round(hpCur / hpMax * 100))) : 0;
        const hpClass = hpPct > 50 ? 'hp-high' : hpPct > 25 ? 'hp-mid' : 'hp-low';
        const xp = char.xp || 0;
        const next = lvl < 20 ? ClassData.XP_THRESHOLDS[lvl + 1] : null;
        const prev = ClassData.XP_THRESHOLDS[lvl] || 0;
        const xpPct = next ? Math.max(0, Math.min(100, Math.round((xp - prev) / (next - prev) * 100))) : 100;
        const ready = next !== null && next !== undefined && xp >= next;
        const percep = passiveOf(char, 'Percepcja');
        const hd = char.hitDicePool || { current: lvl, max: lvl, die: char.hitDie || meta.die || 8 };
        const subclass = char.subclass ? (ClassData.getSubclassesForClass(ck).find(s => s.key === char.subclass)?.name || char.subclass) : '';

        const atk = window.Kits ? Kits.attacks(char, 3) : [];
        const ca = castAbility(char);
        const slots = Object.entries(char.spellSlots || {}).filter(([, v]) => (v?.total || 0) > 0)
            .map(([lv, v]) => `<span class="hc-slot" title="Sloty ${lv}. kręgu"><em>${lv}</em>${'<i class="on"></i>'.repeat(Math.max(0, v.total - (v.used || 0)))}${'<i></i>'.repeat(Math.min(v.total, v.used || 0))}</span>`).join('');
        const down = hpCur <= 0 && hpMax > 0;
        const ds = char.deathSaves || { successes: 0, failures: 0 };
        const profSkills = Object.keys(APIClient.SKILLS).filter(sk => skillLevel(char, sk) > 0)
            .map(sk => ({ sk, b: skillBonus(char, sk), exp: skillLevel(char, sk) === 2 }))
            .sort((a, b) => b.b - a.b || a.sk.localeCompare(b.sk, 'pl'));
        const skillsHtml = `<div class="hc-skills">
                <div class="hc-skills-head"><span>Umiejętności</span><small>Pas. Wgląd ${passiveOf(char, 'Wgląd')} · Śledztwo ${passiveOf(char, 'Śledztwo')}</small></div>
                <div class="hc-skill-list">${profSkills.length ? profSkills.map(x => `<span class="hc-skill ${x.exp ? 'exp' : ''}" title="${x.exp ? 'Ekspertyza' : 'Biegłość'}">${_esc(x.sk)} <b>${_sign(x.b)}</b></span>`).join('') : `<span class="hc-skill-none">${V ? 'Brak biegłości' : 'Brak biegłości — ustaw je w zakładce Umiejętności'}</span>`}</div>
            </div>`;

        return `
        <article class="hero-card ${V ? 'is-view' : ''} ${o.me ? 'is-me' : ''} ${down ? 'is-down' : ''} ${ready && !V ? 'can-level' : ''}" style="--cls:${meta.color}" ${V ? `data-peek="${_esc(char.id)}"` : `data-open="${_esc(char.id)}"`} tabindex="0" aria-label="${V ? (o.me ? 'Moja postać' : 'Podejrzyj kartę') : 'Otwórz kartę'}: ${_esc(char.name)}">
            <header class="hc-head">
                <div class="hc-crest ${char.portrait ? 'has-img' : ''}"><i class="fa-solid ${meta.icon}"></i>${char.portrait ? `<span class="hc-crest-img"><img src="${_esc(char.portrait)}" alt=""></span>` : ''}<span class="hc-lvl" title="Poziom">${lvl}</span>${o.online ? '<span class="hc-on" title="Przy stole"></span>' : ''}</div>
                <div class="hc-id">
                    <h3>${_esc(char.name)}${o.me ? ' <small class="hc-me">(Ty)</small>' : ''}</h3>
                    <p>${_esc(window.PL ? PL.race(char.race || '') : (char.race || ''))}${char.subrace ? ` (${_esc(window.PL ? PL.race(char.subrace) : char.subrace)})` : ''} · ${_esc(meta.pl || char.class || '')}${subclass ? ` <span class="hc-sub">${_esc(subclass)}</span>` : ''}</p>
                    ${(char.background || char.alignment) ? `<small>${_esc([char.background, char.alignment].filter(Boolean).join(' · '))}</small>` : ''}
                </div>
            </header>

            <div class="hc-xp" title="${xp.toLocaleString(window.LOC || 'pl-PL')} XP${next ? ` / ${next.toLocaleString(window.LOC || 'pl-PL')}` : ''}">
                <div class="hc-xp-bar"><div style="width:${xpPct}%"></div></div>
                <span>${next ? `${xp.toLocaleString(window.LOC || 'pl-PL')} / ${next.toLocaleString(window.LOC || 'pl-PL')} XP` : 'Poziom maksymalny'}</span>
                ${lvl < 20 && !V ? `<button class="hc-levelup" data-act="level" title="Awans na poziom ${lvl + 1}">${ready ? '<i class="fa-solid fa-angles-up"></i> Awansuj!' : '<i class="fa-solid fa-arrow-up"></i> Poziom'}</button>` : ''}
            </div>

            <div class="hc-vitals">
                <div class="hc-ac" title="Klasa Pancerza"><i class="fa-solid fa-shield"></i><b>${char.ac ?? 10}</b></div>
                <div class="hc-v"><b>${_sign(initOf(char))}</b><small>Inicjatywa</small></div>
                <div class="hc-v"><b>${char.speed ?? 30}</b><small>ft</small></div>
                <div class="hc-v"><b>${percep}</b><small>Pas. Perc.</small></div>
                <div class="hc-v"><b>+${prof}</b><small>Biegłość</small></div>
            </div>

            <div class="hc-hp">
                <div class="hc-hp-top">
                    <span class="hc-hp-label"><i class="fa-solid fa-heart"></i> PW</span>
                    <span class="hc-hp-val ${hpClass}"><b>${hpCur}</b>/${hpMax}${hpTmp ? ` <em>+${hpTmp}</em>` : ''}</span>
                    <span class="hc-hd" title="Kości Wytrzymałości">${hd.current ?? lvl}/${hd.max ?? lvl} k${hd.die || 8}</span>
                </div>
                <div class="hp-bar"><div class="hp-bar-fill ${hpClass}" style="width:${hpPct}%"></div></div>
                ${down ? `<div class="hc-death">Nieprzytomny · sukcesy ${'●'.repeat(ds.successes || 0)}${'○'.repeat(3 - (ds.successes || 0))} · porażki ${'●'.repeat(ds.failures || 0)}${'○'.repeat(3 - (ds.failures || 0))}</div>` : ''}
                ${V ? '' : `<div class="hc-hp-ctrl">
                    <button data-act="hp" data-sign="-1" class="dmg" title="Obrażenia (Enter)">−</button>
                    <input type="number" min="0" placeholder="PW" data-hpin aria-label="Ile PW">
                    <button data-act="hp" data-sign="0" class="set" title="Ustaw PW na wpisaną liczbę">=</button>
                    <button data-act="hp" data-sign="1" class="heal" title="Leczenie (Shift+Enter)">+</button>
                </div>`}
            </div>

            <div class="hc-abil">
                ${ABIL.map(([k, l]) => `<div class="${(char.savingThrows || []).includes(k.toUpperCase()) ? 'is-save' : ''}"><small>${l}</small><b>${_sign(_mod(sc[k]))}</b><em>${sc[k] ?? 10}</em></div>`).join('')}
            </div>

            ${skillsHtml}

            ${(atk.length || ca) ? `<div class="hc-combat">
                ${atk.map(a => `<div class="hc-atk"><i class="fa-solid ${a.ranged ? 'fa-bullseye' : 'fa-khanda'}"></i><span>${_esc(a.name)}</span><b>${_sign(a.hit)}</b><em>${a.dmg} ${a.type}</em></div>`).join('')}
                ${ca ? `<div class="hc-atk hc-magic"><i class="fa-solid fa-wand-sparkles"></i><span>Czary</span><b>${_sign(_mod(sc[ca]) + prof)}</b><em>ST ${8 + prof + _mod(sc[ca])}</em></div>` : ''}
            </div>` : ''}

            ${slots ? `<div class="hc-slots">${slots}</div>` : ''}

            ${V ? `<footer class="hc-foot"><span><i class="fa-solid ${o.me ? 'fa-user-shield' : 'fa-eye'}"></i> ${o.me ? 'Twoja postać — kliknij, by przejść do karty' : 'Kliknij, aby podejrzeć kartę'}</span><span>${o.player ? `gra: ${_esc(o.player)}` : ''}</span></footer>${o.extra || ''}`
                : `<footer class="hc-foot"><span><i class="fa-solid fa-pen-nib"></i> Kliknij, aby otworzyć kartę</span><span>${(char.inventory || []).length} przedm. · ${char.currency?.gp || 0} sz</span></footer>`}
        </article>`;
    }

    function renderList() {
        const list = document.getElementById('characters-list');
        if (!list) return;

        if (characters.length === 0) {
            list.innerHTML = `
                <div class="add-card" onclick="CharactersModule.showAddCharacterModal()">
                    <div class="add-card-icon">🧙</div>
                    <div class="add-card-text">Dodaj pierwszego bohatera (PC) do tej kampanii</div>
                </div>
            `;
            return;
        }

        list.innerHTML = characters.map(c => heroCard(c)).join('') + `
            <button class="hero-card hero-add" type="button" data-act="add"><i class="fa-solid fa-user-plus"></i><span>Nowy bohater</span><small>Kreator z gotowym zestawem</small></button>`;
        bindList(list);
    }

    function bindList(list) {
        if (list._heroBound) return;
        list._heroBound = true;
        list.addEventListener('click', (e) => {
            const act = e.target.closest('[data-act]');
            const card = e.target.closest('.hero-card[data-open]');
            if (act?.dataset.act === 'add') { showAddCharacterModal(); return; }
            if (!card) return;
            const id = card.dataset.open;
            if (act?.dataset.act === 'level') { e.stopPropagation(); levelUpFor(id); return; }
            if (act?.dataset.act === 'hp') { e.stopPropagation(); cardHP(id, +act.dataset.sign, card.querySelector('[data-hpin]')); return; }
            if (e.target.closest('input, button, a')) return;
            showCharacterSheet(id);
        });
        list.addEventListener('keydown', (e) => {
            const inp = e.target.closest('[data-hpin]');
            if (inp && e.key === 'Enter') { e.preventDefault(); cardHP(inp.closest('.hero-card').dataset.open, e.shiftKey ? 1 : -1, inp); return; }
            const card = e.target.closest('.hero-card[data-open]');
            if (card && e.target === card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); showCharacterSheet(card.dataset.open); }
        });
    }

    function cardHP(id, sign, input) {
        const char = characters.find(c => c.id === id);
        if (!char) return;
        const raw = input?.value;
        if (sign === 0 && (raw === '' || raw === undefined)) { App.showToast('Wpisz liczbę PW, na którą ustawić', 'warning'); input?.focus(); return; }
        const val = Math.abs(parseInt(raw, 10) || 0) || (sign === 0 ? 0 : 1);
        applyHP(char, sign, val);
        StorageManager.saveCharacter(App.getActiveCampaignId(), char);
        App.showToast(`${char.name}: ${HP_MSG[sign](val)} (${char.hp.current}/${char.hp.max})`, sign < 0 ? 'warning' : 'success');
        activate();
        const again = document.querySelector(`.hero-card[data-open="${CSS.escape(id)}"]`);
        if (again) { again.classList.add(sign < 0 ? 'hit' : 'healed'); setTimeout(() => again.classList.remove('hit', 'healed'), 600); }
    }

    function levelUpFor(id) {
        currentCharacterId = id;
        levelUp();
    }

    // Wpisuje gotowy zestaw klasy do istniejącej postaci (zakładka Ekwipunek)
    function showKitModal() {
        const char = getCharacter();
        if (!char || !window.Kits) return;
        const ck = Kits.classKey(char.class);
        const kit = Kits.CLASS_KITS[ck];
        if (!kit) { App.showToast('Brak gotowego zestawu dla tej klasy', 'warning'); return; }
        const choices = kit.choices.map((opts, i) => `
            <div class="cm-kit-choice">
                <div class="cm-kit-choice-label">Wybór ${i + 1}</div>
                <div class="cm-kit-chips">${opts.map((o, j) => `<label class="cm-kit-chip ${j === 0 ? 'is-on' : ''}"><input type="radio" name="kit-${i}" value="${j}" ${j === 0 ? 'checked' : ''}>${_esc(o.label)}</label>`).join('')}</div>
            </div>`).join('');
        const fixed = Kits.fixedSummary(ck);
        App.showModal(`Gotowy zestaw — ${_esc(Kits.CLASS_META[ck].pl)}`, `
            <div class="cm-kit-box">${choices}
                ${fixed.length ? `<div class="cm-kit-choice"><div class="cm-kit-choice-label">Zawsze w zestawie</div><div class="cm-kit-fixed">${fixed.map(f => `<span>${_esc(f)}</span>`).join('')}</div></div>` : ''}
            </div>
            <label class="pick-row"><input type="checkbox" id="kit-ac" checked> <span>Przelicz KP według pancerza i tarczy</span></label>
            <p class="modal-hint">Przedmioty zostaną dopisane do obecnego ekwipunku (powtórki zwiększą ilość).</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="kit-go"><i class="fa-solid fa-box-open"></i> Wpisz zestaw</button>`);
        document.querySelectorAll('.modal .cm-kit-chip input, #modal-overlay .cm-kit-chip input').forEach(r => r.addEventListener('change', () => {
            r.closest('.cm-kit-chips').querySelectorAll('.cm-kit-chip').forEach(c => c.classList.toggle('is-on', c.contains(r)));
        }));
        document.getElementById('kit-go').onclick = () => {
            const picks = kit.choices.map((_, i) => +(document.querySelector(`input[name="kit-${i}"]:checked`)?.value || 0));
            char.inventory = Kits.mergeInto(char.inventory || [], Kits.buildClassKit(ck, picks));
            if (document.getElementById('kit-ac')?.checked) char.ac = Kits.computeAC(char);
            saveCharacter(char);
            App.closeModal();
            App.showToast(`Zestaw wpisany · KP ${char.ac}`, 'success');
            renderSheetTab('inventory');
        };
    }

    let cachedClasses = [];
    let cachedRaces = [];

    async function ensureCacheLoaded() {
        if (cachedClasses.length === 0) {
            const clsList = await APIClient.getClassList();
            cachedClasses = clsList.map(c => c.name);
        }
        if (cachedRaces.length === 0) {
            const rcList = await APIClient.getRaceList();
            cachedRaces = rcList.map(r => r.name);
            cachedRaces.push("Goliat", "Goliath"); // Customowe rasy spoza SRD 5e
            cachedRaces.sort();
        }
    }

    async function showCharacterSheet(charId) {
        currentCharacterId = charId;
        const list = document.getElementById('characters-list');
        const sheet = document.getElementById('character-sheet');
        const btnAdd = document.getElementById('btn-add-character');
        
        if (list) list.classList.add('hidden');
        if (btnAdd) btnAdd.classList.add('hidden');
        if (sheet) sheet.classList.remove('hidden');

        try {
            await ensureCacheLoaded();
        } catch (e) {
            // Offline / SRD down — the sheet still works with stored data
            console.warn('[Characters] SRD lists unavailable:', e);
        }

        // Reset to first tab
        document.querySelectorAll('.sheet-tab').forEach(t => t.classList.remove('active'));
        const firstTab = document.querySelector('.sheet-tab[data-sheet-tab="stats"]');
        if (firstTab) firstTab.classList.add('active');

        renderSheetTab('stats');
    }

    function hideCharacterSheet() {
        currentCharacterId = null;
        const list = document.getElementById('characters-list');
        const sheet = document.getElementById('character-sheet');
        const btnAdd = document.getElementById('btn-add-character');
        
        if (list) list.classList.remove('hidden');
        if (btnAdd) btnAdd.classList.remove('hidden');
        if (sheet) sheet.classList.add('hidden');
    }

    // Older / imported sheets can miss fields — fill safe defaults so no tab crashes
    function normalizeCharacter(c) {
        if (!c) return c;
        c.hp = c.hp || { current: 10, max: 10, temp: 0 };
        if (c.hp.temp == null) c.hp.temp = 0;
        c.abilityScores = Object.assign({ str: 10, dex: 10, con: 10, int: 10, wis: 10, cha: 10 }, c.abilityScores || {});
        c.deathSaves = c.deathSaves || { successes: 0, failures: 0 };
        c.proficiencies = c.proficiencies || [];
        c.savingThrows = c.savingThrows || [];
        c.spellSlots = c.spellSlots || {};
        c.spells = c.spells || [];
        c.inventory = c.inventory || [];
        c.languages = c.languages || [];
        c.currency = Object.assign({ cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 }, c.currency || {});
        c.features = c.features || { class: '', feats: '' };
        c.backstory = Object.assign({ personality: '', ideals: '', bonds: '', flaws: '', history: '' }, c.backstory || {});
        if (c.level == null) c.level = 1;
        if (c.xp == null) c.xp = 0;
        if (c.ac == null) c.ac = 10;
        if (c.speed == null) c.speed = 30;
        return c;
    }

    function getCharacter() {
        return normalizeCharacter(characters.find(c => c.id === currentCharacterId));
    }

    function saveCharacter(char) {
        const campaignId = App.getActiveCampaignId();
        StorageManager.saveCharacter(campaignId, char);
        loadCharacters(); // reload
    }

    function updateCharacterField(fieldPath, value) {
        const char = getCharacter();
        if (!char) return;

        const parts = fieldPath.split('.');
        let obj = char;
        for (let i = 0; i < parts.length - 1; i++) {
            if (!obj[parts[i]]) obj[parts[i]] = {};
            obj = obj[parts[i]];
        }
        obj[parts[parts.length - 1]] = value;
        saveCharacter(char);
    }

    function renderSheetTab(tabId) {
        const char = getCharacter();
        if (!char) return;
        
        const content = document.getElementById('sheet-content');
        if (!content) return;

        let html = '';
        
        if (tabId === 'stats') {
            html = renderStatsTab(char);
        } else if (tabId === 'skills') {
            html = renderSkillsTab(char);
        } else if (tabId === 'combat-stats') {
            html = renderCombatTab(char);
        } else if (tabId === 'spellcasting') {
            html = renderSpellcastingTab(char);
        } else if (tabId === 'inventory') {
            html = renderInventoryTab(char);
        } else if (tabId === 'features') {
            html = renderFeaturesTab(char);
        } else if (tabId === 'backstory') {
            html = renderBackstoryTab(char);
        } else if (tabId === 'notes') {
            html = renderNotesTab(char);
        }

        content.innerHTML = html;
        renderHero(char);

        // Bind change events for inputs to save automatically
        content.querySelectorAll('input, textarea, select').forEach(input => {
            input.addEventListener('change', (e) => {
                const field = e.target.dataset.field;
                if (!field) return;
                
                let value = e.target.value;
                if (e.target.type === 'number') value = parseInt(value) || 0;
                if (e.target.type === 'checkbox') value = e.target.checked;
                
                updateCharacterField(field, value);
                
                // Charactermancer hook
                if (field === 'race' && value) {
                    promptApplyRace(value);
                } else if (field === 'class' && value) {
                    promptApplyClass(value);
                } else if (field === 'level' || field.startsWith('abilityScores.') || field.startsWith('spellSlots.')) {
                    // Re-render if it affects derived stats
                    renderSheetTab(tabId);
                } else {
                    renderHero(getCharacter());
                }
            });
        });
    }

    // --- Charactermancer logic ---
    function promptApplyRace(raceName) {
        const char = getCharacter();
        if (!char) return;
        const body = `<p>Czy chcesz, aby system automatycznie zaaplikował bazowe cechy dla rasy <b>${_esc(raceName)}</b> z bazy SRD D&D 5e (zmiana atrybutów, prędkości, wizji)?</p><p style="color:var(--text-muted); font-size:0.8rem;">To zastąpi Twoje obecne modyfikatory prędkości i punktów Ability Score z rasy.</p>`;
        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Nie, dziękuję</button>
            <button class="btn-primary" onclick="CharactersModule.applyRaceData('${_esc(raceName)}'); App.closeModal()">Zastosuj</button>
        `;
        App.showModal('Charactermancer: Rasa', body, footer);
    }

    function promptApplyClass(className) {
        const char = getCharacter();
        if (!char) return;
        const body = `<p>Zmieniono klasę na <b>${_esc(className)}</b>. Czy zaktualizować na karcie Rzuty Obronne i podstawowe Biegłości zgodne z SRD D&D 5e?</p>`;
        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-primary" onclick="CharactersModule.applyClassData('${_esc(className)}'); App.closeModal()">Tak, Zastosuj</button>
        `;
        App.showModal('Charactermancer: Klasa', body, footer);
    }

    async function applyRaceData(raceName) {
        const index = APIClient._indexify(raceName);
        if(!index) return;
        const data = await APIClient.getRace(index);
        if(!data || data.error) {
            App.showToast('Nie znaleziono tej rasy w bazie D&D 5e.', 'error');
            return;
        }

        const char = getCharacter();
        if(!char) return;

        // Apply Speed
        if(data.speed) {
            char.speed = data.speed;
        }
        
        // Apply Ability Bonuses
        if(data.ability_bonuses) {
            data.ability_bonuses.forEach(b => {
                const attr = b.ability_score.index.toLowerCase(); // 'str', 'dex'...
                char.abilityScores[attr] = (char.abilityScores[attr] || 10) + b.bonus;
            });
        }
        
        // Apply traits as features
        if (!char.traits) char.traits = [];
        if(data.traits && data.traits.length > 0) {
            for(const t of data.traits) {
                if(!char.traits.some(x => x.index === t.index)) {
                    try {
                        const traitInfo = await APIClient.getTrait(t.index);
                        const englishDesc = Array.isArray(traitInfo.desc) ? traitInfo.desc.join('\n') : (traitInfo.desc || '');
                        const translatedDesc = await APIClient.translateText(englishDesc);
                        char.traits.push({ name: traitInfo.name, index: t.index, desc: translatedDesc });
                    } catch (e) {
                        char.traits.push({ name: t.name, index: t.index, desc: '' });
                    }
                }
            }
        }

        saveCharacter(char);
        renderSheetTab(document.querySelector('.sheet-tab.active').dataset.sheetTab);
        App.showToast('Cechy Rasowe zostały nałożone!', 'success');
    }

    async function applyClassData(className) {
        const index = APIClient._indexify(className);
        if(!index) return;
        const data = await APIClient.getClass(index);
        if(!data || data.error) {
            App.showToast('Nie znaleziono tej klasy w bazie D&D 5e.', 'error');
            return;
        }

        const char = getCharacter();
        if(!char) return;

        // Saving Throws
        if(data.saving_throws) {
            char.savingThrows = data.saving_throws.map(st => st.name.substring(0,3)); // e.g. 'STR'
        }

        // Add Hit Dice context to Notes
        if (data.hit_die) {
            char.combatNotes = (char.combatNotes || '') + `\nHit Dice: d${data.hit_die}`;
        }
        
        // Fetch Level 1 class features
        if (!char.classFeatures) char.classFeatures = [];
        try {
            const levelData = await APIClient.getClassLevel(index, 1);
            if(levelData && levelData.features) {
                for(let i=0; i<levelData.features.length; i++) {
                    const fObj = levelData.features[i];
                    if(!char.classFeatures.some(x => x.index === fObj.index)) {
                        const featData = await APIClient.getFeature(fObj.index);
                        if(featData && featData.desc) {
                            const englishDesc = Array.isArray(featData.desc) ? featData.desc.join('\n') : featData.desc;
                            const translatedDesc = await APIClient.translateText(englishDesc);
                            char.classFeatures.push({ name: featData.name, index: fObj.index, desc: translatedDesc });
                        } else {
                            char.classFeatures.push({ name: fObj.name, index: fObj.index, desc: '' });
                        }
                    }
                }
            }
            
            // Append spellcasting info to magic notes if available
            if(levelData && levelData.spellcasting) {
                let spellsInfo = "\n-- Magia (Klasa bazowa) --\n";
                if(levelData.spellcasting.cantrips_known !== undefined) spellsInfo += `Znane sztuczki (Cantrips): ${levelData.spellcasting.cantrips_known}\n`;
                if(levelData.spellcasting.spells_known !== undefined) spellsInfo += `Znane zaklęcia: ${levelData.spellcasting.spells_known}\n`;
                char.spellsNotes = (char.spellsNotes || '') + spellsInfo;
            }
        } catch(e) {
            console.warn("Nie udało się pobrać cech klasy:", e);
        }

        saveCharacter(char);
        renderSheetTab(document.querySelector('.sheet-tab.active').dataset.sheetTab);
        App.showToast('Statystyki Klasy i Opisy zaktualizowane!', 'success');
    }

    // --- Sub-tab renderers ---

    // =====================================================================
    //  ARKUSZ POSTACI — nowy wygląd
    // =====================================================================
    const SKILL_EN = {
        'Acrobatics': 'Akrobatyka', 'Animal Handling': 'Opieka nad zwierzętami', 'Arcana': 'Wiedza mistyczna', 'Athletics': 'Atletyka',
        'Deception': 'Oszustwo', 'History': 'Historia', 'Insight': 'Wgląd', 'Intimidation': 'Zastraszanie', 'Investigation': 'Śledztwo',
        'Medicine': 'Medycyna', 'Nature': 'Natura', 'Perception': 'Percepcja', 'Performance': 'Występy', 'Persuasion': 'Perswazja',
        'Religion': 'Religia', 'Sleight of Hand': 'Zwinne dłonie', 'Stealth': 'Skradanie', 'Survival': 'Sztuka przetrwania'
    };
    const AB_PL = { STR: 'Siła', DEX: 'Zręczność', CON: 'Kondycja', INT: 'Inteligencja', WIS: 'Mądrość', CHA: 'Charyzma' };
    const AB_SHORT = { STR: 'SIŁ', DEX: 'ZRĘ', CON: 'KON', INT: 'INT', WIS: 'MDR', CHA: 'CHA' };

    function skillLevel(char, skill) {
        const has = (list) => (list || []).some(s => s === skill || SKILL_EN[s] === skill);
        if (has(char.expertise)) return 2;
        if (has(char.proficiencies)) return 1;
        return 0;
    }
    // Złota rączka (bard od 2. poziomu): połowa premii z biegłości do testów bez biegłości — także inicjatywy
    function jackBonus(char) {
        const ck = window.Kits ? Kits.classKey(char.class) : String(char.class || '').toLowerCase();
        return ck === 'bard' && (char.level || 1) >= 2 ? Math.floor(APIClient.proficiencyBonus(char.level || 1) / 2) : 0;
    }
    // premia do inicjatywy: wpisana ręcznie (initBonus) albo z atutów z awansu (np. Czujny +5)
    function initExtra(char) {
        if (char.initBonus != null && char.initBonus !== '') return parseInt(char.initBonus, 10) || 0;
        const F = (window.ClassData && ClassData.FEATS) || [];
        return (char.feats || []).reduce((s, f) => s + ((F.find(x => x.key === f.key) || {}).effects?.initiativeBonus || 0), 0);
    }
    function initOf(char) { return _mod(char.abilityScores?.dex) + initExtra(char) + jackBonus(char); }
    function skillBonus(char, skill) {
        const attr = APIClient.SKILLS[skill].toLowerCase();
        const lv = skillLevel(char, skill);
        return _mod(char.abilityScores?.[attr]) + (lv ? lv * APIClient.proficiencyBonus(char.level || 1) : jackBonus(char));
    }
    function saveBonus(char, attr) {
        const prof = (char.savingThrows || []).includes(attr) ? APIClient.proficiencyBonus(char.level || 1) : 0;
        return _mod(char.abilityScores?.[attr.toLowerCase()]) + prof;
    }
    function passiveOf(char, skill) { return 10 + skillBonus(char, skill); }

    function sheetHero(char) {
        const ck = window.Kits ? Kits.classKey(char.class) : '';
        const meta = (window.Kits && Kits.CLASS_META[ck]) || { icon: 'fa-user', color: '#b08a4a', pl: char.class };
        const lvl = char.level || 1;
        const prof = APIClient.proficiencyBonus(lvl);
        const hpMax = char.hp?.max || 0, hpCur = char.hp?.current || 0, hpTmp = char.hp?.temp || 0;
        const hpPct = hpMax > 0 ? Math.max(0, Math.min(100, Math.round(hpCur / hpMax * 100))) : 0;
        const hpClass = hpPct > 50 ? 'hp-high' : hpPct > 25 ? 'hp-mid' : 'hp-low';
        const xp = char.xp || 0;
        const next = lvl < 20 ? ClassData.XP_THRESHOLDS[lvl + 1] : null;
        const prev = ClassData.XP_THRESHOLDS[lvl] || 0;
        const xpPct = next ? Math.max(0, Math.min(100, Math.round((xp - prev) / (next - prev) * 100))) : 100;
        const ready = !!next && xp >= next;
        const subclass = char.subclass ? (ClassData.getSubclassesForClass(ck).find(s => s.key === char.subclass)?.name || char.subclass) : '';
        const hd = char.hitDicePool || { current: lvl, max: lvl, die: char.hitDie || meta.die || 8 };
        const ds = char.deathSaves || { successes: 0, failures: 0 };
        const down = hpCur <= 0 && hpMax > 0;
        const init = initOf(char);   // ZRĘ + premia (np. atut Czujny) + Złota rączka barda
        const pip = (type, n, on) => `<button class="sh-ds ${on ? 'on' : ''}" onclick="CharactersModule.setDeathSave('${type}', ${n})" aria-label="${type === 'successes' ? 'Sukces' : 'Porażka'} ${n}"></button>`;

        return `
        <div class="sh-hero ${down ? 'is-down' : ''}" style="--cls:${meta.color}">
            <div class="sh-ident">
                <div class="hc-crest sh-crest ${char.portrait ? 'has-img' : ''}"><i class="fa-solid ${meta.icon}"></i>${char.portrait ? `<span class="hc-crest-img"><img src="${_esc(char.portrait)}" alt=""></span>` : ''}<span class="hc-lvl">${lvl}</span>
                    <button type="button" class="sh-av-btn" onclick="CharactersModule.pickPortrait()" title="${char.portrait ? 'Zmień obrazek postaci' : 'Wgraj obrazek postaci'}"><i class="fa-solid fa-camera"></i></button>
                    ${char.portrait ? '<button type="button" class="sh-av-btn del" onclick="CharactersModule.clearPortrait()" title="Usuń obrazek"><i class="fa-solid fa-xmark"></i></button>' : ''}</div>
                <div class="sh-ident-text">
                    <h2>${_esc(char.name)}</h2>
                    <p>${_esc(window.PL ? PL.race(char.race || '') : (char.race || ''))}${char.subrace ? ` (${_esc(window.PL ? PL.race(char.subrace) : char.subrace)})` : ''} · ${_esc(meta.pl || char.class || '')}${subclass ? ` · <span class="hc-sub">${_esc(subclass)}</span>` : ''}</p>
                    <small>${_esc([char.background, char.alignment].filter(Boolean).join(' · ') || 'Uzupełnij pochodzenie i charakter w zakładce Statystyki')}</small>
                    <div class="sh-xp">
                        <div class="hc-xp-bar"><div style="width:${xpPct}%"></div></div>
                        <span>${next ? `${xp.toLocaleString(window.LOC || 'pl-PL')} / ${next.toLocaleString(window.LOC || 'pl-PL')} XP` : `${xp.toLocaleString(window.LOC || 'pl-PL')} XP · poziom maks.`}</span>
                    </div>
                    <div class="sh-xp-ctrl">
                        <input type="number" min="0" placeholder="XP" id="sh-xp-in" aria-label="Ile XP dodać">
                        <button onclick="CharactersModule.addXP()" title="Dodaj XP">+ XP</button>
                        ${lvl < 20 ? `<button class="sh-lvl-btn ${ready ? 'ready' : ''}" onclick="CharactersModule.levelUp()"><i class="fa-solid fa-angles-up"></i> ${ready ? 'Awansuj!' : 'Nowy poziom'} <small>${lvl} → ${lvl + 1}</small></button>` : ''}
                    </div>
                </div>
            </div>

            <div class="sh-vitals">
                <div class="hc-ac sh-ac" title="Klasa Pancerza"><b>${char.ac ?? 10}</b></div>
                <button class="sh-v" onclick="CharactersModule.rollCheck('Inicjatywa', ${init})" title="Rzuć na inicjatywę"><b>${_sign(init)}</b><small>Inicjatywa</small></button>
                <div class="sh-v"><b>${char.speed ?? 30}</b><small>Prędkość ft</small></div>
                <div class="sh-v"><b>+${prof}</b><small>Biegłość</small></div>
                <div class="sh-v"><b>${passiveOf(char, 'Percepcja')}</b><small>Pas. Percepcja</small></div>
                <button class="sh-v sh-insp ${char.inspiration ? 'on' : ''}" onclick="CharactersModule.toggleInspiration()" title="Natchnienie"><i class="fa-solid fa-star"></i><small>Natchnienie</small></button>
            </div>

            <div class="sh-hp">
                <div class="sh-hp-top">
                    <span class="hc-hp-label"><i class="fa-solid fa-heart"></i> Punkty Wytrzymałości</span>
                    <span class="hc-hd" title="Kości Wytrzymałości">KW ${hd.current ?? lvl}/${hd.max ?? lvl} k${hd.die || 8}</span>
                </div>
                <div class="sh-hp-val ${hpClass}"><b>${hpCur}</b><span>/ ${hpMax}</span>${hpTmp ? `<em>+${hpTmp} tymcz.</em>` : ''}</div>
                <div class="hp-bar"><div class="hp-bar-fill ${hpClass}" style="width:${hpPct}%"></div></div>
                ${down ? `<div class="sh-death"><span>Sukcesy</span>${[1, 2, 3].map(n => pip('successes', n, ds.successes >= n)).join('')}<span>Porażki</span>${[1, 2, 3].map(n => pip('failures', n, ds.failures >= n)).join('')}</div>` : ''}
                <div class="sh-hp-ctrl">
                    <button class="dmg" onclick="CharactersModule.sheetHP(-1)" title="Obrażenia (Enter)">−</button>
                    <input type="number" min="0" placeholder="PW" id="sh-hp-in" aria-label="Ile PW">
                    <button class="set" onclick="CharactersModule.sheetHP(0)" title="Ustaw PW na tę liczbę">=</button>
                    <button class="heal" onclick="CharactersModule.sheetHP(1)" title="Leczenie (Shift+Enter)">+</button>
                    <button class="tmp" onclick="CharactersModule.sheetHP(2)" title="Ustaw tymczasowe PW">TPW</button>
                </div>
            </div>
        </div>`;
    }

    function renderHero(char) {
        const box = document.getElementById('sheet-hero');
        if (!box) return;
        box.innerHTML = sheetHero(char);
        const inp = document.getElementById('sh-hp-in');
        if (inp) inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); sheetHP(e.shiftKey ? 1 : -1); } });
        const xpIn = document.getElementById('sh-xp-in');
        if (xpIn) xpIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addXP(); } });
    }

    /** mode: -1 obrażenia, 1 leczenie, 0 ustaw, 2 tymczasowe */
    function applyHP(char, mode, val) {
        if (!char.hp) char.hp = { current: 0, max: 0, temp: 0 };
        if (mode === -1) {
            const fromTemp = Math.min(char.hp.temp || 0, val);
            char.hp.temp = (char.hp.temp || 0) - fromTemp;
            char.hp.current = Math.max(0, char.hp.current - (val - fromTemp));
        } else if (mode === 1) {
            const wasDown = char.hp.current <= 0;
            char.hp.current = Math.min(char.hp.max, char.hp.current + val);
            if (wasDown && char.hp.current > 0) char.deathSaves = { successes: 0, failures: 0 };
        } else if (mode === 0) {
            const wasDown = char.hp.current <= 0;
            char.hp.current = Math.max(0, Math.min(char.hp.max || val, val));
            if (wasDown && char.hp.current > 0) char.deathSaves = { successes: 0, failures: 0 };
        } else if (mode === 2) {
            char.hp.temp = Math.max(0, val);
        }
    }
    const HP_MSG = { '-1': (v) => `−${v} PW`, '1': (v) => `+${v} PW`, '0': (v) => `PW ustawione na ${v}`, '2': (v) => `${v} tymczasowych PW` };

    function sheetHP(mode) {
        const char = getCharacter();
        if (!char) return;
        const raw = document.getElementById('sh-hp-in')?.value;
        if ((mode === 0 || mode === 2) && (raw === '' || raw === undefined)) { App.showToast('Wpisz liczbę w pole PW', 'warning'); return; }
        const val = Math.abs(parseInt(raw, 10) || 0) || (mode === 0 || mode === 2 ? 0 : 1);
        applyHP(char, mode, val);
        saveCharacter(char);
        App.showToast(`${char.name}: ${HP_MSG[mode](val)} (${char.hp.current}/${char.hp.max})`, mode === -1 ? 'warning' : 'success');
        renderHero(char);
        updatePinnedCardHP(char);
        const hero = document.querySelector('.sh-hero');
        if (hero) { hero.classList.add(mode === -1 ? 'hit' : 'healed'); setTimeout(() => hero.classList.remove('hit', 'healed'), 600); }
        const tab = document.querySelector('.sheet-tab.active')?.dataset?.sheetTab;
        if (tab === 'combat-stats') renderSheetTab(tab);
    }

    function addXP(amount) {
        const char = getCharacter();
        if (!char) return;
        const v = amount ?? (parseInt(document.getElementById('sh-xp-in')?.value, 10) || 0);
        if (!v) { App.showToast('Wpisz ilość XP', 'warning'); return; }
        char.xp = Math.max(0, (char.xp || 0) + v);
        saveCharacter(char);
        const next = ClassData.XP_THRESHOLDS[(char.level || 1) + 1];
        App.showToast(`${char.name}: +${v} XP${next && char.xp >= next ? ' · gotów do awansu!' : ''}`, 'success');
        renderHero(char);
    }

    // własny obrazek postaci (gracz albo MG)
    async function pickPortrait() {
        if (!window.Portrait) return;
        const url = await Portrait.pick(); if (!url) return;
        const char = getCharacter(); if (!char) return;
        char.portrait = url; char.portraitV = Date.now();
        saveCharacter(char); renderHero(getCharacter() || char);
        App.showToast('Obrazek postaci zapisany', 'success');
    }
    async function clearPortrait() {
        if (!getCharacter()?.portrait) return;
        if (!await Ask.confirm('Zamiast obrazka wróci litera / herb klasy.', { title: 'Usunąć obrazek postaci?', ok: 'Usuń', danger: true })) return;
        const char = getCharacter(); if (!char) return;
        char.portrait = ''; char.portraitV = Date.now();
        saveCharacter(char); renderHero(getCharacter() || char);
    }

    function toggleInspiration() {
        const char = getCharacter();
        if (!char) return;
        char.inspiration = !char.inspiration;
        saveCharacter(char);
        renderHero(char);
    }

    function rollCheck(label, mod) {
        const char = getCharacter();
        const modStr = mod >= 0 ? `+${mod}` : `${mod}`;
        if (window.DiceRoller?.rollExpression) DiceRoller.rollExpression(`1d20${modStr}`, 'normal', `${char ? char.name + ': ' : ''}${label}`);
    }
    function rollDamage(label, expr) {
        const e = String(expr).replace(/k/g, 'd').replace(/−/g, '-');
        if (window.DiceRoller?.rollExpression) DiceRoller.rollExpression(e, 'normal', `${label}: obrażenia`);
    }

    function cycleSkill(skill) {
        const char = getCharacter();
        if (!char) return;
        const lvl = skillLevel(char, skill);
        const strip = (list) => (list || []).filter(s => s !== skill && SKILL_EN[s] !== skill);
        char.proficiencies = strip(char.proficiencies);
        char.expertise = strip(char.expertise);
        if (lvl === 0) char.proficiencies.push(skill);
        else if (lvl === 1) { char.proficiencies.push(skill); char.expertise.push(skill); }
        saveCharacter(char);
        renderSheetTab(document.querySelector('.sheet-tab.active')?.dataset?.sheetTab || 'skills');
        renderHero(char);
    }
    function toggleSave(attr) {
        const char = getCharacter();
        if (!char) return;
        const list = char.savingThrows || [];
        char.savingThrows = list.includes(attr) ? list.filter(a => a !== attr) : [...list, attr];
        saveCharacter(char);
        renderSheetTab(document.querySelector('.sheet-tab.active')?.dataset?.sheetTab || 'stats');
    }

    function slotPip(level, i) {
        const char = getCharacter();
        if (!char) return;
        const s = char.spellSlots?.[level];
        if (!s) return;
        const avail = s.total - (s.used || 0);
        s.used = i < avail ? (s.used || 0) + 1 : Math.max(0, (s.used || 0) - 1);
        saveCharacter(char);
        renderSheetTab('spellcasting');
    }
    function restoreSlots() {
        const char = getCharacter();
        if (!char) return;
        Object.values(char.spellSlots || {}).forEach(s => { if (s) s.used = 0; });
        saveCharacter(char);
        renderSheetTab('spellcasting');
        App.showToast('Sloty czarów odnowione', 'success');
    }

    const sec = (title, icon, body, extra = '') => `<section class="sh-sec ${extra}"><h3 class="sh-sec-title"><i class="fa-solid ${icon}"></i> ${title}</h3>${body}</section>`;

    // ---------- Statystyki ----------
    function renderStatsTab(char) {
        const classOpts = cachedClasses.map(c => `<option value="${_esc(c)}">`).join('');
        const raceOpts = cachedRaces.map(r => `<option value="${_esc(r)}">`).join('');
        const bgOpts = ['Acolyte', 'Charlatan', 'Criminal', 'Entertainer', 'Folk Hero', 'Guild Artisan', 'Hermit', 'Noble', 'Outlander', 'Sage', 'Sailor', 'Soldier', 'Urchin'].map(b => `<option value="${_esc(b)}">`).join('');
        const ALIGNMENTS = ['Praworządny Dobry', 'Neutralny Dobry', 'Chaotyczny Dobry', 'Praworządny Neutralny', 'Neutralny', 'Chaotyczny Neutralny', 'Praworządny Zły', 'Neutralny Zły', 'Chaotyczny Zły'];
        const prof = APIClient.proficiencyBonus(char.level || 1);

        const abil = APIClient.ABILITY_NAMES.map(attr => {
            const k = attr.toLowerCase(), sc = char.abilityScores[k] ?? 10, m = _mod(sc);
            const sv = saveBonus(char, attr), isSave = (char.savingThrows || []).includes(attr);
            return `
            <div class="sh-ab">
                <div class="sh-ab-name">${AB_PL[attr]}</div>
                <button class="sh-ab-mod" onclick="CharactersModule.rollCheck('Test: ${AB_PL[attr]}', ${m})" title="Rzuć test">${_sign(m)}</button>
                <input type="number" class="sh-ab-score" data-field="abilityScores.${k}" value="${sc}" min="1" max="30" aria-label="Wartość: ${AB_PL[attr]}">
                <div class="sh-ab-save">
                    <button class="sh-dot ${isSave ? 'on' : ''}" onclick="CharactersModule.toggleSave('${attr}')" title="Biegłość w rzucie obronnym"></button>
                    <button class="sh-ab-savebtn" onclick="CharactersModule.rollCheck('Rzut obronny: ${AB_PL[attr]}', ${sv})">Obrona <b>${_sign(sv)}</b></button>
                </div>
            </div>`;
        }).join('');

        const languages = char.languages || ['Common'];
        const wp = char.weaponProficiencies || [], ap = char.armorProficiencies || [], tp = char.toolProficiencies || [];
        const chips = (arr) => arr.length ? arr.map(x => `<span class="sh-chip" title="${_esc(x)}">${_esc(x)}</span>`).join('') : '<span class="sh-muted">—</span>';
        const P = window.PL;

        return `
        <datalist id="classOptionsList">${classOpts}</datalist>
        <datalist id="raceOptionsList">${raceOpts}</datalist>
        <datalist id="bgOptionsList">${bgOpts}</datalist>
        <div class="sh-grid sh-grid-stats">
            ${sec('Atrybuty i rzuty obronne', 'fa-dice-d20', `<div class="sh-abil">${abil}</div><p class="sh-hint">Kliknij modyfikator, aby rzucić test. Kropka oznacza biegłość w rzucie obronnym.</p>`)}
            ${sec('Tożsamość', 'fa-id-card', `
                <div class="sh-form">
                    <label class="span2">Imię<input type="text" data-field="name" value="${_esc(char.name)}"></label>
                    <label>Rasa<input type="text" data-field="race" list="raceOptionsList" value="${_esc(char.race || '')}" placeholder="Wybierz lub wpisz…"></label>
                    <label>Klasa<input type="text" data-field="class" list="classOptionsList" value="${_esc(char.class || '')}" placeholder="Wybierz lub wpisz…"></label>
                    <label>Pochodzenie<input type="text" data-field="background" list="bgOptionsList" value="${_esc(char.background || '')}" placeholder="Wybierz lub wpisz…"></label>
                    <label>Poziom<input type="number" data-field="level" value="${char.level}" min="1" max="20"></label>
                    <label class="span2">Charakter<select data-field="alignment"><option value="">— wybierz —</option>${ALIGNMENTS.map(a => `<option value="${a}" ${char.alignment === a ? 'selected' : ''}>${a}</option>`).join('')}</select></label>
                    <div class="sh-kv"><span>Rozmiar</span><b>${_esc(char.size || 'Medium')}</b></div>
                    <div class="sh-kv"><span>Widzenie w ciemności</span><b>${char.darkvision || 0} ft</b></div>
                    <div class="sh-kv"><span>Premia z biegłości</span><b>+${prof}</b></div>
                    <div class="sh-kv"><span>Udźwig</span><b>${(char.abilityScores.str || 10) * 15} lb</b></div>
                </div>`)}
            ${sec('Języki', 'fa-language', `<div class="sh-chips">${chips(P ? P.langs(languages) : languages)}<button class="sh-chip sh-chip-add" onclick="CharactersModule.addLanguage()">+ Dodaj</button></div>`)}
            ${sec('Biegłości', 'fa-graduation-cap', `
                <div class="sh-profs">
                    <div><span>Broń</span><div class="sh-chips">${chips(P ? P.profs(wp) : wp)}</div></div>
                    <div><span>Pancerz</span><div class="sh-chips">${chips(P ? P.profs(ap) : ap)}</div></div>
                    <div><span>Narzędzia</span><div class="sh-chips">${chips(P ? P.profs(tp) : tp)}</div></div>
                </div>`)}
        </div>`;
    }

    // ---------- Umiejętności ----------
    function renderSkillsTab(char) {
        const groups = APIClient.ABILITY_NAMES.map(attr => {
            const skills = Object.keys(APIClient.SKILLS).filter(s => APIClient.SKILLS[s] === attr).sort((a, b) => a.localeCompare(b, 'pl'));
            if (!skills.length) return '';
            const rows = skills.map(s => {
                const lv = skillLevel(char, s), b = skillBonus(char, s);
                return `<div class="sh-skill lv${lv}">
                    <button class="sh-dot ${lv ? 'on' : ''} ${lv === 2 ? 'exp' : ''}" onclick="CharactersModule.cycleSkill('${s}')" title="${['Brak biegłości', 'Biegłość', 'Ekspertyza'][lv]} — kliknij, aby zmienić"></button>
                    <span>${s}</span>
                    <button class="sh-roll" onclick="CharactersModule.rollCheck('${s}', ${b})" title="Rzuć">${_sign(b)}</button>
                </div>`;
            }).join('');
            return `<div class="sh-skgroup"><div class="sh-skgroup-head"><span>${AB_PL[attr]}</span><b>${_sign(_mod(char.abilityScores[attr.toLowerCase()]))}</b></div>${rows}</div>`;
        }).join('');
        const saves = APIClient.ABILITY_NAMES.map(attr => {
            const on = (char.savingThrows || []).includes(attr), b = saveBonus(char, attr);
            return `<div class="sh-save ${on ? 'on' : ''}"><button class="sh-dot ${on ? 'on' : ''}" onclick="CharactersModule.toggleSave('${attr}')" title="Biegłość"></button><span>${AB_SHORT[attr]}</span><button class="sh-roll" onclick="CharactersModule.rollCheck('Rzut obronny: ${AB_PL[attr]}', ${b})">${_sign(b)}</button></div>`;
        }).join('');
        return `
        <div class="sh-passives">
            <div><b>${passiveOf(char, 'Percepcja')}</b><span>Pasywna Percepcja</span></div>
            <div><b>${passiveOf(char, 'Wgląd')}</b><span>Pasywny Wgląd</span></div>
            <div><b>${passiveOf(char, 'Śledztwo')}</b><span>Pasywne Śledztwo</span></div>
        </div>
        ${sec('Rzuty obronne', 'fa-shield-heart', `<div class="sh-saves">${saves}</div>`)}
        ${sec('Umiejętności', 'fa-list-check', `<div class="sh-skills">${groups}</div>
            <p class="sh-hint"><span class="sh-dot"></span> brak · <span class="sh-dot on"></span> biegłość · <span class="sh-dot on exp"></span> ekspertyza (×2) — kliknij kropkę, aby zmienić; kliknij premię, aby rzucić.</p>`)}`;
    }

    // ---------- Walka ----------
    function renderCombatTab(char) {
        const atk = window.Kits ? Kits.attacks(char, 8) : [];
        const ds = char.deathSaves || { successes: 0, failures: 0 };
        const resList = char.classResources ? Object.entries(char.classResources).map(([key, res]) => {
            const rd = ClassData.getResourcesForLevel((window.Kits ? Kits.classKey(char.class) : '') || char.class?.toLowerCase() || '', char.level, char).find(r => r.key === key);
            if (!rd) return '';
            const pips = res.max <= 12 ? `<div class="sh-pips">${Array.from({ length: res.max }, (_, i) => `<i class="${i < res.current ? 'on' : ''}"></i>`).join('')}</div>` : '';
            return `<div class="sh-res">
                <div class="sh-res-name">${rd.icon || ''} ${_esc(rd.namePL)}</div>
                <div class="sh-res-val"><b>${res.current}</b>/${res.max}</div>${pips}
                <div class="sh-res-btns"><button onclick="CharactersModule.useResource('${key}', -1)" ${res.current <= 0 ? 'disabled' : ''}>Użyj</button><button onclick="CharactersModule.useResource('${key}', 1)" ${res.current >= res.max ? 'disabled' : ''}>Odzyskaj</button></div>
            </div>`;
        }).join('') : '';
        const hd = char.hitDicePool;
        return `
        <div class="sh-tiles">
            <label class="sh-tile"><span>Klasa Pancerza</span><input type="number" data-field="ac" value="${char.ac ?? 10}"></label>
            <label class="sh-tile"><span>Prędkość (ft)</span><input type="number" data-field="speed" value="${char.speed ?? 30}"></label>
            <label class="sh-tile"><span>Maks. PW</span><input type="number" data-field="hp.max" value="${char.hp.max}"></label>
            <label class="sh-tile"><span>Obecne PW</span><input type="number" data-field="hp.current" value="${char.hp.current}"></label>
            <label class="sh-tile"><span>Tymczasowe PW</span><input type="number" data-field="hp.temp" value="${char.hp.temp || 0}"></label>
            ${window.Kits ? `<button class="sh-tile sh-tile-btn" onclick="CharactersModule.recalcAC()"><span>Przelicz KP</span><b><i class="fa-solid fa-rotate"></i> z ekwipunku</b></button>` : ''}
        </div>
        <div class="sh-grid">
            ${sec('Ataki', 'fa-khanda', atk.length ? `<div class="sh-attacks">${atk.map(a => `
                <div class="sh-attack">
                    <i class="fa-solid ${a.ranged ? 'fa-bullseye' : 'fa-khanda'}"></i>
                    <span>${_esc(a.name)}</span>
                    <button class="sh-roll" onclick="CharactersModule.rollCheck('Atak: ${_esc(a.name)}', ${a.hit})" title="Rzut na trafienie">${_sign(a.hit)}</button>
                    <button class="sh-roll dmg" onclick="CharactersModule.rollDamage('${_esc(a.name)}', '${a.dmg}')" title="Rzut na obrażenia">${a.dmg}</button>
                    <em>${a.type}</em>
                </div>`).join('')}</div>` : `<p class="sh-muted">Brak broni w ekwipunku. Dodaj ją w zakładce Ekwipunek lub wpisz gotowy zestaw klasy.</p>`)}
            ${sec('Rzuty przeciw śmierci', 'fa-skull', `
                <div class="sh-death-big">
                    <div><span class="ok">Sukcesy</span>${[1, 2, 3].map(n => `<button class="sh-ds ok ${ds.successes >= n ? 'on' : ''}" onclick="CharactersModule.setDeathSave('successes', ${n})"></button>`).join('')}</div>
                    <div><span class="bad">Porażki</span>${[1, 2, 3].map(n => `<button class="sh-ds ${ds.failures >= n ? 'on' : ''}" onclick="CharactersModule.setDeathSave('failures', ${n})"></button>`).join('')}</div>
                    <button class="sh-btn sh-btn-gold" onclick="CharactersModule.deathSaveRoll()" title="k20: 10+ sukces, 1 — dwie porażki, 20 — wstaje z 1 PW"><i class="fa-solid fa-skull"></i> Rzuć</button>
                    <button class="sh-btn" onclick="CharactersModule.resetDeathSaves()">Wyzeruj</button>
                </div>`)}
        </div>
        ${sec('Zasoby', 'fa-battery-half', `<div class="sh-resources">
            ${hd && hd.max > 0 ? `<div class="sh-res">
                <div class="sh-res-name">Kości Wytrzymałości</div>
                <div class="sh-res-val"><b>${hd.current}</b>/${hd.max} <small>k${hd.die}</small></div>
                <div class="sh-pips">${Array.from({ length: Math.min(20, hd.max) }, (_, i) => `<i class="${i < hd.current ? 'on' : ''}"></i>`).join('')}</div>
                <div class="sh-res-btns"><button onclick="CharactersModule.useHitDie()" ${hd.current <= 0 ? 'disabled' : ''}>Użyj (leczy)</button><button onclick="CharactersModule.regainHitDie()">Odzyskaj</button></div>
            </div>` : ''}
            ${resList || ''}
        </div>`)}`;
    }

    function spellLimitNote(char) {
        if (!window.SpellPicker) return '';
        const ck = window.Kits ? Kits.classKey(char.class) : '';
        const lim = SpellPicker.limits(ck, char.level || 1, char.abilityScores || {});
        if (!lim.cantrips && !lim.spells) return '';
        const c = (char.spells || []).filter(x => (x.level || 0) === 0).length, sp = (char.spells || []).length - c;
        const chip = (l, n, m) => `<span class="sp-count ${n > m ? 'over' : n === m ? 'done' : ''}">${l} <b>${n} / ${m}</b></span>`;
        return `<div class="sp-head sp-head-sheet">${lim.cantrips ? chip('Sztuczki', c, lim.cantrips) : ''}${lim.spells ? chip('Czary ' + lim.kind, sp, lim.spells) : ''}<span class="sp-note">do ${lim.maxLevel}. kręgu na ${char.level}. poziomie</span></div>`;
    }

    function recalcAC() {
        const char = getCharacter();
        if (!char || !window.Kits) return;
        char.ac = Kits.computeAC(char);
        saveCharacter(char);
        App.showToast(`KP przeliczone: ${char.ac}`, 'success');
        renderSheetTab('combat-stats');
    }

    // ---------- Czary ----------
    function renderSpellcastingTab(char) {
        if (!char.spells) char.spells = [];
        if (!char.spellSlots) char.spellSlots = {};
        const ca = castAbility(char);
        const prof = APIClient.proficiencyBonus(char.level || 1);
        const caMod = ca ? _mod(char.abilityScores[ca]) : 0;
        const caName = { int: 'Inteligencja', wis: 'Mądrość', cha: 'Charyzma' }[ca] || '—';

        const slots = [];
        for (let i = 1; i <= 9; i++) {
            const s = char.spellSlots[i];
            if (!s || !(s.total > 0)) continue;
            const avail = s.total - (s.used || 0);
            slots.push(`<div class="sh-slot"><span>${i}. krąg</span><div class="sh-slot-pips">${Array.from({ length: s.total }, (_, j) => `<button class="${j < avail ? 'on' : ''}" onclick="CharactersModule.slotPip(${i}, ${j})" title="${j < avail ? 'Zużyj slot' : 'Odzyskaj slot'}"></button>`).join('')}</div><small>${avail}/${s.total}</small></div>`);
        }
        const slotEdit = Array.from({ length: 9 }, (_, k) => {
            const i = k + 1, s = char.spellSlots[i] || { used: 0, total: 0 };
            return `<label>${i}.<input type="number" min="0" max="9" data-field="spellSlots.${i}.total" value="${s.total || 0}"></label>`;
        }).join('');

        let list = '';
        if (!char.spells.length) list = `<p class="sh-muted">Brak przypisanych zaklęć. Dodaj je przyciskiem powyżej.</p>`;
        else {
            const grouped = {};
            char.spells.forEach((s, idx) => { const l = s.level || 0; (grouped[l] = grouped[l] || []).push({ ...s, _idx: idx }); });
            list = Object.keys(grouped).sort((a, b) => a - b).map(l => `
                <div class="sh-spell-group"><div class="sh-spell-head">${+l === 0 ? 'Sztuczki' : `${l}. krąg`}</div>
                ${grouped[l].map(s => `
                    <div class="sh-acc">
                        <div class="sh-acc-head" onclick="CharactersModule.toggleSpellDescription(${s._idx})">
                            <i class="fa-solid fa-wand-sparkles"></i><b title="${_esc(s.name)}">${_esc(window.PL ? PL.spell(s.name) : s.name)}</b>${s.school ? `<small>${_esc(s.school)}</small>` : ''}${window.SpellPicker ? SpellPicker.tags(s) : ''}${s.isCustom ? '<small>własny</small>' : ''}<span class="sh-acc-caret">▾</span>
                            <button class="sh-x" onclick="event.stopPropagation(); CharactersModule.removeSpellFromCharacter(${s._idx})" title="Usuń">✕</button>
                        </div>
                        <div id="char_spell_desc_${s._idx}" class="sh-acc-body sp-body" style="display:none;"><div class="loading-spinner"></div></div>
                    </div>`).join('')}
                </div>`).join('');
        }

        return `
        <div class="sh-tiles">
            <div class="sh-tile"><span>Atrybut magiczny</span><b>${caName}</b></div>
            <div class="sh-tile"><span>ST rzutu obronnego</span><b>${ca ? 8 + prof + caMod : '—'}</b></div>
            <button class="sh-tile sh-tile-btn" ${ca ? `onclick="CharactersModule.rollCheck('Atak czarem', ${prof + caMod})"` : 'disabled'}><span>Atak czarem</span><b>${ca ? _sign(prof + caMod) : '—'}</b></button>
            <div class="sh-tile"><span>Zaklęcia</span><b>${char.spells.length}</b></div>
        </div>
        ${sec('Sloty czarów', 'fa-gem', `
            ${slots.length ? `<div class="sh-slots">${slots.join('')}</div>` : '<p class="sh-muted">Brak slotów. Ustaw ich liczbę poniżej.</p>'}
            <div class="sh-slot-actions">
                ${slots.length ? '<button class="sh-btn" onclick="CharactersModule.restoreSlots()"><i class="fa-solid fa-moon"></i> Odnów wszystkie (długi odpoczynek)</button>' : ''}
                <details class="sh-slot-edit"><summary>Liczba slotów na krąg</summary><div>${slotEdit}</div></details>
            </div>`)}
        ${sec('Księga zaklęć', 'fa-book-open', `
            <div class="sh-sec-tools sh-sec-tools-split">${spellLimitNote(char)}<button class="btn-secondary btn-small" onclick="CharactersModule.showAddSpellToCharacterModal()"><i class="fa-solid fa-book-medical"></i> Wybierz czary z bazy</button></div>
            ${list}`)}
        ${sec('Notatki magiczne', 'fa-feather', `<textarea class="sh-parch" data-field="spellsNotes" placeholder="Komponenty, rytuały, przygotowane czary…">${_esc(char.spellsNotes || '')}</textarea>`)}`;
    }

    let cachedModalSpells = [];

    let _spellPick = null;
    async function showAddSpellToCharacterModal() {
        const char = getCharacter();
        if (!char) return;
        const customDb = StorageManager.getCustomSpells() || [];
        App.showModal('Księga zaklęć — wybierz czary', `
            <div id="sheet-spell-picker"></div>
            <details class="sp-custom">
                <summary><i class="fa-solid fa-feather"></i> Dodaj własny czar (spoza bazy SRD)</summary>
                ${customDb.length ? `<label class="sp-field">Z Twojej bazy własnych zaklęć
                    <select id="add-spell-db"><option value="">— wybierz —</option>${customDb.map(c => `<option value="${_esc(c.id)}">${_esc(c.name)} (${c.level ? c.level + '. krąg' : 'sztuczka'})</option>`).join('')}</select></label>` : ''}
                <div class="sp-custom-grid">
                    <label class="sp-field">Nazwa<input type="text" id="add-spell-custom-name" placeholder="np. Płomień Szeptanego Lasu"></label>
                    <label class="sp-field">Krąg (0 = sztuczka)<input type="number" id="add-spell-custom-level" min="0" max="9" value="1"></label>
                </div>
                <label class="sp-field">Opis<textarea id="add-spell-custom-desc" placeholder="Efekt, zasięg, czas trwania…"></textarea></label>
            </details>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" onclick="CharactersModule.addSpellToCharacter()"><i class="fa-solid fa-book-open"></i> Zapisz księgę</button>`);
        document.getElementById('modal')?.classList.add('modal-wide');
        _spellPick = null;
        const host = document.getElementById('sheet-spell-picker');
        if (host && window.SpellPicker) {
            _spellPick = await SpellPicker.mount(host, {
                cls: char.class, level: char.level || 1, scores: char.abilityScores,
                selected: (char.spells || []).filter(x => !x.isCustom && !x.isFreeform), strict: false
            });
        }
    }

    function updateSpellModalFilters() {}

    async function addSpellToCharacter() {
        const char = getCharacter();
        if (!char) return;
        const keep = (char.spells || []).filter(x => x.isCustom || x.isFreeform);
        const picked = _spellPick ? _spellPick.get() : (char.spells || []).filter(x => !x.isCustom && !x.isFreeform);
        const dbId = document.getElementById('add-spell-db')?.value;
        if (dbId) {
            const info = (StorageManager.getCustomSpells() || []).find(x => String(x.id) === String(dbId));
            if (info && !keep.some(k => String(k.index) === String(dbId))) keep.push({ index: dbId, name: info.name, level: info.level || 0, isCustom: true });
        }
        const name = document.getElementById('add-spell-custom-name')?.value.trim();
        if (name) keep.push({ name, level: parseInt(document.getElementById('add-spell-custom-level').value) || 0, desc: document.getElementById('add-spell-custom-desc').value.trim(), isCustom: true, isFreeform: true });
        char.spells = [...picked, ...keep];
        saveCharacter(char);
        App.closeModal();
        App.showToast(`Księga zaklęć: ${char.spells.length} pozycji`, 'success');
        renderSheetTab('spellcasting');
    }

    async function removeSpellFromCharacter(idx) {
        if (!await Ask.confirm('Czar zniknie z księgi zaklęć postaci.', { title: 'Usunąć czar?', ok: 'Usuń', danger: true })) return;
        const char = getCharacter();
        if (!char || !char.spells) return;
        
        char.spells.splice(idx, 1);
        saveCharacter(char);
        renderSheetTab('spellcasting');
    }

    async function toggleSpellDescription(idx) {
        const char = getCharacter();
        if (!char || !char.spells) return;
        const sp = char.spells[idx];
        const el = document.getElementById(`char_spell_desc_${idx}`);
        if (!el || !sp) return;
        const acc = el.closest('.sh-acc');
        if (el.style.display === 'block') { el.style.display = 'none'; acc?.classList.remove('open'); return; }
        el.style.display = 'block';
        acc?.classList.add('open');
        if (sp.isFreeform) {
            el.innerHTML = `<div class="sp-desc">${(sp.desc || 'Brak opisu.').split(/\n+/).map(p => `<p>${_esc(p)}</p>`).join('')}</div>`;
            return;
        }
        if (sp.isCustom) {
            const d = (StorageManager.getCustomSpells() || []).find(c => String(c.id) === String(sp.index));
            if (!d) { el.innerHTML = '<div class="sp-loading">Nie znaleziono tego czaru w bazie własnych zaklęć.</div>'; return; }
            el.innerHTML = SpellPicker.detailsHTML({
                time: d.castingTime || d.casting_time || '', range: d.range || '', duration: d.duration || '', components: d.components || '',
                desc: String(d.description || d.desc || '').split(/\n+/).filter(Boolean), higher: []
            });
            return;
        }
        await SpellPicker.fillDetails(el, sp.index);
    }

    async function toggleFeatureDesc(type, idx) {
        const char = getCharacter();
        if (!char) return;

        const id = type === 'trait' ? `char_trait_desc_${idx}` : `char_class_desc_${idx}`;
        const el = document.getElementById(id);
        if (!el) return;

        if (el.style.display === 'block') {
            el.style.display = 'none';
            return;
        }

        el.style.display = 'block';

        const featureObj = type === 'trait' ? char.traits[idx] : char.classFeatures[idx];
        if (!featureObj) return;

        // Jeśli opis jest już załadowany
        if (featureObj.desc && featureObj.desc.trim().length > 0) {
            return;
        }

        // Jeśli opisu brak, ale jest index -> pobierz w locie
        if (featureObj.index) {
            el.innerHTML = '<div class="loading-spinner"></div>';
            try {
                let data = null;
                if (type === 'trait') {
                    data = await APIClient.getTrait(featureObj.index);
                } else {
                    data = await APIClient.getFeature(featureObj.index);
                }
                
                if (data) {
                    const rawDesc = Array.isArray(data.desc) ? data.desc.join('\\n') : (data.desc || '');
                    const transDesc = await APIClient.translateText(rawDesc);
                    featureObj.desc = transDesc;
                    saveCharacter(char);
                    el.textContent = transDesc;
                } else {
                    el.innerHTML = 'Opis niedostępny w bazie D&D.';
                }
            } catch (e) {
                console.error(e);
                el.innerHTML = '<span style="color:var(--crimson-light);">Błąd pobierania z API D&D 5e.</span>';
            }
        } else {
            el.innerHTML = 'Brak opisu (cecha własna).';
        }
    }

    // ---------- Ekwipunek ----------
    function renderInventoryTab(char) {
        const inv = char.inventory || [];
        let total = 0;
        const rows = inv.map((item, idx) => {
            total += (parseFloat(item.weight) || 0) * (parseInt(item.quantity) || 1);
            const w = window.Kits && Kits.WEAPONS[item.name], a = window.Kits && Kits.ARMOR[item.name];
            const db = window.ItemsDB && (ItemsDB.find(item.ref) || ItemsDB.find(item.name));
            const icon = db ? (db.cat === 'weapon' && db.props.includes('A') ? 'fa-bullseye' : (ItemsDB.CATS[db.cat] || ItemsDB.CATS.gear)[1]) : w ? (w[2].includes('R') ? 'fa-bullseye' : 'fa-khanda') : a ? 'fa-shield-halved' : 'fa-box';
            let info = db ? ItemsDB.info(db) : w ? `${w[0]} ${w[1]}` : a ? (a[1] === 'S' ? '+2 KP' : `KP ${a[0]}${a[1] === 'L' ? ' + ZRĘ' : a[1] === 'M' ? ' + ZRĘ (maks. 2)' : ''}`) : '';
            const fullInfo = [info, item.cost || db?.cost].filter(x => x && x !== '—').join(' · ');
            if (window.I18N?.en) info = I18N.t(info);
            if (info.length > 70) info = info.slice(0, 68) + '…';
            return `
            <div class="sh-item ${w || db?.cat === 'weapon' ? 'is-weapon' : a || db?.cat === 'armor' ? 'is-armor' : ''}">
                <i class="fa-solid ${icon}"></i>
                <input type="text" value="${_esc(item.name)}" placeholder="Nazwa przedmiotu" list="sh-items-dl" onchange="CharactersModule.updateItem(${idx}, 'name', this.value)">
                <span class="sh-item-info" title="${_esc(fullInfo)}">${_esc(info)}${(item.cost || db?.cost) && (item.cost || db?.cost) !== '—' ? `<em>${_esc(item.cost || db.cost)}</em>` : ''}</span>
                <label class="sh-item-num">×<input type="number" value="${item.quantity}" min="0" onchange="CharactersModule.updateItem(${idx}, 'quantity', this.value)"></label>
                <label class="sh-item-num"><input type="number" value="${item.weight}" step="0.1" min="0" onchange="CharactersModule.updateItem(${idx}, 'weight', this.value)">lb</label>
                ${window.PANEL_ROLA === 'gracz' && window.GraczBridge?.give ? `<button class="sh-give" onclick="GraczBridge.give(${idx})" title="Daj towarzyszowi"><i class="fa-solid fa-hand-holding-heart"></i></button>` : ''}
                <button class="sh-x" onclick="CharactersModule.removeItem(${idx})" title="Usuń">✕</button>
            </div>`;
        }).join('');
        const cap = (char.abilityScores.str || 10) * 15;
        const pct = Math.min(100, Math.round(total / cap * 100));
        const coins = [['pp', 'Platyna', '#d9dde3'], ['gp', 'Złoto', '#e9c46a'], ['ep', 'Elektrum', '#c9d29a'], ['sp', 'Srebro', '#c7ccd1'], ['cp', 'Miedź', '#c27c4a']];
        return `
        <div class="sh-coins">${coins.map(([k, n, c]) => `<label class="sh-coin" style="--coin:${c}"><i></i><span>${n}</span><input type="number" min="0" data-field="currency.${k}" value="${char.currency?.[k] || 0}"></label>`).join('')}</div>
        ${sec('Ekwipunek', 'fa-sack-xmark', `
            <div class="sh-sec-tools">
                <button class="btn-secondary btn-small" onclick="CharactersModule.showKitModal()"><i class="fa-solid fa-box-open"></i> Gotowy zestaw klasy</button>
                <button class="btn-secondary btn-small" onclick="CharactersModule.showEquipmentPickerModal()"><i class="fa-solid fa-book-open"></i> Z bazy przedmiotów</button>
                <button class="btn-primary btn-small" onclick="CharactersModule.addEmptyItem()">+ Własny przedmiot</button>
            </div>
            <div class="sh-items">${rows || '<p class="sh-muted">Plecak jest pusty. Wpisz gotowy zestaw klasy albo dodaj przedmioty z bazy.</p>'}</div>
            ${window.ItemsDB ? `<datalist id="sh-items-dl">${ItemsDB.all.filter(i => i.cat !== 'pack').map(i => `<option value="${_esc(i.name)}">${_esc(i.en || '')}</option>`).join('')}</datalist>` : ''}
            <div class="sh-load ${pct >= 100 ? 'over' : pct >= 66 ? 'heavy' : ''}">
                <div class="sh-load-bar"><div style="width:${pct}%"></div></div>
                <span>Obciążenie <b>${total.toFixed(1)}</b> / ${cap} lb</span>
            </div>`)}`;
    }

    // ---------- Cechy ----------
    function renderFeaturesTab(char) {
        const acc = (list, type, empty) => (list && list.length) ? list.map((t, i) => `
            <div class="sh-acc">
                <div class="sh-acc-head" onclick="CharactersModule.toggleFeatureDesc('${type}', ${i})"><i class="fa-solid ${type === 'trait' ? 'fa-dna' : 'fa-scroll'}"></i><b title="${_esc(t.name)}">${_esc(window.PL ? PL.feat(t.name) : t.name)}</b><span class="sh-acc-caret">▾</span></div>
                <div id="char_${type}_desc_${i}" class="sh-acc-body" style="display:none;">${_esc(t.desc)}</div>
            </div>`).join('') : `<p class="sh-muted">${empty}</p>`;
        return `
        <div class="sh-grid">
            ${sec('Zdolności klasowe', 'fa-scroll', acc(char.classFeatures, 'class', 'Brak — wpisz klasę w zakładce Statystyki, aby pobrać zdolności.'))}
            ${sec('Cechy rasowe', 'fa-dna', acc(char.traits, 'trait', 'Brak — wpisz rasę w zakładce Statystyki, aby pobrać cechy.'))}
        </div>
        <div class="sh-grid">
            ${sec('Atuty', 'fa-award', `<textarea class="sh-parch" data-field="features.feats" placeholder="Np. Czujny, Wytrzymały…">${_esc(char.features?.feats || '')}</textarea>`)}
            ${sec('Własne cechy i notatki', 'fa-pen-nib', `<textarea class="sh-parch" data-field="features.custom" placeholder="Zdolności spoza podręcznika, przedmioty magiczne, błogosławieństwa…">${_esc(char.features?.custom || '')}</textarea>`)}
        </div>`;
    }

    // ---------- Historia ----------
    function renderBackstoryTab(char) {
        const f = (key, title, icon, ph) => sec(title, icon, `<textarea class="sh-parch" data-field="backstory.${key}" placeholder="${ph}">${_esc(char.backstory?.[key] || '')}</textarea>`);
        return `
        <div class="sh-grid sh-grid-4">
            ${f('personality', 'Cechy osobowości', 'fa-face-smile', 'Jak się zachowuje, co go wyróżnia…')}
            ${f('ideals', 'Ideały', 'fa-sun', 'W co wierzy, co nim kieruje…')}
            ${f('bonds', 'Więzi', 'fa-link', 'Ludzie, miejsca i przysięgi…')}
            ${f('flaws', 'Wady', 'fa-heart-crack', 'Słabości, lęki, nałogi…')}
        </div>
        ${sec('Historia postaci', 'fa-book', `<textarea class="sh-parch sh-parch-tall" data-field="backstory.history" placeholder="Skąd pochodzi, co przeżył, dlaczego wyruszył na szlak…">${_esc(char.backstory?.history || '')}</textarea>`)}`;
    }

    // ---------- Notatki ----------
    function renderNotesTab(char) {
        return sec('Notatki Mistrza Gry (prywatne)', 'fa-eye-slash', `<textarea class="sh-parch sh-parch-tall" data-field="notes" placeholder="Sekrety postaci, haki fabularne, długi, wrogowie…">${_esc(char.notes || '')}</textarea>`);
    }

    // --- Actions called from HTML ---

    function toggleProficiency(skill, isProficient) {
        const char = getCharacter();
        if(!char) return;
        if(isProficient && !char.proficiencies.includes(skill)) {
            char.proficiencies.push(skill);
        } else if (!isProficient) {
            char.proficiencies = char.proficiencies.filter(s => s !== skill);
        }
        saveCharacter(char);
        renderSheetTab('skills');
    }

    function toggleSavingThrow(attr, isProficient) {
        const char = getCharacter();
        if(!char) return;
        if(!char.savingThrows) char.savingThrows = [];
        if(isProficient && !char.savingThrows.includes(attr)) {
            char.savingThrows.push(attr);
        } else if (!isProficient) {
            char.savingThrows = char.savingThrows.filter(s => s !== attr);
        }
        saveCharacter(char);
        renderSheetTab('skills');
    }

    function quickModifyHP(amount) {
        const char = getCharacter();
        if(!char) return;
        char.hp.current += amount;
        if (char.hp.current > char.hp.max) char.hp.current = char.hp.max;
        if (char.hp.current < 0) char.hp.current = 0;
        saveCharacter(char);
        renderSheetTab('combat-stats');
        updatePinnedCardHP(char);
    }

    function setDeathSave(type, count) {
        const char = getCharacter();
        if(!char) return;
        if(char.deathSaves[type] === count) char.deathSaves[type] = count - 1;
        else char.deathSaves[type] = count;
        saveCharacter(char);
        renderSheetTab('combat-stats');
    }

    // rzut przeciw śmierci wg PHB: k20 ≥ 10 sukces, < 10 porażka, 1 — dwie porażki, 20 — wstaje z 1 PW;
    // 3 sukcesy — stabilny (0 PW), 3 porażki — śmierć
    async function deathSaveRoll() {
        const char = getCharacter(); if (!char) return;
        if ((char.hp?.current ?? 0) > 0) { App.showToast('Rzuty przeciw śmierci wykonuje się tylko przy 0 PW', 'info'); return; }
        const ds = char.deathSaves = char.deathSaves || { successes: 0, failures: 0 };
        if (ds.successes >= 3 || ds.failures >= 3) { App.showToast(ds.failures >= 3 ? `${char.name} nie żyje` : `${char.name} jest stabilny — nie rzuca już`, 'info'); return; }
        let total = null;
        try {
            if (window.PANEL_ROLA === 'gracz' && window.GraczBridge?.roll) { const w = await GraczBridge.roll('k20', `${char.name}: rzut przeciw śmierci`); total = w?.rzut?.total; }
            else if (window.DiceRoller?.rollExpression) { const r = await DiceRoller.rollExpression('1d20', 'normal', `${char.name}: rzut przeciw śmierci`); total = r?.total; }
        } catch (e) {}
        if (typeof total !== 'number') total = Math.floor(Math.random() * 20) + 1;
        let msg;
        if (total === 20) { char.hp.current = 1; char.deathSaves = { successes: 0, failures: 0 }; msg = 'naturalna 20! Odzyskuje 1 PW i odzyskuje przytomność'; }
        else if (total === 1) { ds.failures = Math.min(3, ds.failures + 2); msg = 'naturalna 1 — dwie porażki'; }
        else if (total >= 10) { ds.successes = Math.min(3, ds.successes + 1); msg = `${total} — sukces`; }
        else { ds.failures = Math.min(3, ds.failures + 1); msg = `${total} — porażka`; }
        if (char.deathSaves.successes >= 3) msg += '. Trzy sukcesy: stabilny, nieprzytomny przy 0 PW';
        if (char.deathSaves.failures >= 3) msg += '. Trzy porażki: postać umiera';
        saveCharacter(char);
        App.showToast(`${char.name}: ${msg}`, total === 20 || total >= 10 ? 'success' : 'warning');
        renderHero(char); renderSheetTab(document.querySelector('.sheet-tab.active')?.dataset.sheetTab || 'combat-stats');
    }

    function resetDeathSaves() {
        const char = getCharacter();
        if(!char) return;
        char.deathSaves.successes = 0;
        char.deathSaves.failures = 0;
        saveCharacter(char);
        renderSheetTab('combat-stats');
}

    function addEmptyItem() {
        const char = getCharacter();
        if(!char) return;
        if(!char.inventory) char.inventory = [];
        char.inventory.push({ name: '', quantity: 1, weight: 0 });
        saveCharacter(char);
        renderSheetTab('inventory');
    }

    function updateItem(idx, field, value) {
        const char = getCharacter();
        if(!char || !char.inventory) return;
        
        if (field === 'quantity') value = Math.max(0, parseInt(value, 10) || 0);
        if (field === 'weight') value = Math.max(0, parseFloat(String(value).replace(',', '.')) || 0);
        
        char.inventory[idx][field] = value;
        // nazwa z bazy: uzupełnij wagę, cenę i odnośnik (nie nadpisuje wagi wpisanej ręcznie)
        if (field === 'name' && window.ItemsDB) {
            const it = char.inventory[idx], db = ItemsDB.find(value);
            if (db && db.cat !== 'pack') { if (!parseFloat(it.weight)) it.weight = db.w || 0; if (!it.cost && db.cost !== '—') it.cost = db.cost; it.ref = db.id; }
            else delete it.ref;
        }
        saveCharacter(char);
        renderSheetTab('inventory'); // Need to rerender for total weight update
    }

    function removeItem(idx) {
        const char = getCharacter();
        if(!char || !char.inventory) return;
        
        char.inventory.splice(idx, 1);
        saveCharacter(char);
        renderSheetTab('inventory');
    }

    // --- Baza przedmiotów (PHB/SRD po polsku): waga, cena i parametry dodają się same ---
    const pickUI = { cat: 'all', q: '' };
    const costOf = (c) => !c ? '' : typeof c === 'string' ? c : `${c.quantity ?? ''} ${({ gp: 'sz', sp: 'ss', cp: 'sm', ep: 'se', pp: 'sp' })[c.unit] || c.unit || ''}`.trim();
    function pickerItems() {
        const custom = (StorageManager.getCustomEquipment?.() || []).map(c => ({
            id: 'c:' + (c._customId || c.id || c.name), name: c.name, en: '', cat: 'custom', cost: costOf(c.cost), w: +c.weight || 0,
            desc: Array.isArray(c.desc) ? c.desc.join(' ') : (c.desc || c.description || ''), _custom: true
        }));
        return [...window.ItemsDB.all, ...custom];
    }
    function addToInventory(char, entries) {
        char.inventory = char.inventory || [];
        entries.forEach(e => {
            const f = char.inventory.find(i => i.name === e.name);
            if (f) { f.quantity = (parseInt(f.quantity, 10) || 0) + e.quantity; if (!f.weight && e.weight) f.weight = e.weight; if (!f.cost && e.cost) f.cost = e.cost; if (!f.ref && e.ref) f.ref = e.ref; }
            else char.inventory.push({ ...e });
        });
    }
    function invLoad(char) {
        const total = (char.inventory || []).reduce((a, it) => a + (parseFloat(it.weight) || 0) * (parseInt(it.quantity, 10) || 0), 0);
        return { total, cap: (char.abilityScores?.str || 10) * 15 };
    }
    function showEquipmentPickerModal() {
        const char = getCharacter(); if (!char) return;
        if (!window.ItemsDB) { App.showToast('Baza przedmiotów nie jest wczytana', 'error'); return; }
        const items = pickerItems();
        const C = window.ItemsDB.CATS;
        const cats = [['all', 'Wszystko', 'fa-layer-group'], ...Object.entries(C).map(([k, v]) => [k, v[0], v[1]]), ...(items.some(i => i._custom) ? [['custom', 'Własne', 'fa-pen']] : [])];
        App.showModal('Dodaj przedmioty z bazy', `<div class="ip">
            <div class="ip-top"><i class="fa-solid fa-magnifying-glass"></i><input class="ip-q" placeholder="Szukaj: miecz, lina, mikstura, rapier, longsword…" value="${_esc(pickUI.q)}"></div>
            <div class="ip-cats">${cats.map(([k, t, ic]) => `<button type="button" data-cat="${k}" class="${pickUI.cat === k ? 'on' : ''}"><i class="fa-solid ${ic}"></i> ${t}</button>`).join('')}</div>
            <div class="ip-list"></div>
            <div class="ip-foot"><span class="ip-load"></span><span class="ip-hint">Waga i cena dodają się same · liczba = ile sztuk dodasz</span></div>
        </div>`, '<button class="btn-primary" onclick="App.closeModal()"><i class="fa-solid fa-check"></i> Gotowe</button>');
        document.getElementById('modal')?.classList.add('modal-wide');
        const body = document.getElementById('modal-body');
        const listEl = body.querySelector('.ip-list'), q = body.querySelector('.ip-q');
        const order = Object.keys(C);
        const loadTxt = () => { const c = getCharacter(); if (!c) return; const { total, cap } = invLoad(c); body.querySelector('.ip-load').innerHTML = `<i class="fa-solid fa-weight-hanging"></i> Obciążenie <b>${total.toFixed(1).replace('.', ',')}</b> / ${cap} lb`; body.querySelector('.ip-load').classList.toggle('over', total > cap); };
        const draw = () => {
            const t = window.ItemsDB.norm(pickUI.q);
            const rows = items.filter(i => (pickUI.cat === 'all' || i.cat === pickUI.cat) && (!t || window.ItemsDB.norm(i.name).includes(t) || window.ItemsDB.norm(i.en).includes(t) || window.ItemsDB.norm(i.sub).includes(t)))
                .sort((a, b) => (order.indexOf(a.cat) - order.indexOf(b.cat)) || a.name.localeCompare(b.name, 'pl'));
            listEl.innerHTML = rows.slice(0, 400).map(i => {
                const ic = i._custom ? 'fa-pen' : (C[i.cat] || C.gear)[1];
                const inf = window.ItemsDB.info(i);
                return `<div class="ip-row c-${i.cat}" data-id="${_esc(i.id)}">
                    <i class="ip-ic fa-solid ${ic}"></i>
                    <div class="ip-main"><b>${_esc(i.name)}</b><small>${_esc([i.en, i.sub || (C[i.cat] || [])[0]].filter(Boolean).join(' · '))}</small>${inf ? `<span class="ip-info">${_esc(inf)}</span>` : ''}</div>
                    <span class="ip-w" title="Waga za sztukę">${i.cat === 'pack' ? 'zawartość' : window.ItemsDB.fmtW(i.w)}</span>
                    <span class="ip-c">${_esc(i.cost || '—')}</span>
                    <input type="number" class="ip-n" min="1" value="${i.qty || 1}" aria-label="Ile sztuk">
                    <button type="button" class="ip-add" title="Dodaj do ekwipunku"><i class="fa-solid fa-plus"></i></button>
                </div>`;
            }).join('') || '<p class="ip-empty">Nic nie znaleziono — dodaj „Własny przedmiot” w ekwipunku.</p>';
        };
        draw(); loadTxt();
        setTimeout(() => q.focus(), 50);
        q.addEventListener('input', () => { pickUI.q = q.value; draw(); });
        body.querySelector('.ip-cats').addEventListener('click', (e) => {
            const b = e.target.closest('[data-cat]'); if (!b) return;
            pickUI.cat = b.dataset.cat; body.querySelectorAll('.ip-cats [data-cat]').forEach(x => x.classList.toggle('on', x === b)); draw();
        });
        listEl.addEventListener('click', (e) => {
            const btn = e.target.closest('.ip-add'); if (!btn) return;
            const row = btn.closest('.ip-row'), it = items.find(i => i.id === row.dataset.id); if (!it) return;
            const c = getCharacter(); if (!c) return;
            const qty = Math.max(1, parseInt(row.querySelector('.ip-n').value, 10) || 1);
            let entries;
            if (it.cat === 'pack') { entries = []; for (let k = 0; k < qty; k++) window.ItemsDB.packContents(it).forEach(x => entries.push(x)); }
            else if (it._custom) entries = [{ name: it.name, quantity: qty, weight: it.w, cost: it.cost }];
            else entries = [window.ItemsDB.toInv(it, qty)];
            addToInventory(c, entries);
            saveCharacter(c);
            renderSheetTab('inventory');
            row.classList.remove('added'); void row.offsetWidth; row.classList.add('added');
            btn.innerHTML = '<i class="fa-solid fa-check"></i>'; setTimeout(() => { btn.innerHTML = '<i class="fa-solid fa-plus"></i>'; }, 900);
            loadTxt();
            App.showToast(`Dodano: ${it.name}${it.cat === 'pack' ? ' (zawartość)' : qty > 1 ? ` ×${qty}` : ''}`, 'success');
        });
        listEl.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.classList.contains('ip-n')) e.target.closest('.ip-row').querySelector('.ip-add').click(); });
    }
    // zgodność wstecz (stary przycisk)
    function confirmEquipmentPicker() { showEquipmentPickerModal(); }

    // --- Języki ---
    async function addLanguage() {
        const char = getCharacter();
        if (!char) return;
        if (!char.languages) char.languages = [];

        let langList = [];
        try {
            langList = await APIClient.getLanguageList();
        } catch(e) { console.warn('Nie udało się pobrać listy języków', e); }

        const ALL_LANGS = ['Common','Dwarvish','Elvish','Giant','Gnomish','Goblin','Halfling','Orc','Abyssal','Celestial','Draconic','Deep Speech','Infernal','Primordial','Sylvan','Undercommon'];
        const available = ALL_LANGS.filter(l => !char.languages.includes(l));

        const options = available.map(l => `<option value="${l}">${l}</option>`).join('');
        const body = `
            <div class="form-group">
                <label style="color:var(--text-gold);">Wybierz język</label>
                <select id="new-language-select" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width: 100%;">
                    ${options}
                </select>
            </div>
            <div class="form-group" style="margin-top:10px;">
                <label style="color:var(--text-gold);">Lub wpisz własny</label>
                <input type="text" id="new-language-custom" placeholder="Np. Thieves' Cant, Druidic..." style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color);">
            </div>
        `;
        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-primary" onclick="CharactersModule.confirmAddLanguage()">Dodaj język</button>
        `;
        App.showModal('Dodaj Język', body, footer);
    }

    function confirmAddLanguage() {
        const char = getCharacter();
        if (!char) return;
        if (!char.languages) char.languages = [];

        const custom = document.getElementById('new-language-custom')?.value?.trim();
        const selected = document.getElementById('new-language-select')?.value;
        const lang = custom || selected;

        if (lang && !char.languages.includes(lang)) {
            char.languages.push(lang);
            saveCharacter(char);
            renderSheetTab('stats');
            App.showToast(`Dodano język: ${lang}`, 'success');
        }
        App.closeModal();
    }

    // --- Modal ---

    function showAddCharacterModal() {
        const campaignId = App.getActiveCampaignId();
        if (!campaignId) {
            App.showToast('Najpierw wybierz lub utwórz kampanię!', 'error');
            return;
        }
        // Użyj nowego Charactermancera jeśli jest dostępny
        if (window.Charactermancer) {
            window.Charactermancer.open();
        } else {
            createCharacterLegacy();
        }
    }

    // Fallback jeśli charactermancer.js nie załadowany
    function createCharacterLegacy() {
        const campaignId = App.getActiveCampaignId();
        if (!campaignId) return;

        const char = {
            id: StorageManager.generateId(),
            name: 'Nowy Bohater',
            race: '',
            subrace: '',
            class: '',
            level: 1,
            alignment: '',
            background: '',
            size: 'Medium',
            darkvision: 0,
            languages: ['Common'],
            ac: 10,
            speed: 30,
            hp: { current: 10, max: 10, temp: 0 },
            hitDie: 8,
            abilityScores: { str: 10, dex: 10, con: 10, int: 10, wis: 10, cha: 10 },
            proficiencies: [],
            savingThrows: [],
            weaponProficiencies: [],
            armorProficiencies: [],
            toolProficiencies: [],
            spellcastingAbility: '',
            spellSlots: {},
            spells: [],
            spellsNotes: '',
            inventory: [],
            currency: { cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 },
            features: { class: '', feats: '' },
            traits: [],
            classFeatures: [],
            backstory: { personality: '', ideals: '', bonds: '', flaws: '', history: '' },
            notes: '',
            deathSaves: { successes: 0, failures: 0 },
            xp: 0
        };

        StorageManager.saveCharacter(campaignId, char);
        App.showToast('Karta postaci została wygenerowana', 'success');
        activate();
        showCharacterSheet(char.id);
    }

    // Alias dla Charactermancera
    function createCharacter() {
        showAddCharacterModal();
    }

    // --- Export / Import ---
    function exportCharacter(charId) {
        const campaignId = App.getActiveCampaignId();
        const chars = StorageManager.getCharacters(campaignId);
        const char = chars.find(c => c.id === charId);
        if (!char) return;

        const dataStr = JSON.stringify(char, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `bohater_${char.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        App.showToast('Zapisano kartę postaci do pliku.', 'success');
    }

    function importCharacter(file) {
        const campaignId = App.getActiveCampaignId();
        if (!campaignId) {
            App.showToast('Najpierw wybierz lub utwórz kampanię!', 'error');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const char = JSON.parse(e.target.result);
                if (!char.name || !char.abilityScores) throw new Error('Nieprawidłowy format karty.');
                
                // Generuj nowe ID, by nie nadpisać istniejących
                char.id = StorageManager.generateId();
                
                StorageManager.saveCharacter(campaignId, char);
                App.showToast(`Pomyślnie zaimportowano: ${char.name}`, 'success');
                activate();
            } catch (err) {
                console.error(err);
                App.showToast('Błąd odczytu pliku. To nie jest poprawna karta postaci.', 'error');
            }
        };
        reader.readAsText(file);
    }

    // --- PDF: drukowana karta postaci (przeglądarka zapisuje ją jako PDF) ---
    function sheetPrintHTML(char) {
        const e = _esc, ck = window.Kits ? Kits.classKey(char.class) : '';
        const meta = (window.Kits && Kits.CLASS_META[ck]) || { color: '#8a5a2b', pl: char.class };
        const lvl = char.level || 1, prof = APIClient.proficiencyBonus(lvl), sc = char.abilityScores || {};
        const subclass = char.subclass ? (ClassData.getSubclassesForClass(ck).find(s => s.key === char.subclass)?.name || char.subclass) : '';
        const init = initOf(char);
        const AB = [['str', 'STR', 'Siła'], ['dex', 'DEX', 'Zręczność'], ['con', 'CON', 'Kondycja'], ['int', 'INT', 'Inteligencja'], ['wis', 'WIS', 'Mądrość'], ['cha', 'CHA', 'Charyzma']];
        const saves = AB.map(([k, K, pl]) => ({ k, pl, score: sc[k] ?? 10, mod: _mod(sc[k]), save: saveBonus(char, K), prof: (char.savingThrows || []).includes(K) }));
        const skills = Object.keys(APIClient.SKILLS).sort((a, b) => a.localeCompare(b, 'pl')).map(s => ({ s, a: AB_SHORT[APIClient.SKILLS[s]], b: skillBonus(char, s), l: skillLevel(char, s) }));
        const atk = window.Kits ? Kits.attacks(char, 12) : [];
        const ca = castAbility(char), caMod = ca ? _mod(sc[ca]) : 0;
        const slots = Object.entries(char.spellSlots || {}).filter(([, s]) => s && s.total > 0).map(([l, s]) => `${l}. krąg: ${'☐'.repeat(Math.min(9, s.total))}`);
        const spellsBy = {}; (char.spells || []).forEach(s => { (spellsBy[s.level || 0] = spellsBy[s.level || 0] || []).push(window.PL ? PL.spell(s.name) : s.name); });
        const inv = char.inventory || [];
        const load = inv.reduce((a, it) => a + (parseFloat(it.weight) || 0) * (parseInt(it.quantity, 10) || 0), 0);
        const cur = char.currency || {};
        const hd = char.hitDicePool || { current: lvl, max: lvl, die: char.hitDie || 8 };
        const feats = [
            ...(char.classFeatures || []).map(f => ({ n: window.PL ? PL.feat(f.name) : f.name, d: f.desc, t: 'Klasa' })),
            ...(char.subclassFeatures || []).map(f => ({ n: f.name, d: f.desc, t: subclass || 'Podklasa' })),
            ...(char.traits || []).map(f => ({ n: window.PL ? PL.feat(f.name) : f.name, d: f.desc, t: 'Rasa' })),
            ...(char.feats || []).map(f => ({ n: f.name, d: f.desc, t: 'Atut' }))];
        const featText = [char.features?.class, (char.feats || []).length ? '' : char.features?.feats].filter(Boolean);
        const bs = char.backstory || {};
        const para = (t) => e(t || '').replace(/\n+/g, '<br>');
        const mark = (l) => l === 2 ? '◉' : l === 1 ? '●' : '○';
        const list = (a) => (a || []).filter(Boolean).map(e).join(', ') || '—';
        const box = (label, val, sub) => `<div class="bx"><b>${val}</b><span>${label}</span>${sub ? `<small>${sub}</small>` : ''}</div>`;
        const sec = (title, body, cls = '') => `<section class="sec ${cls}"><h3>${title}</h3>${body}</section>`;
        const pp = 10 + skillBonus(char, 'Percepcja');
        return `<!doctype html><html lang="pl"><head><meta charset="utf-8"><title>${e(char.name || 'Karta postaci')}</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Alegreya+Sans:wght@400;500;700&display=swap" rel="stylesheet">
<style>
@page { size: A4; margin: 11mm 10mm; }
* { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body { margin: 0; font: 9.6pt/1.35 'Alegreya Sans', 'Segoe UI', Arial, sans-serif; color: #2a1d12; background: #fff; }
:root { --c: ${meta.color || '#8a5a2b'}; --line: #c9b38c; --soft: #f6efe2; }
h1, h2, h3 { font-family: Cinzel, Georgia, serif; margin: 0; }
.head { display: flex; gap: 12px; align-items: center; padding-bottom: 8px; border-bottom: 2.5px solid var(--c); margin-bottom: 8px; }
.por { width: 64px; height: 64px; border-radius: 50%; border: 2.5px solid var(--c); object-fit: cover; flex: none; }
.por.ph { display: grid; place-items: center; font: 700 26pt Cinzel, serif; color: var(--c); background: var(--soft); }
.head h1 { font-size: 19pt; line-height: 1.1; }
.head p { margin: 2px 0 0; font-size: 10pt; }
.head .meta { margin-left: auto; text-align: right; font-size: 8.5pt; color: #6b5640; }
.head .meta b { display: block; font: 700 22pt/1 Cinzel, serif; color: var(--c); }
.row { display: grid; gap: 6px; margin-bottom: 7px; }
.vit { grid-template-columns: repeat(8, 1fr); }
.bx { border: 1.2px solid var(--line); border-radius: 7px; padding: 4px 3px 3px; text-align: center; background: var(--soft); break-inside: avoid; }
.bx b { display: block; font: 700 14pt/1.1 Cinzel, serif; }
.bx span { display: block; font-size: 6.8pt; text-transform: uppercase; letter-spacing: .05em; color: #6b5640; }
.bx small { display: block; font-size: 7pt; color: #8a7458; }
.cols { display: grid; grid-template-columns: 34% 1fr; gap: 8px; }
.abil { display: grid; grid-template-columns: repeat(6, 1fr); gap: 6px; margin-bottom: 7px; }
.ab { border: 1.2px solid var(--line); border-radius: 8px; padding: 4px 4px 5px; text-align: center; break-inside: avoid; }
.ab .n { font-size: 7.2pt; text-transform: uppercase; letter-spacing: .06em; font-weight: 700; }
.ab .m { font: 700 18pt/1.1 Cinzel, serif; color: var(--c); }
.ab .v { display: inline-block; min-width: 28px; border: 1px solid var(--line); border-radius: 999px; font-size: 8.4pt; font-weight: 700; margin: 1px 0 3px; }
.ab .s { font-size: 7.6pt; color: #6b5640; border-top: 1px dotted var(--line); padding-top: 2px; }
.sec { border: 1.2px solid var(--line); border-radius: 8px; padding: 5px 8px 6px; margin-bottom: 7px; break-inside: avoid; }
.sec.flow { break-inside: auto; }
.sec h3 { font-size: 8.6pt; letter-spacing: .06em; text-transform: uppercase; color: var(--c); border-bottom: 1px solid var(--line); padding-bottom: 2px; margin-bottom: 4px; }
.sk { display: grid; grid-template-columns: 12px 1fr auto auto; gap: 0 5px; font-size: 8.6pt; }
.sk i { font-style: normal; color: var(--c); } .sk em { font-style: normal; color: #8a7458; font-size: 7.4pt; } .sk b { text-align: right; min-width: 22px; }
table { width: 100%; border-collapse: collapse; font-size: 8.6pt; }
th { text-align: left; font-size: 7pt; text-transform: uppercase; letter-spacing: .05em; color: #6b5640; border-bottom: 1px solid var(--line); padding: 1px 3px; }
td { padding: 2px 3px; border-bottom: .6px dotted #d8c7a6; vertical-align: top; }
td.r, th.r { text-align: right; white-space: nowrap; }
.kv { font-size: 8.6pt; margin: 1px 0; } .kv b { color: #6b5640; font-weight: 700; }
.ft { margin: 0 0 4px; font-size: 8.4pt; break-inside: avoid; } .ft b { font-size: 9pt; } .ft small { color: #8a7458; } .ft div { color: #3c2c1d; }
.coins { display: grid; grid-template-columns: repeat(5, 1fr); gap: 4px; margin-top: 5px; }
.ds { font-size: 8.6pt; } .ds span { letter-spacing: 3px; }
.pg2 { break-before: page; }
.two { columns: 2; column-gap: 10px; }
.foot { margin-top: 6px; font-size: 7pt; color: #9a8466; text-align: center; }
p.t { margin: 0; font-size: 8.8pt; }
</style></head><body>
<header class="head">
    ${char.portrait ? `<img class="por" src="${e(char.portrait)}" alt="">` : `<div class="por ph">${e(String(char.name || '?').trim().charAt(0).toUpperCase())}</div>`}
    <div><h1>${e(char.name || 'Bohater')}</h1>
        <p>${e([char.race, char.subrace].filter(Boolean).map(x => window.PL ? PL.race(x) : x).join(' — '))} · ${e(meta.pl || char.class || '')}${subclass ? ` (${e(subclass)})` : ''}</p>
        <p style="font-size:8.6pt;color:#6b5640">${e([char.background, char.alignment].filter(Boolean).join(' · '))}</p></div>
    <div class="meta"><b>${lvl}</b>poziom<br>${char.xp || 0} PD</div>
</header>
<div class="row vit">
    ${box('Klasa pancerza', char.ac ?? 10)}
    ${box('Maks. PW', char.hp?.max ?? 0, `obecne: ____ / tymcz.: ___`)}
    ${box('Kości wytrz.', `${hd.max}k${hd.die}`)}
    ${box('Inicjatywa', _sign(init))}
    ${box('Prędkość', `${char.speed ?? 30} ft`)}
    ${box('Premia z biegłości', _sign(prof))}
    ${box('Pas. percepcja', pp)}
    ${box('Widzenie w ciemn.', char.darkvision ? `${char.darkvision} ft` : '—')}
</div>
<div class="abil">${saves.map(a => `<div class="ab"><div class="n">${a.pl}</div><div class="m">${_sign(a.mod)}</div><div class="v">${a.score}</div><div class="s">${a.prof ? '●' : '○'} obrona ${_sign(a.save)}</div></div>`).join('')}</div>
<div class="cols">
    <div>
        ${sec('Umiejętności', `<div class="sk">${skills.map(x => `<i>${mark(x.l)}</i><span>${e(x.s)}</span><em>${x.a}</em><b>${_sign(x.b)}</b>`).join('')}</div><p class="t" style="margin-top:3px;font-size:7pt;color:#8a7458">● biegłość · ◉ ekspert</p>`)}
        ${sec('Biegłości i języki', `<p class="kv"><b>Broń:</b> ${list(window.PL ? PL.profs(char.weaponProficiencies) : char.weaponProficiencies)}</p><p class="kv"><b>Pancerze:</b> ${list(window.PL ? PL.profs(char.armorProficiencies) : char.armorProficiencies)}</p><p class="kv"><b>Narzędzia:</b> ${list(window.PL ? PL.profs(char.toolProficiencies) : char.toolProficiencies)}</p><p class="kv"><b>Języki:</b> ${list(window.PL ? PL.langs(char.languages) : char.languages)}</p>`)}
        ${sec('Rzuty przeciw śmierci', `<p class="ds">Sukcesy <span>☐☐☐</span> &nbsp; Porażki <span>☐☐☐</span></p>`)}
    </div>
    <div>
        ${sec('Ataki', atk.length ? `<table><tr><th>Broń</th><th class="r">Trafienie</th><th>Obrażenia</th></tr>${atk.map(a => `<tr><td>${e(a.name)}</td><td class="r">${_sign(a.hit)}</td><td>${e(a.dmg)} ${e(a.type || '')}</td></tr>`).join('')}</table>` : '<p class="t">—</p>')}
        ${ca || (char.spells || []).length ? sec('Magia', `<p class="kv"><b>Atrybut:</b> ${({ int: 'Inteligencja', wis: 'Mądrość', cha: 'Charyzma' })[ca] || '—'} &nbsp; <b>ST:</b> ${ca ? 8 + prof + caMod : '—'} &nbsp; <b>Atak czarem:</b> ${ca ? _sign(prof + caMod) : '—'}</p>
            ${slots.length ? `<p class="kv"><b>Miejsca na czary:</b> ${slots.join(' &nbsp; ')}</p>` : ''}
            ${Object.keys(spellsBy).sort((a, b) => a - b).map(l => `<p class="kv"><b>${+l === 0 ? 'Sztuczki' : `${l}. krąg`}:</b> ${spellsBy[l].map(e).join(', ')}</p>`).join('')}`) : ''}
        ${sec('Ekwipunek', `<table><tr><th>Przedmiot</th><th class="r">Ilość</th><th class="r">Waga</th></tr>${inv.length ? inv.map(it => `<tr><td>${e(it.name)}</td><td class="r">${it.quantity ?? 1}</td><td class="r">${it.weight ? `${+((parseFloat(it.weight) || 0) * (parseInt(it.quantity, 10) || 1)).toFixed(2)} lb` : '—'}</td></tr>`).join('') : '<tr><td colspan="3">—</td></tr>'}</table>
            <p class="kv" style="margin-top:3px"><b>Obciążenie:</b> ${+load.toFixed(1)} / ${(sc.str ?? 10) * 15} lb</p>
            <div class="coins">${[['pp', 'PM'], ['gp', 'SZ'], ['ep', 'EL'], ['sp', 'SR'], ['cp', 'MD']].map(([k, n]) => box(n, cur[k] || 0)).join('')}</div>`, 'flow')}
    </div>
</div>
<div class="pg2">
    ${sec('Cechy i zdolności', `<div class="two">${feats.length || featText.length ? feats.map(f => `<div class="ft"><b>${e(f.n)}</b> <small>· ${e(f.t)}</small>${f.d ? `<div>${para(f.d)}</div>` : ''}</div>`).join('') + featText.map(t => `<div class="ft"><div>${para(t)}</div></div>`).join('') : '<p class="t">—</p>'}</div>`, 'flow')}
    ${sec('Osobowość', `<div class="two">${[['Cechy osobowości', bs.personality], ['Ideały', bs.ideals], ['Więzi', bs.bonds], ['Wady', bs.flaws]].map(([n, v]) => `<div class="ft"><b>${n}</b><div>${v ? para(v) : '—'}</div></div>`).join('')}</div>`)}
    ${bs.history ? sec('Historia postaci', `<p class="t">${para(bs.history)}</p>`, 'flow') : ''}
    <p class="foot">Karta wygenerowana w Panelu D&amp;D · ${new Date().toLocaleDateString(window.LOC || 'pl-PL')}</p>
</div>
</body></html>`;
    }
    function exportToPDF(charId) {
        const cid = App.getActiveCampaignId();
        const char = normalizeCharacter((StorageManager.getCharacters(cid) || []).find(c => c.id === charId));
        if (!char) return;
        const html = sheetPrintHTML(char);
        const ready = (w, done) => {
            const go = () => { try { w.focus(); w.print(); } catch (er) {} done && setTimeout(done, 1500); };
            const imgs = [...w.document.images].map(i => i.complete ? null : new Promise(r => { i.onload = i.onerror = r; })).filter(Boolean);
            Promise.race([Promise.all([w.document.fonts?.ready, ...imgs]), new Promise(r => setTimeout(r, 2500))]).then(() => setTimeout(go, 150));
        };
        App.showToast('W oknie drukowania wybierz „Zapisz jako PDF”.', 'info');
        // telefony: osobna karta (drukowanie z ramki bywa tam zawodne)
        if (matchMedia('(pointer: coarse)').matches) {
            const w = window.open('', '_blank');
            if (w) { w.document.open(); w.document.write(html); w.document.close(); ready(w); return; }
        }
        const fr = document.createElement('iframe');
        fr.setAttribute('aria-hidden', 'true');
        fr.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
        document.body.appendChild(fr);
        const d = fr.contentWindow.document; d.open(); d.write(html); d.close();
        ready(fr.contentWindow, () => fr.remove());
    }

    // --- Pinning ---

    function pinCharacter(charId) {
        const char = characters.find(c => c.id === charId);
        if (!char) return;

        const overlay = document.getElementById('overlay');
        const pinId = `pinned-char-${char.id}`;
        
        if (document.getElementById(pinId)) {
            App.showToast('Bohater jest już przypięty', 'info');
            return;
        }

        const el = document.createElement('div');
        el.className = 'pinned-character';
        el.id = pinId;
        el.dataset.itemId = pinId;
        
        // Initial position in center
        el.style.left = (window.innerWidth / 2 - 150) + 'px';
        el.style.top = '100px';

        renderPinnedCardContent(el, char);

        overlay.appendChild(el);
        DraggableManager.makeDraggable(el, '.pinned-header');
        DraggableManager.restorePosition(el);
    }

    function unpinCharacter(charId) {
        const pinId = `pinned-char-${charId}`;
        const el = document.getElementById(pinId);
        if (el) {
            el.remove();
            DraggableManager.removeItem(pinId);
        }
    }

    function renderPinnedCardContent(el, char) {
        const hpPct = char.hp.max > 0 ? Math.round((char.hp.current / char.hp.max) * 100) : 0;
        const hpClass = hpPct > 50 ? 'hp-high' : hpPct > 25 ? 'hp-mid' : 'hp-low';
        
        let abilitiesHtml = '<div style="display:grid; grid-template-columns: repeat(6, 1fr); gap: 4px; margin-bottom:10px;">';
        APIClient.ABILITY_NAMES.forEach(ab => {
            const abLow = ab.toLowerCase();
            const mod = APIClient.abilityModifier(char.abilityScores[abLow]);
            const modStr = mod >= 0 ? `+${mod}` : `${mod}`;
            abilitiesHtml += `
                <div style="text-align:center; cursor:pointer; background:rgba(0,0,0,0.3); border-radius:4px; padding:4px;" onclick="CharactersModule.rollStat('${_esc(char.name)}', '${ab}', ${mod})" title="Rzut na ${ab}">
                    <div style="font-size:0.65rem; color:var(--text-muted);">${ab}</div>
                    <div style="font-weight:bold; color:var(--text-gold); font-size:0.9rem;">${modStr}</div>
                </div>
            `;
        });
        abilitiesHtml += '</div>';

        const profBonus = APIClient.proficiencyBonus(char.level);
        let skillsHtml = '<div style="font-size:0.8rem; overflow-y:auto; flex:1; padding-right:4px;">';
        Object.keys(APIClient.SKILLS).sort().forEach(skill => {
            const attr = APIClient.SKILLS[skill];
            const modBase = APIClient.abilityModifier(char.abilityScores[attr.toLowerCase()]);
            const finalMod = char.proficiencies.includes(skill) ? modBase + profBonus : modBase;
            const finalModStr = finalMod >= 0 ? `+${finalMod}` : `${finalMod}`;
            skillsHtml += `
                <div style="display:flex; justify-content:space-between; cursor:pointer; padding:3px 5px; border-bottom:1px solid rgba(255,255,255,0.05);" class="skill-row" onclick="CharactersModule.rollStat('${_esc(char.name)}', '${skill}', ${finalMod})" title="Rzut na ${skill}">
                    <span>${skill}</span>
                    <span style="color:var(--text-gold); font-weight:bold;">${finalModStr}</span>
                </div>
            `;
        });
        skillsHtml += '</div>';
        
        let spellsHtml = '<div style="font-size:0.8rem; overflow-y:auto; flex:1; padding-right:4px;">';
        if ((char.spells && char.spells.length > 0) || (char.spellSlots && Object.values(char.spellSlots).some(s => s.total > 0))) {
            if (char.spellSlots) {
                let slotsOutput = '';
                for (let i = 1; i <= 9; i++) {
                    const slot = char.spellSlots[i];
                    if (slot && slot.total > 0) {
                        const left = slot.total - slot.used;
                        slotsOutput += `
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; background:rgba(0,0,0,0.2); padding:2px 6px; border-radius:4px;">
                                <span>Lvl ${i}: <b style="color:var(--text-gold);">${left}/${slot.total}</b></span>
                                <button class="btn-primary btn-small" style="padding:2px 8px; font-size:0.7rem;" onclick="CharactersModule.useSpellSlot('${char.id}', ${i})" ${left <= 0 ? 'disabled' : ''}>Użyj</button>
                            </div>
                        `;
                    }
                }
                if (slotsOutput) spellsHtml += `<div style="margin-bottom:10px;">${slotsOutput}</div>`;
            }

            if (char.spells && char.spells.length > 0) {
                const grouped = {};
                char.spells.forEach(s => {
                    const lvl = s.level || 0;
                    if (!grouped[lvl]) grouped[lvl] = [];
                    grouped[lvl].push(s);
                });

                Object.keys(grouped).sort((a,b)=>parseInt(a)-parseInt(b)).forEach(lvl => {
                    const lvlLabel = lvl == 0 ? 'Sztuczki (Cantrips)' : `Poziom ${lvl}`;
                    spellsHtml += `<div style="font-weight:bold; color:var(--text-muted); margin-top:5px; margin-bottom:3px; border-bottom:1px solid rgba(255,255,255,0.1);">${lvlLabel}</div>`;
                    grouped[lvl].forEach(sp => {
                        spellsHtml += `
                            <div style="padding-left:8px; border-left:2px solid var(--gold); margin-bottom:4px; font-style:italic; background:rgba(0,0,0,0.1); border-radius:0 4px 4px 0;">
                                ${_esc(sp.name)}
                            </div>
                        `;
                    });
                });
            }
        } else {
            spellsHtml += '<div style="color:var(--text-muted); text-align:center; font-style:italic; padding:10px;">Brak magii.</div>';
        }
        spellsHtml += '</div>';

        let featuresHtml = '<div style="font-size:0.8rem; overflow-y:auto; flex:1; padding-right:4px;">';
        if ((char.traits && char.traits.length > 0) || (char.classFeatures && char.classFeatures.length > 0)) {
            if (char.traits && char.traits.length > 0) {
                featuresHtml += '<div style="font-weight:bold; color:var(--text-muted); margin-bottom:4px; border-bottom:1px solid rgba(255,255,255,0.1);">Cechy Rasowe</div>';
                char.traits.forEach(t => {
                    const descStr = t.desc ? _esc(t.desc).replace(/\\n/g, '<br>') : 'Brak opisu (wymaga pobrania w Karcie Postaci)';
                    featuresHtml += `
                        <div style="margin-bottom:6px;">
                            <div style="padding:4px 8px; border-left:2px solid var(--emerald-dark); background:rgba(0,0,0,0.3); cursor:pointer; border-radius:0 4px 4px 0; font-weight:bold;" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'">
                                ${_esc(t.name)}
                            </div>
                            <div style="display:none; padding:6px 8px; background:rgba(0,0,0,0.5); color:var(--text-muted); font-size:0.75rem; border-radius:0 0 4px 4px;">
                                ${descStr}
                            </div>
                        </div>
                    `;
                });
            }
            if (char.classFeatures && char.classFeatures.length > 0) {
                featuresHtml += '<div style="font-weight:bold; color:var(--text-muted); margin-top:8px; margin-bottom:4px; border-bottom:1px solid rgba(255,255,255,0.1);">Cechy Klasowe</div>';
                char.classFeatures.forEach(f => {
                    const descStr = f.desc ? _esc(f.desc).replace(/\\n/g, '<br>') : 'Brak opisu (wymaga pobrania w Karcie Postaci)';
                    featuresHtml += `
                        <div style="margin-bottom:6px;">
                            <div style="padding:4px 8px; border-left:2px solid var(--gold); background:rgba(0,0,0,0.3); cursor:pointer; border-radius:0 4px 4px 0; font-weight:bold;" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'">
                                ${_esc(f.name)}
                            </div>
                            <div style="display:none; padding:6px 8px; background:rgba(0,0,0,0.5); color:var(--text-muted); font-size:0.75rem; border-radius:0 0 4px 4px;">
                                ${descStr}
                            </div>
                        </div>
                    `;
                });
            }
        } else {
            featuresHtml += '<div style="color:var(--text-muted); text-align:center; font-style:italic; padding:10px;">Brak cech.</div>';
        }
        featuresHtml += '</div>';
        
        let inventoryHtml = '<div style="font-size:0.8rem; overflow-y:auto; flex:1; padding-right:4px;">';
        if (char.inventory && char.inventory.length > 0) {
            char.inventory.forEach(item => {
                inventoryHtml += `
                    <div style="display:flex; justify-content:space-between; padding:4px 6px; background:rgba(0,0,0,0.2); margin-bottom:4px; border-radius:4px; border-left:2px solid var(--text-parchment-muted);">
                        <span style="font-weight:bold;">${_esc(item.name)}</span>
                        <span style="color:var(--text-gold);">x${item.quantity || 1}</span>
                    </div>
                `;
            });
        } else {
            inventoryHtml += '<div style="color:var(--text-muted); text-align:center; font-style:italic; padding:10px;">Ekwipunek jest pusty.</div>';
        }
        inventoryHtml += '</div>';

        // Funkcja pomocnicza wstrzykiwana jako HTML do przełączania tabów
        const tabScript = `
            const p = this.parentElement.parentElement;
            p.querySelectorAll('.pinned-tab-btn').forEach(b => b.style.opacity = '0.5');
            this.style.opacity = '1';
            p.querySelectorAll('.pinned-pane').forEach(pane => pane.style.display = 'none');
            p.querySelector('.pane-' + this.dataset.target).style.display = 'flex';
        `;

        el.innerHTML = `
            <div class="pinned-header" style="cursor:move; background: rgba(20, 15, 10, 0.95); padding:8px 12px; display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid var(--gold); border-radius:8px 8px 0 0;">
                <span class="pinned-name" style="font-family: var(--font-heading); font-size: 1.1rem; color: var(--text-gold); font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:180px;">${_esc(char.name)}</span>
                <div style="display:flex; gap:4px; align-items:center;">
                    <button class="btn-icon btn-small" style="color: white; font-size:1.1rem; padding: 0 4px;" onclick="this.closest('.pinned-character').classList.toggle('collapsed')" title="Zwiń / Rozwiń">▬</button>
                    <button class="btn-icon btn-small" style="color: white; font-size:1.1rem; padding: 0 4px;" onclick="CharactersModule.unpinCharacter('${char.id}')" title="Zamknij">✕</button>
                </div>
            </div>
            
            <div class="pinned-body" style="padding:10px; background: rgba(30, 25, 20, 0.95); backdrop-filter: blur(10px); display:flex; flex-direction:column; gap:8px;">
                <!-- Sekcja HP i szybkiego dostępu -->
                <div>
                    <div class="hp-bar" style="height:16px; background:#111; border-radius:4px; border: 1px solid rgba(255,255,255,0.2); position:relative;">
                        <div class="hp-bar-fill ${hpClass}" style="height:100%; border-radius:3px; width: ${hpPct}%; transition: width 0.3s ease;"></div>
                        <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:0.75rem; color:white; text-shadow:1px 1px 2px black;">HP: ${char.hp.current}/${char.hp.max}</div>
                    </div>
                    <div class="pinned-hp-controls" style="display:flex; gap:4px; margin-top:6px;">
                        <button class="hp-adjust-btn damage btn-small" style="flex:1; background:var(--crimson-dark); color: white; border: none; border-radius: 4px; padding: 2px 0; font-size:0.75rem; cursor: pointer;" onclick="CharactersModule.modifyPinnedHP('${char.id}', -5)">-5</button>
                        <button class="hp-adjust-btn damage btn-small" style="flex:1; background:var(--crimson-dark); color: white; border: none; border-radius: 4px; padding: 2px 0; font-size:0.75rem; cursor: pointer;" onclick="CharactersModule.modifyPinnedHP('${char.id}', -1)">-1</button>
                        <button class="hp-adjust-btn heal btn-small" style="flex:1; background:var(--emerald-dark); color: white; border: none; border-radius: 4px; padding: 2px 0; font-size:0.75rem; cursor: pointer;" onclick="CharactersModule.modifyPinnedHP('${char.id}', 1)">+1</button>
                        <button class="hp-adjust-btn heal btn-small" style="flex:1; background:var(--emerald-dark); color: white; border: none; border-radius: 4px; padding: 2px 0; font-size:0.75rem; cursor: pointer;" onclick="CharactersModule.modifyPinnedHP('${char.id}', 5)">+5</button>
                    </div>
                </div>

                <div style="display:flex; justify-content:space-between; background: rgba(0,0,0,0.3); padding: 6px; border-radius: 6px;">
                    <div style="text-align:center; flex:1;"><div style="font-size:0.65rem; color:var(--text-muted);">KP (AC)</div><div style="font-weight:bold; font-size: 1rem; color: white;">${char.ac}</div></div>
                    <div style="text-align:center; flex:1; cursor:pointer;" onclick="CharactersModule.rollStat('${_esc(char.name)}', 'Inicjatywa', ${APIClient.abilityModifier(char.abilityScores.dex)})" title="Rzut na Inicjatywę"><div style="font-size:0.65rem; color:var(--text-muted);">Init</div><div style="font-weight:bold; font-size: 1rem; color:var(--text-gold);">${APIClient.modifierString(char.abilityScores.dex)}</div></div>
                    <div style="text-align:center; flex:1;"><div style="font-size:0.65rem; color:var(--text-muted);">PP</div><div style="font-weight:bold; font-size: 1rem; color: white;">${10 + APIClient.abilityModifier(char.abilityScores.wis) + (char.proficiencies.includes('Perception') ? APIClient.proficiencyBonus(char.level) : 0)}</div></div>
                    <div style="text-align:center; flex:1;"><div style="font-size:0.65rem; color:var(--text-muted);">Speed</div><div style="font-weight:bold; font-size: 1rem; color: white;">${char.speed}'</div></div>
                </div>

                <!-- Pasek Zakładek -->
                <div style="display:flex; background: rgba(0,0,0,0.4); border-radius: 6px; overflow:hidden;">
                    <button class="pinned-tab-btn" data-target="stats" style="flex:1; padding:6px; background:transparent; border:none; border-bottom:2px solid transparent; color:white; cursor:pointer; opacity:1;" onclick="${tabScript.replace(/"/g, "'")}">🎲</button>
                    <button class="pinned-tab-btn" data-target="magic" style="flex:1; padding:6px; background:transparent; border:none; border-bottom:2px solid transparent; color:white; cursor:pointer; opacity:0.5;" onclick="${tabScript.replace(/"/g, "'")}">🪄</button>
                    <button class="pinned-tab-btn" data-target="features" style="flex:1; padding:6px; background:transparent; border:none; border-bottom:2px solid transparent; color:white; cursor:pointer; opacity:0.5;" onclick="${tabScript.replace(/"/g, "'")}">📜</button>
                    <button class="pinned-tab-btn" data-target="inventory" style="flex:1; padding:6px; background:transparent; border:none; border-bottom:2px solid transparent; color:white; cursor:pointer; opacity:0.5;" onclick="${tabScript.replace(/"/g, "'")}">🎒</button>
                </div>

                <!-- Kontenery Zakładek -->
                <div style="position:relative; min-height: 200px; max-height: 250px; display:flex; flex-direction:column; background:rgba(0,0,0,0.2); border-radius:6px; padding:6px; border:1px solid rgba(255,255,255,0.05);">
                    <div class="pinned-pane pane-stats" style="display:flex; flex-direction:column; flex:1; overflow:hidden;">
                        ${abilitiesHtml}
                        ${skillsHtml}
                    </div>
                    <div class="pinned-pane pane-magic" style="display:none; flex-direction:column; flex:1; overflow:hidden;">
                        ${spellsHtml}
                    </div>
                    <div class="pinned-pane pane-features" style="display:none; flex-direction:column; flex:1; overflow:hidden;">
                        ${featuresHtml}
                    </div>
                    <div class="pinned-pane pane-inventory" style="display:none; flex-direction:column; flex:1; overflow:hidden;">
                        ${inventoryHtml}
                    </div>
                </div>
            </div>
        `;
    }

    function rollStat(charName, statName, modifier) {
        if (!window.DiceRoller) {
            App.showToast('Brak modułu rzutów kośćmi.', 'error');
            return;
        }
        // Roll locally (DiceRoller.roll is async) and record it in the shared dice log
        const modStr = modifier >= 0 ? `+${modifier}` : `${modifier}`;
        const d20 = Math.floor(Math.random() * 20) + 1;
        const result = { expression: `1d20${modStr}`, label: `${charName}: ${statName}`, rolls: [d20], rollGroups: [{ count: 1, sides: 20, rolls: [d20], sum: d20, sign: 1 }],
            modifier, total: d20 + modifier, timestamp: Date.now(), isCritical: d20 === 20, isFumble: d20 === 1 };
        try { window.DiceRoller.addToHistory(result); window.DiceRoller._updateHistoryAndToast(result); } catch (e) {}
        const html = `
            <div style="text-align:center; padding: 20px;">
                <div style="font-size:1.2rem; color:var(--text-muted); margin-bottom:10px;">${charName} testuje: <strong>${statName}</strong></div>
                <div style="font-size:4rem; font-weight:bold; color:var(--text-gold); text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">${result.total}</div>
                <div style="font-size:1rem; color:var(--text-muted); margin-top:10px;">Rzut: [ ${result.rolls.join(', ')} ] ${modStr}</div>
            </div>
        `;
        App.showModal('Wynik Rzutu (VTT)', html, '<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>');
    }

    function modifyPinnedHP(charId, amount) {
        const campaignId = App.getActiveCampaignId();
        const chars = StorageManager.getCharacters(campaignId);
        const char = chars.find(c => c.id === charId);
        if (!char) return;

        char.hp.current += amount;
        if (char.hp.current > char.hp.max) char.hp.current = char.hp.max;
        if (char.hp.current < 0) char.hp.current = 0;
        
        StorageManager.saveCharacter(campaignId, char);
        loadCharacters();
        updatePinnedCardHP(char);
        
        // If sheet is open for this char, refresh combat tab
        if (currentCharacterId === charId) {
            const combatTab = document.querySelector('.sheet-tab[data-sheet-tab="combat-stats"]');
            if (combatTab && combatTab.classList.contains('active')) {
                renderSheetTab('combat-stats');
            }
        }
    }

    function updatePinnedCardHP(char) {
        const el = document.getElementById(`pinned-char-${char.id}`);
        if (el) {
            renderPinnedCardContent(el, char);
        }
    }

    function useSpellSlot(charId, level) {
        const cId = App.getActiveCampaignId();
        const chars = StorageManager.getCharacters(cId);
        const char = chars.find(c => c.id === charId);
        if (!char || !char.spellSlots[level]) return;

        if (char.spellSlots[level].used < char.spellSlots[level].total) {
            char.spellSlots[level].used += 1;
            StorageManager.saveCharacters(cId, chars);
            
            updatePinnedCardHP(char);
            App.showToast(`Użyto slot poziomu ${level}`, 'success');
        }
    }

    // --- Level Up System ---
    async function levelUp() {
        const char = getCharacter();
        if (!char) return;

        const newLevel = char.level + 1;
        if (newLevel > 20) {
            App.showToast('Postać osiągnęła maksymalny poziom (20)!', 'info');
            return;
        }

        App.showModal('⬆️ Przygotowanie Awansu...', '<div style="text-align:center; padding:40px;"><div class="loading-spinner"><div class="spinner"></div></div><p style="color:var(--text-muted); margin-top:15px;">Pobieranie danych poziomu...</p></div>', '');

        const classIndex = APIClient._indexify(char.class);
        let levelData = null;
        try {
            if (classIndex) levelData = await APIClient.getClassLevel(classIndex, newLevel);
        } catch(e) { console.warn('Nie udało się pobrać danych poziomu', e); }

        const conMod = APIClient.abilityModifier(char.abilityScores.con);
        const hitDie = char.hitDie || ClassData.HIT_DIE[char.class?.toLowerCase()] || 8;
        const avgHP = Math.max(1, Math.floor(hitDie / 2) + 1 + conMod);

        const classKey = char.class?.toLowerCase() || '';

        // Check conditions
        const isASI = ClassData.isASILevel(classKey, newLevel);
        const isSubclassLvl = ClassData.isSubclassLevel(classKey, newLevel) && !char.subclass;
        const hasSpellcasting = !!char.spellcastingAbility;

        // Fetch new features from API
        let newFeatures = [];
        if (levelData && levelData.features) {
            for (const f of levelData.features) {
                try {
                    const featData = await APIClient.getFeature(f.index);
                    if (featData) {
                        const desc = Array.isArray(featData.desc) ? featData.desc.join('\n') : (featData.desc || '');
                        const translated = await APIClient.translateText(desc);
                        newFeatures.push({ name: featData.name, index: f.index, desc: translated });
                    }
                } catch(e) {
                    newFeatures.push({ name: f.name, index: f.index, desc: '' });
                }
            }
        }

        // Spell slots update
        let newSlots = {};
        if (levelData && levelData.spellcasting) {
            for (let i = 1; i <= 9; i++) {
                const key = `spell_slots_level_${i}`;
                if (levelData.spellcasting[key] !== undefined && levelData.spellcasting[key] > 0) {
                    newSlots[i] = { used: 0, total: levelData.spellcasting[key] };
                }
            }
        }

        // Cantrips & spells known deltas
        const oldCantrips = ClassData.getCantripsKnown(classKey, char.level);
        const newCantrips = ClassData.getCantripsKnown(classKey, newLevel);
        const cantripsDelta = newCantrips - oldCantrips;
        const oldSpellsKnown = ClassData.getSpellsKnown(classKey, char.level);
        const newSpellsKnown = ClassData.getSpellsKnown(classKey, newLevel);
        const spellsKnownDelta = newSpellsKnown !== null && oldSpellsKnown !== null ? newSpellsKnown - oldSpellsKnown : 0;

        // Resources
        const oldResources = ClassData.getResourcesForLevel(classKey, char.level, char);
        const newResources = ClassData.getResourcesForLevel(classKey, newLevel, char);

        // Extra attack
        const extraAttackLevels = ClassData.EXTRA_ATTACK[classKey] || [];
        const gainsExtraAttack = extraAttackLevels.includes(newLevel);

        // Subclass features
        let newSubclassFeatures = [];
        if (char.subclass) {
            newSubclassFeatures = ClassData.getNewSubclassFeatures(classKey, char.subclass, newLevel);
        }

        // Proficiency bonus change
        const oldProf = APIClient.proficiencyBonus(char.level);
        const newProf = APIClient.proficiencyBonus(newLevel);
        const profChanged = oldProf !== newProf;

        // Store pending data
        CharactersModule._pendingLevelUp = {
            newLevel, hitDie, conMod, avgHP,
            newFeatures, newSlots, isASI, isSubclassLvl,
            cantripsDelta, spellsKnownDelta,
            oldResources, newResources,
            gainsExtraAttack, newSubclassFeatures,
            profChanged, oldProf, newProf,
            classKey, hasSpellcasting
        };

        renderLevelUpModal(char);
    }

    function renderLevelUpModal(char) {
        const p = CharactersModule._pendingLevelUp;
        if (!p) return;

        // --- Build sections ---
        let sections = '';

        // 1. Overview
        sections += `
            <div style="text-align:center; margin-bottom:20px;">
                <div style="font-size:2.5rem; color:var(--text-gold); font-weight:bold; font-family:var(--font-heading); text-shadow: 0 4px 10px rgba(207,170,107,0.5);">
                    Poziom ${char.level} → ${p.newLevel}
                </div>
                <div style="color:var(--text-muted); font-size:1.1rem; margin-top:5px;">
                    ${_esc(char.name)} · ${_esc(char.race)} · ${_esc(char.class)}${char.subclass ? ' (' + _esc(ClassData.getSubclassesForClass(p.classKey).find(s => s.key === char.subclass)?.name || char.subclass) + ')' : ''}
                </div>
                ${p.profChanged ? `<div style="margin-top:8px; padding:6px 16px; display:inline-block; background:rgba(16,185,129,0.2); border:1px solid #10b981; border-radius:20px; color:#10b981; font-weight:bold;">Bonus Biegłości: +${p.oldProf} → +${p.newProf}</div>` : ''}
            </div>`;

        // 2. HP Section
        sections += `
            <div style="padding:15px; background:rgba(0,0,0,0.3); border-radius:10px; margin-bottom:12px; border-left:4px solid #ef4444;">
                <strong style="color:#ef4444; font-size:1.1rem;">❤️ Punkty Życia</strong>
                <p style="color:var(--text-primary); margin:8px 0 5px;">Kość Wytrzymałości: d${p.hitDie} + CON mod (${p.conMod >= 0 ? '+' : ''}${p.conMod})</p>
                <div style="display:flex; gap:15px; align-items:center; margin-top:10px; flex-wrap:wrap;">
                    <label style="color:var(--text-primary); cursor:pointer; padding:6px 12px; background:rgba(255,255,255,0.05); border-radius:6px; border:1px solid var(--border-color);">
                        <input type="radio" name="hp_method" value="avg" checked> Średnia: <strong style="color:#10b981;">+${p.avgHP} HP</strong>
                    </label>
                    <label style="color:var(--text-primary); cursor:pointer; padding:6px 12px; background:rgba(255,255,255,0.05); border-radius:6px; border:1px solid var(--border-color);">
                        <input type="radio" name="hp_method" value="roll"> Rzut kością (d${p.hitDie})
                    </label>
                    <label style="color:var(--text-primary); cursor:pointer; padding:6px 12px; background:rgba(255,255,255,0.05); border-radius:6px; border:1px solid var(--border-color);">
                        <input type="radio" name="hp_method" value="manual"> Ręcznie:
                        <input type="number" id="manual_hp" value="${p.avgHP}" min="1" style="width:50px; background:rgba(0,0,0,0.4); color:white; border:1px solid var(--border-color); border-radius:4px; text-align:center;">
                    </label>
                </div>
            </div>`;

        // 3. Subclass Selection (conditional)
        if (p.isSubclassLvl) {
            const subclasses = ClassData.getSubclassesForClass(p.classKey);
            if (subclasses.length > 0) {
                let subOpts = subclasses.map(sc => `
                    <label style="display:block; padding:12px; margin-bottom:8px; background:rgba(255,255,255,0.05); border:2px solid var(--border-color); border-radius:8px; cursor:pointer; transition: border-color 0.2s;" onmouseover="this.style.borderColor='var(--gold)'" onmouseout="if(!this.querySelector('input').checked) this.style.borderColor='var(--border-color)'">
                        <input type="radio" name="subclass_choice" value="${sc.key}" style="margin-right:10px;">
                        <strong style="color:var(--text-gold); font-size:1.05rem;">${_esc(sc.name)}</strong>
                        <div style="color:var(--text-muted); font-size:0.9rem; margin-top:4px; margin-left:24px;">${_esc(sc.desc)}</div>
                    </label>
                `).join('');
                sections += `
                    <div style="padding:15px; background:rgba(0,0,0,0.3); border-radius:10px; margin-bottom:12px; border-left:4px solid #8b5cf6;">
                        <strong style="color:#8b5cf6; font-size:1.1rem;">🛡️ Wybór Podklasy</strong>
                        <p style="color:var(--text-muted); margin:5px 0 10px;">Wybierz specjalizację dla klasy ${_esc(char.class)}:</p>
                        ${subOpts}
                    </div>`;
            }
        }

        // 4. New Features
        let featuresHtml = '';
        if (p.newFeatures.length > 0) {
            featuresHtml = p.newFeatures.map(f => `
                <div style="padding:8px 12px; background:rgba(207,170,107,0.1); border-left:3px solid var(--gold); border-radius:0 6px 6px 0; margin-bottom:6px;">
                    <strong style="color:var(--text-gold);">${_esc(f.name)}</strong>
                    ${f.desc ? `<div style="color:var(--text-muted); font-size:0.85rem; margin-top:3px;">${_esc(f.desc).substring(0, 200)}${f.desc.length > 200 ? '...' : ''}</div>` : ''}
                </div>
            `).join('');
        }

        if (p.newSubclassFeatures.length > 0 && char.subclass) {
            featuresHtml += p.newSubclassFeatures.map(f => `
                <div style="padding:8px 12px; background:rgba(139,92,246,0.1); border-left:3px solid #8b5cf6; border-radius:0 6px 6px 0; margin-bottom:6px;">
                    <strong style="color:#c4b5fd;">🛡️ ${_esc(f.name)}</strong>
                    <div style="color:var(--text-muted); font-size:0.85rem; margin-top:3px;">${_esc(f.desc).substring(0, 200)}${f.desc.length > 200 ? '...' : ''}</div>
                </div>
            `).join('');
        }

        if (p.gainsExtraAttack) {
            const attackCount = ClassData.EXTRA_ATTACK[p.classKey].filter(l => l <= p.newLevel).length + 1;
            featuresHtml += `
                <div style="padding:8px 12px; background:rgba(239,68,68,0.1); border-left:3px solid #ef4444; border-radius:0 6px 6px 0; margin-bottom:6px;">
                    <strong style="color:#fca5a5;">⚔️ Dodatkowy Atak (${attackCount} ataki na turę)</strong>
                    <div style="color:var(--text-muted); font-size:0.85rem; margin-top:3px;">Gdy podejmujesz akcję Ataku, możesz zaatakować ${attackCount} razy.</div>
                </div>`;
        }

        if (!featuresHtml) featuresHtml = '<em style="color:var(--text-muted);">Brak nowych cech klasowych na tym poziomie.</em>';

        sections += `
            <div style="padding:15px; background:rgba(0,0,0,0.3); border-radius:10px; margin-bottom:12px; border-left:4px solid var(--gold);">
                <strong style="color:var(--text-gold); font-size:1.1rem;">📜 Nowe Cechy</strong>
                <div style="margin-top:10px;">${featuresHtml}</div>
            </div>`;

        // 5. ASI / Feat (conditional)
        if (p.isASI) {
            let featOptions = ClassData.FEATS.map(f => `<option value="${f.key}">${_esc(f.name)}</option>`).join('');
            sections += `
                <div style="padding:15px; background:rgba(0,0,0,0.3); border-radius:10px; margin-bottom:12px; border-left:4px solid #f59e0b;">
                    <strong style="color:#f59e0b; font-size:1.1rem;">🎯 Wzrost Cech (ASI) / Atut</strong>
                    <div style="display:flex; gap:10px; margin:10px 0;">
                        <label style="padding:8px 16px; background:rgba(245,158,11,0.2); border:2px solid #f59e0b; border-radius:8px; cursor:pointer; color:white; font-weight:bold;">
                            <input type="radio" name="asi_or_feat" value="asi" checked onclick="document.getElementById('asi-section').style.display='block'; document.getElementById('feat-section').style.display='none';"> Wzrost Cech (+2)
                        </label>
                        <label style="padding:8px 16px; background:rgba(139,92,246,0.2); border:2px solid #8b5cf6; border-radius:8px; cursor:pointer; color:white; font-weight:bold;">
                            <input type="radio" name="asi_or_feat" value="feat" onclick="document.getElementById('asi-section').style.display='none'; document.getElementById('feat-section').style.display='block';"> Atut (Feat)
                        </label>
                    </div>
                    <div id="asi-section">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                            <p style="color:var(--text-muted); font-size:0.9rem; margin:0;">Rozdziel 2 punkty (max +2 na cechę, max 20):</p>
                            <div id="asi-points-remaining" style="padding:4px 14px; border-radius:20px; font-weight:bold; font-size:1rem; background:rgba(16,185,129,0.2); border:2px solid #10b981; color:#10b981;">Pozostało: 2</div>
                        </div>
                        <div style="display:grid; grid-template-columns:repeat(6,1fr); gap:10px;">
                            ${APIClient.ABILITY_NAMES.map(ab => {
                                const lw = ab.toLowerCase();
                                const cur = char.abilityScores[lw];
                                return `<div style="text-align:center; background:rgba(0,0,0,0.3); padding:10px 5px; border-radius:8px; border:1px solid var(--border-color);">
                                    <div style="color:var(--text-gold); font-size:0.85rem; font-weight:bold;">${ab}</div>
                                    <div style="color:white; font-size:1.3rem; font-weight:bold; margin:4px 0;">${cur}</div>
                                    <div id="asi_preview_${lw}" style="color:#10b981; font-size:0.85rem; font-weight:bold; min-height:18px;"></div>
                                    <input type="hidden" id="asi_${lw}" value="0">
                                    <div style="display:flex; align-items:center; justify-content:center; gap:4px; margin-top:4px;">
                                        <button type="button" onclick="CharactersModule._asiAdjust('${lw}', -1)" style="width:30px; height:30px; border-radius:50%; border:2px solid #ef4444; background:rgba(239,68,68,0.2); color:#ef4444; font-weight:bold; font-size:1.1rem; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.2s;" onmouseover="this.style.background='rgba(239,68,68,0.4)'" onmouseout="this.style.background='rgba(239,68,68,0.2)'">−</button>
                                        <span id="asi_val_${lw}" style="font-size:1.2rem; font-weight:bold; color:#f59e0b; min-width:20px; text-align:center;">0</span>
                                        <button type="button" onclick="CharactersModule._asiAdjust('${lw}', 1)" style="width:30px; height:30px; border-radius:50%; border:2px solid #10b981; background:rgba(16,185,129,0.2); color:#10b981; font-weight:bold; font-size:1.1rem; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.2s;" onmouseover="this.style.background='rgba(16,185,129,0.4)'" onmouseout="this.style.background='rgba(16,185,129,0.2)'">+</button>
                                    </div>
                                </div>`;
                            }).join('')}
                        </div>
                    </div>
                    <div id="feat-section" style="display:none;">
                        <select id="feat_choice" style="width:100%; padding:8px; background:rgba(0,0,0,0.4); color:white; border:1px solid var(--border-color); border-radius:6px; margin-bottom:8px;" onchange="CharactersModule._showFeatDesc(this.value)">
                            <option value="">— Wybierz atut —</option>
                            ${featOptions}
                        </select>
                        <div id="feat-desc" style="padding:10px; background:rgba(139,92,246,0.1); border:1px solid #8b5cf6; border-radius:6px; color:var(--text-primary); font-size:0.9rem; min-height:40px;">
                            <em style="color:var(--text-muted);">Wybierz atut, aby zobaczyć opis.</em>
                        </div>
                    </div>
                </div>`;
        }

        // 6. Spell slots & spells known
        if (p.hasSpellcasting && (Object.keys(p.newSlots).length > 0 || p.cantripsDelta > 0 || p.spellsKnownDelta > 0)) {
            let spellInfo = '';
            if (p.cantripsDelta > 0) spellInfo += `<div style="color:#10b981; margin-bottom:4px;">✨ Nowe sztuczki (cantrips): +${p.cantripsDelta}</div>`;
            if (p.spellsKnownDelta > 0) spellInfo += `<div style="color:#60a5fa; margin-bottom:4px;">📖 Nowe zaklęcia znane: +${p.spellsKnownDelta}</div>`;
            if (Object.keys(p.newSlots).length > 0) {
                spellInfo += '<div style="margin-top:8px;"><strong style="color:var(--text-gold);">Sloty Zaklęć:</strong></div>';
                for (const [lvl, s] of Object.entries(p.newSlots)) {
                    const oldTotal = char.spellSlots?.[lvl]?.total || 0;
                    const changed = s.total !== oldTotal;
                    spellInfo += `<div style="color:${changed ? '#10b981' : 'var(--text-primary)'}; margin-left:10px;">Poziom ${lvl}: ${oldTotal} → ${s.total} slotów ${changed ? '⬆️' : ''}</div>`;
                }
            }
            sections += `
                <div style="padding:15px; background:rgba(0,0,0,0.3); border-radius:10px; margin-bottom:12px; border-left:4px solid #3b82f6;">
                    <strong style="color:#3b82f6; font-size:1.1rem;">🔮 Zaklęcia</strong>
                    <div style="margin-top:8px;">${spellInfo}</div>
                </div>`;
        }

        // 7. Class Resources changes
        let resourceChanges = '';
        p.newResources.forEach(nr => {
            if (nr.isPassive) {
                resourceChanges += `<div style="color:var(--text-primary); margin-bottom:4px;">${nr.icon} <strong>${_esc(nr.namePL)}:</strong> ${nr.max}${nr.suffix ? ' ' + nr.suffix : ''}</div>`;
            } else {
                const old = p.oldResources.find(r => r.key === nr.key);
                const oldMax = old ? old.max : 0;
                const changed = nr.max !== oldMax;
                if (changed || !old) {
                    resourceChanges += `<div style="color:#10b981; margin-bottom:4px;">${nr.icon} <strong>${_esc(nr.namePL)}:</strong> ${oldMax} → ${nr.max} użyć ${!old ? '(NOWE!)' : '⬆️'}</div>`;
                }
            }
        });
        if (resourceChanges) {
            sections += `
                <div style="padding:15px; background:rgba(0,0,0,0.3); border-radius:10px; margin-bottom:12px; border-left:4px solid #10b981;">
                    <strong style="color:#10b981; font-size:1.1rem;">⚡ Zasoby Klasowe</strong>
                    <div style="margin-top:8px;">${resourceChanges}</div>
                </div>`;
        }

        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-primary" onclick="CharactersModule.confirmLevelUp()" style="padding:10px 25px; font-size:1.05rem; background: linear-gradient(135deg, var(--gold), #b8860b); border:none; color:#1a1410; font-weight:bold;">
                ⬆️ Potwierdź Awans na Poziom ${p.newLevel}!
            </button>
        `;

        App.showModal(`⬆️ Level Up — ${_esc(char.name)}`, sections, footer);
    }

    function _asiAdjust(attr, delta) {
        const char = getCharacter();
        if (!char) return;
        const p = CharactersModule._pendingLevelUp;
        if (!p) return;

        const input = document.getElementById(`asi_${attr}`);
        if (!input) return;

        const curVal = parseInt(input.value) || 0;
        const newVal = curVal + delta;

        // Validation: min 0, max 2 per stat
        if (newVal < 0 || newVal > 2) return;

        // Validation: max stat 20
        const curScore = char.abilityScores[attr];
        if (curScore + newVal > 20) return;

        // Validation: total points can't exceed 2
        let totalUsed = 0;
        APIClient.ABILITY_NAMES.forEach(ab => {
            const lw = ab.toLowerCase();
            if (lw === attr) {
                totalUsed += newVal;
            } else {
                totalUsed += parseInt(document.getElementById(`asi_${lw}`)?.value) || 0;
            }
        });
        if (totalUsed > 2) return;

        // Apply
        input.value = newVal;

        // Update display
        const valDisplay = document.getElementById(`asi_val_${attr}`);
        if (valDisplay) valDisplay.textContent = newVal;

        const preview = document.getElementById(`asi_preview_${attr}`);
        if (preview) {
            preview.textContent = newVal > 0 ? `→ ${curScore + newVal}` : '';
        }

        // Update remaining counter
        const remaining = 2 - totalUsed;
        const counter = document.getElementById('asi-points-remaining');
        if (counter) {
            counter.textContent = `Pozostało: ${remaining}`;
            if (remaining === 0) {
                counter.style.background = 'rgba(245,158,11,0.2)';
                counter.style.borderColor = '#f59e0b';
                counter.style.color = '#f59e0b';
            } else {
                counter.style.background = 'rgba(16,185,129,0.2)';
                counter.style.borderColor = '#10b981';
                counter.style.color = '#10b981';
            }
        }
    }

    function _showFeatDesc(featKey) {
        const descEl = document.getElementById('feat-desc');
        if (!descEl) return;
        if (!featKey) { descEl.innerHTML = '<em style="color:var(--text-muted);">Wybierz atut, aby zobaczyć opis.</em>'; return; }
        const feat = ClassData.FEATS.find(f => f.key === featKey);
        if (!feat) return;
        descEl.innerHTML = `<strong style="color:#c4b5fd;">${_esc(feat.name)}</strong><br><span style="color:var(--text-primary);">${_esc(feat.desc)}</span>${feat.prerequisite ? `<br><em style="color:#f59e0b; font-size:0.85rem;">Wymaganie: ${_esc(feat.prerequisite)}</em>` : ''}`;
    }

    async function confirmLevelUp() {
        const char = getCharacter();
        if (!char) return;

        const p = CharactersModule._pendingLevelUp;
        if (!p) return;

        // --- HP ---
        const hpMethod = document.querySelector('input[name="hp_method"]:checked')?.value || 'avg';
        let hpGain = 0;
        if (hpMethod === 'avg') {
            hpGain = p.avgHP;
        } else if (hpMethod === 'roll') {
            const roll = { total: Math.floor(Math.random() * p.hitDie) + 1 + p.conMod };
            hpGain = Math.max(1, roll.total);
            App.showToast(`Rzut na HP: ${roll.total} (d${p.hitDie} + ${p.conMod})`, 'info');
        } else {
            hpGain = parseInt(document.getElementById('manual_hp')?.value) || p.avgHP;
        }
        hpGain = Math.max(1, hpGain);

        char.level = p.newLevel;
        char.hp.max += hpGain;
        char.hp.current += hpGain;

        // --- Hit Dice Pool ---
        if (!char.hitDicePool) char.hitDicePool = { current: 0, max: 0, die: p.hitDie };
        char.hitDicePool.max = p.newLevel;
        char.hitDicePool.current = Math.min(char.hitDicePool.current + 1, char.hitDicePool.max);
        char.hitDicePool.die = p.hitDie;

        // --- Subclass ---
        if (p.isSubclassLvl) {
            const chosenSub = document.querySelector('input[name="subclass_choice"]:checked')?.value;
            if (chosenSub) {
                char.subclass = chosenSub;
                if (!char.subclassFeatures) char.subclassFeatures = [];
                const subFeats = ClassData.getNewSubclassFeatures(p.classKey, chosenSub, p.newLevel);
                subFeats.forEach(f => char.subclassFeatures.push({ ...f, level: p.newLevel }));
                const subName = ClassData.getSubclassesForClass(p.classKey).find(s => s.key === chosenSub)?.name || chosenSub;
                App.showToast(`Wybrano podklasę: ${subName}!`, 'success');
            }
        } else if (char.subclass && p.newSubclassFeatures.length > 0) {
            if (!char.subclassFeatures) char.subclassFeatures = [];
            p.newSubclassFeatures.forEach(f => {
                if (!char.subclassFeatures.some(x => x.name === f.name)) {
                    char.subclassFeatures.push({ ...f, level: p.newLevel });
                }
            });
        }

        // --- ASI / Feat ---
        if (p.isASI) {
            const asiOrFeat = document.querySelector('input[name="asi_or_feat"]:checked')?.value || 'asi';
            if (asiOrFeat === 'asi') {
                // First, calculate total WITHOUT applying changes
                let totalASI = 0;
                const asiChanges = {};
                APIClient.ABILITY_NAMES.forEach(ab => {
                    const lw = ab.toLowerCase();
                    const val = parseInt(document.getElementById(`asi_${lw}`)?.value) || 0;
                    if (val > 0 && char.abilityScores[lw] + val <= 20) {
                        asiChanges[lw] = val;
                        totalASI += val;
                    }
                });

                // Validate before applying
                if (totalASI === 0) {
                    if (!await Ask.confirm('Nie przydzielono żadnych punktów cech. Kontynuować bez podnoszenia statystyk?', { title: 'Brak wzrostu cech', ok: 'Kontynuuj' })) {
                        // Undo level/HP changes made earlier
                        char.level = p.newLevel - 1;
                        char.hp.max -= hpGain;
                        char.hp.current -= hpGain;
                        return;
                    }
                } else if (totalASI < 2) {
                    if (!await Ask.confirm(`Przydzielono tylko ${totalASI} z 2 punktów cech. Niewykorzystane punkty przepadną.`, { title: 'Nie wszystkie punkty', ok: 'Kontynuuj' })) {
                        char.level = p.newLevel - 1;
                        char.hp.max -= hpGain;
                        char.hp.current -= hpGain;
                        return;
                    }
                }

                // Now apply the ASI changes
                for (const [attr, val] of Object.entries(asiChanges)) {
                    char.abilityScores[attr] += val;
                }
                if (totalASI > 0) App.showToast(`Atrybuty zwiększone o ${totalASI} pkt!`, 'success');
            } else {
                const featKey = document.getElementById('feat_choice')?.value;
                if (featKey) {
                    const feat = ClassData.FEATS.find(f => f.key === featKey);
                    if (feat) {
                        if (!char.feats) char.feats = [];
                        char.feats.push({ key: feat.key, name: feat.name, desc: feat.desc, level: p.newLevel });

                        // Apply feat mechanical effects
                        if (feat.effects) {
                            if (feat.effects.abilityIncrease) {
                                for (const [ab, val] of Object.entries(feat.effects.abilityIncrease)) {
                                    if (char.abilityScores[ab] + val <= 20) char.abilityScores[ab] += val;
                                }
                            }
                            if (feat.effects.hpPerLevel) {
                                char.hp.max += feat.effects.hpPerLevel * p.newLevel;
                                char.hp.current += feat.effects.hpPerLevel * p.newLevel;
                            }
                            if (feat.effects.speedBonus) {
                                char.speed = (char.speed || 30) + feat.effects.speedBonus;
                            }
                        }
                        App.showToast(`Zdobyto atut: ${feat.name}!`, 'success');
                    }
                }
            }
        }

        // --- New class features ---
        if (!char.classFeatures) char.classFeatures = [];
        p.newFeatures.forEach(f => {
            if (!char.classFeatures.some(x => x.index === f.index)) {
                char.classFeatures.push(f);
            }
        });

        // --- Extra Attack ---
        if (p.gainsExtraAttack) {
            if (!char.extraAttacks) char.extraAttacks = 1;
            else char.extraAttacks++;
        }

        // --- Spell slots ---
        if (Object.keys(p.newSlots).length > 0) {
            if (!char.spellSlots) char.spellSlots = {};
            for (const [lvl, s] of Object.entries(p.newSlots)) {
                const oldUsed = char.spellSlots[lvl]?.used || 0;
                char.spellSlots[lvl] = { used: Math.min(oldUsed, s.total), total: s.total };
            }
        }

        // --- Class Resources ---
        if (!char.classResources) char.classResources = {};
        p.newResources.forEach(r => {
            if (!r.isPassive) {
                if (!char.classResources[r.key]) {
                    char.classResources[r.key] = { current: r.max, max: r.max };
                } else {
                    char.classResources[r.key].max = r.max;
                    char.classResources[r.key].current = r.max; // Reset on level-up
                }
            }
        });

        // --- Level History ---
        if (!char.levelHistory) char.levelHistory = [];
        char.levelHistory.push({
            level: p.newLevel,
            hpGained: hpGain,
            timestamp: new Date().toISOString()
        });

        // --- XP ---
        const reqXP = ClassData.XP_THRESHOLDS[p.newLevel] || 0;
        if ((char.xp || 0) < reqXP) char.xp = reqXP;

        // Save and refresh
        saveCharacter(char);
        App.closeModal();
        App.showToast(`🎉 ${char.name} awansował na poziom ${p.newLevel}! (+${hpGain} HP)`, 'success');

        renderSheetTab(document.querySelector('.sheet-tab.active')?.dataset?.sheetTab || 'stats');
        activate();

        // Update pinned card if exists
        const pinnedEl = document.querySelector(`.pinned-character[data-char-id="${char.id}"]`);
        if (pinnedEl) renderPinnedCardContent(pinnedEl, char);
    }

    function updateCharacterField(fieldPath, value) {
        const char = getCharacter();
        if (!char) return;

        let obj = char;
        const parts = fieldPath.split('.');
        const last = parts.pop();
        for (let p of parts) {
            if (obj[p] === undefined) obj[p] = {};
            obj = obj[p];
        }
        obj[last] = value;
        saveCharacter(char);
    }

    function _rerenderStats() {
        const char = getCharacter();
        if (!char) return;
        renderSheetTab('stats');
    }

    function useResource(resourceKey, amount) {
        const char = getCharacter();
        if (!char || !char.classResources || !char.classResources[resourceKey]) return;
        
        let res = char.classResources[resourceKey];
        res.current += amount;
        if (res.current < 0) res.current = 0;
        if (res.current > res.max) res.current = res.max;
        
        saveCharacter(char);
        renderSheetTab('combat-stats');
    }

    function useHitDie() {
        const char = getCharacter();
        if (!char || !char.hitDicePool || char.hitDicePool.current <= 0) return;
        
        char.hitDicePool.current--;
        
        const conMod = APIClient.abilityModifier(char.abilityScores.con);
        // DiceRoller.roll is async and does not take a modifier — roll locally so HP never becomes NaN
        const dieRoll = Math.floor(Math.random() * char.hitDicePool.die) + 1;
        const healAmt = Math.max(1, dieRoll + conMod);
        
        char.hp.current = Math.min(char.hp.max, char.hp.current + healAmt);
        
        App.showToast(`Kość Wytrzymałości: k${char.hitDicePool.die} = ${dieRoll} ${conMod >= 0 ? '+' : '−'} ${Math.abs(conMod)} → +${healAmt} PW`, 'success');
        
        saveCharacter(char);
        renderSheetTab('combat-stats');
    }

    function regainHitDie() {
        const char = getCharacter();
        if (!char || !char.hitDicePool || char.hitDicePool.current >= char.hitDicePool.max) return;
        
        char.hitDicePool.current++;
        saveCharacter(char);
        renderSheetTab('combat-stats');
    }

    // Public API
    // dane zmienione z zewnątrz (gracz przez sieć, drugi komputer MG)
    function refreshFromStorage() {
        if (!App.getActiveCampaignId()) return;
        loadCharacters();
        const sheet = document.getElementById('character-sheet');
        if (currentCharacterId && sheet && !sheet.classList.contains('hidden')) {
            const a = document.activeElement;
            if (a && sheet.contains(a) && a.matches('input, textarea, select')) return;
            const ch = getCharacter(); if (!ch) return;
            renderHero(ch);
            renderSheetTab(document.querySelector('.sheet-tab.active')?.dataset.sheetTab || 'stats');
        } else if (App.currentTab === 'characters') {
            if (window.PartyModule) PartyModule.render(); else renderList();
        }
    }

    return {
        init,
        activate,
        refreshFromStorage,
        showAddCharacterModal,
        createCharacter,
        showCharacterSheet,
        toggleProficiency,
        toggleSavingThrow,
        quickModifyHP,
        setDeathSave,
        resetDeathSaves,
        addEmptyItem,
        updateItem,
        removeItem,
        showEquipmentPickerModal,
        confirmEquipmentPicker,
        pinCharacter,
        unpinCharacter,
        modifyPinnedHP,
        useSpellSlot,
        rollStat,
        showAddSpellToCharacterModal,
        updateSpellModalFilters,
        addSpellToCharacter,
        removeSpellFromCharacter,
        toggleSpellDescription,
        applyRaceData,
        applyClassData,
        toggleFeatureDesc,
        levelUp,
        levelUpFor,
        sheetHP,
        addXP,
        toggleInspiration,
        pickPortrait,
        clearPortrait,
        rollCheck,
        rollDamage,
        cycleSkill,
        toggleSave,
        slotPip,
        restoreSlots,
        recalcAC,
        showKitModal,
        confirmLevelUp,
        _showFeatDesc,
        _asiAdjust,
        updateCharacterField,
        _rerenderStats,
        useResource,
        useHitDie,
        regainHitDie,
        addLanguage,
        confirmAddLanguage,
        exportCharacter,
        deathSaveRoll,
        initOf,
        exportToPDF,
        sheetPrintHTML,
        heroCard,
        normalizeCharacter,
        importCharacter
    };
})();

window.CharactersModule = CharactersModule;
