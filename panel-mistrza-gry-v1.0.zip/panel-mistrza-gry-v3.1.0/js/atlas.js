/* ============================================
   D&D 5e DM Panel — Atlas kampanii
   Mapy + Lokacje: nawigacja między mapami, panel lokacji,
   drużyna i trasa podróży, tekst do odczytania graczom,
   sekrety MG, odkrywanie lokacji, tryb prezentacji.
   ============================================ */

const Atlas = (() => {
    const W = 2500, H = 1600;
    // mapy wbudowane: domyślnie tylko pergamin jako mapa świata; pakiet kampanii (assets/kampania/pakiet.js) może dodać własne
    const PAK_MAPS = (window.PANEL_PAKIET && window.PANEL_PAKIET.mapy) || {};
    const BUILTIN = { world: { name: 'Mapa świata', url: 'assets/pergamin.jpg' }, ...PAK_MAPS };
    const HAS_WORLD = !!PAK_MAPS.world;
    const DEFAULT_SUBMAP = 'assets/oak_table_texture_1789741203855.jpg';
    const TYPES = {
        capital: ['Stolica', 'fa-chess-rook', 'settle'], city: ['Miasto', 'fa-city', 'settle'], town: ['Miasteczko', 'fa-house-chimney-window', 'settle'],
        village: ['Wioska', 'fa-house', 'settle'], market: ['Rynek', 'fa-scale-balanced', 'settle'], tavern: ['Karczma', 'fa-beer-mug-empty', 'settle'],
        guild: ['Gildia', 'fa-shield-halved', 'settle'], fortress: ['Twierdza', 'fa-fort-awesome', 'war', 'fa-brands'], castle: ['Zamek', 'fa-chess-rook', 'war'],
        ruin: ['Ruiny', 'fa-monument', 'danger'], cave: ['Jaskinia', 'fa-mound', 'danger'], hideout: ['Kryjówka', 'fa-mask', 'danger'], dungeon: ['Loch', 'fa-dungeon', 'danger'],
        forest: ['Las', 'fa-tree', 'nature'], mountain: ['Góra', 'fa-mountain', 'nature'], sea: ['Morze', 'fa-water', 'nature'], wilderness: ['Dzicz', 'fa-leaf', 'nature'],
        temple: ['Świątynia', 'fa-place-of-worship', 'sacred'], plane: ['Inny wymiar', 'fa-meteor', 'sacred'], other: ['Inne', 'fa-location-dot', 'other'],
        house: ['Dom', 'fa-house', 'settle'], manor: ['Dwór / kasztel', 'fa-house-flag', 'settle'], palace: ['Pałac', 'fa-crown', 'settle'],
        tower: ['Wieża', 'fa-tower-observation', 'war'], gate: ['Brama', 'fa-archway', 'war'], barracks: ['Koszary', 'fa-shield', 'war'],
        smithy: ['Kuźnia', 'fa-hammer', 'settle'], shop: ['Sklep', 'fa-store', 'settle'], docks: ['Przystań', 'fa-anchor', 'settle'],
        mill: ['Młyn', 'fa-wind', 'settle'], farm: ['Gospodarstwo', 'fa-wheat-awn', 'nature'], well: ['Studnia', 'fa-bucket', 'settle'],
        shrine: ['Kapliczka', 'fa-hands-praying', 'sacred'], graveyard: ['Cmentarz', 'fa-cross', 'danger'], bridge: ['Most', 'fa-bridge', 'other'],
        camp: ['Obóz', 'fa-campground', 'danger'],
        region: ['Napis regionu', 'fa-font', 'region']
    };
    const CATS = { settle: 'Osady', war: 'Warownie', danger: 'Niebezpieczne', nature: 'Natura', sacred: 'Święte', other: 'Inne', region: 'Regiony' };
    const ROUTES = { road: 'Droga', path: 'Ścieżka', sea: 'Szlak morski', secret: 'Ukryte przejście' };

    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const cid = () => App.getActiveCampaignId();
    const locs = () => StorageManager.getLocations(cid()) || [];
    const saveLocs = (l) => StorageManager.saveLocations(cid(), l);
    const meta = () => StorageManager.get(`atlas_${cid()}`) || { party: null, trail: [] };
    const saveMeta = (m) => StorageManager.set(`atlas_${cid()}`, m);
    const typeOf = (l) => TYPES[l.type] ? l.type : 'other';
    const icon = (t) => `<i class="${TYPES[t][3] || 'fa-solid'} ${TYPES[t][1]}"></i>`;
    // mała tarcza herbowa — ta sama co znaczniki na mapie (spisy miejsc w panelu)
    const crest = (t) => { const E = window.MapEmblems; return E?.shield ? `<span class="ai-crest">${E.shield(t, TYPES[t][2], (E.MAJOR || []).includes(t))}</span>` : icon(t); };
    const mapOfLoc = (l) => l.mapType || 'world';
    const discovered = (l) => l.discovered !== false;
    const norm = (s) => String(s || '').trim().toLowerCase();

    const st = {
        map: 'world', zoom: 0.5, panX: 0, panY: 0, fitted: {}, mode: 'view', route: 'road', linkFrom: null,
        sel: null, present: false, lead: (() => { try { return localStorage.getItem('dnd5e_ui_lead') !== '0'; } catch { return true; } })(), minis: (() => { try { return localStorage.getItem('dnd5e_ui_minis') !== '0'; } catch { return true; } })(), partyFrom: null, dim: { w: 2500, h: 1600 },
        build: { tool: 'room', floor: 'w', wall: '#', obj: 'table', rot: 0, sel: null, brush: 1, cat: 'home' }, lvl: {}, hist: {},
        q: '', cat: 'all', disc: 'all', gzSel: null
    };
    let refresh = () => {};

    // ---------- mapy ----------
    function maps() {
        const L = locs();
        const out = [];
        const wd = worldOf(cid());
        Object.entries(BUILTIN).forEach(([id, b]) => {
            if (!(id === 'world' || L.some(l => mapOfLoc(l) === id))) return;
            if (id === 'world' && wd) out.push({ id, name: wd.name || b.name, url: wd.url || b.url, builtin: true, kind: 'world', dim: wd.w && wd.h ? { w: wd.w, h: wd.h } : null, custom: !!wd.url });
            else out.push({ id, name: b.name, url: b.url, builtin: true, kind: id === 'world' ? 'world' : 'local' });
        });
        L.filter(l => l.hasSubmap).forEach(l => out.push({ id: l.id, name: l.name, url: l.submapUrl || DEFAULT_SUBMAP, loc: l, kind: l.interior ? 'interior' : 'local' }));
        return out;
    }
    const mapById = (id) => maps().find(m => m.id === id) || maps()[0];
    // mapa, do której prowadzi lokacja (własna albo podpięta)
    function innerMap(l) {
        if (l.hasSubmap) return l.id;
        if (l.linkMap) return l.linkMap;
        const b = Object.entries(BUILTIN).find(([id, v]) => v.anchor && norm(v.anchor) === norm(l.name) && id !== mapOfLoc(l));
        return b && locs().some(x => mapOfLoc(x) === b[0]) ? b[0] : null;
    }
    function parentLoc(mapId) {
        return locs().find(l => innerMap(l) === mapId && mapOfLoc(l) !== mapId) || null;
    }
    function crumbs(mapId) {
        const out = [];
        let id = mapId, guard = 0;
        while (id && guard++ < 8) {
            out.unshift(mapById(id));
            const p = parentLoc(id);
            id = p ? mapOfLoc(p) : (id === 'world' ? null : (id !== 'world' ? 'world' : null));
            if (out.some(m => m.id === id)) break;
        }
        return out;
    }

    // ---------- ustawienia map: siatka, żetony, wnętrza ----------
    const mapMeta = (id) => (meta().maps || {})[id] || {};
    function saveMapMeta(id, fn) { const M = meta(); M.maps = M.maps || {}; M.maps[id] = M.maps[id] || {}; fn(M.maps[id]); saveMeta(M); }
    const interiorOf = (id) => MapForge.migrate(mapMeta(id).interior || null);
    function curLevelId(id, it) {
        if (!it) return null;
        let lid = st.lvl[id];
        if (!it.levels.some(L => L.id === lid)) lid = (it.levels[it.ground ?? 0] || it.levels[0]).id;
        st.lvl[id] = lid;
        return lid;
    }
    function tokSlot(id) { const m = maps().find(x => x.id === id); if (m && m.kind === 'interior') { const it = interiorOf(id); if (it) return curLevelId(id, it); } return null; }
    function gridOf(m) {
        if (!m || m.kind === 'world') return null;
        if (m.kind === 'interior') return { show: true, size: MapForge.CELL, ox: 0, oy: 0, alpha: 0.32 };
        return { show: true, size: 70, ox: 0, oy: 0, alpha: 0.35, ...(mapMeta(m.id).grid || {}) };
    }
    const tokensOf = (id) => { const mm = mapMeta(id), slot = tokSlot(id); const raw = slot ? (mm.tokensL || {})[slot] : mm.tokens; return { mode: 'party', party: null, chars: {}, others: [], ...(raw || {}) }; };
    function withTokens(id, fn) {
        const slot = tokSlot(id);
        saveMapMeta(id, mm => {
            const raw = slot ? (mm.tokensL || {})[slot] : mm.tokens;
            const t = { mode: 'party', party: null, chars: {}, others: [], ...(raw || {}) };
            t.chars = { ...(t.chars || {}) }; t.others = [...(t.others || [])];
            fn(t);
            if (slot) { mm.tokensL = mm.tokensL || {}; mm.tokensL[slot] = t; } else mm.tokens = t;
        });
    }
    const chars = () => StorageManager.getCharacters(cid()) || [];
    const KIND_ICON = { world: 'fa-earth-europe', local: 'fa-map', interior: 'fa-door-open' };

    // ---------- powiązania ----------
    const npcsAt = (l) => (StorageManager.getNPCs(cid()) || []).filter(n => norm(n.location) === norm(l.name));
    const questsAt = (l) => (StorageManager.getQuests(cid()) || []).filter(q => norm(q.location) === norm(l.name));
    const conns = (l) => (l.connections || []).map(c => typeof c === 'string' ? { id: c, style: 'path' } : { id: c.id, style: ({ solid: 'road', dashed: 'path' })[c.style] || c.style || 'road' });

    // ---------- widok mapy ----------
    window.addEventListener('panel-ping', (ev) => {
        const p = ev.detail, mapEl = document.getElementById('atl-map');
        if (mapEl && p.mapId === st.map && (!p.levelId || p.levelId === tokSlot(st.map)) && window.MapEmblems?.ping) MapEmblems.ping(mapEl, p);
        else if (p.rola !== 'mg') App.showToast(`${p.kto} wskazuje miejsce na mapie: ${(mapById(p.mapId) || {}).name || 'inna mapa'}`, 'info');
    });
    let sceneTimer = null;
    function leadScene() {
        clearTimeout(sceneTimer);
        if (!st.lead) return;   // wstrzymane: gracze zostają na ostatniej pokazanej mapie
        sceneTimer = setTimeout(() => { if (window.OnlineModule?.setScene) OnlineModule.setScene(st.map, tokSlot(st.map), true); }, 300);
    }
    function renderMap() {
        leadScene();
        if (!cid()) return '<div class="empty-state">Najpierw wybierz kampanię</div>';
        const all = locs();
        const m = mapById(st.map);
        st.map = m.id;
        const it = m.kind === 'interior' ? (interiorOf(m.id) || MapForge.blank(24, 16)) : null;
        const li = it ? Math.max(0, it.levels.findIndex(L => L.id === curLevelId(m.id, it))) : 0;
        const lv = it ? it.levels[li] : null;
        st.dim = lv ? MapForge.dims(lv) : (m.dim || { w: W, h: H });
        const hist = st.hist[m.id] || { u: [], r: [] };
        if (st.mode === 'build' && !it) st.mode = 'view';
        const grid = gridOf(m), tok = m.kind === 'world' ? null : tokensOf(m.id);
        const here = all.filter(l => mapOfLoc(l) === m.id && l.x != null && l.y != null);
        const vis = here.filter(l => !st.present || discovered(l));
        const M = meta();
        const party = all.find(l => l.id === M.party);

        // trakty
        let lines = '';
        const seen = new Set(), segs = [];
        here.forEach(a => conns(a).forEach(c => {
            const b = here.find(x => x.id === c.id);
            if (!b) return;
            const key = [a.id, b.id].sort().join('|');
            if (seen.has(key)) return; seen.add(key);
            if (st.present && (c.style === 'secret' || !discovered(a) || !discovered(b))) return;
            segs.push({ a, b, style: c.style || 'road', key });
        }));
        lines = window.MapEmblems?.routes ? MapEmblems.routes(segs)
            : segs.map(({ a, b, style }) => `<line class="atl-route r-${style}" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" vector-effect="non-scaling-stroke"/>`).join('');
        // trasa drużyny na tej mapie
        const trail = (M.trail || []).map(t => all.find(l => l.id === t.id)).filter(l => l && mapOfLoc(l) === m.id && l.x != null);
        let trailSvg = '';
        if (trail.length > 1) trailSvg = `<polyline class="atl-trail" points="${trail.map(l => `${l.x},${l.y}`).join(' ')}" vector-effect="non-scaling-stroke"/>`;

        const pins = vis.filter(l => typeOf(l) !== 'region').sort((a, b) => a.y - b.y).map(l => {
            const t = typeOf(l), sub = innerMap(l);
            const badges = `${sub ? '<span class="atl-pin-sub mp-badge" title="Ma własną mapę"><svg viewBox="0 0 16 16"><path d="M2 4l4-2 4 2 4-2v10l-4 2-4-2-4 2zM6 2v10M10 4v10"/></svg></span>' : ''}${discovered(l) ? '' : '<span class="atl-pin-hidden mp-badge" title="Gracze jeszcze nie znają">?</span>'}`;
            if (window.MapEmblems) return MapEmblems.pin({ ...l, type: t }, {
                cls: `${discovered(l) ? '' : 'undisc'} ${st.sel === l.id ? 'sel' : ''} ${st.linkFrom === l.id ? 'linking' : ''} ${M.party === l.id ? 'here' : ''}`,
                attr: `data-id="${esc(l.id)}"`, label: esc(l.name), name: esc(l.name), badges, mini: st.minis
            });
            return `<button class="atl-pin cat-${TYPES[t][2]} ${discovered(l) ? '' : 'undisc'} ${st.sel === l.id ? 'sel' : ''} ${['capital', 'city'].includes(t) ? 'major' : ''}" data-id="${esc(l.id)}" style="left:${l.x}%;top:${l.y}%" aria-label="${esc(l.name)}"><span class="atl-pin-dot">${icon(t)}</span>${badges}<span class="atl-pin-label">${esc(l.name)}</span></button>`;
        }).join('');
        const regions = vis.filter(l => typeOf(l) === 'region').map(l =>
            `<div class="atl-region ${st.mode === 'edit' ? 'editable' : ''}" data-id="${esc(l.id)}" style="left:${l.x}%;top:${l.y}%;--rot:${l.rotation || 0}deg">${esc(l.name)}</div>`).join('');
        const token = party && mapOfLoc(party) === m.id && party.x != null
            ? `<div class="atl-party ${window.MapEmblems ? 'mp-party' : ''}" id="atl-party" style="left:${party.x}%;top:${party.y}%" title="Drużyna jest tutaj">${window.MapEmblems ? MapEmblems.banner : '<i class="fa-solid fa-flag"></i>'}</div>` : '';

        const cr = crumbs(m.id);
        const mapOpts = maps().map(x => `<option value="${esc(x.id)}" ${x.id === m.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('');
        const allNames = all.filter(l => typeOf(l) !== 'region').map(l => `<option value="${esc(l.name)}">`).join('');

        return `
        <div class="atl ${st.present ? 'present' : ''} ${st.placing ? 'placing' : ''} mode-${st.mode} kind-${m.kind}">
            <div class="atl-bar">
                <nav class="atl-crumbs" aria-label="Mapy">${cr.map((c, i) => `${i ? '<i class="fa-solid fa-chevron-right"></i>' : ''}<button data-map="${esc(c.id)}" class="${c.id === m.id ? 'on' : ''}"><i class="fa-solid ${KIND_ICON[c.kind] || 'fa-map'}"></i> ${esc(c.name)}</button>`).join('')}</nav>
                <select class="atl-mapsel" aria-label="Wybierz mapę">${mapOpts}</select>
                <div class="atl-find"><i class="fa-solid fa-magnifying-glass"></i><input list="atl-names" placeholder="Znajdź miejsce…" aria-label="Znajdź lokację"><datalist id="atl-names">${allNames}</datalist></div>
                <div class="atl-modes" role="group" aria-label="Tryb">
                    <button data-mode="view" class="${st.mode === 'view' ? 'on' : ''}" title="Przeglądaj i wybieraj miejsca"><i class="fa-solid fa-hand-pointer"></i> Podgląd</button>
                    <button data-mode="edit" class="${st.mode === 'edit' ? 'on' : ''}" title="Przesuwaj znaczniki, dwuklik dodaje miejsce"><i class="fa-solid fa-pen-ruler"></i> Edycja</button>
                    <button data-mode="link" class="${st.mode === 'link' ? 'on' : ''}" title="Łącz miejsca traktami"><i class="fa-solid fa-route"></i> Trakty</button>
                    ${it ? `<button data-mode="build" class="${st.mode === 'build' ? 'on' : ''}" title="Ściany, podłogi i meble"><i class="fa-solid fa-trowel-bricks"></i> Budowa</button>` : ''}
                </div>
                ${st.mode === 'link' ? `<select class="atl-route-sel" aria-label="Rodzaj traktu">${Object.entries(ROUTES).map(([k, v]) => `<option value="${k}" ${st.route === k ? 'selected' : ''}>${v}</option>`).join('')}</select>` : ''}
                ${m.kind !== 'world' && !st.present ? `<button class="atl-btn atl-fight-btn" data-tofight title="Przenieś tę mapę ze stworzeniami i drużyną na pole walki"><i class="fa-solid fa-khanda"></i> Walka tutaj</button>` : ''}
                ${window.OnlineModule?.available?.() ? `<button class="atl-btn atl-lead-btn ${st.lead ? 'on' : ''}" data-lead title="${st.lead ? 'Gracze widzą u siebie mapę, którą masz teraz otwartą (bez sekretów). Kliknij, by zatrzymać ich na obecnej mapie, gdy przygotowujesz coś innego.' : 'Gracze zostali na ostatniej pokazanej mapie. Kliknij, by znów widzieli Twoją mapę.'}"><i class="fa-solid ${st.lead ? 'fa-users-viewfinder' : 'fa-pause'}"></i> ${st.lead ? 'Gracze widzą tę mapę' : 'Mapa graczy wstrzymana'}</button>` : ''}
                ${window.MapEmblems?.mini ? `<button class="atl-btn atl-minis-btn ${st.minis ? 'on' : ''}" data-minis title="Pokaż/ukryj makiety 3D pod znacznikami"><i class="fa-solid fa-cubes"></i> Makiety 3D: ${st.minis ? 'wł.' : 'wył.'}</button>` : ''}
                ${m.kind === 'interior' ? `<button class="atl-btn atl-fog-btn ${mapMeta(m.id).fog ? 'on' : ''}" data-fog title="Mgła wojny: gracze widzą tylko to, co widzą ich postacie (ściany, meble i ciemność zasłaniają widok)"><i class="fa-solid fa-smog"></i> Mgła: ${mapMeta(m.id).fog ? 'wł.' : 'wył.'}</button>${mapMeta(m.id).fog ? `<button class="atl-btn ${mapMeta(m.id).fogShare !== false ? 'on' : ''}" data-fogshare title="Wspólne widzenie: każdy gracz widzi to, co widzi cała drużyna (wył. — tylko jego postać)"><i class="fa-solid fa-people-group"></i> ${mapMeta(m.id).fogShare !== false ? 'Wspólne' : 'Osobne'}</button>` : ''}` : ''}
                ${m.kind === 'world' && !st.present ? `<button class="atl-btn atl-world-btn" data-worldmap title="Podmień obraz albo nazwę mapy świata tej kampanii"><i class="fa-solid fa-earth-europe"></i> Zmień mapę świata</button>` : ''}
                <button class="atl-btn atl-present-btn" data-present title="Pełny ekran bez sekretów i nieodkrytych miejsc"><i class="fa-solid ${st.present ? 'fa-eye-slash' : 'fa-tv'}"></i> ${st.present ? 'Zakończ pokaz' : 'Pokaż graczom'}</button>
            </div>
            <div class="atl-main">
                <div class="atl-vp" id="atl-vp">
                    <div class="atl-map kind-${m.kind}" id="atl-map" style="width:${st.dim.w}px;height:${st.dim.h}px;${it ? '' : `background-image:url('${esc(m.url)}')`}">
                        ${lv ? `<div class="mf-layer">${MapForge.svg(lv, { sel: st.mode === 'build' ? st.build.sel : null, player: st.present })}</div>` : ''}
                        ${MapForge.gridHTML(grid)}
                        <svg class="atl-lines" viewBox="0 0 100 100" preserveAspectRatio="none">${lines}${trailSvg}<line id="atl-temp" class="atl-route r-${st.route}" x1="0" y1="0" x2="0" y2="0" vector-effect="non-scaling-stroke" style="display:none"/></svg>
                        ${regions}${pins}${m.kind === 'world' ? token : ''}
                        ${tok ? MapForge.tokensHTML(tok, grid, chars(), { player: st.present, lv, comps: window.Companions ? Companions.forMaps() : [] }) : ''}
                        ${st.present && lv && tok && mapMeta(m.id).fog && MapForge.vision ? (() => {
                            const cs = chars(), dv = (id) => MapForge.darkvisionOf((cs.find(c => c.id === id) || {}).race);
                            const viewers = tok.mode === 'split' ? Object.entries(tok.chars || {}).map(([id, p]) => ({ x: p.x, y: p.y, n: 1, dv: dv(id) })) : (tok.party ? [{ x: tok.party.x, y: tok.party.y, n: 1, dv: Math.max(0, ...cs.map(c => dv(c.id))) }] : []);
                            Object.entries(tok.comp || {}).forEach(([nid, p]) => { const n = window.Companions && Companions.list().find(x => x.id === nid && !x.party.charId); if (n && p) viewers.push({ x: p.x, y: p.y, n: 1, dv: MapForge.darkvisionOf(n.race, n.stats?.senses) }); });
                            const O = MapForge.sightGrid(lv, lv.cols, lv.rows, {}, { player: true });
                            const V = MapForge.vision(O, lv.cols, lv.rows, viewers, { dark: +lv.dark || 0, lights: MapForge.lightsOf(lv) });
                            return `<svg class="vt-fog atl-fog" width="${st.dim.w}" height="${st.dim.h}" viewBox="0 0 ${st.dim.w} ${st.dim.h}">${MapForge.fogSVG(V, null, lv.cols, lv.rows, MapForge.CELL)}</svg>`;
                        })() : ''}
                    </div>
                    ${it && (it.levels.length > 1 || st.mode === 'build') ? `<div class="mf-lvlbar"><i class="fa-solid fa-stairs"></i>${it.levels.map((L, i) => ({ L, i })).reverse().map(({ L, i }) => `<button data-lvlgo="${i}" class="${i === li ? 'on' : ''}">${esc(L.name)}</button>`).join('')}</div>` : ''}
                    <div class="atl-zoom">
                        <button data-zoom="in" title="Przybliż">+</button><button data-zoom="out" title="Oddal">−</button><button data-zoom="fit" title="Cała mapa"><i class="fa-solid fa-expand"></i></button>
                    </div>
                    <div class="atl-hint">${({ view: 'Kliknij miejsce, by zobaczyć szczegóły · kółko myszy przybliża · przeciągnij, by przesunąć', edit: 'Przeciągaj znaczniki · dwuklik lub prawy przycisk na mapie dodaje nowe miejsce', link: st.linkFrom ? 'Kliknij drugie miejsce, by je połączyć (ponowne połączenie usuwa trakt) · Esc anuluje' : 'Kliknij pierwsze miejsce traktu', build: 'Lewy przycisk maluje i stawia · prawy przesuwa widok · R obraca · Del usuwa' })[st.mode]}</div>
                    ${st.present ? '<div class="atl-reveal" id="atl-reveal" hidden></div>' : ''}
                </div>
                ${st.present ? '' : `<aside class="atl-insp ${st.mode === 'build' ? 'mf-pal' : ''}" id="atl-insp">${st.mode === 'build' && it ? MapForge.paletteHTML(st.build, it, li, hist.u.length, hist.r.length) : inspector(st.sel ? all.find(l => l.id === st.sel) : null, m)}</aside>`}
            </div>
        </div>`;
    }

    // ---------- panel lokacji ----------
    function inspector(l, m) {
        if (!l) {
            const all = locs(), here = all.filter(x => mapOfLoc(x) === (m?.id || st.map) && typeOf(x) !== 'region');
            const M = meta(), party = all.find(x => x.id === M.party);
            const trail = (M.trail || []).slice(-6).reverse();
            return `
            <div class="ai-head ai-map"><i class="fa-solid fa-map"></i><div><h3>${esc(m?.name || '')}</h3><p>${here.length} miejsc · ${here.filter(x => !discovered(x)).length} nieodkrytych</p></div></div>
            <div class="ai-sec"><h4><i class="fa-solid fa-flag"></i> Drużyna</h4>${party ? `<button class="ai-link" data-goto="${esc(party.id)}">${esc(party.name)}</button><small>na mapie: ${esc(mapById(mapOfLoc(party)).name)}</small>` : '<p class="ai-muted">Wybierz miejsce i kliknij „Drużyna tutaj”.</p>'}</div>
            ${trail.length ? `<div class="ai-sec"><h4><i class="fa-solid fa-shoe-prints"></i> Ostatnia trasa</h4><ol class="ai-trail">${trail.map(t => { const x = all.find(y => y.id === t.id); return x ? `<li class="cat-${TYPES[typeOf(x)][2]}">${crest(typeOf(x))}<button class="ai-link" data-goto="${esc(x.id)}">${esc(x.name)}</button><small>${new Date(t.at).toLocaleDateString(window.LOC || 'pl-PL')}</small></li>` : ''; }).join('')}</ol></div>` : ''}
            ${m && m.kind !== 'world' ? tokenPanel(m) : ''}
            ${m && m.kind === 'local' ? gridPanel(m) : ''}
            ${here.some(x => x.x == null) ? `<div class="ai-sec ai-unplaced"><h4><i class="fa-solid fa-map-pin"></i> Do postawienia na mapie</h4><p class="ai-muted">Kliknij nazwę, a potem miejsce na mapie.</p>
                <div class="ai-places">${here.filter(x => x.x == null).sort((a, b) => a.name.localeCompare(b.name, 'pl')).map(x => `<button class="ai-place cat-${TYPES[typeOf(x)][2]} ${st.placing === x.id ? 'placing' : ''}" data-placeit="${esc(x.id)}">${crest(typeOf(x))}<span>${esc(x.name)}</span></button>`).join('')}</div></div>` : ''}
            <div class="ai-sec"><h4><i class="fa-solid fa-list"></i> Miejsca na tej mapie</h4>
                <div class="ai-places">${here.filter(x => x.x != null).sort((a, b) => a.name.localeCompare(b.name, 'pl')).map(x => `<button class="ai-place cat-${TYPES[typeOf(x)][2]} ${discovered(x) ? '' : 'undisc'}" data-goto="${esc(x.id)}">${crest(typeOf(x))}<span>${esc(x.name)}</span></button>`).join('') || '<p class="ai-muted">Brak — dwuklik na mapie w trybie Edycji doda pierwsze.</p>'}</div>
            </div>
            <div class="ai-actions"><button class="btn-primary btn-small" data-add><i class="fa-solid fa-plus"></i> Nowe miejsce</button>${m && !m.builtin ? '<button class="btn-secondary btn-small" data-bg><i class="fa-solid fa-image"></i> Zmień tło mapy</button><input type="file" accept="image/*" id="atl-bg-file" hidden>' : ''}</div>`;
        }
        const t = typeOf(l), M = meta(), isHere = M.party === l.id;
        const npcs = npcsAt(l), quests = questsAt(l), sub = innerMap(l);
        const visits = (M.trail || []).filter(x => x.id === l.id);
        const cs = conns(l).map(c => ({ c, to: locs().find(x => x.id === c.id) })).filter(x => x.to);
        const disp = { friendly: 'Przyjazny', neutral: 'Neutralny', hostile: 'Wrogi' };
        return `
        <div class="ai-head ai-loc cat-${TYPES[t][2]}"${/^#[0-9a-f]{3,8}$/i.test(l.color || '') ? ` style="--cc:${l.color}"` : ''}>
            ${model(t, 'big')}
            <div><h3>${esc(l.name)}</h3><p>${TYPES[t][0]} · ${esc(mapById(mapOfLoc(l)).name)}</p></div>
            <button class="ai-close" data-close title="Zamknij">✕</button>
        </div>
        <div class="ai-flags">
            <button class="ai-flag ${discovered(l) ? 'on' : 'off'}" data-disc title="Czy gracze znają to miejsce">${discovered(l) ? '<i class="fa-solid fa-eye"></i> Odkryte' : '<i class="fa-solid fa-eye-slash"></i> Nieodkryte'}</button>
            <button class="ai-flag ${isHere ? 'party' : ''}" data-party>${isHere ? '<i class="fa-solid fa-flag"></i> Drużyna jest tutaj' : '<i class="fa-regular fa-flag"></i> Drużyna tutaj'}</button>
            ${mapById(mapOfLoc(l)).kind !== 'world' ? '<button class="ai-flag" data-tokhere title="Przestaw żeton drużyny na to miejsce"><i class="fa-solid fa-chess-pawn"></i> Żeton tutaj</button>' : ''}
            ${visits.length ? `<span class="ai-visits"><i class="fa-solid fa-shoe-prints"></i> ${visits.length}× odwiedzone</span>` : ''}
        </div>
        ${l.readAloud ? `<div class="ai-read"><div class="ai-read-head"><span><i class="fa-solid fa-book-open-reader"></i> Do przeczytania graczom</span><span class="ai-read-btns">${window.OnlineModule?.available?.() ? '<button data-sendread title="Wyślij na ekrany graczy"><i class="fa-solid fa-paper-plane"></i></button>' : ''}<button data-read title="Pokaż na pełnym ekranie"><i class="fa-solid fa-up-right-from-square"></i></button></span></div><p>${esc(l.readAloud)}</p></div>` : ''}
        ${l.description ? `<div class="ai-sec"><h4><i class="fa-solid fa-scroll"></i> Opis</h4><p class="ai-text">${esc(l.description)}</p></div>` : ''}
        ${l.secret ? `<div class="ai-sec ai-secret"><h4><i class="fa-solid fa-user-secret"></i> Sekrety Mistrza Gry</h4><p class="ai-text">${esc(l.secret)}</p></div>` : ''}
        <div class="ai-sec"><h4><i class="fa-solid fa-users"></i> Postacie${npcs.length ? ` (${npcs.length})` : ''}</h4>
            ${npcs.length ? `<ul class="ai-list ai-npcs">${npcs.map(n => `<li class="d-${esc(n.disposition || 'neutral')}"><button class="ai-npc" data-npcopen="${esc(n.id)}" title="Otwórz kartę postaci"><i class="fa-solid ${n.disposition === 'hostile' ? 'fa-skull' : n.disposition === 'friendly' ? 'fa-handshake' : 'fa-user'}"></i><span><b>${esc(n.name)}</b><small>${esc(n.role || n.race || '')}${n.disposition ? ` · ${disp[n.disposition] || ''}` : ''}</small></span>${n.hasStats && n.stats ? `<em title="KP / PW">${parseInt(n.stats.ac, 10) || 10} · ${parseInt(n.stats.hp, 10) || 0}</em>` : ''}</button></li>`).join('')}</ul>` : '<p class="ai-muted">Nikt tu jeszcze nie mieszka.</p>'}
            <div class="ai-mini-actions"><button class="ai-link" data-addnpc="npc"><i class="fa-solid fa-user-plus"></i> NPC tutaj</button><button class="ai-link" data-addnpc="enemy"><i class="fa-solid fa-skull"></i> Przeciwnik tutaj</button></div>
        </div>
        ${quests.length ? `<div class="ai-sec"><h4><i class="fa-solid fa-scroll"></i> Zlecenia (${quests.length})</h4><ul class="ai-list">${quests.map(q => `<li><b>${esc(q.title)}</b><small>${esc(QuestBoardStatus(q.status))}</small></li>`).join('')}</ul></div>` : ''}
        ${cs.length ? `<div class="ai-sec"><h4><i class="fa-solid fa-route"></i> Trakty</h4><ul class="ai-list ai-conns">${cs.map(({ c, to }) => `<li><button class="ai-link" data-goto="${esc(to.id)}">${esc(to.name)}</button><small>${ROUTES[c.style] || ''}</small><button class="ai-x" data-unlink="${esc(to.id)}" title="Usuń trakt">✕</button></li>`).join('')}</ul></div>` : ''}
        <div class="ai-actions">
            ${sub && mapById(sub)?.kind !== 'world' ? `<button class="btn-secondary btn-small" data-tofight="${esc(sub)}" title="Przenieś tę lokację na pole walki"><i class="fa-solid fa-khanda"></i> Walka tutaj</button>` : ''}
            ${sub ? `<button class="btn-primary btn-small" data-enter="${esc(sub)}"><i class="fa-solid fa-door-open"></i> Wejdź na mapę</button>` : `<button class="btn-secondary btn-small" data-mkmap="image" title="Mapa z obrazka (np. miasto, las)"><i class="fa-solid fa-image"></i> Mapa z obrazu</button><button class="btn-secondary btn-small" data-mkmap="interior" title="Zbuduj wnętrze: ściany, podłogi, meble"><i class="fa-solid fa-trowel-bricks"></i> Zbuduj wnętrze</button>`}
            <button class="btn-secondary btn-small" data-edit><i class="fa-solid fa-pen"></i> Edytuj</button>
            <button class="btn-secondary btn-small" data-onmap title="Pokaż na mapie"><i class="fa-solid fa-location-crosshairs"></i></button>
            <button class="btn-danger btn-small" data-del title="Usuń"><i class="fa-solid fa-trash"></i></button>
        </div>`;
    }
    function tokenPanel(m) {
        const tok = tokensOf(m.id), cs = chars();
        const body = tok.mode === 'split'
            ? `<ul class="ai-list mf-toklist">${cs.map(c => `<li><b>${esc(c.name)}</b>${tok.chars?.[c.id] ? `<button class="ai-link" data-tokremove="${esc(c.id)}">zdejmij</button>` : `<button class="ai-link" data-tokplace="${esc(c.id)}">postaw</button>`}</li>`).join('') || '<li><small>Brak bohaterów w kampanii</small></li>'}</ul>
               <div class="ai-actions"><button class="btn-secondary btn-small" data-tokplace="all"><i class="fa-solid fa-users"></i> Postaw wszystkich</button>${Object.keys(tok.chars || {}).length ? '<button class="btn-secondary btn-small" data-tokremove="all">Zdejmij wszystkich</button>' : ''}</div>`
            : `<div class="ai-actions">${tok.party ? '<button class="btn-secondary btn-small" data-tokremove="party"><i class="fa-solid fa-xmark"></i> Zdejmij żeton drużyny</button>' : '<button class="btn-primary btn-small" data-tokplace="party"><i class="fa-solid fa-flag"></i> Postaw drużynę</button>'}</div>`;
        const others = tok.others || [];
        const creatures = `<div class="ai-sec"><h4><i class="fa-solid fa-skull"></i> NPC, wrogowie i potwory (${others.length})</h4>
            ${others.length ? `<ul class="ai-list mf-toklist">${others.map(o => `<li class="d-${esc(o.disp)}"><b>${esc(o.name)}</b>${o.max ? `<small>${o.hp}/${o.max}</small>` : ''}<button class="ai-link" data-ohide="${esc(o.id)}" title="${o.hidden ? 'Ujawnij' : 'Ukryj przed graczami'}">${o.hidden ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>'}</button><button class="ai-x" data-odel="${esc(o.id)}" title="Usuń z mapy">✕</button></li>`).join('')}</ul>` : '<p class="ai-muted">Brak — dodaj mieszkańców, strażników albo potwory z bestiariusza.</p>'}
            <div class="ai-actions"><button class="btn-primary btn-small" data-addcreature><i class="fa-solid fa-dragon"></i> Dodaj NPC / potwora</button></div></div>`;
        return creatures + `<div class="ai-sec"><h4><i class="fa-solid fa-chess-pawn"></i> Drużyna na tej mapie</h4>
            <div class="mf-seg"><button data-tokmode="party" class="${tok.mode !== 'split' ? 'on' : ''}"><i class="fa-solid fa-people-group"></i> Razem</button><button data-tokmode="split" class="${tok.mode === 'split' ? 'on' : ''}"><i class="fa-solid fa-user"></i> Osobno</button></div>
            ${body}<p class="ai-muted" style="margin-top:6px">Żetony przeciągasz po polach siatki — także w pokazie dla graczy.</p></div>`;
    }
    function gridPanel(m) {
        const g = gridOf(m);
        return `<div class="ai-sec mf-gridpanel"><h4><i class="fa-solid fa-border-all"></i> Siatka</h4>
            <label class="mf-check"><input type="checkbox" id="mf-g-show" ${g.show ? 'checked' : ''}> pokaż siatkę</label>
            <label class="mf-range"><span>Wielkość pola</span><input type="range" id="mf-g-size" min="30" max="220" value="${g.size}"><b>${g.size}</b></label>
            <label class="mf-range"><span>Przesunięcie ←→</span><input type="range" id="mf-g-ox" min="0" max="${g.size}" value="${g.ox || 0}"></label>
            <label class="mf-range"><span>Przesunięcie ↑↓</span><input type="range" id="mf-g-oy" min="0" max="${g.size}" value="${g.oy || 0}"></label>
            <label class="mf-range"><span>Widoczność</span><input type="range" id="mf-g-alpha" min="5" max="80" value="${Math.round((g.alpha ?? 0.35) * 100)}"></label></div>`;
    }

    function QuestBoardStatus(s) {
        return ({ 'Brak': 'do wzięcia', 'Przyjęte': 'w trakcie', 'Zaliczone': 'wykonane', 'Nieudane': 'nieudane', 'Odrzucone': 'odrzucone', 'Nieznane': 'nieodkryte' })[s] || 'do wzięcia';
    }

    // makieta 3D na postumencie + tarcza herbowa (jak na mapie)
    function model(t, cls = '') {
        const E = window.MapEmblems;
        if (!E || !E.shield) return `<span class="ai-medal">${E ? E.svg(t) : icon(t)}</span>`;
        return `<span class="loc-model ${cls}"><span class="loc-plinth"></span><span class="loc-mini">${E.mini(t)}</span><span class="loc-shield">${E.shield(t, TYPES[t][2], (E.MAJOR || []).includes(t))}</span></span>`;
    }

    // ---------- spis lokacji ----------
    function renderGazetteer() {
        if (!cid()) return '<div class="empty-state">Najpierw wybierz kampanię</div>';
        const all = locs().filter(l => typeOf(l) !== 'region');
        if (!all.length) return `<div class="atl-empty"><i class="fa-solid fa-map-location-dot"></i><p>Brak miejsc w tej kampanii.</p>
            <div><button class="btn-primary" data-add><i class="fa-solid fa-plus"></i> Dodaj pierwsze miejsce</button> ${window.PANEL_PAKIET?.lokacje ? '<button class="btn-secondary" onclick="CampaignsModule.loadSampleWorld()"><i class="fa-solid fa-wand-magic-sparkles"></i> Wczytaj przykładowy świat</button>' : ''}</div></div>`;
        const M = meta(), q = norm(st.q);
        const ok = (l) => (st.cat === 'all' || TYPES[typeOf(l)][2] === st.cat) && (st.disc === 'all' || (st.disc === 'yes') === discovered(l)) &&
            (!q || [l.name, l.description, l.readAloud, l.secret].some(v => norm(v).includes(q)));
        const groups = maps().map(m => ({ m, list: all.filter(l => mapOfLoc(l) === m.id && ok(l)).sort((a, b) => a.name.localeCompare(b.name, 'pl')) })).filter(g => g.list.length);
        const catCount = (c) => all.filter(l => c === 'all' || TYPES[typeOf(l)][2] === c).length;
        const card = (l) => {
            const t = typeOf(l), n = npcsAt(l).length, qs = questsAt(l).length;
            const col = /^#[0-9a-f]{3,8}$/i.test(l.color || '') ? ` style="--cc:${l.color}"` : '';
            return `<article class="gz-card cat-${TYPES[t][2]} ${discovered(l) ? '' : 'undisc'} ${st.gzSel === l.id ? 'sel' : ''}" data-pick="${esc(l.id)}" tabindex="0"${col}>
                ${model(t)}
                <div class="gz-body">
                    <h4>${esc(l.name)}</h4>
                    <div class="gz-type">${TYPES[t][0]}${innerMap(l) ? ' · <i class="fa-solid fa-map"></i> ma mapę' : ''}</div>
                    ${l.description ? `<p>${esc(l.description)}</p>` : ''}
                    <div class="gz-badges">
                        ${M.party === l.id ? '<span class="b-party"><i class="fa-solid fa-flag"></i> Drużyna</span>' : ''}
                        ${discovered(l) ? '' : '<span class="b-hidden"><i class="fa-solid fa-eye-slash"></i> Nieodkryte</span>'}
                        ${n ? `<span><i class="fa-solid fa-users"></i> ${n}</span>` : ''}${qs ? `<span><i class="fa-solid fa-scroll"></i> ${qs}</span>` : ''}
                        ${l.readAloud ? '<span title="Ma tekst dla graczy"><i class="fa-solid fa-book-open-reader"></i></span>' : ''}${l.secret ? '<span title="Ma sekrety MG"><i class="fa-solid fa-user-secret"></i></span>' : ''}
                    </div>
                </div>
            </article>`;
        };
        const sel = st.gzSel ? locs().find(l => l.id === st.gzSel) : null;
        return `
        <div class="atl-gz">
            <div class="atl-bar">
                <div class="atl-find"><i class="fa-solid fa-magnifying-glass"></i><input class="gz-search" placeholder="Szukaj w nazwach, opisach i sekretach…" value="${esc(st.q)}" aria-label="Szukaj lokacji"></div>
                <div class="gz-cats">${['all', 'settle', 'war', 'danger', 'nature', 'sacred', 'other'].map(c => `<button data-cat="${c}" class="${st.cat === c ? 'on' : ''}">${c === 'all' ? 'Wszystkie' : CATS[c]} <small>${catCount(c)}</small></button>`).join('')}</div>
                <select class="gz-disc" aria-label="Odkrycie"><option value="all" ${st.disc === 'all' ? 'selected' : ''}>Odkryte i nieodkryte</option><option value="yes" ${st.disc === 'yes' ? 'selected' : ''}>Tylko odkryte</option><option value="no" ${st.disc === 'no' ? 'selected' : ''}>Tylko nieodkryte</option></select>
            </div>
            <div class="atl-main">
                <div class="gz-list">
                    ${groups.map(g => `<section class="gz-group">
                        <header><h3><span>${esc(g.m.name)}</span> <small>${g.list.length} ${g.list.length === 1 ? 'miejsce' : g.list.length % 10 >= 2 && g.list.length % 10 <= 4 && (g.list.length % 100 < 10 || g.list.length % 100 >= 20) ? 'miejsca' : 'miejsc'}</small></h3><button class="atl-btn" data-openmap="${esc(g.m.id)}"><i class="fa-solid fa-map-location-dot"></i> Otwórz mapę</button></header>
                        <div class="gz-grid">${g.list.map(card).join('')}</div>
                    </section>`).join('') || '<p class="ai-muted">Nic nie pasuje do filtrów.</p>'}
                </div>
                <aside class="atl-insp" id="atl-insp">${sel ? inspector(sel) : `<div class="ai-empty"><span class="ai-empty-seal"><i class="fa-solid fa-map-location-dot"></i></span><h4>Księga miejsc</h4><p>Wybierz miejsce z listy, aby zobaczyć opis, mieszkańców, zlecenia i trakty.</p><p class="ai-empty-stats"><b>${all.length}</b> miejsc · <b>${all.filter(x => !discovered(x)).length}</b> nieodkrytych · <b>${(StorageManager.getNPCs(cid()) || []).filter(n => n.location).length}</b> postaci</p></div>`}</aside>
            </div>
        </div>`;
    }

    // ---------- edytor ----------
    function editor(id, preset = {}) {
        const all = locs();
        const l = id ? all.find(x => x.id === id) : null;
        const cur = l || { type: 'city', mapType: preset.mapType || st.map, discovered: true, ...preset };
        const SC = window.MapEmblems?.SCOPE || { world: Object.keys(TYPES), local: Object.keys(TYPES) };
        const kindOf = (mid) => (maps().find(m => m.id === mid) || {}).kind === 'world' ? 'world' : 'local';
        const scope0 = kindOf(mapOfLoc(cur));
        const inScope = (k, sc) => sc === 'all' || SC[sc].includes(k) || k === typeOf(cur);
        const typeGrid = Object.entries(TYPES).map(([k, v]) => `<label class="icon-picker-label ae-type" data-k="${k}" ${inScope(k, scope0) ? '' : 'hidden'}><input type="radio" name="atl-type" value="${k}" ${typeOf(cur) === k ? 'checked' : ''} class="hidden-radio"><div class="icon-picker-box cat-${v[2]}" title="${v[0]}">${window.MapEmblems && k !== 'region' ? MapEmblems.svg(k) + (MapEmblems.mini ? MapEmblems.mini(k) : '') : icon(k)}</div><small>${v[0]}</small></label>`).join('');
        const PAL = window.MapEmblems?.PALETTE || [];
        const curCol = /^#[0-9a-f]{6}$/i.test(cur.color || '') ? cur.color : '';
        const colorRow = `<div class="ae-colors">
            <label class="ae-sw auto" title="Kolor kategorii"><input type="radio" name="ae-col" value="" ${curCol ? '' : 'checked'}><span>Auto</span></label>
            ${PAL.map(c => `<label class="ae-sw" title="${c}"><input type="radio" name="ae-col" value="${c}" ${curCol.toLowerCase() === c ? 'checked' : ''}><span style="--sw:${c}"></span></label>`).join('')}
            <label class="ae-sw custom" title="Własny kolor"><input type="radio" name="ae-col" value="custom" ${curCol && !PAL.includes(curCol.toLowerCase()) ? 'checked' : ''}><input type="color" id="ae-colpick" value="${curCol || '#c9a86a'}"></label>
        </div>`;
        const mapOpts = maps().filter(m => !l || m.id !== l.id).map(m => `<option value="${esc(m.id)}" ${mapOfLoc(cur) === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('');
        const linkOpts = maps().filter(m => m.id !== mapOfLoc(cur) && (!l || m.id !== l.id)).map(m => `<option value="${esc(m.id)}" ${cur.linkMap === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('');
        const mapMode = cur.hasSubmap ? (cur.interior ? 'interior' : 'own') : cur.linkMap ? 'link' : 'none';

        App.showModal(l ? `Edytuj: ${l.name}` : 'Nowe miejsce', `
            <div class="ae">
                <div class="ae-grid">
                    <label class="ae-f"><span>Nazwa</span><input type="text" id="ae-name" value="${esc(cur.name || '')}" placeholder="np. Karczma Pod Złamanym Ostrzem"></label>
                    <label class="ae-f"><span>Na mapie</span><select id="ae-map">${mapOpts}</select></label>
                </div>
                <div class="ae-f"><span>Rodzaj znacznika
                    <span class="ae-scope" role="group" aria-label="Zestaw znaczników">
                        <button type="button" data-scope="world" class="${scope0 === 'world' ? 'on' : ''}"><i class="fa-solid fa-earth-europe"></i> Mapa świata</button>
                        <button type="button" data-scope="local" class="${scope0 === 'local' ? 'on' : ''}"><i class="fa-solid fa-house-chimney"></i> Miasto / region</button>
                        <button type="button" data-scope="all"><i class="fa-solid fa-layer-group"></i> Wszystkie</button>
                    </span></span><div class="icon-picker-grid ae-types">${typeGrid}</div></div>
                <div class="ae-f"><span><i class="fa-solid fa-palette"></i> Kolor znacznika</span>${colorRow}</div>
                <label class="ae-f"><span><i class="fa-solid fa-scroll"></i> Opis (dla Ciebie)</span><textarea id="ae-desc" rows="3" placeholder="Co to za miejsce, kto tu rządzi, co tu można znaleźć…">${esc(cur.description || '')}</textarea></label>
                <label class="ae-f"><span><i class="fa-solid fa-book-open-reader"></i> Tekst do odczytania graczom</span><textarea id="ae-read" rows="3" class="ae-parch" placeholder="Gdy wchodzicie przez bramę, uderza was zapach…">${esc(cur.readAloud || '')}</textarea></label>
                <label class="ae-f"><span><i class="fa-solid fa-user-secret"></i> Sekrety Mistrza Gry</span><textarea id="ae-secret" rows="2" placeholder="Ukryte przejście za kominkiem, karczmarz jest szpiegiem…">${esc(cur.secret || '')}</textarea></label>
                <div class="ae-grid">
                    <label class="ae-check"><input type="checkbox" id="ae-disc" ${discovered(cur) ? 'checked' : ''}> Gracze znają to miejsce (widoczne w pokazie)</label>
                    <label class="ae-f ae-rot" ${typeOf(cur) === 'region' ? '' : 'hidden'}><span>Obrót napisu (°)</span><input type="number" id="ae-rot" value="${cur.rotation || 0}" min="-90" max="90"></label>
                </div>
                <div class="ae-f"><span><i class="fa-solid fa-map"></i> Mapa tego miejsca</span>
                    <div class="ae-mapmode">
                        <label><input type="radio" name="ae-mm" value="none" ${mapMode === 'none' ? 'checked' : ''}> Brak</label>
                        <label><input type="radio" name="ae-mm" value="own" ${mapMode === 'own' ? 'checked' : ''}> Mapa z obrazu (miasto, las…)</label>
                        <label><input type="radio" name="ae-mm" value="interior" ${mapMode === 'interior' ? 'checked' : ''}> Wnętrze do zbudowania (karczma, loch…)</label>
                        ${linkOpts ? `<label><input type="radio" name="ae-mm" value="link" ${mapMode === 'link' ? 'checked' : ''}> Prowadzi do istniejącej mapy</label>` : ''}
                    </div>
                    <div class="ae-mm-own" ${mapMode === 'own' ? '' : 'hidden'}><input type="file" id="ae-file" accept="image/*"><small>${cur.submapUrl ? 'Mapa wgrana — wybierz plik, by ją podmienić.' : 'Bez pliku użyję drewnianego tła, które zmienisz później.'}</small></div>
                    <div class="ae-mm-link" ${mapMode === 'link' ? '' : 'hidden'}><select id="ae-link">${linkOpts}</select></div>
                    <div class="ae-mm-int" ${mapMode === 'interior' ? '' : 'hidden'}>${l && interiorOf(l.id) ? '<small>Wnętrze już istnieje — edytujesz je trybem „Budowa” na mapie.</small>' : `<select id="ae-int"><option value="tavern">Gotowa karczma (30×20) — do przerobienia</option><option value="16x10">Mała izba (16×10)</option><option value="24x16" selected>Budynek (24×16)</option><option value="40x26">Duża budowla / loch (40×26)</option></select>`}</div>
                </div>
            </div>`,
            `${l ? '<button class="btn-danger" id="ae-del" style="margin-right:auto"><i class="fa-solid fa-trash"></i> Usuń</button>' : ''}
             <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="ae-save"><i class="fa-solid fa-check"></i> ${l ? 'Zapisz' : 'Dodaj miejsce'}</button>`);
        document.getElementById('modal')?.classList.add('modal-wide');

        let uploaded = null;
        const modal = document.getElementById('modal-body');
        modal.querySelectorAll('input[name="ae-mm"]').forEach(r => r.addEventListener('change', () => {
            modal.querySelector('.ae-mm-own').hidden = r.value !== 'own' || !r.checked;
            modal.querySelector('.ae-mm-int').hidden = r.value !== 'interior' || !r.checked;
            const ln = modal.querySelector('.ae-mm-link'); if (ln) ln.hidden = r.value !== 'link' || !r.checked;
        }));
        modal.querySelectorAll('input[name="atl-type"]').forEach(r => r.addEventListener('change', () => { modal.querySelector('.ae-rot').hidden = r.value !== 'region'; }));
        const setScope = (sc) => {
            modal.querySelectorAll('[data-scope]').forEach(x => x.classList.toggle('on', x.dataset.scope === sc));
            const chk = modal.querySelector('input[name="atl-type"]:checked')?.value;
            modal.querySelectorAll('.ae-type').forEach(x => { x.hidden = !(sc === 'all' || SC[sc].includes(x.dataset.k) || x.dataset.k === chk); });
        };
        modal.querySelectorAll('[data-scope]').forEach(x => x.addEventListener('click', () => setScope(x.dataset.scope)));
        document.getElementById('ae-map').addEventListener('change', (e) => setScope(kindOf(e.target.value)));
        const pick = document.getElementById('ae-colpick');
        pick.addEventListener('input', () => { modal.querySelector('input[name="ae-col"][value="custom"]').checked = true; });
        document.getElementById('ae-file').addEventListener('change', (e) => compress(e.target.files[0], (url) => { uploaded = url; App.showToast('Mapa wczytana', 'success'); }));

        document.getElementById('ae-save').onclick = () => {
            const name = document.getElementById('ae-name').value.trim();
            if (!name) { App.showToast('Podaj nazwę miejsca', 'warning'); return; }
            const list = locs();
            const obj = l ? list.find(x => x.id === l.id) : { id: StorageManager.generateId(), connections: [], x: preset.x ?? 50, y: preset.y ?? 50 };
            const newMap = document.getElementById('ae-map').value;
            if (l && newMap !== mapOfLoc(l)) { obj.x = 50; obj.y = 50; }
            Object.assign(obj, {
                name, mapType: newMap,
                type: modal.querySelector('input[name="atl-type"]:checked')?.value || 'other',
                description: document.getElementById('ae-desc').value.trim(),
                readAloud: document.getElementById('ae-read').value.trim(),
                secret: document.getElementById('ae-secret').value.trim(),
                discovered: document.getElementById('ae-disc').checked,
                rotation: parseInt(document.getElementById('ae-rot').value, 10) || 0
            });
            const colV = modal.querySelector('input[name="ae-col"]:checked')?.value || '';
            const col = colV === 'custom' ? pick.value : colV;
            if (/^#[0-9a-f]{6}$/i.test(col)) obj.color = col; else delete obj.color;
            const mm = modal.querySelector('input[name="ae-mm"]:checked')?.value || 'none';
            obj.hasSubmap = mm === 'own' || mm === 'interior';
            obj.interior = mm === 'interior';
            if (mm === 'own' && uploaded) obj.submapUrl = uploaded;
            let newInterior = false;
            if (mm === 'interior' && !interiorOf(obj.id)) {
                const v = document.getElementById('ae-int')?.value || '24x16';
                const it = v === 'tavern' ? MapForge.tavern() : MapForge.blank(...v.split('x').map(Number));
                saveMapMeta(obj.id, x => { x.interior = it; });
                newInterior = true;
            }
            obj.linkMap = mm === 'link' ? document.getElementById('ae-link').value : '';
            if (!l) list.push(obj);
            saveLocs(list);
            App.closeModal();
            App.showToast(l ? 'Zapisano zmiany' : `Dodano „${name}”`, 'success');
            st.sel = obj.id; st.gzSel = obj.id;
            if (newInterior) { st.mode = 'build'; st.build.tool = 'room'; App.showToast('Buduj wnętrze: Pokój rysuje ściany i podłogę jednym przeciągnięciem', 'info'); openMap(obj.id); return; }
            refresh();
        };
        const del = document.getElementById('ae-del');
        if (del) del.onclick = () => { App.closeModal(); remove(l.id); };
        setTimeout(() => document.getElementById('ae-name')?.focus(), 80);
    }

    async function remove(id) {
        const l = locs().find(x => x.id === id);
        if (!l || !await Ask.confirm(`Trakty do tego miejsca też znikną.`, { title: `Usunąć „${l.name}”?`, ok: 'Usuń', danger: true })) return;
        const list = locs().filter(x => x.id !== id);
        list.forEach(x => { if (x.connections) x.connections = x.connections.filter(c => (typeof c === 'string' ? c : c.id) !== id); });
        saveLocs(list);
        const M = meta(); if (M.party === id) M.party = null; M.trail = (M.trail || []).filter(t => t.id !== id); saveMeta(M);
        if (st.map === id) st.map = mapOfLoc(l);
        st.sel = null; st.gzSel = null;
        App.showToast('Usunięto miejsce', 'info');
        refresh();
    }

    function compress(file, done) {
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            const img = new Image();
            img.onload = () => {
                let w = img.width, h = img.height; const k = Math.min(1, 2400 / Math.max(w, h)); w *= k; h *= k;
                const c = document.createElement('canvas'); c.width = w; c.height = h;
                c.getContext('2d').drawImage(img, 0, 0, w, h);
                done(c.toDataURL('image/jpeg', 0.72));
            };
            img.src = ev.target.result;
        };
        reader.readAsDataURL(file);
    }

    // ---------- mapa świata kampanii: domyślna, pusty pergamin albo własny obraz ----------
    const worldOf = (cId) => (cId && (StorageManager.get(`atlas_${cId}`) || {}).world) || null;
    function setWorld(cId, w) {
        const M = StorageManager.get(`atlas_${cId}`) || { party: null, trail: [] };
        if (w && (w.url || w.name)) M.world = w; else delete M.world;
        StorageManager.set(`atlas_${cId}`, M);
        const back = StorageManager.get(`atlas_${cId}`) || {};
        return !w || !w.url || (back.world && back.world.url === w.url);   // false = brak miejsca w pamięci przeglądarki
    }
    // obraz z pliku → JPEG (najdłuższy bok 2400 px); współrzędne mapy: szerokość 2500, wysokość wg proporcji obrazu
    function readWorldFile(file, done) {
        if (!file) return;
        const fr = new FileReader();
        fr.onload = (ev) => {
            const img = new Image();
            img.onload = () => {
                let w = img.width, h = img.height; const k = Math.min(1, 2400 / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k);
                const c = document.createElement('canvas'); c.width = w; c.height = h;
                c.getContext('2d').drawImage(img, 0, 0, w, h);
                done({ url: c.toDataURL('image/jpeg', 0.78), w: 2500, h: Math.max(700, Math.min(4200, Math.round(2500 * h / w))) });
            };
            img.onerror = () => App.showToast('Nie udało się wczytać tego obrazu', 'error');
            img.src = ev.target.result;
        };
        fr.readAsDataURL(file);
    }
    // pusty pergamin do rysowania własnej krainy: plamy, ramka, róża wiatrów
    function parchment(seed) {
        const w = 2400, h = 1536, c = document.createElement('canvas'); c.width = w; c.height = h;
        const g = c.getContext('2d');
        let s = (seed || Date.now()) >>> 0; const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
        g.fillStyle = '#e2cf9f'; g.fillRect(0, 0, w, h);
        for (let i = 0; i < 160; i++) {
            const x = rnd() * w, y = rnd() * h, r = 40 + rnd() * 260, dark = rnd() < 0.55;
            const gr = g.createRadialGradient(x, y, 0, x, y, r);
            gr.addColorStop(0, dark ? `rgba(150,110,55,${0.05 + rnd() * 0.07})` : `rgba(255,248,220,${0.05 + rnd() * 0.08})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
            g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
        }
        for (let i = 0; i < 9000; i++) { g.fillStyle = `rgba(90,60,25,${rnd() * 0.07})`; g.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 2, 1 + rnd() * 2); }
        for (let i = 0; i < 3; i++) { const x = rnd() * w, y = rnd() * h, r = 60 + rnd() * 120; g.strokeStyle = `rgba(120,80,35,${0.10 + rnd() * 0.08})`; g.lineWidth = 6 + rnd() * 8; g.beginPath(); g.arc(x, y, r, rnd() * 3, 3 + rnd() * 3); g.stroke(); }
        const vg = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.72);
        vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(95,55,20,.55)'); g.fillStyle = vg; g.fillRect(0, 0, w, h);
        g.strokeStyle = 'rgba(80,50,20,.75)'; g.lineWidth = 6; g.strokeRect(46, 46, w - 92, h - 92);
        g.lineWidth = 2; g.strokeRect(62, 62, w - 124, h - 124);
        g.setLineDash([3, 14]); g.strokeStyle = 'rgba(80,50,20,.18)'; g.lineWidth = 2;
        for (let x = 300; x < w - 100; x += 300) { g.beginPath(); g.moveTo(x, 70); g.lineTo(x, h - 70); g.stroke(); }
        for (let y = 256; y < h - 100; y += 256) { g.beginPath(); g.moveTo(70, y); g.lineTo(w - 70, y); g.stroke(); }
        g.setLineDash([]);
        // róża wiatrów
        const cx = w - 260, cy = h - 250, R = 150;
        g.save(); g.translate(cx, cy); g.strokeStyle = 'rgba(70,40,15,.8)'; g.lineWidth = 3;
        g.beginPath(); g.arc(0, 0, R * 0.78, 0, 6.283); g.stroke(); g.beginPath(); g.arc(0, 0, R * 0.7, 0, 6.283); g.stroke();
        for (let i = 0; i < 8; i++) {
            const big = i % 2 === 0, L = big ? R : R * 0.6, a = i * Math.PI / 4;
            g.save(); g.rotate(a);
            g.beginPath(); g.moveTo(0, -L); g.lineTo(L * 0.13, 0); g.lineTo(0, 0); g.closePath(); g.fillStyle = 'rgba(70,40,15,.85)'; g.fill();
            g.beginPath(); g.moveTo(0, -L); g.lineTo(-L * 0.13, 0); g.lineTo(0, 0); g.closePath(); g.fillStyle = 'rgba(232,214,170,.95)'; g.fill(); g.stroke();
            g.restore();
        }
        g.fillStyle = 'rgba(70,40,15,.9)'; g.font = '700 46px Cinzel, Georgia, serif'; g.textAlign = 'center'; g.fillText('N', 0, -R - 16);
        g.restore();
        return { url: c.toDataURL('image/jpeg', 0.8), w: 2500, h: 1600 };
    }
    // okno wyboru mapy świata (Atlas oraz tworzenie kampanii)
    function worldPicker({ cId = cid(), onDone } = {}) {
        if (!cId) return;
        const cur = worldOf(cId), onWorld = (StorageManager.getLocations(cId) || []).filter(l => mapOfLoc(l) === 'world' && l.x != null).length;
        const mode0 = cur?.url ? (cur.parch ? 'parch' : 'own') : 'default';
        App.showModal('Mapa świata', `
            <div class="wm-pick">
                <p class="wm-lead">Każda kampania może mieć własną krainę. Miejsca na mapie zapisują się w procentach, więc znaczniki zostają tam, gdzie były na obrazie.</p>
                <div class="form-group"><label for="wm-name">Nazwa mapy</label><input type="text" id="wm-name" maxlength="60" value="${esc(cur?.name || '')}" placeholder="Mapa świata"></div>
                <div class="wm-opts" role="radiogroup">
                    <label class="wm-opt"><input type="radio" name="wm" value="default" ${mode0 === 'default' ? 'checked' : ''}><span class="wm-th" style="background-image:url('${esc(BUILTIN.world.url)}')"></span><b>${HAS_WORLD ? 'Gotowa kraina' : 'Pergamin'}</b><small>${HAS_WORLD ? 'Mapa dołączona do panelu' : 'Domyślna mapa — gotowa do rysowania'}</small></label>
                    <label class="wm-opt"><input type="radio" name="wm" value="parch" ${mode0 === 'parch' ? 'checked' : ''}><span class="wm-th wm-th-parch"><i class="fa-regular fa-compass"></i></span><b>Pusty pergamin</b><small>Narysujesz świat znacznikami i napisami regionów</small></label>
                    <label class="wm-opt"><input type="radio" name="wm" value="own" ${mode0 === 'own' ? 'checked' : ''}><span class="wm-th" id="wm-own-th" style="${cur?.url && !cur.parch ? `background-image:url('${esc(cur.url)}')` : ''}">${cur?.url && !cur.parch ? '' : '<i class="fa-solid fa-image"></i>'}</span><b>Własny obraz</b><small>Wgraj mapę z pliku (JPG, PNG)</small></label>
                </div>
                <input type="file" id="wm-file" accept="image/*" hidden>
                ${onWorld ? `<label class="wm-clear"><input type="checkbox" id="wm-clear"> Zdejmij z mapy obecne znaczniki (${onWorld}) — zostaną w spisie miejsc i postawisz je na nowo</label>` : ''}
            </div>`, `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="wm-ok"><i class="fa-solid fa-check"></i> Zapisz mapę</button>`);
        const body = document.getElementById('modal-body');
        let own = cur?.url && !cur.parch ? { url: cur.url, w: cur.w, h: cur.h } : null;
        const file = body.querySelector('#wm-file');
        body.querySelector('input[value="own"]').addEventListener('click', () => { if (!own) file.click(); });
        body.querySelector('#wm-own-th').addEventListener('click', (e) => { e.preventDefault(); body.querySelector('input[value="own"]').checked = true; file.click(); });
        file.addEventListener('change', () => readWorldFile(file.files[0], (r) => {
            own = r; const th = body.querySelector('#wm-own-th'); th.innerHTML = ''; th.style.backgroundImage = `url('${r.url}')`;
            body.querySelector('input[value="own"]').checked = true;
        }));
        document.getElementById('wm-ok').onclick = () => {
            const mode = body.querySelector('input[name="wm"]:checked')?.value || 'default';
            const name = body.querySelector('#wm-name').value.trim();
            let w = null;
            if (mode === 'own') { if (!own) { App.showToast('Wybierz plik z mapą', 'warning'); file.click(); return; } w = { ...own, name }; }
            else if (mode === 'parch') w = cur?.parch ? { ...cur, name } : { ...parchment(), parch: true, name };
            else w = name ? { name } : null;
            if (!setWorld(cId, w)) { App.showToast('Za mało miejsca w pamięci przeglądarki — spróbuj mniejszego obrazu', 'error'); return; }
            if (body.querySelector('#wm-clear')?.checked) {
                const L = StorageManager.getLocations(cId) || [];
                L.forEach(l => { if (mapOfLoc(l) === 'world') { l.x = null; l.y = null; } });
                StorageManager.saveLocations(cId, L);
            }
            App.closeModal();
            App.showToast('Mapa świata zapisana', 'success');
            onDone?.();
        };
    }

    // ---------- akcje ----------
    function update(id, fn) { const list = locs(); const l = list.find(x => x.id === id); if (l) { fn(l, list); saveLocs(list); } return l; }

    function setParty(id) {
        const M = meta();
        if (M.party === id) return;
        st.partyFrom = M.party;
        M.party = id;
        M.trail = [...(M.trail || []), { id, at: new Date().toISOString() }].slice(-200);
        saveMeta(M);
        const l = update(id, x => { if (!discovered(x)) x.discovered = true; });
        App.showToast(`Drużyna dociera do: ${l?.name || ''}`, 'success');
    }

    function showRead(l) {
        const box = document.getElementById('atl-reveal');
        const text = l.readAloud || l.description || '';
        const html = `<div class="ar-card"><span class="ai-medal">${window.MapEmblems ? MapEmblems.svg(typeOf(l)) : icon(typeOf(l))}</span><h2>${esc(l.name)}</h2>${text ? `<p>${esc(text)}</p>` : ''}<button class="ar-close" data-closeread>Zamknij</button></div>`;
        if (box) { box.innerHTML = html; box.hidden = false; return; }
        App.showModal(l.name, `<div class="ar-modal">${text ? `<p>${esc(text)}</p>` : ''}</div>`, '<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>');
        document.getElementById('modal')?.classList.add('modal-wide');
    }

    // ---------- przesuwanie i przybliżanie ----------
    function applyView(mapEl, vp) {
        mapEl.style.transform = `translate(${st.panX}px, ${st.panY}px) scale(${st.zoom})`;
        mapEl.style.setProperty('--inv', (1 / st.zoom).toFixed(4));
        mapEl.style.setProperty('--mf', Math.max(.8, Math.min(1.4, st.zoom)).toFixed(4));
        vp.classList.toggle('labels', st.zoom >= 0.22);
    }
    function clampView(vp) {
        const vw = vp.clientWidth, vh = vp.clientHeight;
        // mapy nie da się oddalić bardziej, niż wypełnia okno (bez pustych pasów wokół)
        const minZ = Math.max(vw / st.dim.w, vh / st.dim.h);
        st.zoom = Math.max(minZ, Math.min(Math.max(2.5, minZ * 3), st.zoom));
        const mw = st.dim.w * st.zoom, mh = st.dim.h * st.zoom;
        st.panX = mw <= vw ? (vw - mw) / 2 : Math.min(0, Math.max(vw - mw, st.panX));
        st.panY = mh <= vh ? (vh - mh) / 2 : Math.min(0, Math.max(vh - mh, st.panY));
    }
    function fit(vp) { const fw = vp.clientWidth / st.dim.w, fh = vp.clientHeight / st.dim.h; st.zoom = Math.max(fw, fh); st.panX = (vp.clientWidth - st.dim.w * st.zoom) / 2; st.panY = (vp.clientHeight - st.dim.h * st.zoom) / 2; clampView(vp); }
    function zoomAt(vp, factor, cx, cy) {
        const z0 = st.zoom;
        st.zoom = z0 * factor;
        clampView(vp);
        const k = st.zoom / z0;
        st.panX = cx - (cx - st.panX) * k; st.panY = cy - (cy - st.panY) * k;
        clampView(vp);
    }
    function centerOn(vp, l, zoom) {
        if (zoom) st.zoom = zoom;
        clampView(vp);
        st.panX = vp.clientWidth / 2 - (l.x / 100) * st.dim.w * st.zoom;
        st.panY = vp.clientHeight / 2 - (l.y / 100) * st.dim.h * st.zoom;
        clampView(vp);
    }
    const toPct = (mapEl, e) => { const r = mapEl.getBoundingClientRect(); return { x: +(((e.clientX - r.left) / r.width) * 100).toFixed(2), y: +(((e.clientY - r.top) / r.height) * 100).toFixed(2) }; };

    // ---------- zdarzenia: mapa ----------
    function bindMap(container, rerender) {
        refresh = rerender;
        const root = container.querySelector('.atl');
        if (!root) return;
        const vp = root.querySelector('#atl-vp'), mapEl = root.querySelector('#atl-map');
        if (!st.fitted[st.map]) { fit(vp); st.fitted[st.map] = true; } else clampView(vp);
        if (st.pendingFocus) { const l = locs().find(x => x.id === st.pendingFocus); if (l && l.x != null) centerOn(vp, l, Math.max(st.zoom, 0.8)); st.pendingFocus = null; }
        applyView(mapEl, vp);
        requestAnimationFrame(() => mapEl.classList.add('ready'));

        // przejazd pionka drużyny
        const tok = root.querySelector('#atl-party');
        if (tok && st.partyFrom) {
            const from = locs().find(l => l.id === st.partyFrom);
            if (from && mapOfLoc(from) === st.map) {
                const to = { left: tok.style.left, top: tok.style.top };
                tok.style.transition = 'none'; tok.style.left = `${from.x}%`; tok.style.top = `${from.y}%`;
                requestAnimationFrame(() => requestAnimationFrame(() => { tok.style.transition = ''; tok.classList.add('travel'); tok.style.left = to.left; tok.style.top = to.top; }));
            } else tok.classList.add('arrive');
            st.partyFrom = null;
        }

        const goMap = (id, focus) => { st.map = id; st.sel = null; st.linkFrom = null; if (focus) st.pendingFocus = focus; rerender(); };
        root.addEventListener('click', (e) => {
            const t = e.target;
            const b = (sel) => t.closest(sel);
            if (b('[data-map]')) { goMap(b('[data-map]').dataset.map); return; }
            if (b('[data-mode]')) { st.mode = b('[data-mode]').dataset.mode; st.linkFrom = null; rerender(); return; }
            if (b('[data-present]')) { togglePresent(root); return; }
            if (b('[data-placeit]')) {
                const id = b('[data-placeit]').dataset.placeit, l = locs().find(x => x.id === id);
                st.placing = st.placing === id ? null : id;
                if (st.placing && l) App.showToast(`Kliknij na mapie, gdzie ma stać: ${l.name}`, 'info');
                rerender(); return;
            }
            if (b('[data-worldmap]')) { worldPicker({ onDone: () => { st.fitted.world = false; rerender(); } }); return; }
            if (b('[data-fog]')) { let on = false; saveMapMeta(st.map, mm => { mm.fog = !mm.fog; on = mm.fog; }); rerender(); App.showToast(on ? 'Mgła wojny włączona — gracze widzą tylko to, co widzą ich postacie' : 'Mgła wojny wyłączona', 'info'); return; }
            if (b('[data-fogshare]')) { saveMapMeta(st.map, mm => { mm.fogShare = mm.fogShare === false; }); rerender(); return; }
            if (b('[data-pingparty]')) {
                const m = mapById(st.map), mapEl2 = root.querySelector('#atl-map');
                let pt = null;
                if (m.kind === 'world') { const pl = locs().find(l => l.id === meta().party); if (pl && mapOfLoc(pl) === st.map) pt = { x: pl.x, y: pl.y }; }
                else {
                    const el = root.querySelector('.mf-token.party') || root.querySelector('.mf-token:not(.other)');
                    if (el && mapEl2) pt = { x: +(parseFloat(el.style.left) / mapEl2.offsetWidth * 100).toFixed(2), y: +(parseFloat(el.style.top) / mapEl2.offsetHeight * 100).toFixed(2) };
                }
                if (!pt) { App.showToast('Na tej mapie nie ma drużyny — dwuklik na mapie pinguje dowolne miejsce', 'info'); return; }
                OnlineModule.ping(st.map, tokSlot(st.map), pt.x, pt.y);
                return;
            }
            if (b('[data-lead]')) { st.lead = !st.lead; try { localStorage.setItem('dnd5e_ui_lead', st.lead ? '1' : '0'); } catch { } rerender(); App.showToast(st.lead ? 'Gracze znów widzą Twoją mapę' : 'Gracze zostają na obecnej mapie, dopóki nie wznowisz', 'info'); return; }
            if (b('[data-minis]')) { st.minis = !st.minis; try { localStorage.setItem('dnd5e_ui_minis', st.minis ? '1' : '0'); } catch { } rerender(); return; }
            if (b('[data-tofight]')) {
                const mid = b('[data-tofight]').dataset.tofight || st.map;
                if (window.VTTModule?.importDialog) VTTModule.importDialog({ mapId: mid, levelId: mid === st.map ? tokSlot(mid) : null });
                return;
            }
            if (b('[data-zoom]')) { const z = b('[data-zoom]').dataset.zoom; if (z === 'fit') fit(vp); else zoomAt(vp, z === 'in' ? 1.25 : 0.8, vp.clientWidth / 2, vp.clientHeight / 2); mapEl.classList.add('smooth'); applyView(mapEl, vp); setTimeout(() => mapEl.classList.remove('smooth'), 260); return; }
            if (b('[data-closeread]')) { root.querySelector('#atl-reveal').hidden = true; return; }
            if (b('[data-lvlgo]')) { const it = interiorOf(st.map); if (it) { st.lvl[st.map] = it.levels[+b('[data-lvlgo]').dataset.lvlgo].id; st.build.sel = null; st.fitted[st.map] = false; rerender(); } return; }
            insClick(e, root, vp, mapEl, goMap);
        });
        root.querySelector('.atl-mapsel')?.addEventListener('change', (e) => goMap(e.target.value));
        root.querySelector('.atl-route-sel')?.addEventListener('change', (e) => { st.route = e.target.value; });
        const find = root.querySelector('.atl-find input');
        find?.addEventListener('change', () => {
            const l = locs().find(x => norm(x.name) === norm(find.value));
            if (!l) { App.showToast('Nie znaleziono takiego miejsca', 'warning'); return; }
            st.sel = l.id;
            if (mapOfLoc(l) !== st.map) goMap(mapOfLoc(l), l.id); else { st.pendingFocus = l.id; rerender(); }
        });

        // ---- pomocnicze: piksele mapy, pola siatki ----
        const m = mapById(st.map);
        const grid = gridOf(m);
        const mapPx = (e) => { const r = mapEl.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * st.dim.w, y: (e.clientY - r.top) / r.height * st.dim.h }; };
        const cellOf = (e, g = grid) => { const q = mapPx(e); return { x: Math.floor((q.x - (g.ox || 0)) / g.size), y: Math.floor((q.y - (g.oy || 0)) / g.size) }; };
        const CG = { size: MapForge.CELL, ox: 0, oy: 0 };
        const layer = mapEl.querySelector('.mf-layer');
        const getInterior = () => JSON.parse(JSON.stringify(interiorOf(st.map) || MapForge.blank(24, 16)));
        const liNow = (it) => Math.max(0, it.levels.findIndex(L => L.id === curLevelId(st.map, it)));
        const redrawInterior = (it) => { if (layer) layer.innerHTML = MapForge.svg(it.levels[liNow(it)], { sel: st.build.sel }); };
        const H = () => (st.hist[st.map] = st.hist[st.map] || { u: [], r: [] });
        const saveInterior = (it, prevJSON) => {
            const prev = prevJSON || JSON.stringify(interiorOf(st.map));
            if (prev !== JSON.stringify(it)) { H().u.push(prev); if (H().u.length > 60) H().u.shift(); H().r = []; }
            saveMapMeta(st.map, mm => { mm.interior = it; });
        };

        // ---- pan / drag pinów / żetonów / budowa ----
        let drag = null;
        vp.addEventListener('pointerdown', (e) => {
            if (e.target.closest('.atl-zoom, .atl-reveal, .mf-pop, .mf-lvlbar')) return;
            const tokEl = e.target.closest('.mf-token');
            if (e.button === 0 && tokEl && grid) {
                drag = { kind: 'token', el: tokEl, key: tokEl.dataset.tok, x: e.clientX, y: e.clientY, moved: false, id: e.pointerId };
                return;
            }
            const ui = st.build;
            if (st.mode === 'build' && e.button === 0 && ui.tool !== 'pan' && !e.target.closest('.atl-pin')) {
                const it = getInterior(), lv = it.levels[liNow(it)], c = cellOf(e, CG);
                const before = JSON.stringify(it);
                vp.setPointerCapture(e.pointerId);
                if (ui.tool === 'object') {
                    const o = { id: MapForge.uid(), t: ui.obj, x: c.x, y: c.y, r: ui.rot || 0 };
                    const [fw, fh] = MapForge.footprint(o);
                    o.x = Math.max(0, Math.min(lv.cols - fw, c.x)); o.y = Math.max(0, Math.min(lv.rows - fh, c.y));
                    const clash = MapForge.overlaps(lv, o);
                    if (clash) { App.showToast(`Tu stoi już: ${MapForge.OBJ[clash.t]?.[0] || 'inny element'} — elementy nie mogą na siebie nachodzić`, 'warning'); return; }
                    lv.objects = [...(lv.objects || []), o];
                    // schody prowadzą na inne piętro — utwórz je, jeśli go brak
                    const sd = MapForge.meta(o.t).stairs;
                    if (sd) {
                        const i = liNow(it), j = i + sd;
                        if (j < 0 || j >= it.levels.length) {
                            const L = MapForge.level(sd > 0 ? `Piętro ${it.levels.length}` : 'Podziemia', lv.cols, lv.rows, false);
                            if (sd > 0) it.levels.splice(i + 1, 0, L); else it.levels.splice(i, 0, L);
                            App.showToast(`Schody prowadzą na nowy poziom: ${L.name}`, 'success');
                        }
                    }
                    saveInterior(it, before); redrawInterior(it);
                    pal && (pal.innerHTML = MapForge.paletteHTML(ui, it, liNow(it), H().u.length, H().r.length));
                    return;
                }
                if (ui.tool === 'prefab') {
                    const r = MapForge.stampRoom(lv, ui.prefab, c.x, c.y);
                    if (!r) { App.showToast('Za mało miejsca na tym piętrze — powiększ je w „Rozmiar piętra”.', 'warning'); return; }
                    saveInterior(it, before); redrawInterior(it);
                    pal && (pal.innerHTML = MapForge.paletteHTML(ui, it, liNow(it), H().u.length, H().r.length));
                    App.showToast(`Wstawiono: ${MapForge.ROOMS[ui.prefab][0]} (Ctrl+Z cofa)`, 'success');
                    return;
                }
                if (ui.tool === 'select') {
                    const hit = MapForge.objectAt(lv, c.x, c.y);
                    ui.sel = hit ? hit.id : null;
                    drag = hit ? { kind: 'obj', it, before, oid: hit.id, off: { x: c.x - hit.x, y: c.y - hit.y }, moved: false } : null;
                    redrawInterior(it);
                    pal && (pal.innerHTML = MapForge.paletteHTML(ui, it, liNow(it), H().u.length, H().r.length));
                    return;
                }
                ui._erase = null;   // nowe pociągnięcie gumki
                drag = { kind: 'paint', it, before, base: JSON.parse(before), from: c, last: c };
                if (ui.tool !== 'room') { MapForge.paint(lv, ui, c.x, c.y); redrawInterior(it); }
                return;
            }
            const panBtn = e.button === 0 || (st.mode === 'build' && e.button === 2);
            if (!panBtn) return;
            const pin = st.mode === 'build' ? null : e.target.closest('.atl-pin, .atl-region.editable');
            drag = { kind: 'pan', x: e.clientX, y: e.clientY, px: st.panX, py: st.panY, pin, moved: false, id: e.pointerId };
        });
        vp.addEventListener('pointermove', (e) => {
            if (st.mode === 'link' && st.linkFrom) {
                const a = locs().find(l => l.id === st.linkFrom), p = toPct(mapEl, e), tmp = root.querySelector('#atl-temp');
                if (a && tmp) { tmp.style.display = ''; tmp.setAttribute('x1', a.x); tmp.setAttribute('y1', a.y); tmp.setAttribute('x2', p.x); tmp.setAttribute('y2', p.y); }
            }
            if (!drag) return;
            if (drag.kind === 'paint') {
                const c = cellOf(e, CG);
                if (c.x === drag.last.x && c.y === drag.last.y) return;
                drag.last = c;
                if (st.build.tool === 'room') { drag.it = JSON.parse(JSON.stringify(drag.base)); MapForge.paint(drag.it.levels[liNow(drag.it)], st.build, c.x, c.y, drag.from); }
                else if (st.build.tool !== 'fill') MapForge.paint(drag.it.levels[liNow(drag.it)], st.build, c.x, c.y);
                redrawInterior(drag.it);
                return;
            }
            if (drag.kind === 'obj') {
                const c = cellOf(e, CG), lv = drag.it.levels[liNow(drag.it)], o = lv.objects.find(x => x.id === drag.oid);
                if (!o) return;
                const [fw, fh] = MapForge.footprint(o);
                const nx = Math.max(0, Math.min(lv.cols - fw, c.x - drag.off.x)), ny = Math.max(0, Math.min(lv.rows - fh, c.y - drag.off.y));
                if (nx !== o.x || ny !== o.y) {
                    // nie wjeżdżaj na inny element — zostań na ostatnim wolnym miejscu
                    if (MapForge.overlaps(lv, { ...o, x: nx, y: ny })) { if (!drag.warned) { drag.warned = true; App.showToast('Tam stoi inny element', 'warning'); } return; }
                    o.x = nx; o.y = ny; drag.moved = true; redrawInterior(drag.it);
                }
                return;
            }
            const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
            if (!drag.moved && Math.hypot(dx, dy) < 4) return;
            if (!drag.moved) { drag.moved = true; vp.setPointerCapture(drag.id); vp.classList.add('grabbing'); }
            if (drag.kind === 'token') {
                const q = mapPx(e);
                drag.el.style.left = `${q.x}px`; drag.el.style.top = `${q.y}px`; drag.el.classList.add('dragging');
                return;
            }
            if (drag.pin && st.mode === 'edit') {
                const p = toPct(mapEl, e);
                drag.pin.style.left = `${Math.max(0, Math.min(100, p.x))}%`; drag.pin.style.top = `${Math.max(0, Math.min(100, p.y))}%`;
                drag.pin.classList.add('dragging');
            } else { st.panX = drag.px + dx; st.panY = drag.py + dy; clampView(vp); applyView(mapEl, vp); }
        });
        const end = (e) => {
            if (!drag) return;
            const d = drag; drag = null; vp.classList.remove('grabbing');
            if (d.kind === 'paint') { st.build._erase = null; saveInterior(d.it, d.before); if (pal) pal.innerHTML = MapForge.paletteHTML(st.build, d.it, liNow(d.it), H().u.length, H().r.length); return; }
            if (d.kind === 'obj') { if (d.moved) saveInterior(d.it, d.before); return; }
            if (d.kind === 'token') {
                if (d.key.startsWith('f:')) { if (!d.moved) App.showToast('Towarzysz idzie za swoim bohaterem — przesuń bohatera albo zmień „Prowadzi” w Drużynie.', 'info'); rerender(); return; }
                if (!d.moved) { if (d.key.startsWith('o:')) openPop(d.key.slice(2)); return; }
                const n = +(d.el.style.getPropertyValue('--ts').replace('px', '')) / grid.size || 1;
                const q = mapPx(e);
                const c = { x: Math.max(0, Math.round((q.x - (grid.ox || 0)) / grid.size - n / 2)), y: Math.max(0, Math.round((q.y - (grid.oy || 0)) / grid.size - n / 2)) };
                withTokens(st.map, t => {
                    if (d.key === 'party') { t.party = null; t.party = MapForge.freeCell(t, c.x, c.y); }
                    else if (d.key.startsWith('n:')) { t.comp = { ...(t.comp || {}), [d.key.slice(2)]: { x: c.x, y: c.y } }; }
                    else if (d.key.startsWith('o:')) {
                        const id = d.key.slice(2), o = t.others.find(x => x.id === id); if (!o) return;
                        const rest = { ...t, others: t.others.filter(x => x.id !== id) };
                        Object.assign(o, MapForge.freeCell(rest, c.x, c.y, o.size || 1));
                    } else { delete t.chars[d.key]; t.chars[d.key] = MapForge.freeCell(t, c.x, c.y); }
                });
                rerender(); return;
            }
            if (d.moved && d.pin && st.mode === 'edit') {
                const p = toPct(mapEl, e);
                update(d.pin.dataset.id, l => { l.x = Math.max(0, Math.min(100, p.x)); l.y = Math.max(0, Math.min(100, p.y)); });
                rerender(); return;
            }
            if (d.moved) return;
            if (st.placing && !d.pin) {
                const p = toPct(mapEl, e), id = st.placing; st.placing = null;
                const l = update(id, x => { x.x = Math.max(0, Math.min(100, p.x)); x.y = Math.max(0, Math.min(100, p.y)); x.mapType = st.map; });
                if (l) App.showToast(`${l.name} stoi na mapie`, 'success');
                rerender(); return;
            }
            if (d.pin) { pinClick(d.pin.dataset.id, root, goMap); return; }
            // klik w schody na wnętrzu → inne piętro
            if (m.kind === 'interior' && st.mode !== 'build') {
                const it = interiorOf(st.map), i = liNow(it), c = cellOf(e, CG);
                const o = MapForge.objectAt(it.levels[i], c.x, c.y), sd = o && MapForge.meta(o.t).stairs;
                if (sd && it.levels[i + sd]) { st.lvl[st.map] = it.levels[i + sd].id; App.showToast(`${sd > 0 ? 'Wchodzicie na' : 'Schodzicie do'}: ${it.levels[i + sd].name}`, 'info'); st.fitted[st.map] = true; rerender(); }
            }
        };
        vp.addEventListener('pointerup', end);
        vp.addEventListener('pointercancel', () => { drag = null; vp.classList.remove('grabbing'); });

        // ---- okienko żetonu NPC / potwora ----
        function openPop(id) {
            const t = tokensOf(st.map).others.find(x => x.id === id); if (!t) return;
            root.querySelector('.mf-pop')?.remove();
            const el = mapEl.querySelector(`.mf-token[data-tok="o:${CSS.escape(id)}"]`);
            const r = el.getBoundingClientRect(), vr = vp.getBoundingClientRect();
            vp.insertAdjacentHTML('beforeend', MapForge.tokenPop(t));
            const pop = vp.querySelector('.mf-pop');
            pop.style.left = `${Math.min(vr.width - 250, Math.max(8, r.right - vr.left + 8))}px`;
            pop.style.top = `${Math.min(vr.height - pop.offsetHeight - 8, Math.max(8, r.top - vr.top - 10))}px`;
            const mod = (fn) => { withTokens(st.map, tt => { const o = tt.others.find(x => x.id === id); if (o) fn(o, tt); }); st.popOpen = id; rerender(); };
            pop.addEventListener('click', (e) => {
                const b = (s) => e.target.closest(s);
                if (b('[data-pop-close]')) { pop.remove(); return; }
                if (b('[data-pop-hp]')) { const v = Math.abs(parseInt(pop.querySelector('#mf-pop-v').value, 10) || 1), sg = +b('[data-pop-hp]').dataset.popHp; mod(o => { o.hp = Math.max(0, Math.min(o.max, (o.hp ?? o.max) + sg * v)); }); return; }
                if (b('[data-pop-disp]')) { mod(o => { o.disp = b('[data-pop-disp]').dataset.popDisp; }); return; }
                if (b('[data-pop-hide]')) { mod(o => { o.hidden = !o.hidden; }); return; }
                if (b('[data-pop-del]')) { withTokens(st.map, tt => { tt.others = tt.others.filter(x => x.id !== id); }); rerender(); return; }
                if (b('[data-pop-open]')) { if (t.kind === 'npc') App.switchTab('npcs'); else App.switchTab('bestiary'); return; }
                if (b('[data-pop-fight]')) {
                    if (!window.CombatModule?.addCombatant) { App.showToast('Moduł walki niedostępny', 'warning'); return; }
                    const init = Math.floor(Math.random() * 20) + 1 + (t.dexMod || 0);
                    CombatModule.addCombatant({ name: t.name, initiative: init, ac: t.ac || 10, hp: t.hp ?? t.max ?? 10, maxHp: t.max || 10, type: t.kind === 'npc' ? 'npc' : 'monster' });
                    App.showToast(`${t.name} dołącza do walki (inicjatywa ${init})`, 'success'); return;
                }
            });
            pop.querySelector('[data-pop-size]').addEventListener('change', (e) => mod(o => { o.size = +e.target.value; }));
        }

        if (st.popOpen) { const pid = st.popOpen; st.popOpen = null; requestAnimationFrame(() => openPop(pid)); }

        // ---- paleta budowy ----
        const pal = root.querySelector('.mf-pal');
        if (pal) {
            const ui = st.build;
            const repaint = () => { const it = getInterior(); redrawInterior(it); pal.innerHTML = MapForge.paletteHTML(ui, it, liNow(it), H().u.length, H().r.length); };
            pal.addEventListener('input', (e) => {
                if (e.target.id === 'mf-dark') {
                    const it = getInterior(); it.levels[liNow(it)].dark = +e.target.value / 100;
                    e.target.nextElementSibling.textContent = `${e.target.value}%`;
                    redrawInterior(it); pal._darkIt = it;
                }
                if (e.target.classList.contains('mf-osearch')) { ui.q = e.target.value; const pos = e.target.selectionStart; repaint(); const s2 = pal.querySelector('.mf-osearch'); s2.focus(); s2.setSelectionRange(pos, pos); }
            });
            pal.addEventListener('change', (e) => { if (e.target.id === 'mf-dark' && pal._darkIt) { saveInterior(pal._darkIt); pal._darkIt = null; } });
            pal.addEventListener('click', (e) => {
                const b = (s) => e.target.closest(s);
                if (b('[data-tool]')) { const t = b('[data-tool]').dataset.tool; if (t === 'token') { openPicker(); return; } ui.tool = t; if (t !== 'select') ui.sel = null; repaint(); return; }
                if (b('[data-brush]')) { ui.brush = +b('[data-brush]').dataset.brush; repaint(); return; }
                if (b('[data-etarget]')) { ui.etarget = b('[data-etarget]').dataset.etarget; repaint(); return; }
                if (b('[data-floor]')) { ui.floor = b('[data-floor]').dataset.floor; if (!['room', 'floor', 'fill'].includes(ui.tool)) ui.tool = 'floor'; repaint(); return; }
                if (b('[data-wall]')) { ui.wall = b('[data-wall]').dataset.wall; if (!['room', 'wall'].includes(ui.tool)) ui.tool = 'wall'; repaint(); return; }
                if (b('[data-ocat]')) { ui.cat = b('[data-ocat]').dataset.ocat; repaint(); return; }
                if (b('[data-obj]')) { ui.obj = b('[data-obj]').dataset.obj; ui.tool = 'object'; ui.sel = null; repaint(); return; }
                if (b('[data-rot]')) { ui.rot = ((ui.rot || 0) + 90) % 360; repaint(); return; }
                if (b('[data-undo]') || b('[data-redo]')) { undoRedo(b('[data-undo]') ? 'u' : 'r'); return; }
                if (b('[data-lvl]')) { const it = getInterior(); st.lvl[st.map] = it.levels[+b('[data-lvl]').dataset.lvl].id; ui.sel = null; st.fitted[st.map] = false; rerender(); return; }
                if (b('[data-lvladd]')) {
                    const it = getInterior(), i = liNow(it), cur = it.levels[i], up = b('[data-lvladd]').dataset.lvladd === 'up';
                    const L = MapForge.level(up ? `Piętro ${it.levels.length}` : 'Podziemia', cur.cols, cur.rows, false);
                    if (up) it.levels.splice(i + 1, 0, L); else it.levels.splice(i, 0, L);
                    if (!up) L.dark = 0.7;
                    saveInterior(it); st.lvl[st.map] = L.id; st.fitted[st.map] = false;
                    App.showToast(`Dodano: ${L.name} — postaw schody, by połączyć poziomy`, 'success'); rerender(); return;
                }
                if (b('[data-lvlren]')) { const it = getInterior(), L = it.levels[liNow(it)]; Ask.prompt('Nazwa piętra', L.name, { title: 'Zmień nazwę piętra', ok: 'Zapisz' }).then(n => { if (n && n.trim()) { L.name = n.trim().slice(0, 40); saveInterior(it); rerender(); } }); return; }
                if (b('[data-lvldel]')) { const it = getInterior(), i = liNow(it); if (it.levels.length < 2) { App.showToast('To jedyne piętro — nie da się go usunąć.', 'warning'); return; } const nm = it.levels[i].name; Ask.confirm('Zniknie razem ze ścianami, elementami i stworzeniami na nim. Tego nie da się cofnąć.', { title: `Usunąć piętro „${nm}”?`, ok: 'Usuń piętro', danger: true }).then(ok => { if (!ok) return; const it2 = getInterior(), j = it2.levels.findIndex(L => L.name === nm && L.id === it.levels[i].id); if (j < 0 || it2.levels.length < 2) return; it2.levels.splice(j, 1); if (it2.ground != null && it2.ground >= it2.levels.length) it2.ground = it2.levels.length - 1; else if (it2.ground != null && j < it2.ground) it2.ground--; saveInterior(it2); st.lvl[st.map] = it2.levels[Math.max(0, j - 1)].id; rerender(); App.showToast(`Usunięto piętro: ${nm}`, 'info'); }); return; }
                if (b('[data-prefab]')) { ui.prefab = b('[data-prefab]').dataset.prefab; ui.tool = 'prefab'; ui.sel = null; repaint(); App.showToast(`Kliknij na mapie, gdzie ma stanąć: ${MapForge.ROOMS[ui.prefab][0]}`, 'info'); return; }
                if (b('[data-ster]')) {
                    const it = getInterior(), lv = it.levels[liNow(it)], o = (lv.objects || []).find(x => x.id === ui.sel); if (!o) return;
                    const v = b('[data-ster]').dataset.ster; if (v) o.ter = v; else delete o.ter;
                    saveInterior(it); repaint(); return;
                }
                if (b('[data-srot]') || b('[data-sdel]') || b('[data-sdup]')) {
                    const it = getInterior(), lv = it.levels[liNow(it)], o = (lv.objects || []).find(x => x.id === ui.sel); if (!o) return;
                    if (b('[data-sdel]')) { lv.objects = lv.objects.filter(x => x !== o); ui.sel = null; }
                    else if (b('[data-sdup]')) {
                        // kopia obok oryginału — na pierwszym wolnym miejscu w pobliżu
                        const [fw, fh] = MapForge.footprint(o);
                        const tries = [[fw, 0], [0, fh], [-fw, 0], [0, -fh], [fw, fh], [-fw, -fh], [fw, -fh], [-fw, fh], [fw * 2, 0], [0, fh * 2]];
                        let c = null;
                        for (const [dx, dy] of tries) {
                            const t = { ...o, id: MapForge.uid(), x: o.x + dx, y: o.y + dy };
                            if (t.x < 0 || t.y < 0 || t.x + fw > lv.cols || t.y + fh > lv.rows || MapForge.overlaps(lv, t)) continue;
                            c = t; break;
                        }
                        if (!c) { App.showToast('Brak wolnego miejsca obok na kopię', 'warning'); return; }
                        lv.objects.push(c); ui.sel = c.id;
                    }
                    else {
                        const prev = { r: o.r, x: o.x, y: o.y };
                        o.r = ((o.r || 0) + 90) % 360; const [fw, fh] = MapForge.footprint(o); o.x = Math.min(o.x, lv.cols - fw); o.y = Math.min(o.y, lv.rows - fh);
                        const clash = MapForge.overlaps(lv, o);
                        if (clash) { Object.assign(o, prev); App.showToast(`Po obrocie wszedłby na: ${MapForge.OBJ[clash.t]?.[0] || 'inny element'}`, 'warning'); return; }
                    }
                    saveInterior(it); repaint(); return;
                }
                if (b('[data-resize]')) {
                    const it = getInterior(), lv = it.levels[liNow(it)];
                    MapForge.resize(lv, parseInt(pal.querySelector('#mf-cols').value, 10) || lv.cols, parseInt(pal.querySelector('#mf-rows').value, 10) || lv.rows);
                    saveInterior(it); st.fitted[st.map] = false; rerender(); return;
                }
                if (b('[data-clear]')) { Ask.confirm('Ściany, podłogi i wszystkie elementy z tego piętra znikną.', { title: 'Wyczyścić to piętro?', ok: 'Wyczyść', danger: true }).then(ok => { if (!ok) return; const it = getInterior(), lv = it.levels[liNow(it)]; lv.floor = '.'.repeat(lv.cols * lv.rows); lv.walls = '.'.repeat(lv.cols * lv.rows); lv.objects = []; saveInterior(it); ui.sel = null; repaint(); }); return; }
                if (b('[data-tpl]')) { Ask.confirm('Obecne wnętrze zostanie zastąpione gotową karczmą (piwnica, parter, piętro).', { title: 'Wstawić wzór karczmy?', ok: 'Zastąp' }).then(ok => { if (!ok) return; const t = MapForge.tavern(); saveInterior(t); st.lvl[st.map] = t.levels[t.ground].id; ui.sel = null; st.fitted[st.map] = false; rerender(); }); return; }
                if (b('[data-done]')) { st.mode = 'view'; ui.sel = null; rerender(); return; }
            });
        }
        function undoRedo(dir) {
            const h = H(), from = dir === 'u' ? h.u : h.r, to = dir === 'u' ? h.r : h.u;
            if (!from.length) return;
            to.push(JSON.stringify(interiorOf(st.map)));
            const prev = JSON.parse(from.pop());
            saveMapMeta(st.map, mm => { mm.interior = prev; });
            st.build.sel = null;
            rerender();
        }
        root._undo = undoRedo;

        // ---- wybór NPC / potworów ----
        root.querySelectorAll('[data-addcreature]').forEach(btn => btn.addEventListener('click', () => openPicker()));
        function openPicker() { creaturePicker((list) => {
            const r = vp.getBoundingClientRect(), mr = mapEl.getBoundingClientRect();
            const px = (r.left + r.width / 2 - mr.left) / mr.width * st.dim.w, py = (r.top + r.height / 2 - mr.top) / mr.height * st.dim.h;
            const cx = Math.max(0, Math.floor((px - grid.ox) / grid.size)), cy = Math.max(0, Math.floor((py - grid.oy) / grid.size));
            withTokens(st.map, t => list.forEach(c => { const p = MapForge.freeCell(t, cx, cy, c.size || 1); t.others.push({ ...c, id: MapForge.uid(), x: p.x, y: p.y }); }));
            App.showToast(list.length > 1 ? `Na mapie: ${list.length} × ${list[0].name.replace(/ \d+$/, '')}` : `Na mapie: ${list[0].name}`, 'success');
            rerender();
        }); }

        // ---- siatka (mapy lokalne) ----
        const gp = root.querySelector('.mf-gridpanel');
        if (gp) {
            const ov = mapEl.querySelector('.mf-grid');
            const read = () => ({ show: gp.querySelector('#mf-g-show').checked, size: +gp.querySelector('#mf-g-size').value, ox: +gp.querySelector('#mf-g-ox').value, oy: +gp.querySelector('#mf-g-oy').value, alpha: +gp.querySelector('#mf-g-alpha').value / 100 });
            gp.addEventListener('input', () => {
                const g = read();
                gp.querySelector('#mf-g-size + b').textContent = g.size;
                gp.querySelector('#mf-g-ox').max = g.size; gp.querySelector('#mf-g-oy').max = g.size;
                if (ov) { ov.style.setProperty('--gs', `${g.size}px`); ov.style.setProperty('--gx', `${g.ox}px`); ov.style.setProperty('--gy', `${g.oy}px`); ov.style.setProperty('--ga', g.alpha); ov.style.display = g.show ? '' : 'none'; }
            });
            gp.addEventListener('change', () => { const g = read(); saveMapMeta(st.map, mm => { mm.grid = g; }); rerender(); });
        }

        vp.addEventListener('wheel', (e) => {
            e.preventDefault();
            const r = vp.getBoundingClientRect();
            zoomAt(vp, e.deltaY < 0 ? 1.12 : 1 / 1.12, e.clientX - r.left, e.clientY - r.top);
            applyView(mapEl, vp);
        }, { passive: false });
        const addAt = (e) => {
            if (st.mode !== 'edit' || e.target.closest('.atl-pin, .atl-region')) return;
            e.preventDefault();
            const p = toPct(mapEl, e);
            editor(null, { x: p.x, y: p.y, mapType: st.map });
        };
        vp.addEventListener('dblclick', (e) => {
            if (st.mode === 'edit') return addAt(e);
            if (st.mode === 'build' || e.target.closest('.atl-pin, .atl-region, .mf-token, .atl-zoom')) return;
            if (!window.OnlineModule?.available?.()) return;
            e.preventDefault();
            const p = toPct(mapEl, e);
            OnlineModule.ping(st.map, tokSlot(st.map), p.x, p.y);
        });
        vp.addEventListener('contextmenu', (e) => { if (st.mode === 'edit') addAt(e); else e.preventDefault(); });
        vp.addEventListener('auxclick', (e) => e.preventDefault());

        const onKey = (e) => {
            if (!document.body.contains(root)) { document.removeEventListener('keydown', onKey); return; }
            if (st.mode === 'build' && (e.ctrlKey || e.metaKey) && !/input|textarea/i.test(e.target.tagName)) {
                if (e.key === 'z' || e.key === 'Z') { e.preventDefault(); root._undo?.(e.shiftKey ? 'r' : 'u'); return; }
                if (e.key === 'y' || e.key === 'Y') { e.preventDefault(); root._undo?.('r'); return; }
            }
            if (st.mode === 'build' && !/input|textarea|select/i.test(e.target.tagName)) {
                if (e.key === 'r' || e.key === 'R') {
                    if (st.build.sel) root.querySelector('[data-srot]')?.click(); else root.querySelector('[data-rot]')?.click();
                    e.preventDefault(); return;
                }
                if ((e.key === 'Delete' || e.key === 'Backspace') && st.build.sel) { root.querySelector('[data-sdel]')?.click(); e.preventDefault(); return; }
            }
            if (e.key === 'Escape') {
                if (st.mode === 'build' && st.build.sel) { st.build.sel = null; rerender(); return; }
                if (st.linkFrom) { st.linkFrom = null; rerender(); }
                else if (st.present) togglePresent(root, false);
                else if (st.sel) { st.sel = null; rerender(); }
            }
        };
        document.addEventListener('keydown', onKey);
        root.querySelector('#atl-bg-file')?.addEventListener('change', (e) => compress(e.target.files[0], (url) => {
            update(st.map, l => { l.submapUrl = url; }); App.showToast('Tło mapy zmienione', 'success'); rerender();
        }));
    }

    function pinClick(id, root, goMap) {
        const l = locs().find(x => x.id === id);
        if (!l) return;
        if (st.mode === 'link') {
            if (!st.linkFrom) { st.linkFrom = id; refresh(); return; }
            if (st.linkFrom === id) { st.linkFrom = null; refresh(); return; }
            const from = st.linkFrom;
            update(from, a => {
                a.connections = a.connections || [];
                const i = a.connections.findIndex(c => (typeof c === 'string' ? c : c.id) === id);
                if (i >= 0) { a.connections.splice(i, 1); App.showToast('Usunięto trakt', 'info'); }
                else { a.connections.push({ id, style: st.route }); App.showToast(`${ROUTES[st.route]}: połączono`, 'success'); }
            });
            update(id, b => { if (b.connections) b.connections = b.connections.filter(c => (typeof c === 'string' ? c : c.id) !== from); });
            st.linkFrom = id; refresh(); return;
        }
        if (st.present) { showRead(l); return; }
        st.sel = st.sel === id ? null : id;
        refresh();
    }

    function insClick(e, root, vp, mapEl, goMap) {
        const b = (s) => e.target.closest(s);
        const id = st.sel || st.gzSel;
        if (b('[data-goto]')) {
            const l = locs().find(x => x.id === b('[data-goto]').dataset.goto); if (!l) return;
            st.sel = l.id; st.gzSel = l.id;
            if (root.classList.contains('atl') && mapOfLoc(l) !== st.map) goMap(mapOfLoc(l), l.id);
            else { st.pendingFocus = l.id; refresh(); }
            return;
        }
        if (b('[data-add]')) { editor(null, { mapType: st.map }); return; }
        if (b('[data-bg]')) { root.querySelector('#atl-bg-file')?.click(); return; }
        if (b('[data-close]')) { st.sel = null; st.gzSel = null; refresh(); return; }
        if (b('[data-tokmode]')) { const mode = b('[data-tokmode]').dataset.tokmode; withTokens(st.map, t => { t.mode = mode; }); refresh(); return; }
        if (b('[data-ohide]')) { const oid = b('[data-ohide]').dataset.ohide; withTokens(st.map, t => { const o = t.others.find(x => x.id === oid); if (o) o.hidden = !o.hidden; }); refresh(); return; }
        if (b('[data-odel]')) { const oid = b('[data-odel]').dataset.odel; withTokens(st.map, t => { t.others = t.others.filter(x => x.id !== oid); }); refresh(); return; }
        if (b('[data-tokplace]') || b('[data-tokremove]')) {
            const place = b('[data-tokplace]')?.dataset.tokplace, rem = b('[data-tokremove]')?.dataset.tokremove;
            const m = mapById(st.map), g = gridOf(m);
            // środek widoku → pole siatki
            const r = vp ? vp.getBoundingClientRect() : null, mr = mapEl ? mapEl.getBoundingClientRect() : null;
            let cx = 2, cy = 2;
            if (r && mr && g) { const px = (r.left + r.width / 2 - mr.left) / mr.width * st.dim.w, py = (r.top + r.height / 2 - mr.top) / mr.height * st.dim.h; cx = Math.max(0, Math.floor((px - g.ox) / g.size)); cy = Math.max(0, Math.floor((py - g.oy) / g.size)); }
            withTokens(st.map, t => {
                if (rem === 'party') t.party = null;
                else if (rem === 'all') t.chars = {};
                else if (rem) delete t.chars[rem];
                if (place === 'party') t.party = MapForge.freeCell(t, cx, cy);
                else if (place === 'all') chars().forEach(c => { if (!t.chars[c.id]) t.chars[c.id] = MapForge.freeCell(t, cx, cy); });
                else if (place) t.chars[place] = MapForge.freeCell(t, cx, cy);
            });
            refresh(); return;
        }
        if (!id) return;
        const l = locs().find(x => x.id === id); if (!l) return;
        if (b('[data-disc]')) { update(id, x => { x.discovered = !discovered(x); }); App.showToast(discovered(locs().find(x => x.id === id)) ? `Gracze odkryli: ${l.name}` : `${l.name} ukryte przed graczami`, 'info'); refresh(); return; }
        if (b('[data-party]')) { setParty(id); refresh(); return; }
        if (b('[data-read]')) { showRead(l); return; }
        if (b('[data-sendread]')) { window.OnlineModule?.showText(l.name, l.readAloud || l.description || ''); return; }
        if (b('[data-edit]')) { editor(id); return; }
        if (b('[data-npcopen]')) { const nid = b('[data-npcopen]').dataset.npcopen; App.switchTab('npcs'); setTimeout(() => window.NPCsModule?.showDetail(nid), 60); return; }
        if (b('[data-addnpc]')) { window.NPCsModule?.openEditor(null, b('[data-addnpc]').dataset.addnpc, { preset: { location: l.name } }); return; }
        if (b('[data-del]')) { remove(id); return; }
        if (b('[data-unlink]')) { const to = b('[data-unlink]').dataset.unlink; update(id, x => { x.connections = (x.connections || []).filter(c => (typeof c === 'string' ? c : c.id) !== to); }); update(to, x => { x.connections = (x.connections || []).filter(c => (typeof c === 'string' ? c : c.id) !== id); }); refresh(); return; }
        if (b('[data-enter]')) { openMap(b('[data-enter]').dataset.enter); return; }
        if (b('[data-onmap]')) { openMap(mapOfLoc(l), l.id); return; }
        if (b('[data-tokhere]')) {
            const m = mapById(mapOfLoc(l)), g = gridOf(m); if (!g) return;
            const px = l.x / 100 * st.dim.w, py = l.y / 100 * st.dim.h;
            const c = { x: Math.max(0, Math.floor((px - g.ox) / g.size)), y: Math.max(0, Math.floor((py - g.oy) / g.size)) };
            withTokens(m.id, t => { if (t.mode === 'split') { const ids = chars().map(x => x.id); ids.forEach(k => { delete t.chars[k]; }); ids.forEach(k => { t.chars[k] = MapForge.freeCell(t, c.x, c.y); }); } else t.party = c; });
            App.showToast(`Drużyna przy: ${l.name}`, 'success'); refresh(); return;
        }
        if (b('[data-mkmap]')) {
            const kind = b('[data-mkmap]').dataset.mkmap;
            update(id, x => { x.hasSubmap = true; x.interior = kind === 'interior'; });
            if (kind === 'interior') {
                saveMapMeta(id, mm => { if (!mm.interior) mm.interior = ['tavern', 'inn'].includes(l.type) ? MapForge.tavern() : MapForge.blank(24, 16); });
                st.mode = 'build'; st.build.tool = 'room';
                App.showToast('Wnętrze utworzone — buduj ściany, podłogi i meble', 'success');
            } else App.showToast('Utworzono mapę — wgraj jej obraz przyciskiem „Zmień tło mapy”', 'success');
            openMap(id); return;
        }
    }

    function togglePresent(root, force) {
        st.present = force ?? !st.present;
        st.sel = null; st.mode = 'view'; st.linkFrom = null;
        if (st.present) {
            document.documentElement.requestFullscreen?.().catch(() => {});
            if (window.OnlineModule?.available?.()) OnlineModule.showMap(st.map, tokSlot(st.map), mapById(st.map)?.name).then(ok => { if (ok) App.showToast('Gracze widzą tę mapę na swoich ekranach', 'info'); });
        }
        else if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
        st.fitted[st.map] = false;
        refresh();
    }
    document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && st.present) { st.present = false; st.fitted[st.map] = false; refresh(); } });

    // ---------- wybór NPC / potworów z bestiariusza ----------
    let monsterCache = null;
    async function creaturePicker(done) {
        const npcs = StorageManager.getNPCs(cid()) || [];
        const custom = StorageManager.getCustomMonsters?.() || [];
        const tab = { v: 'monster' };
        App.showModal('Dodaj na mapę', `
            <div class="cp">
                <div class="mf-seg cp-tabs"><button data-cpt="monster" class="on"><i class="fa-solid fa-dragon"></i> Bestiariusz</button><button data-cpt="npc"><i class="fa-solid fa-users"></i> NPC</button><button data-cpt="custom"><i class="fa-solid fa-pen"></i> Własny wróg</button></div>
                <div class="cp-tools"><input class="cp-q" placeholder="Szukaj…"><label>Ile <input type="number" class="cp-n" min="1" max="12" value="1"></label>
                    <label class="mf-check"><input type="checkbox" class="cp-hid"> ukryci przed graczami</label></div>
                <div class="cp-list"><p class="ai-muted">Wczytywanie bestiariusza…</p></div>
                <div class="cp-custom" hidden>
                    <div class="ae-grid"><label class="ae-f"><span>Nazwa</span><input id="cp-name" placeholder="np. Strażnik bramy"></label><label class="ae-f"><span>PW</span><input id="cp-hp" type="number" value="11" min="1"></label></div>
                    <div class="ae-grid"><label class="ae-f"><span>KP</span><input id="cp-ac" type="number" value="12"></label><label class="ae-f"><span>Rozmiar</span><select id="cp-size"><option value="1">Średni</option><option value="2">Duży</option><option value="3">Wielki</option><option value="4">Gigantyczny</option></select></label></div>
                    <div class="mf-seg cp-disp">${Object.entries(MapForge.DISP).map(([k, v]) => `<button data-cpd="${k}" class="${k === 'hostile' ? 'on' : ''}">${v[0]}</button>`).join('')}</div>
                    <button class="btn-primary" id="cp-add-custom"><i class="fa-solid fa-plus"></i> Postaw na mapie</button>
                </div>
            </div>`, '<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>');
        document.getElementById('modal')?.classList.add('modal-wide');
        const body = document.getElementById('modal-body');
        const listEl = body.querySelector('.cp-list'), q = body.querySelector('.cp-q'), n = body.querySelector('.cp-n'), hid = body.querySelector('.cp-hid');
        let disp = 'hostile';
        const make = (base) => {
            const k = Math.max(1, Math.min(12, parseInt(n.value, 10) || 1));
            return Array.from({ length: k }, (_, i) => ({ ...base, name: k > 1 ? `${base.name} ${i + 1}` : base.name, hidden: hid.checked }));
        };
        const draw = () => {
            const t = norm(q.value);
            let rows = '';
            if (tab.v === 'npc') {
                rows = npcs.filter(x => !t || norm(x.name).includes(t) || norm(x.role).includes(t)).map(x => `<button class="cp-row d-${esc(x.disposition || 'neutral')}" data-npc="${esc(x.id)}"><b>${esc(x.name)}</b><small>${esc([x.race, x.role].filter(Boolean).join(' · '))}</small><span>${x.stats?.hp ? `${x.stats.hp} PW` : ''}</span></button>`).join('') || '<p class="ai-muted">Brak NPC w tej kampanii.</p>';
            } else if (tab.v === 'monster') {
                const all = [...custom.map(c => ({ ...c, _custom: true })), ...(monsterCache || [])];
                rows = all.filter(x => !t || norm(x.name).includes(t)).slice(0, 80).map(x => `<button class="cp-row d-hostile" data-mon="${esc(x.index || x.id || x.name)}"><b>${esc(x.name)}</b><small>${esc([x.size, x.type, x.challenge_rating != null ? `CR ${x.challenge_rating}` : (x.cr ? `CR ${x.cr}` : '')].filter(Boolean).join(' · '))}${x._custom ? ' · własny' : ''}</small><span>${x.hit_points || x.hp || ''} PW</span></button>`).join('') || (monsterCache ? '<p class="ai-muted">Nic nie znaleziono.</p>' : '<p class="ai-muted">Wczytywanie…</p>');
            }
            listEl.innerHTML = rows;
        };
        if (!monsterCache) { try { monsterCache = (await APIClient.getMonsterList()) || []; } catch (e) { monsterCache = []; } }
        draw();
        q.addEventListener('input', draw);
        body.querySelector('.cp-tabs').addEventListener('click', (e) => {
            const b = e.target.closest('[data-cpt]'); if (!b) return;
            tab.v = b.dataset.cpt;
            body.querySelectorAll('[data-cpt]').forEach(x => x.classList.toggle('on', x === b));
            body.querySelector('.cp-custom').hidden = tab.v !== 'custom';
            listEl.hidden = tab.v === 'custom';
            draw();
        });
        body.querySelector('.cp-disp').addEventListener('click', (e) => { const b = e.target.closest('[data-cpd]'); if (!b) return; disp = b.dataset.cpd; body.querySelectorAll('[data-cpd]').forEach(x => x.classList.toggle('on', x === b)); });
        const acOf = (m) => Array.isArray(m.armor_class) ? (m.armor_class[0]?.value ?? 10) : (m.armor_class ?? m.ac ?? 10);
        listEl.addEventListener('click', (e) => {
            const npcB = e.target.closest('[data-npc]'), monB = e.target.closest('[data-mon]');
            if (npcB) {
                const x = npcs.find(y => y.id === npcB.dataset.npc); if (!x) return;
                const hp = x.stats?.hp || 0;
                const td = window.NPCsModule?.tokenData?.(x.id);
                done(make(td || { kind: 'npc', ref: x.id, name: x.name, disp: x.disposition || 'neutral', hp, max: hp, ac: x.stats?.ac || 10, size: 1 }));
                App.closeModal(); return;
            }
            if (monB) {
                const key = monB.dataset.mon;
                const x = [...custom, ...(monsterCache || [])].find(y => (y.index || y.id || y.name) === key); if (!x) return;
                const hp = x.hit_points || x.hp || 10;
                done(make({ kind: 'monster', ref: key, name: x.name, disp: 'hostile', hp, max: hp, ac: acOf(x), size: MapForge.SIZE[x.size] || 1, dexMod: Math.floor(((x.dexterity || 10) - 10) / 2) }));
                App.closeModal();
            }
        });
        body.querySelector('#cp-add-custom').addEventListener('click', () => {
            const name = body.querySelector('#cp-name').value.trim() || 'Przeciwnik';
            const hp = parseInt(body.querySelector('#cp-hp').value, 10) || 10;
            done(make({ kind: 'custom', name, disp, hp, max: hp, ac: parseInt(body.querySelector('#cp-ac').value, 10) || 10, size: +body.querySelector('#cp-size').value || 1 }));
            App.closeModal();
        });
    }

    // otwiera zakładkę Mapy (z opcjonalnym skupieniem na miejscu)
    function openMap(mapId, focusId) {
        st.map = mapId || st.map; st.sel = focusId || null;
        if (focusId) st.pendingFocus = focusId;
        if (window.CampaignsModule?.getSubtab?.() === 'maps') refresh();
        else App.switchTab ? App.switchTab('campaign', 'maps') : CampaignsModule.openSubtab('maps');
    }

    // ---------- zdarzenia: spis ----------
    function bindGazetteer(container, rerender) {
        refresh = rerender;
        const root = container.querySelector('.atl-gz') || container.querySelector('.atl-empty');
        if (!root) return;
        root.addEventListener('click', (e) => {
            const b = (s) => e.target.closest(s);
            if (b('[data-cat]')) { st.cat = b('[data-cat]').dataset.cat; rerender(); return; }
            if (b('[data-openmap]')) { openMap(b('[data-openmap]').dataset.openmap); return; }
            const card = b('[data-pick]');
            if (card) { st.gzSel = st.gzSel === card.dataset.pick ? null : card.dataset.pick; rerender(); return; }
            insClick(e, root, null, null, (id, f) => openMap(id, f));
        });
        root.addEventListener('keydown', (e) => { const c = e.target.closest('[data-pick]'); if (c && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); c.click(); } });
        const s = root.querySelector('.gz-search');
        s?.addEventListener('input', () => { st.q = s.value; const pos = s.selectionStart; rerender(); const n = document.querySelector('.gz-search'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } });
        root.querySelector('.gz-disc')?.addEventListener('change', (e) => { st.disc = e.target.value; rerender(); });
    }

    // ---------- pole walki: dane lokacji dla VTT ----------
    function rawTok(mapId, levelId) {
        const mm = mapMeta(mapId), raw = levelId ? (mm.tokensL || {})[levelId] : mm.tokens;
        return { mode: 'party', party: null, chars: {}, others: [], ...(raw || {}) };
    }
    function fightScenes() {
        if (!cid()) return [];
        return maps().filter(m => m.kind !== 'world').map(m => {
            const it = m.kind === 'interior' ? interiorOf(m.id) : null;
            if (m.kind === 'interior' && !it) return null;
            const levels = it ? it.levels.map(L => ({ id: L.id, name: L.name, cols: L.cols, rows: L.rows, n: (rawTok(m.id, L.id).others || []).length })) : null;
            const ground = it ? (it.levels[it.ground ?? 0] || it.levels[0]).id : null;
            const parent = parentLoc(m.id);
            return { id: m.id, name: m.name, kind: m.kind, url: m.url, type: m.loc ? typeOf(m.loc) : null, ground, levels,
                where: parent ? mapById(mapOfLoc(parent)).name : '', n: levels ? levels.reduce((a, L) => a + L.n, 0) : (rawTok(m.id, null).others || []).length };
        }).filter(Boolean);
    }
    function fightData(mapId, levelId) {
        const m = maps().find(x => x.id === mapId);
        if (!m || m.kind === 'world') return null;
        if (m.kind === 'interior') {
            const it = interiorOf(m.id); if (!it) return null;
            const lv = it.levels.find(L => L.id === levelId) || it.levels[it.ground ?? 0] || it.levels[0];
            const d = MapForge.dims(lv);
            return { kind: 'interior', name: m.name, levelId: lv.id, levelName: lv.name, levels: it.levels.map(L => ({ id: L.id, name: L.name })), lv, w: d.w, h: d.h, grid: { size: MapForge.CELL, ox: 0, oy: 0 }, tok: rawTok(m.id, lv.id) };
        }
        return { kind: 'local', name: m.name, url: m.url, w: W, h: H, grid: gridOf(m), tok: rawTok(m.id, null) };
    }
    function fightWrite(mapId, levelId, fn) {
        saveMapMeta(mapId, mm => {
            const raw = levelId ? (mm.tokensL || {})[levelId] : mm.tokens;
            const t = { mode: 'party', party: null, chars: {}, others: [], ...(raw || {}) };
            t.chars = { ...(t.chars || {}) }; t.others = [...(t.others || [])];
            fn(t);
            if (levelId) { mm.tokensL = mm.tokensL || {}; mm.tokensL[levelId] = t; } else mm.tokens = t;
        });
    }

    return {
        fightScenes, fightData, fightWrite, TYPE_ICON: (t) => TYPES[t] ? icon(t) : '',
        renderMap, renderGazetteer, bindMap, bindGazetteer, editor, openMap, _st: st,
        addHere: () => editor(null, { mapType: st.map }),
        worldPicker, setWorld, parchment, worldOf,
        focus: (id) => { const l = locs().find(x => x.id === id); if (l) openMap(mapOfLoc(l), id); },
        TYPES
    };
})();

window.Atlas = Atlas;
