/* ============================================
   D&D 5e DM Panel — Gotowe zestawy startowe (PHB)
   Broń, pancerze, pakiety i ekwipunek klas / pochodzeń,
   plus pomocnicze wyliczenia KP i ataków dla kart postaci.
   ============================================ */

const Kits = (() => {
    // ---------- Klasy: PL / EN → klucz ----------
    const CLASS_KEYS = {
        barbarian: 'barbarian', barbarzyńca: 'barbarian', bard: 'bard', cleric: 'cleric', kleryk: 'cleric', kapłan: 'cleric',
        druid: 'druid', fighter: 'fighter', wojownik: 'fighter', monk: 'monk', mnich: 'monk', paladin: 'paladin', paladyn: 'paladin',
        ranger: 'ranger', łowca: 'ranger', tropiciel: 'ranger', rogue: 'rogue', łotrzyk: 'rogue', sorcerer: 'sorcerer', zaklinacz: 'sorcerer',
        warlock: 'warlock', czarnoksiężnik: 'warlock', wizard: 'wizard', czarodziej: 'wizard'
    };
    const CLASS_META = {
        barbarian: { pl: 'Barbarzyńca', icon: 'fa-burst', color: '#c0392b', die: 12 },
        bard: { pl: 'Bard', icon: 'fa-music', color: '#b5559b', die: 8 },
        cleric: { pl: 'Kleryk', icon: 'fa-sun', color: '#d4a537', die: 8 },
        druid: { pl: 'Druid', icon: 'fa-leaf', color: '#4f9a4a', die: 8 },
        fighter: { pl: 'Wojownik', icon: 'fa-shield-halved', color: '#a5683a', die: 10 },
        monk: { pl: 'Mnich', icon: 'fa-hand-fist', color: '#3f8fa8', die: 8 },
        paladin: { pl: 'Paladyn', icon: 'fa-shield-heart', color: '#d8b84a', die: 10 },
        ranger: { pl: 'Łowca', icon: 'fa-crosshairs', color: '#5d8a3a', die: 10 },
        rogue: { pl: 'Łotrzyk', icon: 'fa-mask', color: '#6b6b7a', die: 8 },
        sorcerer: { pl: 'Zaklinacz', icon: 'fa-fire', color: '#d0612b', die: 6 },
        warlock: { pl: 'Czarnoksiężnik', icon: 'fa-eye', color: '#7b4aa8', die: 8 },
        wizard: { pl: 'Czarodziej', icon: 'fa-hat-wizard', color: '#3d6bc0', die: 6 }
    };
    const classKey = (c) => {
        const k = String(c || '').toLowerCase().trim();
        return CLASS_KEYS[k] || (CLASS_META[k] ? k : '');
    };

    // ---------- Broń: [kości, typ obrażeń, właściwości, waga lb] ----------
    // właściwości: F finezyjna, R dystansowa, T rzucana, L lekka, 2 dwuręczna, V wszechstronna
    const WEAPONS = {
        'Topór bojowy': ['1k8', 'cięte', 'V', 4], 'Topór dwuręczny': ['1k12', 'cięte', '2', 7], 'Toporek': ['1k6', 'cięte', 'LT', 2],
        'Miecz długi': ['1k8', 'cięte', 'V', 3], 'Miecz dwuręczny': ['2k6', 'cięte', '2', 6], 'Miecz krótki': ['1k6', 'kłute', 'FL', 2],
        'Rapier': ['1k8', 'kłute', 'F', 2], 'Sejmitar': ['1k6', 'cięte', 'FL', 3], 'Sztylet': ['1k4', 'kłute', 'FLT', 1],
        'Buzdygan': ['1k6', 'obuchowe', '', 4], 'Młot bojowy': ['1k8', 'obuchowe', 'V', 2], 'Kostur': ['1k6', 'obuchowe', 'V', 4],
        'Włócznia': ['1k6', 'kłute', 'TV', 3], 'Oszczep': ['1k6', 'kłute', 'T', 2], 'Lekki młot': ['1k4', 'obuchowe', 'LT', 2],
        'Łuk krótki': ['1k6', 'kłute', 'R2', 2], 'Łuk długi': ['1k8', 'kłute', 'R2', 2], 'Kusza lekka': ['1k8', 'kłute', 'R2', 5],
        'Strzałka': ['1k4', 'kłute', 'FT', 0.25], 'Pałka': ['1k4', 'obuchowe', 'L', 2], 'Morgensztern': ['1k8', 'kłute', '', 4],
        // nazwy angielskie (stare karty / SRD)
        'Battleaxe': ['1k8', 'cięte', 'V', 4], 'Greataxe': ['1k12', 'cięte', '2', 7], 'Handaxe': ['1k6', 'cięte', 'LT', 2],
        'Longsword': ['1k8', 'cięte', 'V', 3], 'Greatsword': ['2k6', 'cięte', '2', 6], 'Shortsword': ['1k6', 'kłute', 'FL', 2],
        'Scimitar': ['1k6', 'cięte', 'FL', 3], 'Dagger': ['1k4', 'kłute', 'FLT', 1], 'Mace': ['1k6', 'obuchowe', '', 4],
        'Warhammer': ['1k8', 'obuchowe', 'V', 2], 'Quarterstaff': ['1k6', 'obuchowe', 'V', 4], 'Spear': ['1k6', 'kłute', 'TV', 3],
        'Javelin': ['1k6', 'kłute', 'T', 2], 'Shortbow': ['1k6', 'kłute', 'R2', 2], 'Longbow': ['1k8', 'kłute', 'R2', 2],
        'Crossbow, light': ['1k8', 'kłute', 'R2', 5], 'Light crossbow': ['1k8', 'kłute', 'R2', 5], 'Dart': ['1k4', 'kłute', 'FT', 0.25]
    };
    // ---------- Pancerze: [KP, rodzaj (L/M/H/S), waga] ----------
    const ARMOR = {
        'Zbroja skórzana': [11, 'L', 10], 'Zbroja ćwiekowana': [12, 'L', 13], 'Przeszywanica': [11, 'L', 8],
        'Kaftan kolczy': [13, 'M', 20], 'Zbroja łuskowa': [14, 'M', 45], 'Napierśnik': [14, 'M', 20], 'Półpłytówka': [15, 'M', 40],
        'Kolczuga': [16, 'H', 55], 'Zbroja paskowa': [17, 'H', 60], 'Płytówka': [18, 'H', 65],
        'Tarcza': [2, 'S', 6], 'Drewniana tarcza': [2, 'S', 6],
        'Leather Armor': [11, 'L', 10], 'Leather': [11, 'L', 10], 'Studded Leather': [12, 'L', 13], 'Scale Mail': [14, 'M', 45],
        'Chain Shirt': [13, 'M', 20], 'Breastplate': [14, 'M', 20], 'Half Plate': [15, 'M', 40], 'Chain Mail': [16, 'H', 55],
        'Splint': [17, 'H', 60], 'Plate': [18, 'H', 65], 'Shield': [2, 'S', 6]
    };
    // ---------- Pozostałe przedmioty: waga ----------
    const GEAR = {
        'Plecak': 5, 'Śpiwór': 7, 'Menażka': 1, 'Krzesiwo': 1, 'Pochodnia': 1, 'Racje żywnościowe (1 dzień)': 2, 'Bukłak': 5,
        'Lina konopna (50 stóp)': 10, 'Łom': 5, 'Młotek': 3, 'Klin żelazny': 0.5, 'Koc': 3, 'Świeca': 0, 'Szkatułka na jałmużnę': 1,
        'Kadzidło': 0, 'Kadzielnica': 1, 'Szaty liturgiczne': 4, 'Księga wiedzy': 5, 'Butelka atramentu': 0, 'Pióro': 0,
        'Arkusz pergaminu': 0, 'Woreczek piasku': 1, 'Nożyk': 0, 'Strój kostiumowy': 4, 'Zestaw do charakteryzacji': 3,
        'Kulki łożyskowe (worek 1000)': 2, 'Sznurek (10 stóp)': 0, 'Dzwonek': 0, 'Latarnia z przesłoną': 2, 'Flaszka oleju': 1,
        'Skrzynia': 25, 'Tuba na mapy': 1, 'Strój szlachecki': 6, 'Lampa': 1, 'Arkusz papieru': 0, 'Flakonik perfum': 0,
        'Lak do pieczęci': 0, 'Mydło': 0, 'Strzały': 0.05, 'Bełty': 0.075, 'Kołczan': 1, 'Futerał na bełty': 1,
        'Symbol święty': 1, 'Fokus druidyczny': 0, 'Fokus arkanistyczny': 1, 'Sakiewka komponentów': 2, 'Księga czarów': 3,
        'Narzędzia złodziejskie': 1, 'Lutnia': 2, 'Flet': 1, 'Modlitewnik': 5, 'Strój zwykły': 3, 'Strój podróżny': 4,
        'Strój wytworny': 6, 'Ciemny strój z kapturem': 3, 'Sakiewka': 1, 'Kostki do gry': 0, 'Talia kart': 0,
        'Narzędzia rzemieślnicze': 5, 'Łopata': 5, 'Żelazny garnek': 10, 'List polecający z gildii': 0, 'Pojemnik na zwoje': 1,
        'Zestaw zielarski': 3, 'Sygnet': 0, 'Zwój rodowodu': 0, 'Kij podróżny': 4, 'Sidła myśliwskie': 25,
        'Trofeum zwierzęcia': 0, 'Kawałek belki (pamiątka)': 1, 'Insygnia stopnia': 0, 'Trofeum wroga': 0,
        'Mapa miasta': 0, 'Oswojona mysz': 0, 'Pamiątka po rodzicach': 0, 'Pałka obciążona ołowiem': 0,
        'Instrument muzyczny': 3, 'Pamiątka od wielbiciela': 0, 'Butelka ciemnego atramentu': 0, 'List od zmarłego kolegi': 0,
        'Szczęśliwy amulet': 0, 'Lina jedwabna (50 stóp)': 5
    };

    // ---------- Pakiety ----------
    const PACKS = {
        explorer: { name: 'Zestaw odkrywcy', items: [['Plecak'], ['Śpiwór'], ['Menażka'], ['Krzesiwo'], ['Pochodnia', 10], ['Racje żywnościowe (1 dzień)', 10], ['Bukłak'], ['Lina konopna (50 stóp)']] },
        dungeoneer: { name: 'Zestaw podróżnika lochów', items: [['Plecak'], ['Łom'], ['Młotek'], ['Klin żelazny', 10], ['Pochodnia', 10], ['Krzesiwo'], ['Racje żywnościowe (1 dzień)', 10], ['Bukłak'], ['Lina konopna (50 stóp)']] },
        priest: { name: 'Zestaw kapłana', items: [['Plecak'], ['Koc'], ['Świeca', 10], ['Krzesiwo'], ['Szkatułka na jałmużnę'], ['Kadzidło', 2], ['Kadzielnica'], ['Szaty liturgiczne'], ['Racje żywnościowe (1 dzień)', 2], ['Bukłak']] },
        scholar: { name: 'Zestaw uczonego', items: [['Plecak'], ['Księga wiedzy'], ['Butelka atramentu'], ['Pióro'], ['Arkusz pergaminu', 10], ['Woreczek piasku'], ['Nożyk']] },
        entertainer: { name: 'Zestaw artysty', items: [['Plecak'], ['Śpiwór'], ['Strój kostiumowy', 2], ['Świeca', 5], ['Racje żywnościowe (1 dzień)', 5], ['Bukłak'], ['Zestaw do charakteryzacji']] },
        burglar: { name: 'Zestaw włamywacza', items: [['Plecak'], ['Kulki łożyskowe (worek 1000)'], ['Sznurek (10 stóp)'], ['Dzwonek'], ['Świeca', 5], ['Łom'], ['Młotek'], ['Klin żelazny', 10], ['Latarnia z przesłoną'], ['Flaszka oleju', 2], ['Racje żywnościowe (1 dzień)', 5], ['Krzesiwo'], ['Bukłak'], ['Lina konopna (50 stóp)']] },
        diplomat: { name: 'Zestaw dyplomaty', items: [['Skrzynia'], ['Tuba na mapy', 2], ['Strój szlachecki'], ['Butelka atramentu'], ['Pióro'], ['Lampa'], ['Flaszka oleju', 2], ['Arkusz papieru', 5], ['Flakonik perfum'], ['Lak do pieczęci'], ['Mydło']] }
    };
    const P = (k) => ({ pack: k });

    // ---------- Zestawy klas (PHB). Każdy wybór: [opcja domyślna, ...alternatywy] ----------
    const CLASS_KITS = {
        barbarian: {
            choices: [
                [{ label: 'Topór dwuręczny', items: [['Topór dwuręczny']] }, { label: 'Miecz dwuręczny', items: [['Miecz dwuręczny']] }],
                [{ label: '2 toporki', items: [['Toporek', 2]] }, { label: 'Włócznia', items: [['Włócznia']] }]
            ],
            fixed: [P('explorer'), ['Oszczep', 4]]
        },
        bard: {
            choices: [
                [{ label: 'Rapier', items: [['Rapier']] }, { label: 'Miecz długi', items: [['Miecz długi']] }, { label: 'Sztylet', items: [['Sztylet']] }],
                [{ label: 'Zestaw dyplomaty', items: [P('diplomat')] }, { label: 'Zestaw artysty', items: [P('entertainer')] }],
                [{ label: 'Lutnia', items: [['Lutnia']] }, { label: 'Flet', items: [['Flet']] }]
            ],
            fixed: [['Zbroja skórzana'], ['Sztylet']]
        },
        cleric: {
            choices: [
                [{ label: 'Buzdygan', items: [['Buzdygan']] }, { label: 'Młot bojowy', items: [['Młot bojowy']] }],
                [{ label: 'Zbroja łuskowa', items: [['Zbroja łuskowa']] }, { label: 'Zbroja skórzana', items: [['Zbroja skórzana']] }, { label: 'Kolczuga', items: [['Kolczuga']] }],
                [{ label: 'Kusza lekka + 20 bełtów', items: [['Kusza lekka'], ['Bełty', 20], ['Futerał na bełty']] }, { label: 'Włócznia', items: [['Włócznia']] }],
                [{ label: 'Zestaw kapłana', items: [P('priest')] }, { label: 'Zestaw odkrywcy', items: [P('explorer')] }]
            ],
            fixed: [['Tarcza'], ['Symbol święty']]
        },
        druid: {
            choices: [
                [{ label: 'Drewniana tarcza', items: [['Drewniana tarcza']] }, { label: 'Kostur', items: [['Kostur']] }],
                [{ label: 'Sejmitar', items: [['Sejmitar']] }, { label: 'Włócznia', items: [['Włócznia']] }]
            ],
            fixed: [['Zbroja skórzana'], P('explorer'), ['Fokus druidyczny']]
        },
        fighter: {
            choices: [
                [{ label: 'Kolczuga', items: [['Kolczuga']] }, { label: 'Zbroja skórzana + łuk długi i 20 strzał', items: [['Zbroja skórzana'], ['Łuk długi'], ['Strzały', 20], ['Kołczan']] }],
                [{ label: 'Miecz długi + tarcza', items: [['Miecz długi'], ['Tarcza']] }, { label: 'Miecz dwuręczny', items: [['Miecz dwuręczny']] }, { label: 'Topór bojowy + tarcza', items: [['Topór bojowy'], ['Tarcza']] }],
                [{ label: 'Kusza lekka + 20 bełtów', items: [['Kusza lekka'], ['Bełty', 20], ['Futerał na bełty']] }, { label: '2 toporki', items: [['Toporek', 2]] }],
                [{ label: 'Zestaw podróżnika lochów', items: [P('dungeoneer')] }, { label: 'Zestaw odkrywcy', items: [P('explorer')] }]
            ],
            fixed: []
        },
        monk: {
            choices: [
                [{ label: 'Miecz krótki', items: [['Miecz krótki']] }, { label: 'Kostur', items: [['Kostur']] }],
                [{ label: 'Zestaw odkrywcy', items: [P('explorer')] }, { label: 'Zestaw podróżnika lochów', items: [P('dungeoneer')] }]
            ],
            fixed: [['Strzałka', 10]]
        },
        paladin: {
            choices: [
                [{ label: 'Miecz długi + tarcza', items: [['Miecz długi'], ['Tarcza']] }, { label: 'Miecz dwuręczny', items: [['Miecz dwuręczny']] }],
                [{ label: '5 oszczepów', items: [['Oszczep', 5]] }, { label: 'Buzdygan', items: [['Buzdygan']] }],
                [{ label: 'Zestaw kapłana', items: [P('priest')] }, { label: 'Zestaw odkrywcy', items: [P('explorer')] }]
            ],
            fixed: [['Kolczuga'], ['Symbol święty']]
        },
        ranger: {
            choices: [
                [{ label: 'Zbroja łuskowa', items: [['Zbroja łuskowa']] }, { label: 'Zbroja skórzana', items: [['Zbroja skórzana']] }],
                [{ label: '2 miecze krótkie', items: [['Miecz krótki', 2]] }, { label: '2 toporki', items: [['Toporek', 2]] }],
                [{ label: 'Zestaw odkrywcy', items: [P('explorer')] }, { label: 'Zestaw podróżnika lochów', items: [P('dungeoneer')] }]
            ],
            fixed: [['Łuk długi'], ['Strzały', 20], ['Kołczan']]
        },
        rogue: {
            choices: [
                [{ label: 'Rapier', items: [['Rapier']] }, { label: 'Miecz krótki', items: [['Miecz krótki']] }],
                [{ label: 'Łuk krótki + 20 strzał', items: [['Łuk krótki'], ['Strzały', 20], ['Kołczan']] }, { label: 'Miecz krótki', items: [['Miecz krótki']] }],
                [{ label: 'Zestaw włamywacza', items: [P('burglar')] }, { label: 'Zestaw podróżnika lochów', items: [P('dungeoneer')] }, { label: 'Zestaw odkrywcy', items: [P('explorer')] }]
            ],
            fixed: [['Zbroja skórzana'], ['Sztylet', 2], ['Narzędzia złodziejskie']]
        },
        sorcerer: {
            choices: [
                [{ label: 'Kusza lekka + 20 bełtów', items: [['Kusza lekka'], ['Bełty', 20], ['Futerał na bełty']] }, { label: 'Kostur', items: [['Kostur']] }],
                [{ label: 'Fokus arkanistyczny', items: [['Fokus arkanistyczny']] }, { label: 'Sakiewka komponentów', items: [['Sakiewka komponentów']] }],
                [{ label: 'Zestaw podróżnika lochów', items: [P('dungeoneer')] }, { label: 'Zestaw odkrywcy', items: [P('explorer')] }]
            ],
            fixed: [['Sztylet', 2]]
        },
        warlock: {
            choices: [
                [{ label: 'Kusza lekka + 20 bełtów', items: [['Kusza lekka'], ['Bełty', 20], ['Futerał na bełty']] }, { label: 'Kostur', items: [['Kostur']] }],
                [{ label: 'Fokus arkanistyczny', items: [['Fokus arkanistyczny']] }, { label: 'Sakiewka komponentów', items: [['Sakiewka komponentów']] }],
                [{ label: 'Zestaw uczonego', items: [P('scholar')] }, { label: 'Zestaw podróżnika lochów', items: [P('dungeoneer')] }]
            ],
            fixed: [['Zbroja skórzana'], ['Włócznia'], ['Sztylet', 2]]
        },
        wizard: {
            choices: [
                [{ label: 'Kostur', items: [['Kostur']] }, { label: 'Sztylet', items: [['Sztylet']] }],
                [{ label: 'Fokus arkanistyczny', items: [['Fokus arkanistyczny']] }, { label: 'Sakiewka komponentów', items: [['Sakiewka komponentów']] }],
                [{ label: 'Zestaw uczonego', items: [P('scholar')] }, { label: 'Zestaw odkrywcy', items: [P('explorer')] }]
            ],
            fixed: [['Księga czarów']]
        }
    };

    // ---------- Ekwipunek pochodzeń (PHB); złoto w sakiewce liczy kreator ----------
    const BACKGROUND_GEAR = {
        acolyte: [['Symbol święty'], ['Modlitewnik'], ['Kadzidło', 5], ['Szaty liturgiczne'], ['Strój zwykły'], ['Sakiewka']],
        charlatan: [['Strój wytworny'], ['Zestaw do charakteryzacji'], ['Sakiewka']],
        criminal: [['Łom'], ['Ciemny strój z kapturem'], ['Sakiewka']],
        entertainer: [['Instrument muzyczny'], ['Pamiątka od wielbiciela'], ['Strój kostiumowy'], ['Sakiewka']],
        'folk-hero': [['Narzędzia rzemieślnicze'], ['Łopata'], ['Żelazny garnek'], ['Strój zwykły'], ['Sakiewka']],
        'guild-artisan': [['Narzędzia rzemieślnicze'], ['List polecający z gildii'], ['Strój podróżny'], ['Sakiewka']],
        hermit: [['Pojemnik na zwoje'], ['Koc'], ['Strój zwykły'], ['Zestaw zielarski']],
        noble: [['Strój wytworny'], ['Sygnet'], ['Zwój rodowodu'], ['Sakiewka']],
        outlander: [['Kij podróżny'], ['Sidła myśliwskie'], ['Trofeum zwierzęcia'], ['Strój podróżny'], ['Sakiewka']],
        sage: [['Butelka ciemnego atramentu'], ['Pióro'], ['Nożyk'], ['List od zmarłego kolegi'], ['Strój zwykły'], ['Sakiewka']],
        sailor: [['Lina jedwabna (50 stóp)'], ['Szczęśliwy amulet'], ['Strój zwykły'], ['Sakiewka']],
        soldier: [['Insygnia stopnia'], ['Trofeum wroga'], ['Kostki do gry'], ['Strój zwykły'], ['Sakiewka']],
        urchin: [['Nożyk'], ['Mapa miasta'], ['Oswojona mysz'], ['Pamiątka po rodzicach'], ['Strój zwykły'], ['Sakiewka']]
    };

    function weightOf(name) {
        const db = window.ItemsDB && ItemsDB.find(name);
        if (db && db.cat !== 'pack') return db.w || 0;
        if (WEAPONS[name]) return WEAPONS[name][3];
        if (ARMOR[name]) return ARMOR[name][2];
        return GEAR[name] ?? 0;
    }

    // Rozwija listę [nazwa, ilość] / pakiety w pozycje ekwipunku, łącząc powtórki
    function expand(list, into = []) {
        list.forEach(entry => {
            if (entry && entry.pack) { expand(PACKS[entry.pack].items, into); return; }
            const [name, qty = 1] = entry;
            const found = into.find(i => i.name === name);
            if (found) found.quantity += qty;
            else { const db = window.ItemsDB && ItemsDB.find(name); into.push({ name, quantity: qty, weight: weightOf(name), ...(db && db.cost !== '—' ? { cost: db.cost, ref: db.id } : {}) }); }
        });
        return into;
    }

    /** Ekwipunek klasy dla podanych wyborów (indeksy opcji; brak = domyślna). */
    function buildClassKit(cls, picks = []) {
        const kit = CLASS_KITS[classKey(cls)];
        if (!kit) return [];
        const list = [];
        kit.choices.forEach((opts, i) => list.push(...(opts[picks[i] || 0] || opts[0]).items));
        list.push(...kit.fixed);
        return expand(list);
    }
    function buildBackgroundKit(bgId) {
        return expand(BACKGROUND_GEAR[bgId] || []);
    }
    function mergeInto(inv, items) {
        items.forEach(it => {
            const f = inv.find(i => i.name === it.name);
            if (f) f.quantity = (+f.quantity || 0) + it.quantity; else inv.push({ ...it });
        });
        return inv;
    }
    const fixedSummary = (cls) => {
        const kit = CLASS_KITS[classKey(cls)];
        if (!kit) return [];
        return kit.fixed.map(e => e.pack ? PACKS[e.pack].name : (e[1] > 1 ? `${e[0]} ×${e[1]}` : e[0]));
    };

    // ---------- KP i ataki ----------
    const mod = (s) => Math.floor(((s ?? 10) - 10) / 2);
    // pancerz / broń z pełnej bazy przedmiotów (ItemsDB), a gdy jej brak — z tabel powyżej
    const dbItem = (name) => (window.ItemsDB && ItemsDB.find(name)) || null;
    function armorOf(it) {
        const db = dbItem(it.name);
        if (db && db.cat === 'armor') return [db.kind === 'S' ? 2 : db.ac, db.kind];
        const a = ARMOR[it.name]; return a ? [a[0], a[1]] : null;
    }
    // KP wg PHB: pancerz (lekki + ZRĘ, średni + ZRĘ maks. 2, ciężki bez ZRĘ), tarcza +2,
    // bez pancerza: 10 + ZRĘ albo cechy klas (barbarzyńca + KON, mnich + MDR bez tarczy,
    // zaklinacz z linii smoczej 13 + ZRĘ). Przy kilku pancerzach w plecaku liczy ten oznaczony
    // jako założony, a jeśli żaden nie jest oznaczony — najlepszy.
    function computeAC(char) {
        const inv = char.inventory || [];
        const dex = mod(char.abilityScores?.dex);
        let body = null, shield = 0;
        const worn = inv.filter(it => it.equipped !== false);
        const anyEq = inv.some(it => it.equipped === true);
        (anyEq ? inv.filter(it => it.equipped === true) : worn).forEach(it => {
            const a = armorOf(it); if (!a) return;
            if (a[1] === 'S') shield = 2;
            else if (!body || a[0] > body[0]) body = a;
        });
        const ck = classKey(char.class);
        let ac;
        if (body) ac = body[0] + (body[1] === 'L' ? dex : body[1] === 'M' ? Math.min(dex, 2) : 0);
        else if (ck === 'barbarian') ac = 10 + dex + mod(char.abilityScores?.con);
        else if (ck === 'monk' && !shield) ac = 10 + dex + mod(char.abilityScores?.wis);
        else if (ck === 'sorcerer' && /dracon|smocz/i.test(String(char.subclass || ''))) ac = 13 + dex;
        else ac = 10 + dex;
        return ac + shield;
    }
    // biegłość w broni: „Simple/Broń prosta”, „Martial/Broń żołnierska” albo nazwa konkretnej broni
    function proficientWith(char, name, db) {
        const list = (char.weaponProficiencies || []).map(x => String(x).toLowerCase());
        if (!list.length) return true;                                  // stare karty bez listy — zakładamy biegłość
        const simple = db ? /prosta/i.test(db.sub || '') : true;
        if (list.some(x => /simple|prost/.test(x)) && simple) return true;
        if (list.some(x => /martial|żołniersk/.test(x)) && (!db || !simple)) return true;
        // „Light Crossbows” = „Crossbow, light”, „Daggers” = „Dagger”, „Sztylety” = „Sztylet”
        const key = (s) => String(s).toLowerCase().replace(/[^a-ząćęłńóśźż ]/g, ' ').split(/\s+/).filter(Boolean).map(w => w.replace(/(s|y|i)$/, '')).sort().join(' ');
        const names = [name, db?.name, db?.en].filter(Boolean).map(key);
        return list.some(x => names.includes(key(x)));
    }
    // ataki bronią wg PHB: walka wręcz SIŁ, dystansowa ZRĘ, finezyjna — lepsza z obu;
    // premia z biegłości tylko przy biegłości w danej broni; modyfikator dodany do obrażeń.
    function attacks(char, limit = 3) {
        const prof = Math.ceil((char.level || 1) / 4) + 1;
        const str = mod(char.abilityScores?.str), dex = mod(char.abilityScores?.dex);
        const out = [];
        (char.inventory || []).forEach(it => {
            if (out.length >= limit) return;
            const db = dbItem(it.name);
            let dice, type, props, ranged;
            if (db && db.cat === 'weapon') {
                if (!db.dmg) return;                                   // sieć itp. — bez obrażeń
                dice = db.dmg; type = db.dt; props = db.props || ''; ranged = /dystansow/i.test(db.sub || '');
            } else {
                const w = WEAPONS[it.name]; if (!w) return;
                [dice, type, props] = w; ranged = props.includes('R');
            }
            const label = db?.name || it.name;
            if (out.some(o => o.name === label)) return;
            const m = props.includes('F') ? Math.max(str, dex) : ranged ? dex : str;
            const pr = proficientWith(char, it.name, db);
            const flat = /^\d+$/.test(String(dice));
            out.push({ name: label, hit: m + (pr ? prof : 0), dmg: flat ? String(Math.max(1, +dice + m)) : `${dice}${m ? (m > 0 ? '+' : '−') + Math.abs(m) : ''}`, type, ranged, proficient: pr, range: db?.range || '', vers: db?.vers || '' });
        });
        return out;
    }

    return {
        CLASS_META, CLASS_KITS, PACKS, BACKGROUND_GEAR, WEAPONS, ARMOR,
        classKey, buildClassKit, buildBackgroundKit, mergeInto, fixedSummary, computeAC, attacks, weightOf
    };
})();

window.Kits = Kits;
