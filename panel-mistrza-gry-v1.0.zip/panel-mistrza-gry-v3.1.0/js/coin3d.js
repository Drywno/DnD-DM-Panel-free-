/* ============================================
   Rzut monetą w 3D — ten sam w panelu Mistrza Gry i u gracza
   Złota moneta (orzeł / reszka) z grubym rantem: podskakuje, wiruje
   w powietrzu, odbija się od stołu i kładzie wynikiem do góry.
   Wynik ustala wywołujący (MG losuje u siebie, gracz dostaje go z serwera).
   ============================================ */
const Coin3D = (() => {
    const DUR = 1900;
    let box = null, cap = null, hideT = null, busy = false;
    // orzeł w koronie (symetryczny, rysowany z połówki)
    const EAGLE = (() => {
        const wing = [[48, 46], [40, 41], [31, 35], [19, 31], [10, 34], [18, 37], [11, 41], [20, 43], [13, 48], [23, 49], [17, 54], [28, 54], [24, 59], [35, 57], [44, 58]];
        const mir = (pts) => pts.map(([x, y]) => [100 - x, y]);
        const P = (pts) => 'M' + pts.map(p => p.join(' ')).join('L') + 'Z';
        const tail = [[44, 64], [39, 76], [45, 72], [50, 79], [55, 72], [61, 76], [56, 64]];
        const crown = [[43, 29], [43, 21], [46.5, 25], [50, 18], [53.5, 25], [57, 21], [57, 29]];
        return `<svg viewBox="0 0 100 100" aria-hidden="true">
            <circle cx="50" cy="50" r="44" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="1.5 3.2"/>
            <g fill="currentColor"><path d="${P(wing)}"/><path d="${P(mir(wing).reverse())}"/><path d="${P(tail)}"/>
            <ellipse cx="50" cy="52" rx="7.5" ry="13"/><circle cx="50" cy="36" r="5.5"/><path d="M53 35l6 2-5 2z"/><path d="${P(crown)}"/>
            <path d="M44 66l-4 6M56 66l4 6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></g></svg>`;
    })();
    const VALUE = `<svg viewBox="0 0 100 100" aria-hidden="true">
        <circle cx="50" cy="50" r="44" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="1.5 3.2"/>
        <path fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" d="M24 70c-8-10-8-30 4-42M76 70c8-10 8-30-4-42"/>
        <path fill="currentColor" d="M22 62l-6-3 5-2zM20 50l-6-2 5-3zM22 38l-5-4 6-1zM78 62l6-3-5-2zM80 50l6-2-5-3zM78 38l5-4-6-1z"/>
        <text x="50" y="60" text-anchor="middle" font-family="Georgia, serif" font-weight="700" font-size="30" fill="currentColor">10</text>
        <text x="50" y="76" text-anchor="middle" font-family="Georgia, serif" font-weight="700" font-size="9" letter-spacing="1.5" fill="currentColor">MZ</text></svg>`;
    function build() {
        box = document.createElement('div');
        box.className = 'coin3d-stage';
        const rim = Array.from({ length: 14 }, (_, i) => `<i style="--z:${(i - 6.5) * 0.55}px"></i>`).join('');
        box.innerHTML = `<div class="coin3d-shadow"></div><div class="coin3d-arc"><div class="coin3d"><div class="coin3d-rim">${rim}</div>
            <div class="coin3d-face front">${EAGLE}</div><div class="coin3d-face back">${VALUE}</div></div></div>`;
        document.body.appendChild(box);
        cap = document.createElement('div');
        cap.className = 'dice-tray-result coin3d-cap';
        document.body.appendChild(cap);
        const off = () => { if (!busy) hide(); };
        cap.addEventListener('mousedown', off);
        document.addEventListener('mousedown', (e) => { if (!busy && box.classList.contains('show') && !e.target.closest('#dice-roller, #dice-fab')) hide(); }, true);
    }
    function hide() {
        clearTimeout(hideT);
        if (!box) return;
        box.classList.remove('show'); cap.classList.remove('show');
    }
    // heads: true = orzeł, false = reszka
    function flip(heads, label = '') {
        if (!box) build();
        clearTimeout(hideT);
        busy = true;
        const coin = box.querySelector('.coin3d'), arc = box.querySelector('.coin3d-arc');
        const turns = 5 + Math.floor(Math.random() * 3);
        coin.style.setProperty('--end', `${turns * 360 + (heads ? 0 : 180)}deg`);
        coin.style.setProperty('--tilt', `${(Math.random() * 30 - 15).toFixed(1)}deg`);
        cap.classList.remove('show');
        box.classList.remove('show', 'go'); void box.offsetWidth;
        box.classList.add('show', 'go');
        try { navigator.vibrate?.(25); } catch (e) {}
        return new Promise((done) => {
            setTimeout(() => {
                busy = false;
                cap.innerHTML = `<div class="dtr-expr">${label ? label.replace(/[<>&]/g, '') + ' · ' : ''}Rzut monetą</div><div class="dtr-total">${heads ? 'Orzeł' : 'Reszka'}</div>`;
                cap.classList.add('show');
                hideT = setTimeout(hide, 2800);
                done(heads);
            }, DUR);
        });
    }
    return { flip, hide, DUR };
})();
window.Coin3D = Coin3D;
