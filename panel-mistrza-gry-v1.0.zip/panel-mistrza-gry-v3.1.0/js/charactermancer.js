/* ============================================
   D&D 5e DM Panel — Charactermancer
   ============================================ */

const Charactermancer = (function() {
    let state = {};
    let cache = {
        races: [], classes: [], backgrounds: [], languages: []
    };
    let currentStep = 1;
    const TOTAL_STEPS = 7;

    const SKILL_EN_TO_PL = {
        'Acrobatics': 'Akrobatyka', 'Animal Handling': 'Opieka nad zwierzętami',
        'Arcana': 'Wiedza mistyczna', 'Athletics': 'Atletyka', 'Deception': 'Oszustwo',
        'History': 'Historia', 'Insight': 'Wgląd', 'Intimidation': 'Zastraszanie',
        'Investigation': 'Śledztwo', 'Medicine': 'Medycyna', 'Nature': 'Natura',
        'Perception': 'Percepcja', 'Performance': 'Występy', 'Persuasion': 'Perswazja',
        'Religion': 'Religia', 'Sleight of Hand': 'Zwinne dłonie', 'Stealth': 'Skradanie',
        'Survival': 'Sztuka przetrwania'
    };

    const BACKGROUNDS = {
        'acolyte': { name: 'Acolyte (Akolita)', skills: ['Insight', 'Religion'], tools: [], languages: 2, gold: 15 },
        'charlatan': { name: 'Charlatan (Szarlatan)', skills: ['Deception', 'Sleight of Hand'], tools: ['Disguise kit', 'Forgery kit'], languages: 0, gold: 15 },
        'criminal': { name: 'Criminal (Zbrodniarz)', skills: ['Deception', 'Stealth'], tools: ['Thieves\' tools', 'Gaming set'], languages: 0, gold: 15 },
        'entertainer': { name: 'Entertainer (Artysta)', skills: ['Acrobatics', 'Performance'], tools: ['Disguise kit', 'Musical instrument'], languages: 0, gold: 15 },
        'folk-hero': { name: 'Folk Hero (Bohater Ludu)', skills: ['Animal Handling', 'Survival'], tools: ['Artisan\'s tools', 'Vehicles (land)'], languages: 0, gold: 10 },
        'guild-artisan': { name: 'Guild Artisan (Rzemieślnik)', skills: ['Insight', 'Persuasion'], tools: ['Artisan\'s tools'], languages: 1, gold: 15 },
        'hermit': { name: 'Hermit (Pustelnik)', skills: ['Medicine', 'Religion'], tools: ['Herbalism kit'], languages: 1, gold: 5 },
        'noble': { name: 'Noble (Szlachcic)', skills: ['History', 'Persuasion'], tools: ['Gaming set'], languages: 1, gold: 25 },
        'outlander': { name: 'Outlander (Outsider)', skills: ['Athletics', 'Survival'], tools: ['Musical instrument'], languages: 1, gold: 10 },
        'sage': { name: 'Sage (Mędrzec)', skills: ['Arcana', 'History'], tools: [], languages: 2, gold: 10 },
        'sailor': { name: 'Sailor (Marynarz)', skills: ['Athletics', 'Perception'], tools: ['Navigator\'s tools', 'Vehicles (water)'], languages: 0, gold: 10 },
        'soldier': { name: 'Soldier (Żołnierz)', skills: ['Athletics', 'Intimidation'], tools: ['Gaming set', 'Vehicles (land)'], languages: 0, gold: 10 },
        'urchin': { name: 'Urchin (Urwis)', skills: ['Sleight of Hand', 'Stealth'], tools: ['Disguise kit', 'Thieves\' tools'], languages: 0, gold: 10 }
    };

    const STARTING_GOLD = {
        barbarian: 50, bard: 125, cleric: 125, druid: 50, fighter: 125,
        monk: 13, paladin: 125, ranger: 125, rogue: 100, sorcerer: 75,
        warlock: 100, wizard: 100
    };

    const CUSTOM_RACES = ['Goliat', 'Aasimar', 'Tabaxi', 'Firbolg', 'Kenku', 'Lizardfolk', 'Genasi', 'Tortle', 'Changeling', 'Kalashtar'];

    function _esc(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    async function openModal() {
        state = {
            name: '', raceObj: null, subraceObj: null, customRaceName: '',
            classObj: null, selectedClassSkills: [],
            abilityMethod: 'standard', // standard, pointbuy, manual
            rawScores: { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 },
            standardArrayRemaining: [15, 14, 13, 12, 10, 8],
            pointBuyRemaining: 27,
            backgroundId: '', backgroundObj: null,
            alignment: '',
            chosenLanguages: [],
            equipmentMethod: 'class',
            kitPicks: [],
            selectedSpells: []
        };
        currentStep = 1;

        // Fetch initial data
        try {
            cache.races = await APIClient.getRaceList();
            cache.classes = await APIClient.getClassList();
            cache.languages = await APIClient.getLanguageList();
        } catch (e) { console.error('Charactermancer init err:', e); }

        render();
    }

    function render() {
        const body = `
            <div style="display:flex; flex-direction:column; min-height:400px; max-height: 70vh; overflow-y:auto; padding-right:10px;">
                ${renderStepIndicator()}
                <div style="flex:1; margin-top:20px;">
                    ${renderCurrentStep()}
                </div>
            </div>
        `;

        const footer = `
            <div style="display:flex; justify-content:space-between; width:100%;">
                <button class="btn-secondary" onclick="Charactermancer.prevStep()" ${currentStep === 1 ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>Wstecz</button>
                ${currentStep < TOTAL_STEPS 
                    ? `<button class="btn-primary" onclick="Charactermancer.nextStep()">Dalej</button>`
                    : `<button class="btn-primary" onclick="Charactermancer.finish()">Zakończ i Utwórz</button>`}
            </div>
        `;

        App.showModal('Kreator Postaci (Charactermancer)', body, footer);
        setTimeout(attachEventHandlers, 50);
    }

    function renderStepIndicator() {
        let html = '<div style="display:flex; justify-content:space-between; border-bottom:1px solid var(--border-color); padding-bottom:10px;">';
        const labels = ['Rasa', 'Klasa', 'Atrybuty', 'Pochodzenie', 'Szczegóły', 'Ekwipunek', 'Magia'];
        for (let i = 1; i <= TOTAL_STEPS; i++) {
            const isCurrent = i === currentStep;
            const isDone = i < currentStep;
            const color = isCurrent ? 'var(--text-gold)' : (isDone ? 'var(--emerald-light)' : 'var(--text-muted)');
            const bg = isCurrent ? 'rgba(207,170,107,0.2)' : 'transparent';
            html += `
                <div style="text-align:center; padding:5px 10px; border-radius:8px; background:${bg}; color:${color};">
                    <div style="font-weight:bold; font-size:1.1rem;">${i}</div>
                    <div style="font-size:0.7rem; text-transform:uppercase;">${labels[i-1]}</div>
                </div>
            `;
        }
        html += '</div>';
        return html;
    }

    function renderCurrentStep() {
        switch(currentStep) {
            case 1: return renderStep1();
            case 2: return renderStep2();
            case 3: return renderStep3();
            case 4: return renderStep4();
            case 5: return renderStep5();
            case 6: return renderStep6();
            case 7: return renderStep7();
            default: return '';
        }
    }

    function attachEventHandlers() {
        if (currentStep === 1) {
            const rSel = document.getElementById('cm-race-select');
            if (rSel) rSel.addEventListener('change', handleRaceChange);
            const srSel = document.getElementById('cm-subrace-select');
            if (srSel) srSel.addEventListener('change', handleSubraceChange);
        } else if (currentStep === 2) {
            const cSel = document.getElementById('cm-class-select');
            if (cSel) cSel.addEventListener('change', handleClassChange);
            document.querySelectorAll('.cm-skill-cb').forEach(cb => {
                cb.addEventListener('change', handleSkillChange);
            });
        } else if (currentStep === 3) {
            document.querySelectorAll('.cm-method-tab').forEach(t => t.addEventListener('click', handleMethodChange));
            document.querySelectorAll('.cm-score-select, .cm-score-input, .cm-score-btn').forEach(el => {
                if (el.tagName === 'SELECT') el.addEventListener('change', handleScoreChange);
                else el.addEventListener('click', handleScoreChange);
            });
            document.querySelectorAll('.cm-manual-input').forEach(el => el.addEventListener('change', handleManualScoreChange));
        } else if (currentStep === 4) {
            const bgSel = document.getElementById('cm-bg-select');
            if (bgSel) bgSel.addEventListener('change', handleBgChange);
        } else if (currentStep === 5) {
            const nameInp = document.getElementById('cm-name');
            if (nameInp) nameInp.addEventListener('change', e => state.name = e.target.value);
            const alignSel = document.getElementById('cm-alignment');
            if (alignSel) alignSel.addEventListener('change', e => state.alignment = e.target.value);
        } else if (currentStep === 7) {
            const host = document.getElementById('cm-spell-picker');
            if (host) document.getElementById('modal')?.classList.add('modal-wide');
            if (host && window.SpellPicker && state.classObj) {
                SpellPicker.mount(host, {
                    cls: state.classObj.index, level: 1, strict: true,
                    scores: { str: getFinalScore('str'), dex: getFinalScore('dex'), con: getFinalScore('con'), int: getFinalScore('int'), wis: getFinalScore('wis'), cha: getFinalScore('cha') },
                    selected: state.selectedSpells || [],
                    onChange: (list) => { state.selectedSpells = list; }
                });
            }
        } else if (currentStep === 6) {
            document.querySelectorAll('input[name="cm-equip-method"]').forEach(r => r.addEventListener('change', e => {
                state.equipmentMethod = e.target.value;
                render();
            }));
            document.querySelectorAll('input[data-kit]').forEach(r => r.addEventListener('change', e => {
                state.kitPicks[+e.target.dataset.kit] = +e.target.value;
                render();
            }));
        }
    }

    // --- STEP 1: RACE ---
    function renderStep1() {
        let options = '<option value="">-- Wybierz Rasę --</option>';
        options += '<optgroup label="SRD (D&D 5e API)">';
        cache.races.forEach(r => {
            const sel = (state.raceObj && state.raceObj.index === r.index) ? 'selected' : '';
            options += `<option value="srd_${r.index}" ${sel}>${_esc(r.name)}</option>`;
        });
        options += '</optgroup><optgroup label="Customowe">';
        CUSTOM_RACES.forEach(cr => {
            const sel = state.customRaceName === cr ? 'selected' : '';
            options += `<option value="cust_${cr}" ${sel}>${cr}</option>`;
        });
        options += '</optgroup>';

        let html = `
            <div class="form-group">
                <label>Rasa</label>
                <select id="cm-race-select" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width:100%; padding:8px;">
                    ${options}
                </select>
            </div>
        `;

        if (state.raceObj) {
            html += `<div style="margin-top:15px; padding:10px; background:rgba(0,0,0,0.2); border-radius:8px;">`;
            html += `<p><strong style="color:var(--text-gold);">Szybkość:</strong> ${state.raceObj.speed} ft.</p>`;
            html += `<p><strong style="color:var(--text-gold);">Rozmiar:</strong> ${state.raceObj.size}</p>`;
            
            let bonuses = state.raceObj.ability_bonuses.map(b => `${b.ability_score.name} +${b.bonus}`).join(', ');
            html += `<p><strong style="color:var(--text-gold);">Atrybuty:</strong> ${bonuses || 'Brak'}</p>`;
            
            let langs = state.raceObj.languages.map(l => l.name).join(', ');
            html += `<p><strong style="color:var(--text-gold);">Języki:</strong> ${langs}</p>`;

            let traitsHtml = '';
            if (state.raceObj.traits_full && state.raceObj.traits_full.length > 0) {
                traitsHtml = state.raceObj.traits_full.map(t => `<div style="margin-bottom:8px; padding:8px; background:rgba(0,0,0,0.3); border-radius:4px; border:1px solid var(--border-color);"><strong>${t.name}</strong><div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">${t.desc}</div></div>`).join('');
            } else if (state.raceObj.traits && state.raceObj.traits.length > 0) {
                traitsHtml = state.raceObj.traits.map(t => t.name).join(', ');
            }
            html += `<div style="margin-top:10px;"><strong style="color:var(--text-gold);">Cechy Rasowe:</strong><br> ${traitsHtml || 'Brak'}</div>`;

            if (state.raceObj.subraces && state.raceObj.subraces.length > 0) {
                let srOpts = '<option value="">-- Wybierz Subrasę --</option>';
                state.raceObj.subraces.forEach(sr => {
                    const sel = (state.subraceObj && state.subraceObj.index === sr.index) ? 'selected' : '';
                    srOpts += `<option value="${sr.index}" ${sel}>${_esc(sr.name)}</option>`;
                });
                html += `
                    <div class="form-group" style="margin-top:10px;">
                        <label>Subrasa</label>
                        <select id="cm-subrace-select" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width:100%; padding:8px;">
                            ${srOpts}
                        </select>
                    </div>
                `;
            }

            if (state.subraceObj) {
                html += `<div style="margin-top:10px; padding-left:10px; border-left:2px solid var(--gold);">`;
                let srBonuses = state.subraceObj.ability_bonuses.map(b => `${b.ability_score.name} +${b.bonus}`).join(', ');
                if (srBonuses) html += `<p><strong style="color:var(--text-gold);">Dodatkowe Atrybuty:</strong> ${srBonuses}</p>`;
                let srTraitsHtml = '';
                if (state.subraceObj.traits_full && state.subraceObj.traits_full.length > 0) {
                    srTraitsHtml = state.subraceObj.traits_full.map(t => `<div style="margin-bottom:8px; padding:8px; background:rgba(0,0,0,0.3); border-radius:4px; border:1px solid var(--border-color);"><strong>${t.name}</strong><div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">${t.desc}</div></div>`).join('');
                } else if (state.subraceObj.racial_traits && state.subraceObj.racial_traits.length > 0) {
                    srTraitsHtml = state.subraceObj.racial_traits.map(t => t.name).join(', ');
                }
                if (srTraitsHtml) html += `<div style="margin-top:10px;"><strong style="color:var(--text-gold);">Dodatkowe Cechy (Subrasa):</strong><br> ${srTraitsHtml}</div>`;
                html += `</div>`;
            }
            html += `</div>`;
        } else if (state.customRaceName) {
            html += `
                <div style="margin-top:15px; padding:10px; background:rgba(0,0,0,0.2); border-radius:8px;">
                    <p style="color:var(--text-muted);">Z uwagi na brak rasy w bazie SRD, będziesz musiał przypisać bonusy rasowe ręcznie w kroku Atrybuty, a cechy wpisać w zakładce Cechy na gotowej karcie.</p>
                </div>
            `;
        }

        return html;
    }

    async function handleRaceChange(e) {
        const val = e.target.value;
        state.subraceObj = null;
        state.customRaceName = '';
        
        if (!val) {
            state.raceObj = null;
            render();
            return;
        }

        App.showToast('Pobieranie informacji o rasie...', 'info');

        if (val.startsWith('srd_')) {
            const idx = val.split('_')[1];
            try {
                state.raceObj = await APIClient.getRace(idx);
                // Pobierz pełne opisy cech (traits)
                if (state.raceObj.traits) {
                    state.raceObj.traits_full = [];
                    for (const t of state.raceObj.traits) {
                        try {
                            const tData = await APIClient.getTrait(t.index);
                            const desc = Array.isArray(tData.desc) ? tData.desc.join('\n') : (tData.desc || '');
                            const trans = await APIClient.translateText(desc);
                            state.raceObj.traits_full.push({ name: tData.name, desc: trans });
                        } catch(err) {
                            state.raceObj.traits_full.push({ name: t.name, desc: 'Brak opisu.' });
                        }
                    }
                }
                if (state.raceObj.subraces && state.raceObj.subraces.length === 1) {
                    state.subraceObj = await APIClient.getSubrace(state.raceObj.subraces[0].index);
                    // Pobierz opisy cech subrasy
                    if (state.subraceObj.racial_traits) {
                        state.subraceObj.traits_full = [];
                        for (const t of state.subraceObj.racial_traits) {
                            try {
                                const tData = await APIClient.getTrait(t.index);
                                const desc = Array.isArray(tData.desc) ? tData.desc.join('\\n') : (tData.desc || '');
                                const trans = await APIClient.translateText(desc);
                                state.subraceObj.traits_full.push({ name: tData.name, desc: trans });
                            } catch(err) {
                                state.subraceObj.traits_full.push({ name: t.name, desc: 'Brak opisu.' });
                            }
                        }
                    }
                }
            } catch(ex) { console.error(ex); App.showToast('Błąd pobierania rasy', 'error'); }
        } else {
            state.customRaceName = val.split('_')[1];
        }
        render();
    }

    async function handleSubraceChange(e) {
        const val = e.target.value;
        state.subraceObj = null;
        if (!val) { render(); return; }
        try {
            state.subraceObj = await APIClient.getSubrace(val);
        } catch(ex) { console.error(ex); }
        render();
    }

    // --- STEP 2: CLASS ---
    function renderStep2() {
        let options = '<option value="">-- Wybierz Klasę --</option>';
        cache.classes.forEach(c => {
            const sel = (state.classObj && state.classObj.index === c.index) ? 'selected' : '';
            options += `<option value="${c.index}" ${sel}>${_esc(c.name)}</option>`;
        });

        let html = `
            <div class="form-group">
                <label>Klasa</label>
                <select id="cm-class-select" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width:100%; padding:8px;">
                    ${options}
                </select>
            </div>
        `;

        if (state.classObj) {
            html += `<div style="margin-top:15px; padding:10px; background:rgba(0,0,0,0.2); border-radius:8px;">`;
            html += `<p><strong style="color:var(--text-gold);">Hit Die:</strong> d${state.classObj.hit_die}</p>`;
            
            let profs = state.classObj.proficiencies.map(p => p.name).filter(p => !p.startsWith('Saving Throw')).join(', ');
            html += `<p><strong style="color:var(--text-gold);">Biegłości:</strong> ${profs || 'Brak'}</p>`;

            if (state.classObj.spellcasting) {
                html += `<p><strong style="color:var(--text-gold);">Atrybut Magiczny:</strong> ${state.classObj.spellcasting.spellcasting_ability.name}</p>`;
            }
            
            html += `<p><strong style="color:var(--text-gold);">Rzuty obronne:</strong> ${state.classObj.saving_throws.map(s => s.name).join(', ')}</p>`;
            
            let classFeatsHtml = '';
            if (state.classObj.features_full && state.classObj.features_full.length > 0) {
                classFeatsHtml = state.classObj.features_full.map(f => `<div style="margin-bottom:8px; padding:8px; background:rgba(0,0,0,0.3); border-radius:4px; border:1px solid var(--border-color);"><strong>${f.name}</strong><div style="font-size:0.85rem;color:var(--text-muted);margin-top:4px;">${f.desc}</div></div>`).join('');
            }
            if (classFeatsHtml) {
                html += `<div style="margin-top:15px;"><strong style="color:var(--text-gold);">Cechy Klasowe (Poziom 1):</strong><br> ${classFeatsHtml}</div>`;
            }

            if (state.classObj.proficiency_choices && state.classObj.proficiency_choices.length > 0) {
                const choice = state.classObj.proficiency_choices[0]; // Usually skills
                const allowed = choice.choose;
                const selectedCount = state.selectedClassSkills.length;
                
                html += `<div style="margin-top:10px;">
                    <strong style="color:var(--text-gold);">Wybierz umiejętności (${selectedCount} / ${allowed}):</strong>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:5px; margin-top:5px;">
                `;

                choice.from.options.forEach(opt => {
                    if (opt.item) {
                        const nameEn = opt.item.name.replace('Skill: ', '');
                        const namePl = SKILL_EN_TO_PL[nameEn] || nameEn;
                        const isSel = state.selectedClassSkills.includes(namePl);
                        const disabled = (!isSel && selectedCount >= allowed) ? 'disabled' : '';
                        html += `
                            <label style="display:flex; align-items:center; gap:5px;">
                                <input type="checkbox" class="cm-skill-cb" value="${namePl}" ${isSel?'checked':''} ${disabled}>
                                <span>${namePl}</span>
                            </label>
                        `;
                    }
                });
                html += `</div></div>`;
            }
            html += `</div>`;
        }
        return html;
    }

    async function handleClassChange(e) {
        const val = e.target.value;
        if (!val) {
            state.classObj = null;
            render();
            return;
        }

        App.showToast('Pobieranie informacji o klasie...', 'info');
        try {
            state.classObj = await APIClient.getClass(val);
            state.classObj.features_full = [];
            const lvlData = await APIClient.getClassLevel(val, 1);
            if (lvlData && lvlData.features) {
                for (const f of lvlData.features) {
                    try {
                        const featData = await APIClient.getFeature(f.index);
                        if (featData) {
                            const desc = Array.isArray(featData.desc) ? featData.desc.join('\n') : (featData.desc || '');
                            const trans = await APIClient.translateText(desc);
                            state.classObj.features_full.push({ name: featData.name, desc: trans });
                        }
                    } catch(err) {
                        state.classObj.features_full.push({ name: f.name, desc: 'Brak opisu.' });
                    }
                }
            }
        } catch(e) {
            console.error(e);
            state.classObj = null;
        }
        
        // Reset selected skills since allowed count changes
        state.selectedClassSkills = [];
        render();
    }

    function handleSkillChange(e) {
        const val = e.target.value;
        if (e.target.checked) {
            if (!state.selectedClassSkills.includes(val)) state.selectedClassSkills.push(val);
        } else {
            state.selectedClassSkills = state.selectedClassSkills.filter(s => s !== val);
        }
        render();
    }

    // --- STEP 3: ABILITY SCORES ---
    function renderStep3() {
        let html = `
            <div style="display:flex; border-bottom:1px solid var(--border-color); margin-bottom:15px;">
                <div class="cm-method-tab ${state.abilityMethod==='standard'?'active':''}" data-m="standard" style="padding:8px 15px; cursor:pointer; color:${state.abilityMethod==='standard'?'var(--text-gold)':'inherit'}; border-bottom:${state.abilityMethod==='standard'?'2px solid var(--gold)':'none'};">Standard Array</div>
                <div class="cm-method-tab ${state.abilityMethod==='pointbuy'?'active':''}" data-m="pointbuy" style="padding:8px 15px; cursor:pointer; color:${state.abilityMethod==='pointbuy'?'var(--text-gold)':'inherit'}; border-bottom:${state.abilityMethod==='pointbuy'?'2px solid var(--gold)':'none'};">Point Buy</div>
                <div class="cm-method-tab ${state.abilityMethod==='manual'?'active':''}" data-m="manual" style="padding:8px 15px; cursor:pointer; color:${state.abilityMethod==='manual'?'var(--text-gold)':'inherit'}; border-bottom:${state.abilityMethod==='manual'?'2px solid var(--gold)':'none'};">Ręcznie</div>
            </div>
        `;

        const attrNames = APIClient.ABILITY_NAMES;
        
        let rb = { str:0, dex:0, con:0, int:0, wis:0, cha:0 };
        if (state.raceObj) {
            state.raceObj.ability_bonuses.forEach(b => { rb[b.ability_score.index] = (rb[b.ability_score.index] || 0) + b.bonus; });
        }
        if (state.subraceObj) {
            state.subraceObj.ability_bonuses.forEach(b => { rb[b.ability_score.index] = (rb[b.ability_score.index] || 0) + b.bonus; });
        }

        if (state.abilityMethod === 'standard') {
            html += `<p style="font-size:0.9rem; color:var(--text-muted);">Przypisz wartości (15, 14, 13, 12, 10, 8) do cech.</p>`;
            html += `<div style="display:grid; grid-template-columns:repeat(6, 1fr); gap:10px;">`;
            attrNames.forEach(attr => {
                const lw = attr.toLowerCase();
                const curVal = state.rawScores[lw];
                let opts = `<option value="8" ${curVal===8?'selected':''}>--</option>`;
                const available = [15,14,13,12,10,8].filter(v => v === curVal || !Object.values(state.rawScores).includes(v));
                available.forEach(v => {
                    if (v !== 8 || curVal === 8) {
                        opts += `<option value="${v}" ${curVal===v?'selected':''}>${v}</option>`;
                    }
                });
                
                html += `
                    <div style="text-align:center;">
                        <div style="color:var(--text-gold); font-weight:bold;">${attr}</div>
                        <select class="cm-score-select" data-attr="${lw}" style="width:100%; padding:5px; background:rgba(0,0,0,0.3); color:white; border:1px solid var(--border-color); margin-top:5px;">
                            ${opts}
                        </select>
                    </div>
                `;
            });
            html += `</div>`;
        } else if (state.abilityMethod === 'pointbuy') {
            html += `<p style="font-size:0.9rem; color:var(--text-muted);">Pozostało punktów: <strong style="color:var(--text-gold); font-size:1.2rem;">${state.pointBuyRemaining}</strong></p>`;
            html += `<div style="display:grid; grid-template-columns:repeat(6, 1fr); gap:10px;">`;
            attrNames.forEach(attr => {
                const lw = attr.toLowerCase();
                const curVal = state.rawScores[lw];
                html += `
                    <div style="text-align:center;">
                        <div style="color:var(--text-gold); font-weight:bold;">${attr}</div>
                        <div style="display:flex; justify-content:center; align-items:center; margin-top:5px; gap:5px;">
                            <button class="cm-score-btn btn-secondary btn-small" data-attr="${lw}" data-dir="-1" style="padding:2px 8px;">-</button>
                            <span style="font-weight:bold;">${curVal}</span>
                            <button class="cm-score-btn btn-secondary btn-small" data-attr="${lw}" data-dir="1" style="padding:2px 8px;">+</button>
                        </div>
                    </div>
                `;
            });
            html += `</div>`;
        } else {
            html += `<p style="font-size:0.9rem; color:var(--text-muted);">Wpisz wartości bazowe ręcznie (bez bonusów rasowych).</p>`;
            html += `<div style="display:grid; grid-template-columns:repeat(6, 1fr); gap:10px;">`;
            attrNames.forEach(attr => {
                const lw = attr.toLowerCase();
                html += `
                    <div style="text-align:center;">
                        <div style="color:var(--text-gold); font-weight:bold;">${attr}</div>
                        <input type="number" class="cm-manual-input" data-attr="${lw}" value="${state.rawScores[lw]}" min="1" max="20" style="width:100%; padding:5px; text-align:center; background:rgba(0,0,0,0.3); color:white; border:1px solid var(--border-color); margin-top:5px;">
                    </div>
                `;
            });
            html += `</div>`;
        }

        html += `<h4 style="margin-top:25px; color:var(--text-gold); text-align:center;">Finalne Wyniki (z bonusem rasowym)</h4>`;
        html += `<div style="display:grid; grid-template-columns:repeat(6, 1fr); gap:10px; background:rgba(0,0,0,0.2); padding:10px; border-radius:8px;">`;
        attrNames.forEach(attr => {
            const lw = attr.toLowerCase();
            const raw = state.rawScores[lw];
            const bonus = rb[lw] || 0;
            const final = raw + bonus;
            const mod = APIClient.modifierString(final);
            html += `
                <div style="text-align:center;">
                    <div style="font-size:0.8rem; color:var(--text-muted);">${attr}</div>
                    <div style="font-size:1.5rem; font-weight:bold;">${final}</div>
                    <div style="font-size:0.9rem; color:${bonus > 0 ? 'var(--emerald-light)' : 'var(--text-muted)'};">${mod}</div>
                </div>
            `;
        });
        html += `</div>`;
        return html;
    }

    function handleMethodChange(e) {
        const m = e.target.dataset.m;
        if (m === state.abilityMethod) return;
        state.abilityMethod = m;
        state.rawScores = { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 };
        state.pointBuyRemaining = 27;
        render();
    }

    function handleScoreChange(e) {
        const attr = e.target.dataset.attr;
        if (state.abilityMethod === 'standard') {
            state.rawScores[attr] = parseInt(e.target.value);
            render();
        } else if (state.abilityMethod === 'pointbuy') {
            const dir = parseInt(e.target.dataset.dir);
            const cur = state.rawScores[attr];
            const pbCost = { 8:0, 9:1, 10:2, 11:3, 12:4, 13:5, 14:7, 15:9 };
            let newVal = cur + dir;
            if (newVal < 8 || newVal > 15) return;
            const costDiff = pbCost[newVal] - pbCost[cur];
            if (costDiff > state.pointBuyRemaining) {
                App.showToast('Brak punktów', 'warning');
                return;
            }
            state.rawScores[attr] = newVal;
            state.pointBuyRemaining -= costDiff;
            render();
        }
    }

    function handleManualScoreChange(e) {
        const attr = e.target.dataset.attr;
        let val = parseInt(e.target.value) || 8;
        if (val < 1) val = 1; if (val > 20) val = 20;
        state.rawScores[attr] = val;
        render();
    }

    // --- STEP 4: BACKGROUND ---
    function renderStep4() {
        let options = '<option value="">-- Wybierz Pochodzenie --</option>';
        Object.keys(BACKGROUNDS).forEach(k => {
            const sel = state.backgroundId === k ? 'selected' : '';
            options += `<option value="${k}" ${sel}>${BACKGROUNDS[k].name}</option>`;
        });

        let html = `
            <div class="form-group">
                <label>Pochodzenie (Background)</label>
                <select id="cm-bg-select" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width:100%; padding:8px;">
                    ${options}
                </select>
            </div>
        `;

        if (state.backgroundId) {
            const bg = BACKGROUNDS[state.backgroundId];
            html += `<div style="margin-top:15px; padding:10px; background:rgba(0,0,0,0.2); border-radius:8px;">`;
            
            const skillsPl = bg.skills.map(s => SKILL_EN_TO_PL[s] || s).join(', ');
            html += `<p><strong style="color:var(--text-gold);">Biegłości (Umiejętności):</strong> ${skillsPl}</p>`;
            
            const tools = bg.tools.length > 0 ? bg.tools.join(', ') : 'Brak';
            html += `<p><strong style="color:var(--text-gold);">Biegłości (Narzędzia):</strong> ${tools}</p>`;
            
            html += `<p><strong style="color:var(--text-gold);">Złoto Startowe:</strong> ${bg.gold} GP</p>`;
            html += `<p><strong style="color:var(--text-gold);">Dodatkowe języki:</strong> ${bg.languages}</p>`;
            html += `</div>`;
        }

        return html;
    }

    function handleBgChange(e) {
        state.backgroundId = e.target.value;
        if (state.backgroundId) {
            state.backgroundObj = BACKGROUNDS[state.backgroundId];
        } else {
            state.backgroundObj = null;
        }
        render();
    }

    // --- STEP 5: DETAILS ---
    function renderStep5() {
        const ALIGNMENTS = ['Praworządny Dobry','Neutralny Dobry','Chaotyczny Dobry','Praworządny Neutralny','Neutralny','Chaotyczny Neutralny','Praworządny Zły','Neutralny Zły','Chaotyczny Zły'];
        let alignOpts = '<option value="">-- Wybierz Charakter --</option>';
        ALIGNMENTS.forEach(a => {
            const sel = state.alignment === a ? 'selected' : '';
            alignOpts += `<option value="${a}" ${sel}>${a}</option>`;
        });

        // Compute languages from race & background
        let autoLangs = [];
        if (state.raceObj && state.raceObj.languages) {
            autoLangs.push(...state.raceObj.languages.map(l => l.name));
        }
        if (state.customRaceName) {
            autoLangs.push('Common'); // Default assumption
        }
        
        let extraLangCount = 0;
        if (state.backgroundObj) extraLangCount += state.backgroundObj.languages;
        
        autoLangs = [...new Set(autoLangs)]; // deduplicate

        let html = `
            <div class="form-group">
                <label>Imię Postaci</label>
                <input type="text" id="cm-name" value="${_esc(state.name)}" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width:100%; padding:8px;">
            </div>
            <div class="form-group" style="margin-top:15px;">
                <label>Charakter (Alignment)</label>
                <select id="cm-alignment" style="background: rgba(0,0,0,0.3); color: var(--text-primary); border: 1px solid var(--border-color); width:100%; padding:8px;">
                    ${alignOpts}
                </select>
            </div>
            
            <div style="margin-top:20px; padding:10px; background:rgba(0,0,0,0.2); border-radius:8px;">
                <h4 style="margin:0 0 10px; color:var(--text-gold);">Języki</h4>
                <p style="font-size:0.9rem;">Otrzymane z rasy: <strong style="color:white;">${autoLangs.join(', ')}</strong></p>
        `;

        if (extraLangCount > 0) {
            html += `<p style="font-size:0.9rem; color:var(--emerald-light);">Dodatkowe języki do wyboru z pochodzenia: ${extraLangCount} (Do uzupełnienia na pełnej karcie)</p>`;
        }
        html += `</div>`;
        return html;
    }

    // --- STEP 6: EQUIPMENT ---
    function renderStep6() {
        const classIndex = state.classObj ? state.classObj.index : '';
        const kit = window.Kits ? Kits.CLASS_KITS[Kits.classKey(classIndex)] : null;
        if (!kit && state.equipmentMethod === 'class') state.equipmentMethod = 'gold';
        state.kitPicks = state.kitPicks || [];

        let html = `
            <div class="cm-equip-switch">
                <label class="cm-equip-opt ${state.equipmentMethod === 'class' ? 'is-on' : ''} ${kit ? '' : 'is-off'}">
                    <input type="radio" name="cm-equip-method" value="class" ${state.equipmentMethod === 'class' ? 'checked' : ''} ${kit ? '' : 'disabled'}>
                    <i class="fa-solid fa-box-open"></i>
                    <span><b>Gotowy zestaw</b><small>Ekwipunek klasy i pochodzenia wpisany od razu na kartę</small></span>
                </label>
                <label class="cm-equip-opt ${state.equipmentMethod === 'gold' ? 'is-on' : ''}">
                    <input type="radio" name="cm-equip-method" value="gold" ${state.equipmentMethod === 'gold' ? 'checked' : ''}>
                    <i class="fa-solid fa-coins"></i>
                    <span><b>Złoto startowe</b><small>Kupujesz sam — przedmioty dopiszesz później</small></span>
                </label>
            </div>`;

        if (state.equipmentMethod === 'gold' || !kit) {
            const gold = STARTING_GOLD[classIndex] || 100;
            const bgGold = state.backgroundObj ? state.backgroundObj.gold : 0;
            html += `
                <div class="cm-kit-box" style="text-align:center;">
                    <p>Złoto początkowe klasy + sakiewka z pochodzenia:</p>
                    <div class="cm-kit-gold">${gold + bgGold} sz</div>
                    <p class="cm-kit-hint">Przedmioty dodasz w zakładce Ekwipunek na karcie postaci.</p>
                </div>`;
            return html;
        }

        const choices = kit.choices.map((opts, i) => `
            <div class="cm-kit-choice">
                <div class="cm-kit-choice-label">Wybór ${i + 1}</div>
                <div class="cm-kit-chips">
                    ${opts.map((o, j) => `<label class="cm-kit-chip ${(state.kitPicks[i] || 0) === j ? 'is-on' : ''}">
                        <input type="radio" name="cm-kit-${i}" value="${j}" data-kit="${i}" ${(state.kitPicks[i] || 0) === j ? 'checked' : ''}>${_esc(o.label)}</label>`).join('')}
                </div>
            </div>`).join('');
        const fixed = Kits.fixedSummary(classIndex);
        const items = Kits.buildClassKit(classIndex, state.kitPicks);
        const bgItems = Kits.buildBackgroundKit(state.backgroundId);
        const all = Kits.mergeInto(items.map(i => ({ ...i })), bgItems);
        const scores = { str: getFinalScore('str'), dex: getFinalScore('dex'), con: getFinalScore('con'), int: getFinalScore('int'), wis: getFinalScore('wis'), cha: getFinalScore('cha') };
        const preview = { class: classIndex, level: 1, abilityScores: scores, inventory: all };
        const ac = Kits.computeAC(preview);
        const atk = Kits.attacks(preview, 4);
        const weight = all.reduce((s, i) => s + (i.weight || 0) * i.quantity, 0);
        const bgGold = state.backgroundObj ? state.backgroundObj.gold : 0;

        html += `
            <div class="cm-kit-box">
                ${choices}
                ${fixed.length ? `<div class="cm-kit-choice"><div class="cm-kit-choice-label">Zawsze w zestawie</div><div class="cm-kit-fixed">${fixed.map(f => `<span>${_esc(f)}</span>`).join('')}</div></div>` : ''}
            </div>
            <div class="cm-kit-summary">
                <div class="cm-kit-stat"><i class="fa-solid fa-shield-halved"></i><b>${ac}</b><small>KP</small></div>
                <div class="cm-kit-stat"><i class="fa-solid fa-weight-hanging"></i><b>${Math.round(weight)}</b><small>lb</small></div>
                <div class="cm-kit-stat"><i class="fa-solid fa-coins"></i><b>${bgGold}</b><small>sz</small></div>
                <div class="cm-kit-atk">${atk.map(a => `<span><b>${_esc(a.name)}</b> ${a.hit >= 0 ? '+' : ''}${a.hit} · ${a.dmg}</span>`).join('') || '<span>brak broni</span>'}</div>
            </div>
            <details class="cm-kit-list" open>
                <summary>Zostanie wpisane na kartę (${all.length} pozycji)</summary>
                <div>${all.map(i => `<span>${_esc(i.name)}${i.quantity > 1 ? ` <em>×${i.quantity}</em>` : ''}</span>`).join('')}</div>
            </details>`;
        return html;
    }

    // --- STEP 7: SPELLS ---
    function renderStep7() {
        if (!state.classObj || !state.classObj.spellcasting) {
            return `
                <div style="text-align:center; margin-top:30px;">
                    <h3 style="color:var(--text-gold);">Brak Magii</h3>
                    <p style="color:var(--text-muted);">Twoja klasa (${state.classObj ? state.classObj.name : 'Nieznana'}) nie używa zaklęć na 1 poziomie.</p>
                    <p>Przejdź dalej aby zakończyć.</p>
                </div>
            `;
        }

        const scInfo = state.classObj.spellcasting;
        const attr = scInfo.spellcasting_ability.name; // e.g. INT
        const mod = APIClient.abilityModifier(getFinalScore(attr.toLowerCase()));
        const prof = 2; // level 1
        const dc = 8 + prof + mod;
        const atk = prof + mod;

        let html = `
            <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px; text-align:center; margin-bottom:20px;">
                <div style="background:rgba(0,0,0,0.3); border:1px solid var(--border-color); padding:10px; border-radius:8px;">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Atrybut</div>
                    <div style="font-size:1.2rem; font-weight:bold; color:var(--text-gold);">${attr}</div>
                </div>
                <div style="background:rgba(0,0,0,0.3); border:1px solid var(--border-color); padding:10px; border-radius:8px;">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Spell Save DC</div>
                    <div style="font-size:1.2rem; font-weight:bold; color:white;">${dc}</div>
                </div>
                <div style="background:rgba(0,0,0,0.3); border:1px solid var(--border-color); padding:10px; border-radius:8px;">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Spell Attack Mod</div>
                    <div style="font-size:1.2rem; font-weight:bold; color:white;">+${atk}</div>
                </div>
            </div>
        `;
        const lim = window.SpellPicker ? SpellPicker.limits(state.classObj.index, 1, { wis: getFinalScore('wis'), cha: getFinalScore('cha'), int: getFinalScore('int') }) : { cantrips: 0, spells: 0 };
        if (!lim.cantrips && !lim.spells) {
            html += `<div class="cm-kit-box" style="text-align:center;"><p>Na 1. poziomie ta klasa nie zna jeszcze zaklęć — czary dojdą przy awansie na 2. poziom.</p></div>`;
        } else {
            html += `<p class="cm-kit-hint" style="margin:0 0 8px;">Wybierz zaklęcia dostępne na 1. poziomie. Kliknij nazwę, aby przeczytać opis.</p><div id="cm-spell-picker"></div>`;
        }

        return html;
    }

    // --- HELPERS ---
    function getFinalScore(attr) {
        let bonus = 0;
        if (state.raceObj) state.raceObj.ability_bonuses.forEach(b => { if (b.ability_score.index === attr) bonus += b.bonus; });
        if (state.subraceObj) state.subraceObj.ability_bonuses.forEach(b => { if (b.ability_score.index === attr) bonus += b.bonus; });
        return (state.rawScores[attr] || 8) + bonus;
    }

    // --- NAVIGATION ---
    function prevStep() {
        if (currentStep > 1) {
            currentStep--;
            render();
        }
    }

    function nextStep() {
        // Validation
        if (currentStep === 1 && !state.raceObj && !state.customRaceName) {
            App.showToast('Wybierz rasę!', 'warning'); return;
        }
        if (currentStep === 2 && !state.classObj) {
            App.showToast('Wybierz klasę!', 'warning'); return;
        }
        if (currentStep === 2 && state.classObj && state.classObj.proficiency_choices && state.classObj.proficiency_choices.length > 0) {
            const allowed = state.classObj.proficiency_choices[0].choose;
            if (state.selectedClassSkills.length !== allowed) {
                App.showToast(`Wybierz dokładnie ${allowed} umiejętności.`, 'warning'); return;
            }
        }
        if (currentStep === 4 && !state.backgroundId) {
            App.showToast('Wybierz pochodzenie!', 'warning'); return;
        }
        if (currentStep === 5 && !state.name.trim()) {
            App.showToast('Imię postaci nie może być puste!', 'warning'); return;
        }

        if (currentStep < TOTAL_STEPS) {
            currentStep++;
            render();
        }
    }

    async function finish() {
        const campaignId = App.getActiveCampaignId();
        if (!campaignId) return;

        const finalScores = {
            str: getFinalScore('str'), dex: getFinalScore('dex'), con: getFinalScore('con'),
            int: getFinalScore('int'), wis: getFinalScore('wis'), cha: getFinalScore('cha')
        };

        const hitDie = state.classObj ? state.classObj.hit_die : 8;
        const maxHP = hitDie + APIClient.abilityModifier(finalScores.con);

        const saves = state.classObj ? state.classObj.saving_throws.map(s => s.name.substring(0,3).toUpperCase()) : [];
        
        let profs = [...state.selectedClassSkills];
        let toolProfs = [];
        let extraGold = 0;
        let bgLangs = 0;

        if (state.backgroundObj) {
            state.backgroundObj.skills.forEach(s => {
                const pName = SKILL_EN_TO_PL[s] || s;
                if (!profs.includes(pName)) profs.push(pName);
            });
            toolProfs = [...state.backgroundObj.tools];
            extraGold = state.backgroundObj.gold || 0;
            bgLangs = state.backgroundObj.languages || 0;
        }

        let wProfs = [], aProfs = [];
        if (state.classObj && state.classObj.proficiencies) {
            state.classObj.proficiencies.forEach(p => {
                if (!p.name.startsWith('Saving Throw') && !p.name.startsWith('Skill')) {
                    if (p.name.toLowerCase().includes('armor') || p.name.toLowerCase().includes('shield')) {
                        aProfs.push(p.name);
                    } else {
                        wProfs.push(p.name);
                    }
                }
            });
        }

        let langs = [];
        if (state.raceObj && state.raceObj.languages) {
            langs.push(...state.raceObj.languages.map(l => l.name));
        }
        if (state.customRaceName) langs.push('Common');

        let gp = extraGold;
        let equip = [];
        if (state.equipmentMethod === 'gold') {
            const classIndex = state.classObj ? state.classObj.index : '';
            gp += STARTING_GOLD[classIndex] || 100;
        } else if (window.Kits && state.classObj && Kits.CLASS_KITS[Kits.classKey(state.classObj.index)]) {
            equip = Kits.buildClassKit(state.classObj.index, state.kitPicks || []);
            Kits.mergeInto(equip, Kits.buildBackgroundKit(state.backgroundId));
        } else if (state.classObj && state.classObj.starting_equipment) {
            state.classObj.starting_equipment.forEach(se => {
                equip.push({ name: se.equipment.name, quantity: se.quantity, weight: 0 });
            });
        }

        let traits = [];
        if (state.raceObj && state.raceObj.traits) traits.push(...state.raceObj.traits);
        if (state.subraceObj && state.subraceObj.racial_traits) traits.push(...state.subraceObj.racial_traits);

        // Przygotowanie do pobrania pełnych danych o cechach i traitsach
        App.showToast('Generowanie postaci, pobieranie danych...', 'info');

        let fullTraits = [];
        for (const t of traits) {
            try {
                if (t.index) {
                    const tData = await APIClient.getTrait(t.index);
                    if (tData) {
                        const desc = Array.isArray(tData.desc) ? tData.desc.join('\\n') : (tData.desc || '');
                        const trans = await APIClient.translateText(desc);
                        fullTraits.push({ name: tData.name, index: t.index, desc: trans });
                        continue;
                    }
                }
            } catch(e) {}
            fullTraits.push({ name: t.name || t, index: t.index || '', desc: 'Opis niedostępny w SRD.' });
        }

        let classFeats = [];
        if (state.classObj) {
            try {
                const lvlData = await APIClient.getClassLevel(state.classObj.index, 1);
                if (lvlData && lvlData.features) {
                    for (const f of lvlData.features) {
                        try {
                            const featData = await APIClient.getFeature(f.index);
                            if (featData) {
                                const desc = Array.isArray(featData.desc) ? featData.desc.join('\\n') : (featData.desc || '');
                                const trans = await APIClient.translateText(desc);
                                classFeats.push({ name: featData.name, index: f.index, desc: trans });
                            }
                        } catch(e) {
                            classFeats.push({ name: f.name, index: f.index, desc: '' });
                        }
                    }
                }
            } catch(e) {}
        }

        const charObj = {
            id: StorageManager.generateId(),
            name: state.name.trim(),
            race: state.raceObj ? state.raceObj.name : state.customRaceName,
            subrace: state.subraceObj ? state.subraceObj.name : '',
            class: state.classObj ? state.classObj.name : '',
            level: 1,
            alignment: state.alignment,
            background: state.backgroundObj ? BACKGROUNDS[state.backgroundId].name : '',
            size: state.raceObj ? state.raceObj.size : 'Medium',
            speed: state.raceObj ? state.raceObj.speed : 30,
            darkvision: traits.some(t => t.index === 'darkvision') ? 60 : 0,
            languages: [...new Set(langs)],
            ac: window.Kits ? Kits.computeAC({ class: state.classObj ? state.classObj.index : '', abilityScores: finalScores, inventory: equip }) : 10 + APIClient.abilityModifier(finalScores.dex),
            hp: { current: maxHP, max: maxHP, temp: 0 },
            hitDie: hitDie,
            abilityScores: finalScores,
            proficiencies: profs,
            savingThrows: saves,
            weaponProficiencies: wProfs,
            armorProficiencies: aProfs,
            toolProficiencies: toolProfs,
            spellcastingAbility: state.classObj && state.classObj.spellcasting ? state.classObj.spellcasting.spellcasting_ability.name : '',
            spellSlots: {},
            spells: (state.selectedSpells || []).map(x => ({ ...x })),
            spellsNotes: '',
            inventory: equip,
            currency: { cp: 0, sp: 0, ep: 0, gp: gp, pp: 0 },
            features: { class: '', feats: '' },
            traits: fullTraits,
            classFeatures: classFeats,
            backstory: { personality: '', ideals: '', bonds: '', flaws: '', history: '' },
            notes: '',
            deathSaves: { successes: 0, failures: 0 },
            xp: 0
        };

        // Fetch spell slots for level 1
        if (charObj.spellcastingAbility) {
            try {
                const cIndex = state.classObj.index;
                const lvlData = await APIClient.getClassLevel(cIndex, 1);
                if (lvlData && lvlData.spellcasting) {
                    if (lvlData.spellcasting.spell_slots_level_1 > 0) {
                        charObj.spellSlots[1] = { used: 0, total: lvlData.spellcasting.spell_slots_level_1 };
                    }
                }
            } catch(e) {}
        }

        StorageManager.saveCharacter(campaignId, charObj);
        App.closeModal();
        App.showToast('Postać pomyślnie utworzona!', 'success');
        
        if (window.CharactersModule) {
            window.CharactersModule.activate();
            window.CharactersModule.showCharacterSheet(charObj.id);
            // Optionally auto-open languages modal if they have choices pending
            if (bgLangs > 0) {
                setTimeout(() => {
                    App.showToast(`Pamiętaj, by dodać ${bgLangs} język(i) z pochodzenia!`, 'info');
                    window.CharactersModule.addLanguage();
                }, 1000);
            }
        }
    }

    return { 
        open: openModal,
        prevStep: prevStep,
        nextStep: nextStep,
        finish: finish
    };
})();

window.Charactermancer = Charactermancer;
