// ============================================================
// NotesModule — szybkie notatki
// - notatka „przypięta” wisi na ekranie (nad każdą zakładką),
// - „schowana” czeka w kafelku Szybkie notatki na Pulpicie,
// - kolory karteczek, zwijanie, zmiana rozmiaru, przeciąganie,
// - animacja przypinania (pinezka) i chowania (odlot do Pulpitu).
// ============================================================
const NotesModule = (() => {
    const COLORS = {
        parchment: { name: 'Pergamin', bg: '#f1e3bf', edge: '#c9a35c' },
        rose:      { name: 'Róż',      bg: '#f4c9c4', edge: '#b4554b' },
        mint:      { name: 'Mięta',    bg: '#cfe8cf', edge: '#4f8a5c' },
        sky:       { name: 'Błękit',   bg: '#cddff2', edge: '#4c6f9c' },
        lavender:  { name: 'Lawenda',  bg: '#ddd0ee', edge: '#7a5a9e' },
        peach:     { name: 'Brzoskwinia', bg: '#f6d6b0', edge: '#c07a32' },
        ink:       { name: 'Atrament', bg: '#2e2620', edge: '#c9a35c', dark: true }
    };
    // stare nazwy kolorów → nowe
    const LEGACY = { default: 'parchment', red: 'rose', green: 'mint', blue: 'sky', purple: 'lavender', gold: 'peach' };
    const SAVE_MS = 350;
    const timers = {};

    const cid = () => App.getActiveCampaignId();
    const esc = (s) => App.esc(s);
    const colorOf = (c) => COLORS[LEGACY[c] || c] ? (LEGACY[c] || c) : 'parchment';
    const reduceMotion = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

    function all() { return cid() ? (StorageManager.getNotes(cid()) || []) : []; }
    function get(id) { return all().find(n => n.id === id); }
    function put(note) {
        note.updatedAt = Date.now();
        StorageManager.saveNote(cid(), note);
        if (window.App && App.currentTab === 'dashboard') App.updateDashboard();
    }

    // ── Public API ──────────────────────────────────────────
    function init() {
        document.getElementById('btn-add-note')?.addEventListener('click', () => newNote());
        window.addEventListener('resize', () => document.querySelectorAll('#overlay .draggable-note').forEach(clampIntoView));
        loadNotes();
    }

    function newNote(opts = {}) {
        if (!cid()) { App.showToast('Najpierw wybierz kampanię', 'warning'); return null; }
        const w = 280;
        const note = {
            id: StorageManager.generateId(),
            title: opts.title || 'Nowa notatka',
            content: opts.content || '',
            color: colorOf(opts.color || 'parchment'),
            type: opts.type || 'text',
            x: Math.round(window.innerWidth / 2 - w / 2 + (Math.random() * 120 - 60)),
            y: Math.round(window.innerHeight / 3 + (Math.random() * 80 - 40)),
            width: w, height: null,
            collapsed: false,
            pinned: opts.pinned !== false,
            pos2: true,
            createdAt: Date.now()
        };
        put(note);
        if (note.pinned) {
            const el = mount(note, { animate: true });
            if (!opts.content) setTimeout(() => el?.querySelector('.note-textarea')?.focus(), 450);
        }
        return note;
    }

    // zgodność wsteczna: createNote({title, content, color, type})
    function createNote(options = {}) {
        if (options.id) return mount({ ...options, color: colorOf(options.color) });
        return newNote(options);
    }

    function loadNotes() {
        clearOverlay();
        all().forEach(n => {
            // stare notatki liczyły pozycję od krawędzi menu (280 px) — przelicz raz na cały ekran
            if (!n.pos2) { n.x = (n.x || 0) + 280; n.pos2 = true; StorageManager.saveNote(cid(), n); }
            const pinned = n.pinned !== false; // stare notatki były zawsze na ekranie
            if (pinned) mount({ ...n, color: colorOf(n.color) });
        });
    }

    function clearOverlay() {
        document.querySelectorAll('#overlay .draggable-note').forEach(el => el.remove());
    }
    function refreshNotes() { loadNotes(); }

    // Postrzępione brzegi starej kartki — inne dla każdej notatki (losowanie z id)
    function tornEdge(id) {
        let seed = 0; for (const ch of String(id)) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
        const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
        const pts = [], step = 4, j = (m) => (rnd() * m).toFixed(2);
        for (let x = 0; x <= 100; x += step) pts.push(`${x}% ${j(1.6)}%`);                 // góra
        for (let y = step; y <= 100; y += step) pts.push(`${(100 - rnd() * 1.4).toFixed(2)}% ${y}%`); // prawa
        for (let x = 100 - step; x >= 0; x -= step) pts.push(`${x}% ${(100 - rnd() * 2.6).toFixed(2)}%`); // dół
        for (let y = 100 - step; y > 0; y -= step) pts.push(`${j(1.4)}% ${y}%`);           // lewa
        return `polygon(${pts.join(',')})`;
    }

    // ── Okno notatki ────────────────────────────────────────
    function mount(n, { animate = false } = {}) {
        const overlay = document.getElementById('overlay');
        if (!overlay) return null;
        document.getElementById(`note-${n.id}`)?.remove();
        const c = COLORS[colorOf(n.color)];

        const el = document.createElement('div');
        el.className = `draggable-note qn ${c.dark ? 'qn-dark' : ''} ${n.collapsed ? 'collapsed' : ''}`;
        el.id = `note-${n.id}`;
        el.dataset.noteId = n.id;
        el.dataset.noteType = n.type || 'text';
        el.style.setProperty('--qn-bg', c.bg);
        el.style.setProperty('--qn-edge', c.edge);
        el.style.left = `${n.x ?? 120}px`;
        el.style.top = `${n.y ?? 120}px`;
        el.style.width = `${n.width || 280}px`;
        if (n.height && !n.collapsed) el.style.height = `${n.height}px`;
        el.style.setProperty('--tilt', `${((n.id.charCodeAt(n.id.length - 1) % 5) - 2) * 0.6}deg`);

        el.innerHTML = `
            <div class="qn-paper" aria-hidden="true" style="clip-path:${tornEdge(n.id)}"></div>
            <span class="qn-pin" aria-hidden="true"></span>
            <div class="note-header qn-head">
                <span class="note-title" title="Kliknij, aby zmienić tytuł">${esc(n.title || 'Notatka')}</span>
                <input class="note-title-input hidden" type="text" maxlength="80">
                <div class="note-controls">
                    <button class="note-btn" data-act="color" title="Kolor karteczki"><i class="fa-solid fa-palette"></i></button>
                    <button class="note-btn" data-act="collapse" title="Zwiń do zakładki / rozwiń (albo dwuklik w pasek)"><i class="fa-solid ${n.collapsed ? 'fa-chevron-down' : 'fa-chevron-up'}"></i></button>
                    <button class="note-btn" data-act="stash" title="Schowaj na Pulpit"><i class="fa-solid fa-box-archive"></i></button>
                    <button class="note-btn" data-act="delete" title="Usuń"><i class="fa-solid fa-trash"></i></button>
                </div>
            </div>
            <div class="note-body">
                <textarea class="note-textarea" placeholder="Pisz… (zapisuje się samo)"></textarea>
            </div>
            <div class="qn-foot"><span class="qn-saved"></span></div>`;
        el.querySelector('.note-title-input').value = n.title || '';
        el.querySelector('.note-textarea').value = (n.content || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/?strong>/gi, '');

        overlay.appendChild(el);
        DraggableManager.makeDraggable(el, '.note-header');
        DraggableManager.makeResizable(el);
        clampIntoView(el);
        DraggableManager.bringToFront(el);

        bind(el, n.id);
        if (animate && !reduceMotion()) {
            el.classList.add('qn-pinning');
            el.addEventListener('animationend', (e) => { if (e.target === el) el.classList.remove('qn-pinning'); });
        }
        return el;
    }

    function bind(el, id) {
        const title = el.querySelector('.note-title');
        const input = el.querySelector('.note-title-input');
        title.addEventListener('click', (e) => {
            e.stopPropagation();
            title.classList.add('hidden'); input.classList.remove('hidden');
            input.focus(); input.select();
        });
        const commit = () => {
            const v = input.value.trim() || 'Notatka';
            title.textContent = v; title.classList.remove('hidden'); input.classList.add('hidden');
            save(id, { title: v });
        };
        input.addEventListener('blur', commit);
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } if (e.key === 'Escape') { input.value = title.textContent; input.blur(); } });

        el.querySelector('.note-controls').addEventListener('click', (e) => {
            const b = e.target.closest('[data-act]'); if (!b) return;
            e.stopPropagation();
            ({ color: () => colorPicker(el, id), collapse: () => toggleCollapse(id), stash: () => stash(id), delete: () => deleteNote(id) })[b.dataset.act]();
        });
        el.querySelector('.note-textarea').addEventListener('input', (e) => save(id, { content: e.target.value }, true));
        el.addEventListener('mousedown', () => DraggableManager.bringToFront(el));
        el.querySelector('.qn-head').addEventListener('dblclick', (e) => { if (e.target.closest('.note-controls, .note-title-input, .note-title')) return; toggleCollapse(id); });
        // zapis pozycji/rozmiaru po puszczeniu myszy
        el.addEventListener('mouseup', () => setTimeout(() => {
            const patch = { x: parseInt(el.style.left, 10) || 0, y: parseInt(el.style.top, 10) || 0, width: el.offsetWidth };
            if (!el.classList.contains('collapsed')) patch.height = el.style.height ? el.offsetHeight : null;
            save(id, patch);
        }, 0));
    }

    function save(id, patch, debounce = false) {
        const run = () => {
            const n = get(id); if (!n) return;
            Object.assign(n, patch);
            put(n);
            const el = document.getElementById(`note-${id}`);
            const s = el?.querySelector('.qn-saved');
            if (s) { s.textContent = 'zapisano'; s.classList.add('show'); clearTimeout(s._t); s._t = setTimeout(() => s.classList.remove('show'), 1200); }
        };
        if (!debounce) return run();
        clearTimeout(timers[id]); timers[id] = setTimeout(run, SAVE_MS);
    }

    function clampIntoView(el) {
        const r = el.getBoundingClientRect();
        const maxX = window.innerWidth - Math.min(r.width, window.innerWidth) - 8;
        const maxY = window.innerHeight - Math.min(r.height, window.innerHeight - 16) - 8;
        const x = Math.max(8, Math.min(parseInt(el.style.left, 10) || 0, maxX));
        const y = Math.max(8, Math.min(parseInt(el.style.top, 10) || 0, maxY));
        el.style.left = x + 'px'; el.style.top = y + 'px';
    }

    // ── Akcje ───────────────────────────────────────────────
    function toggleCollapse(id) {
        const el = document.getElementById(`note-${id}`); if (!el) return;
        const collapsed = !el.classList.contains('collapsed');
        el.classList.toggle('collapsed', collapsed);
        if (collapsed) el.style.height = '';
        else { const n = get(id); if (n?.height) el.style.height = n.height + 'px'; }
        el.querySelector('[data-act="collapse"] i').className = `fa-solid ${collapsed ? 'fa-chevron-down' : 'fa-chevron-up'}`;
        save(id, { collapsed });
    }

    function changeColor(id, color) {
        color = colorOf(color);
        const c = COLORS[color];
        const el = document.getElementById(`note-${id}`);
        if (el) {
            el.style.setProperty('--qn-bg', c.bg); el.style.setProperty('--qn-edge', c.edge);
            el.classList.toggle('qn-dark', !!c.dark);
            el.classList.remove('qn-recolor'); void el.offsetWidth; el.classList.add('qn-recolor');
        }
        save(id, { color });
    }

    function colorPicker(el, id) {
        const old = el.querySelector('.qn-palette');
        if (old) { old.remove(); return; }
        const cur = colorOf(get(id)?.color);
        const pal = document.createElement('div');
        pal.className = 'qn-palette';
        pal.innerHTML = Object.entries(COLORS).map(([k, c]) => `<button data-c="${k}" title="${c.name}" class="${k === cur ? 'active' : ''}" style="--sw:${c.bg};--swe:${c.edge}"></button>`).join('');
        pal.addEventListener('click', (e) => { const b = e.target.closest('[data-c]'); if (!b) return; e.stopPropagation(); changeColor(id, b.dataset.c); pal.remove(); });
        el.appendChild(pal);
        const off = (e) => { if (!pal.contains(e.target) && !e.target.closest('[data-act="color"]')) { pal.remove(); document.removeEventListener('mousedown', off, true); } };
        setTimeout(() => document.addEventListener('mousedown', off, true), 0);
    }

    // schowaj: karteczka odlatuje do Pulpitu
    function stash(id) {
        const el = document.getElementById(`note-${id}`);
        save(id, { pinned: false });
        if (!el) return;
        const target = document.querySelector('.nav-tab[data-tab="dashboard"]') || document.getElementById('btn-add-note');
        if (target && !reduceMotion()) {
            const r = el.getBoundingClientRect(), t = target.getBoundingClientRect();
            el.style.setProperty('--fx', `${t.left + t.width / 2 - (r.left + r.width / 2)}px`);
            el.style.setProperty('--fy', `${t.top + t.height / 2 - (r.top + r.height / 2)}px`);
            el.classList.add('qn-stashing');
            setTimeout(() => el.remove(), 560);
            target.classList.remove('qn-receive'); void target.offsetWidth; target.classList.add('qn-receive');
        } else el.remove();
        App.showToast('Notatka schowana na Pulpicie', 'info');
    }

    // przypnij na ekran z animacją pinezki
    function pin(id) {
        const n = get(id); if (!n) return;
        n.pinned = true;
        // jeśli była poza ekranem — wróć w widoczne miejsce
        if (n.x == null || n.x > window.innerWidth - 60 || n.y > window.innerHeight - 60) { n.x = Math.round(window.innerWidth / 2 - 140); n.y = Math.round(window.innerHeight / 3); }
        put(n);
        mount({ ...n, color: colorOf(n.color) }, { animate: true });
    }

    function deleteNote(id) {
        const n = get(id); if (!n) return;
        const el = document.getElementById(`note-${id}`);
        const doDelete = () => {
            StorageManager.deleteNote(cid(), id);
            if (App.currentTab === 'dashboard') App.updateDashboard();
        };
        if (el && !reduceMotion()) { el.classList.add('qn-tearing'); setTimeout(() => el.remove(), 420); }
        else el?.remove();
        doDelete();
        undoToast(n);
    }

    function undoToast(n) {
        const box = document.getElementById('toast-container'); if (!box) return;
        const t = document.createElement('div');
        t.className = 'toast info';
        t.innerHTML = `<i class="fa-solid fa-trash toast-icon"></i><span class="toast-msg">Usunięto „${esc(n.title || 'Notatka')}”</span><button class="toast-undo">Cofnij</button>`;
        t.querySelector('.toast-undo').onclick = () => {
            StorageManager.saveNote(cid(), n);
            if (n.pinned !== false) mount({ ...n, color: colorOf(n.color) }, { animate: true });
            if (App.currentTab === 'dashboard') App.updateDashboard();
            t.remove();
        };
        box.appendChild(t);
        setTimeout(() => { t.classList.add('leaving'); setTimeout(() => t.remove(), 250); }, 6000);
    }

    // ── Kafelek „Szybkie notatki” na Pulpicie ───────────────
    function renderDashboard(container) {
        if (!container) return;
        const notes = all().slice().sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
        const items = notes.map(n => {
            const c = COLORS[colorOf(n.color)];
            const on = n.pinned !== false;
            const text = String(n.content || '').replace(/<[^>]+>/g, ' ').trim();
            return `<div class="qn-mini ${c.dark ? 'qn-dark' : ''} ${on ? 'is-pinned' : ''}" style="--qn-bg:${c.bg};--qn-edge:${c.edge}" data-note="${esc(n.id)}">
                ${on ? '<span class="qn-mini-pin" title="Wisi na ekranie"></span>' : ''}
                <b>${esc(n.title || 'Notatka')}</b>
                <p>${esc(text.slice(0, 120)) || '<i>pusta</i>'}</p>
                <div class="qn-mini-act">
                    <button data-qn="${on ? 'unpin' : 'pin'}" title="${on ? 'Schowaj z ekranu' : 'Przypnij na ekran'}"><i class="fa-solid ${on ? 'fa-box-archive' : 'fa-thumbtack'}"></i> ${on ? 'Schowaj' : 'Przypnij'}</button>
                    <span class="qn-mini-colors">${Object.entries(COLORS).map(([k, cc]) => `<button data-qn="color" data-c="${k}" title="${cc.name}" style="--sw:${cc.bg};--swe:${cc.edge}" class="${k === colorOf(n.color) ? 'active' : ''}"></button>`).join('')}</span>
                    <button data-qn="delete" title="Usuń"><i class="fa-solid fa-trash"></i></button>
                </div>
            </div>`;
        }).join('');
        container.innerHTML = `
            <div class="qn-board">
                ${items}
                <button class="qn-mini qn-new" data-qn="new"><i class="fa-solid fa-plus"></i><span>Nowa notatka</span></button>
            </div>`;
        if (!container._qnBound) {
            container._qnBound = true;
            container.addEventListener('click', (e) => {
                const b = e.target.closest('[data-qn]');
                const card = e.target.closest('[data-note]');
                if (!b) { if (card) pin(card.dataset.note); return; }
                e.stopPropagation();
                const id = card?.dataset.note;
                const act = b.dataset.qn;
                if (act === 'new') { newNote(); App.updateDashboard(); return; }
                if (act === 'pin') { pin(id); App.updateDashboard(); }
                if (act === 'unpin') { stash(id); App.updateDashboard(); }
                if (act === 'color') { changeColor(id, b.dataset.c); App.updateDashboard(); }
                if (act === 'delete') deleteNote(id);
            });
        }
    }

    return { init, createNote, newNote, deleteNote, toggleCollapse, changeColor, loadNotes, clearOverlay, refreshNotes, pin, stash, renderDashboard, COLORS };
})();

window.NotesModule = NotesModule;
