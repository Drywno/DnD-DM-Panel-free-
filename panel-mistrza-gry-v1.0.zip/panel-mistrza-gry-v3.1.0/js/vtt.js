// ============================================================
// VTTModule — Pole walki (wirtualny stół)
// Plansza: pusta, z obrazka albo przeniesiona z Atlasu (karczma,
// loch, mapa miasta) razem ze stworzeniami i drużyną.
// Żetony = uczestnicy z trackera inicjatywy (CombatModule).
// ============================================================
const VTTModule = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const cid = () => (typeof App !== 'undefined' && App.getActiveCampaignId && App.getActiveCampaignId()) || 'none';
    const KEY = () => `vtt_${cid()}`;
    const BLOCK = '#hXLPBV';           // ściany, zamknięte drzwi, brony, kraty, okna
    const ELEMENTS = {
        fire: ['Ogień', '#ff6a1a'], cold: ['Zimno', '#6cc8ff'], lightning: ['Błyskawica', '#f3e96a'],
        acid: ['Kwas', '#8fe04a'], necrotic: ['Nekrotyczne', '#a066ff'], radiant: ['Promienne', '#ffe9a8']
    };
    const TOOLS = [
        ['select', 'fa-hand-pointer', 'Wskaż', 'Przesuwaj żetony, przeciągnij tło by przesunąć widok'],
        ['ruler', 'fa-ruler', 'Miarka', 'Przeciągnij, by zmierzyć odległość'],
        ['sphere', 'fa-circle', 'Kula', 'Promień od punktu (np. Kula ognia 20 ft)'],
        ['cone', 'fa-play', 'Stożek', 'Stożek z punktu (np. Oddech smoka)'],
        ['line', 'fa-grip-lines', 'Linia', 'Linia szerokości 5 ft (np. Błyskawica)'],
        ['cube', 'fa-square', 'Sześcian', 'Kwadratowy obszar (np. Fala gromu)'],
        ['ping', 'fa-bullseye', 'Wskaż graczom', 'Kliknij, by zaznaczyć miejsce'],
        ['terrain', 'fa-mountain', 'Teren', 'Maluj po polach: przeszkoda (nie da się wejść), trudny teren, wzniesienie — ruch po nich kosztuje podwójnie']
    ];
    const TER_BRUSH = [['b', 'fa-ban', 'Przeszkoda', 'Nie da się wejść (komin, filar, ściana skalna)'], ['h', 'fa-water', 'Trudny teren', 'Ruch kosztuje ×2 (gruz, błoto, krzaki)'],
        ['e', 'fa-stairs', 'Wzniesienie', 'Wspinaczka, ruch ×2 — stół, skała, podest'], ['f', 'fa-check', 'Zwykły', 'Znosi utrudnienie z mebla / podłogi'], ['x', 'fa-eraser', 'Gumka', 'Usuń to, co namalowane']];
    let terVer = 0;
    const COND_PL = {
        Oslepienie: 'Oślepienie', Zauroczenie: 'Zauroczenie', Gluchota: 'Głuchota', Przerazenie: 'Przerażenie', Pochwycenie: 'Pochwycenie',
        Obezwladnienie: 'Obezwładnienie', Niewidzialnosc: 'Niewidzialność', Paraliz: 'Paraliż', Spetryfikowanie: 'Spetryfikowanie',
        Zatrucie: 'Zatrucie', Lezenie: 'Leżenie', Skrepowanie: 'Skrępowanie', Ogluszenie: 'Ogłuszenie', Nieprzytomnosc: 'Nieprzytomność',
        Zmeczenie: 'Zmęczenie', Koncentracja: 'Koncentracja'
    };
    const COND_ICON = {
        Oslepienie: 'fa-eye-slash', Zauroczenie: 'fa-heart', Gluchota: 'fa-ear-deaf', Przerazenie: 'fa-ghost', Pochwycenie: 'fa-hand-fist',
        Obezwladnienie: 'fa-ban', Niewidzialnosc: 'fa-user-ninja', Paraliz: 'fa-bolt', Spetryfikowanie: 'fa-gem', Zatrucie: 'fa-skull-crossbones',
        Lezenie: 'fa-bed', Skrepowanie: 'fa-link', Ogluszenie: 'fa-star', Nieprzytomnosc: 'fa-moon', Zmeczenie: 'fa-battery-empty', Koncentracja: 'fa-brain'
    };
    const BG = { stone: 'Kamienna posadzka', grass: 'Trawa', wood: 'Deski', sand: 'Piasek', cave: 'Jaskinia' };
    const SIZES = ['Średni / mały', 'Duży (2×2)', 'Wielki (3×3)', 'Gigantyczny (4×4)'];

    const DEF = () => ({ kind: 'blank', name: 'Pusta plansza', bg: 'stone', cols: 26, rows: 18, cell: 70, ox: 0, oy: 0,
        grid: true, galpha: 0.3, diag: 'phb', limit: true, tokens: {}, tpl: [] });
    let S = null, loadedFor = null;
    const ui = { zoom: 1, panX: 0, panY: 0, tool: 'select', el: 'fire', player: false, follow: true, sel: null, tplSel: null,
        pop: null, gridPop: false, fitKey: null, ter: 'b', rc: null, lastTurn: null, drag: null, bgUrl: null };
    let G = null;                       // geometria bieżącej sceny
    let root = null;

    // ---------- stan ----------
    function sc() {
        if (!S || loadedFor !== cid()) {
            S = { ...DEF(), ...(StorageManager.get(KEY()) || {}) };
            S.tokens = S.tokens || {}; S.tpl = S.tpl || [];
            loadedFor = cid(); ui.fitKey = null; ui.sel = null; ui.pop = null;
        }
        return S;
    }
    function save() {
        try { StorageManager.set(KEY(), S); } catch (e) { /* pełna pamięć */ }
    }
    const combatants = () => (window.CombatModule && CombatModule.getCombatants()) || [];
    const active = () => (window.CombatModule && CombatModule.getActiveCombatant && CombatModule.getActiveCombatant()) || null;
    const byId = (id) => combatants().find(c => c.id === id);
    const sizeOf = (c) => Math.max(1, Math.min(4, +c?.size || 1));
    const sceneKey = () => `${S.kind}|${S.mapId || ''}|${S.levelId || ''}|${S.url ? S.url.length : ''}|${S.cols}x${S.rows}|${S.cell}`;

    function geo() {
        const s = sc();
        let g = null;
        if (s.kind === 'atlas' && window.Atlas?.fightData) {
            const d = Atlas.fightData(s.mapId, s.levelId);
            if (d && d.kind === 'interior') g = { kind: 'interior', d, w: d.w, h: d.h, cell: d.grid.size, ox: 0, oy: 0, lv: d.lv };
            else if (d) g = { kind: 'local', d, w: d.w, h: d.h, cell: s.cell || d.grid.size, ox: s.ox || 0, oy: s.oy || 0, url: d.url };
        }
        if (!g && s.kind === 'image' && s.url) g = { kind: 'image', w: s.w, h: s.h, cell: s.cell, ox: s.ox || 0, oy: s.oy || 0, url: s.url };
        if (!g) g = { kind: 'blank', w: s.cols * s.cell, h: s.rows * s.cell, cell: s.cell, ox: 0, oy: 0 };
        g.cols = Math.max(1, Math.floor((g.w - g.ox) / g.cell));
        g.rows = Math.max(1, Math.floor((g.h - g.oy) / g.cell));
        g.T = terrainOf(g);
        return g;
    }

    // ---------- piętra: każdy żeton stoi na swoim poziomie wnętrza ----------
    const isInt = () => !!(G && G.kind === 'interior');
    const curLv = () => isInt() ? G.d.levelId : null;
    const lvOf = (t) => t ? (t.lv || S.levelId || null) : null;
    const onCur = (id) => !isInt() || lvOf(S.tokens[id]) === curLv();
    const paintFor = (lvId) => { if (S.kind === 'atlas' && lvId) { S.terL = S.terL || {}; return (S.terL[lvId] = S.terL[lvId] || {}); } return (S.ter = S.ter || {}); };
    const curPaint = () => paintFor(curLv());
    function terrainOf(g) {
        if (!window.MapForge?.terrain) return { at: (x, y) => (x < 0 || y < 0 || x >= g.cols || y >= g.rows) ? 3 : 0, cols: g.cols, rows: g.rows };
        return MapForge.terrain(g.kind === 'interior' ? g.lv : null, g.cols, g.rows, paintFor(g.kind === 'interior' ? g.d.levelId : null), { secret: !ui.player });
    }
    // ---------- geometria pól ----------
    const px = (x) => G.ox + x * G.cell;
    const py = (y) => G.oy + y * G.cell;
    function blocked(x, y) {
        if (x < 0 || y < 0 || x >= G.cols || y >= G.rows) return true;
        return G.T.at(x, y) === 3;
    }
    // czym jest pole, w które nie da się wejść (do komunikatu)
    function whatBlocks(x, y, n) {
        for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
            const cx = x + i, cy = y + j;
            if (cx < 0 || cy < 0 || cx >= G.cols || cy >= G.rows) return 'Poza planszą';
            if (G.T.at(cx, cy) !== 3) continue;
            if (curPaint()[`${cx},${cy}`] === 'b') return 'Przeszkoda — nie da się tu wejść';
            if (G.kind === 'interior') {
                const w = G.lv.walls[cy * G.lv.cols + cx] || '.';
                if (BLOCK.includes(w) || w === 'S') return (MapForge.WALLS[w]?.[0] || 'Ściana') + ' — nie da się przejść';
                const o = MapForge.objectAt(G.lv, cx, cy);
                if (o) return `${MapForge.OBJ[o.t]?.[0] || 'Przeszkoda'} — nie da się tu wejść`;
                if (G.lv.floor[cy * G.lv.cols + cx] === 'p') return 'Otchłań — nie da się tu stanąć';
            }
            return 'Przeszkoda — nie da się tu wejść';
        }
        return 'Tu nie można stanąć';
    }
    function reachFor(id) {
        const c = byId(id), t = S.tokens[id], n = sizeOf(c);
        const key = `${id}|${t.x},${t.y}|${n}|${S.diag}|${terVer}|${sceneKey()}|${ui.player}`;
        if (!ui.rc || ui.rc.key !== key) ui.rc = { key, fn: MapForge.reach(G.T, t.x, t.y, n, S.diag) };
        return ui.rc.fn;
    }
    const terAreaMax = (x, y, n) => { let m = 0; for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) m = Math.max(m, G.T.at(x + i, y + j)); return m; };
    function areaBlocked(x, y, n) {
        for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) if (blocked(x + i, y + j)) return true;
        return false;
    }
    function pathBlocked(x0, y0, x1, y1, n) {
        if (G.kind !== 'interior') return false;
        const steps = Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) * 4) || 1;
        for (let k = 1; k <= steps; k++) {
            const t = k / steps, cx = x0 + (x1 - x0) * t + n / 2, cy = y0 + (y1 - y0) * t + n / 2;
            if (blocked(Math.floor(cx), Math.floor(cy))) return true;
        }
        return false;
    }
    function occupied(exceptId) {
        const out = [];
        Object.entries(S.tokens).forEach(([id, t]) => { if (id !== exceptId && byId(id) && onCur(id)) out.push({ x: t.x, y: t.y, n: sizeOf(byId(id)) }); });
        return out;
    }
    function freeCell(x, y, n, taken) {
        const hit = (cx, cy) => taken.some(t => cx < t.x + t.n && cx + n > t.x && cy < t.y + t.n && cy + n > t.y);
        for (let r = 0; r < 30; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
            if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
            const cx = x + dx, cy = y + dy;
            if (!areaBlocked(cx, cy, n) && !hit(cx, cy)) return { x: cx, y: cy };
        }
        return { x: Math.max(0, Math.min(G.cols - n, x)), y: Math.max(0, Math.min(G.rows - n, y)) };
    }
    function feet(dx, dy) {
        dx = Math.abs(dx); dy = Math.abs(dy);
        const mx = Math.max(dx, dy), mn = Math.min(dx, dy);
        return S.diag === 'alt' ? (mx + Math.floor(mn / 2)) * 5 : mx * 5;
    }
    function viewCenterCell() {
        const vp = root?.querySelector('.vt-vp');
        if (!vp || !vp.clientWidth) return { x: Math.floor(G.cols / 2), y: Math.floor(G.rows / 2) };
        const bx = (vp.clientWidth / 2 - ui.panX) / ui.zoom, by = (vp.clientHeight / 2 - ui.panY) / ui.zoom;
        return { x: Math.max(0, Math.min(G.cols - 1, Math.floor((bx - G.ox) / G.cell))), y: Math.max(0, Math.min(G.rows - 1, Math.floor((by - G.oy) / G.cell))) };
    }

    // ---------- kolory i wygląd żetonów ----------
    function colorOf(c) {
        if (c.type === 'pc' || c.type === 'player') {
            const ch = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null);
            const chr = ch ? (StorageManager.getCharacters(cid()) || []).find(x => x.id === ch) : null;
            if (chr && window.Kits) return Kits.CLASS_META[Kits.classKey(chr.class)]?.color || '#4a7fc0';
            return '#4a7fc0';
        }
        if (c.disp === 'friendly') return '#3f8f4a';
        if (c.disp === 'neutral' || c.type === 'npc') return '#a8862a';
        return '#b0301f';
    }
    const initials = (name) => String(name || '?').replace(/\s*\d+$/, '').trim().split(/\s+/).slice(0, 2).map(s => s[0] || '').join('').toUpperCase();

    // ---------- render: szkielet ----------
    function renderAll() {
        root = document.getElementById('vtt-container');
        if (!root) return;
        sc(); G = geo();
        if (isInt()) Object.values(S.tokens).forEach(t => { if (!t.lv) t.lv = G.d.levelId; });
        const lvls = G.kind === 'interior' ? G.d.levels : null;
        const lvCount = (id) => Object.entries(S.tokens).filter(([cid0, t]) => byId(cid0) && lvOf(t) === id).length;
        const toolBtns = TOOLS.map(([k, ic, name, tip]) => `<button class="vt-tool ${ui.tool === k ? 'on' : ''}" data-tool="${k}" title="${esc(name)} — ${esc(tip)}"><i class="fa-solid ${ic}"></i><span>${name}</span></button>`).join('');
        const isAoe = ['sphere', 'cone', 'line', 'cube'].includes(ui.tool);
        root.className = 'vtt-container vt';
        root.innerHTML = `
        <div class="vt-top">
            <div class="vt-scene"><i class="fa-solid ${({ interior: 'fa-door-open', local: 'fa-map', image: 'fa-image', blank: 'fa-chess-board' })[G.kind]}"></i>
                <div><b>${esc(S.kind === 'atlas' && G.d ? G.d.name : S.name)}</b><small>${({ interior: 'Lokacja z Atlasu', local: 'Mapa z Atlasu', image: 'Własny obraz', blank: BG[S.bg] || 'Pusta plansza' })[G.kind]} · ${G.cols}×${G.rows} pól</small></div>
                ${lvls && lvls.length > 1 ? `<label class="vt-lvl" title="Piętro"><i class="fa-solid fa-stairs"></i><select data-lvl>${lvls.slice().reverse().map(L => `<option value="${esc(L.id)}" ${L.id === G.d.levelId ? 'selected' : ''}>${esc(L.name)}${lvCount(L.id) ? ` (${lvCount(L.id)})` : ''}</option>`).join('')}</select></label>` : ''}
            </div>
            <div class="vt-acts">
                <button class="vt-btn gold" data-v="import" title="Przenieś karczmę, loch albo mapę z Atlasu"><i class="fa-solid fa-map-location-dot"></i> Lokacja z Atlasu</button>
                <button class="vt-btn" data-v="image" title="Wgraj obraz mapy"><i class="fa-solid fa-image"></i> Obraz</button>
                <button class="vt-btn" data-v="blank" title="Pusta plansza z siatką"><i class="fa-solid fa-chess-board"></i> Plansza</button>
                <span class="vt-sep"></span>
                <button class="vt-btn ${ui.gridPop ? 'on' : ''}" data-v="gridpop" title="Siatka i zasady ruchu"><i class="fa-solid fa-border-all"></i> Siatka</button>
                <button class="vt-btn ${ui.player ? 'on' : ''}" data-v="player" title="Ukrywa sekrety i schowane stworzenia — do pokazania graczom"><i class="fa-solid ${ui.player ? 'fa-eye' : 'fa-eye-slash'}"></i> Widok graczy</button>
                ${S.kind === 'atlas' && G.d ? `<button class="vt-btn" data-v="writeback" title="Zapisz pozycje i PW stworzeń z powrotem w lokacji"><i class="fa-solid fa-floppy-disk"></i> Do lokacji</button>` : ''}
                <button class="vt-btn" data-v="full" title="Pełny ekran"><i class="fa-solid fa-expand"></i></button>
                <input type="file" accept="image/*" class="vt-file" hidden>
            </div>
        </div>
        ${ui.gridPop ? gridPopHTML() : ''}
        <div class="vt-stage">
            <div class="vt-rail">
                ${toolBtns}
 ${ui.tool === 'terrain' ? `<div class="vt-ters">${TER_BRUSH.map(([k, ic, n, tip]) => `<button data-ter="${k}" class="b-${k} ${ui.ter === k ? 'on' : ''}" title="${n} — ${tip}"><i class="fa-solid ${ic}"></i><span>${n}</span></button>`).join('')}${Object.keys(curPaint()).length ? '<button data-v="clearter" class="b-clr" title="Usuń cały namalowany teren"><i class="fa-solid fa-trash-can"></i><span>Wyczyść</span></button>' : ''}</div>` : ''}
                <div class="vt-elems ${isAoe ? '' : 'off'}" title="Żywioł szablonu">${Object.entries(ELEMENTS).map(([k, [n, col]]) => `<button data-el="${k}" class="${ui.el === k ? 'on' : ''}" style="--c:${col}" title="${n}"></button>`).join('')}</div>
                <button class="vt-tool small" data-v="cleartpl" title="Usuń wszystkie szablony obszarów"><i class="fa-solid fa-eraser"></i><span>Wyczyść</span></button>
            </div>
            <div class="vt-vp ${'tool-' + ui.tool}">
                <div class="vt-board" style="width:${G.w}px;height:${G.h}px">
                    <div class="vt-bg bg-${G.kind === 'blank' ? S.bg : G.kind}">${bgHTML()}</div>
                    ${S.grid ? `<div class="vt-grid" style="--gs:${G.cell}px;--gx:${G.ox}px;--gy:${G.oy}px;--ga:${S.galpha ?? 0.3}"></div>` : ''}
                    <svg class="vt-ter ${ui.tool === 'terrain' ? 'edit' : ''}" width="${G.w}" height="${G.h}" viewBox="0 0 ${G.w} ${G.h}"></svg>
                    <svg class="vt-tpl" width="${G.w}" height="${G.h}" viewBox="0 0 ${G.w} ${G.h}"></svg>
                    <div class="vt-toks"></div>
                    <svg class="vt-fog" width="${G.w}" height="${G.h}" viewBox="0 0 ${G.w} ${G.h}"></svg>
                    <svg class="vt-over" width="${G.w}" height="${G.h}" viewBox="0 0 ${G.w} ${G.h}"></svg>
                </div>
                <div class="vt-banner-wrap"></div>
                <div class="vt-zoom"><button data-zoom="in" title="Przybliż">+</button><button data-zoom="out" title="Oddal">−</button><button data-zoom="fit" title="Cała plansza"><i class="fa-solid fa-expand"></i></button><button data-zoom="turn" title="Pokaż aktywnego"><i class="fa-solid fa-crosshairs"></i></button></div>
                <div class="vt-hint">${esc(TOOLS.find(t => t[0] === ui.tool)?.[3] || '')} · kółko myszy: zoom · prawy przycisk: przesuwanie${G.kind === 'interior' ? ' · ściany i meble blokują ruch (Shift = ignoruj)' : ' · Shift = przesuń bez zasad ruchu'}</div>
                <div class="vt-empty-wrap"></div>
            </div>
        </div>`;
        bind();
        renderTer();
        renderTpl();
        renderTokens();
        applyTransform();
        requestAnimationFrame(() => { if (ui.fitKey !== sceneKey()) fit(); });
    }

    // ---------- teren (namalowany + z mebli wnętrza w trybie edycji) ----------
    function renderTer() {
        const el = root?.querySelector('.vt-ter'); if (!el) return;
        const edit = ui.tool === 'terrain', P = curPaint(), c = G.cell, cls = ['', 'h', 'e', 'b'];
        let out = `<defs>
            <pattern id="vt-p-h" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="12" height="12" fill="rgba(224,170,60,.16)"/><rect width="4" height="12" fill="rgba(224,170,60,.45)"/></pattern>
            <pattern id="vt-p-e" width="18" height="16" patternUnits="userSpaceOnUse"><rect width="18" height="16" fill="rgba(90,150,230,.15)"/><path d="M3 12L9 5L15 12" fill="none" stroke="rgba(120,180,255,.6)" stroke-width="2.4"/></pattern>
            <pattern id="vt-p-b" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="rgba(200,50,40,.22)"/><path d="M0 0L14 14M14 0L0 14" stroke="rgba(230,80,60,.55)" stroke-width="2"/></pattern></defs>`;
        for (let y = 0; y < G.rows; y++) for (let x = 0; x < G.cols; x++) {
            const k = `${x},${y}`, painted = P[k];
            if (painted === 'f') { if (edit) out += `<rect x="${px(x) + 3}" y="${py(y) + 3}" width="${c - 6}" height="${c - 6}" rx="6" class="vt-ter-f"/>`; continue; }
            const v = G.T.at(x, y);
            if (!v) continue;
            const fromWall = G.kind === 'interior' && v === 3 && !painted && (BLOCK + 'S').includes(G.lv.walls[y * G.lv.cols + x] || '.');
            if (fromWall) continue;
            if (!painted && !edit) continue;
            out += `<rect x="${px(x)}" y="${py(y)}" width="${c}" height="${c}" fill="url(#vt-p-${cls[v]})" class="vt-ter-c ${painted ? 'own' : 'auto'}"/>`;
        }
        el.innerHTML = out;
    }
    // podgląd mgły wojny dla MG („Widok graczy”): to, co widzi cała drużyna na tym piętrze
    const inPartyNpc = (c) => !!(c.npcId && window.Companions && Companions.list().some(n => n.id === c.npcId));
    const isEyes = (c) => c.type === 'pc' || c.type === 'player' || String(c.id).endsWith('-druzyna') || inPartyNpc(c);
    const isAllyC = (c) => isEyes(c) || c.disp === 'friendly';
    function fogViewers(lvId) {
        const chars = typeof StorageManager !== 'undefined' ? (StorageManager.getCharacters(cid()) || []) : [];
        const npcs = typeof StorageManager !== 'undefined' ? (StorageManager.getNPCs(cid()) || []) : [];
        const onLv = (id) => lvId === undefined ? onCur(id) : (!isInt() || lvOf(S.tokens[id]) === lvId);
        return combatants().filter(c => S.tokens[c.id] && onLv(c.id) && c.hp > 0 && isEyes(c)).map(c => {
            const t = S.tokens[c.id], chId = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null);
            const n = c.npcId && npcs.find(x => x.id === c.npcId);
            const dv = chId ? MapForge.darkvisionOf((chars.find(x => x.id === chId) || {}).race) : n ? MapForge.darkvisionOf(n.race, n.stats?.senses) : 0;
            return { x: t.x, y: t.y, n: sizeOf(c), dv, light: t.light ? 8 : 0 };
        });
    }
    function renderFog() {
        const el = root?.querySelector('.vt-fog'); if (!el) return;
        if (!S.fog || !ui.player || !window.MapForge?.vision) { el.innerHTML = ''; return; }
        const lv = isInt() ? G.lv : null;
        const O = MapForge.sightGrid(lv, G.cols, G.rows, curPaint(), { player: true });
        const V = MapForge.vision(O, G.cols, G.rows, fogViewers(), { dark: lv ? +lv.dark || 0 : 0, lights: lv ? MapForge.lightsOf(lv) : [] });
        el.innerHTML = MapForge.fogSVG(V, null, G.cols, G.rows, G.cell, G.ox, G.oy);
    }
    // wrogowie w zasięgu wzroku drużyny zostają „odkryci” — dopiero wtedy gracze wiedzą, że są
    let discT = null;
    function scheduleDiscover() { clearTimeout(discT); discT = setTimeout(discover, 150); }
    function discover() {
        if (!S || !S.fog || !G || !window.MapForge?.vision) return;
        const list = combatants();
        const lvIds = isInt() ? [...new Set(list.filter(c => isEyes(c) && S.tokens[c.id] && c.hp > 0).map(c => lvOf(S.tokens[c.id])))] : [null];
        const found = [];
        lvIds.forEach(lvId => {
            const lv = !isInt() ? null : lvId === curLv() ? G.lv : (Atlas.fightData(S.mapId, lvId) || {}).lv;
            if (isInt() && !lv) return;
            const cols = lv ? lv.cols : G.cols, rows = lv ? lv.rows : G.rows;
            const paint = lv ? ((S.terL || {})[lvId] || {}) : (S.ter || {});
            const O = MapForge.sightGrid(lv, cols, rows, paint, { player: true });
            const V = MapForge.vision(O, cols, rows, fogViewers(isInt() ? lvId : undefined), { dark: lv ? +lv.dark || 0 : 0, lights: lv ? MapForge.lightsOf(lv) : [] });
            list.forEach(c => {
                const t = S.tokens[c.id]; if (!t || c.seen || isAllyC(c) || c.hidden) return;
                if (isInt() && lvOf(t) !== lvId) return;
                const n = sizeOf(c);
                for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) { const x = t.x + i, y = t.y + j; if (x >= 0 && y >= 0 && x < cols && y < rows && V[y * cols + x]) { found.push(c.id); return; } }
            });
        });
        [...new Set(found)].forEach(id => CombatModule.updateCombatant(id, { seen: true }));
    }
    function paintTer(p) {
        const x = Math.floor((p.x - G.ox) / G.cell), y = Math.floor((p.y - G.oy) / G.cell);
        if (x < 0 || y < 0 || x >= G.cols || y >= G.rows) return;
        const k = `${x},${y}`, P = curPaint();
        if (ui.ter === 'x') { if (!(k in P)) return; delete P[k]; }
        else { if (P[k] === ui.ter) return; P[k] = ui.ter; }
        terVer++; G.T = terrainOf(G); renderTer(); renderTokens();
    }

    function bgHTML() {
        if (ui.bgUrl) { URL.revokeObjectURL(ui.bgUrl); ui.bgUrl = null; }
        if (G.kind === 'interior') {
            const svg = MapForge.svg(G.lv, { player: ui.player });
            ui.bgUrl = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
            return `<img src="${ui.bgUrl}" alt="" draggable="false">`;
        }
        if (G.url) return `<img src="${esc(G.url)}" alt="" draggable="false" style="width:100%;height:100%">`;
        return '';
    }

    function gridPopHTML() {
        const img = G.kind === 'image' || G.kind === 'local';
        return `<div class="vt-gridpop">
            <label class="vt-chk"><input type="checkbox" data-g="grid" ${S.grid ? 'checked' : ''}> pokaż siatkę</label>
            <label class="vt-rng"><span>Widoczność</span><input type="range" data-g="galpha" min="5" max="80" value="${Math.round((S.galpha ?? 0.3) * 100)}"></label>
            ${img ? `<label class="vt-rng"><span>Wielkość pola</span><input type="range" data-g="cell" min="24" max="220" value="${G.cell}"><b>${G.cell}px</b></label>
            <label class="vt-rng"><span>Przesunięcie ←→</span><input type="range" data-g="ox" min="0" max="${G.cell}" value="${G.ox}"></label>
            <label class="vt-rng"><span>Przesunięcie ↑↓</span><input type="range" data-g="oy" min="0" max="${G.cell}" value="${G.oy}"></label>` : ''}
            ${G.kind === 'blank' ? `<label class="vt-num"><span>Kolumny</span><input type="number" data-g="cols" min="6" max="80" value="${S.cols}"></label><label class="vt-num"><span>Wiersze</span><input type="number" data-g="rows" min="6" max="80" value="${S.rows}"></label>
            <label class="vt-num"><span>Podłoże</span><select data-g="bg">${Object.entries(BG).map(([k, v]) => `<option value="${k}" ${S.bg === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>` : ''}
            <label class="vt-num"><span>Skosy</span><select data-g="diag"><option value="phb" ${S.diag !== 'alt' ? 'selected' : ''}>5 ft (PHB)</option><option value="alt" ${S.diag === 'alt' ? 'selected' : ''}>5 / 10 ft (DMG)</option></select></label>
            <label class="vt-chk"><input type="checkbox" data-g="limit" ${S.limit !== false ? 'checked' : ''}> pilnuj szybkości w turze</label>
            <label class="vt-chk"><input type="checkbox" data-g="follow" ${ui.follow ? 'checked' : ''}> pokazuj aktywnego przy zmianie tury</label>
            <label class="vt-chk"><input type="checkbox" data-g="playersMove" ${S.playersMove !== false ? 'checked' : ''}> gracze przesuwają swoje żetony (w swojej turze)</label>
            <div class="vt-gp-h"><i class="fa-solid fa-smog"></i> Mgła wojny</div>
            <label class="vt-chk"><input type="checkbox" data-g="fog" ${S.fog ? 'checked' : ''}> gracze widzą tylko to, co widzą ich postacie</label>
            <label class="vt-chk ${S.fog ? '' : 'off'}"><input type="checkbox" data-g="fogShare" ${S.fogShare ? 'checked' : ''} ${S.fog ? '' : 'disabled'}> wspólne widzenie drużyny</label>
            <p class="vt-gp-note">Ściany, zamknięte drzwi i wysokie meble zasłaniają widok, okna i kraty — nie. W ciemnym wnętrzu (Mrok ≥ 45%) widać tylko oświetlone miejsca, w zasięgu widzenia w ciemności (krasnolud, elf, gnom…) albo niesionego światła (przycisk „Światło” przy żetonie). Podgląd: „Widok graczy”.</p>
        </div>`;
    }

    // ---------- render: żetony ----------
    function renderTokens() {
        if (!root || !root.querySelector('.vt-toks')) return;
        const list = combatants(), act = active(), lay = root.querySelector('.vt-toks');
        const chars = typeof StorageManager !== 'undefined' ? (StorageManager.getCharacters(cid()) || []) : [];
        const faceOf = (c) => { const id = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null); const ch = id && chars.find(x => x.id === id); return ch && ch.portrait && window.Portrait ? Portrait.img(ch.portrait) : ''; };
        const hits = tplHits();
        lay.innerHTML = list.map(c => {
            const t = S.tokens[c.id]; if (!t || !onCur(c.id)) return '';
            if (ui.player && c.hidden) return '';
            const n = sizeOf(c), s = n * G.cell;
            const pct = c.maxHp > 0 ? Math.max(0, Math.min(100, Math.round(c.hp / c.maxHp * 100))) : 0;
            const hpCol = pct > 50 ? '#4caf50' : pct > 20 ? '#e0b030' : '#d6402c';
            const num = (String(c.name).match(/(\d+)$/) || [])[1];
            const isTurn = act && act.id === c.id;
            const conds = (c.conditions || []).slice(0, 4).map(k => `<i class="fa-solid ${COND_ICON[k] || 'fa-circle-exclamation'}" title="${esc(COND_PL[k] || k)}"></i>`).join('');
            const rem = isTurn ? remainOf(c, t) : null;
            return `<div class="vt-tok t-${esc(c.type)} ${isTurn ? 'turn' : ''} ${ui.sel === c.id ? 'sel' : ''} ${c.hp <= 0 ? 'down' : ''} ${c.hidden ? 'hid' : ''} ${hits.has(c.id) ? 'hit' : ''}"
                data-cid="${esc(c.id)}" style="left:${px(t.x)}px;top:${py(t.y)}px;--s:${s}px;--c:${colorOf(c)};--hpc:${hpCol}" title="${esc(c.name)} · KP ${c.ac} · ${c.hp}/${c.maxHp} PW">
                <div class="vt-face"><span>${esc(initials(c.name))}</span>${num ? `<em>${num}</em>` : ''}${faceOf(c)}</div>
                ${c.hp <= 0 ? '<div class="vt-skull"><i class="fa-solid fa-skull"></i></div>' : ''}
                ${ui.player && c.type !== 'pc' ? '' : `<div class="vt-hp"><i style="width:${pct}%"></i></div>`}
                <div class="vt-name">${esc(c.name)}</div>
                ${conds ? `<div class="vt-conds">${conds}</div>` : ''}
                ${(() => { const st = stairsTo(c.id); return st && !ui.player ? `<button type="button" class="vt-stair" data-stairs="${esc(c.id)}" title="Przejdź schodami: ${esc(st.name)}"><i class="fa-solid fa-${st.sd > 0 ? 'arrow-up' : 'arrow-down'}"></i> ${esc(st.name)}</button>` : ''; })()}
                ${terAreaMax(t.x, t.y, n) === 2 ? '<div class="vt-elev" title="Na podwyższeniu / wspina się"><i class="fa-solid fa-arrow-up"></i></div>' : terAreaMax(t.x, t.y, n) === 1 ? '<div class="vt-elev hard" title="W trudnym terenie"><i class="fa-solid fa-water"></i></div>' : ''}
                ${isTurn && S.limit !== false && combatActive() ? `<div class="vt-move">${rem} ft</div>` : ''}
            </div>`;
        }).join('');
        renderBanner();
        renderEmpty();
        renderFog();
        if (S.fog) scheduleDiscover();
        // liczba żetonów na piętrach w przełączniku
        const sel = isInt() && root.querySelector('[data-lvl]');
        if (sel) [...sel.options].forEach(op => { const L = G.d.levels.find(x => x.id === op.value); if (!L) return; const n = Object.entries(S.tokens).filter(([k, t]) => byId(k) && lvOf(t) === L.id).length; op.textContent = `${L.name}${n ? ` (${n})` : ''}`; });
        if (ui.pop) placePop();
    }
    const combatActive = () => !!(window.CombatModule && CombatModule.isActive && CombatModule.isActive());
    // ruch w turze liczony tak samo jak na serwerze (gracze widzą te same stopy)
    const STOP = ['Pochwycenie', 'Skrepowanie', 'Paraliz', 'Ogluszenie', 'Nieprzytomnosc', 'Spetryfikowanie', 'Obezwladnienie'];
    const turnTag = () => { const a = active(); return a && CombatModule.getRound ? `${CombatModule.getRound()}:${a.id}` : ''; };
    const movedOf = (t) => (t && t.tt === turnTag() ? (t.moved || 0) : 0);
    const totalOf = (c, t) => ((c.conditions || []).some(k => STOP.includes(k)) ? 0 : (c.speed || 30) * (t && t.dash && t.dash === turnTag() ? 2 : 1));
    const remainOf = (c, t) => Math.max(0, totalOf(c, t) - movedOf(t));

    function renderBanner() {
        const w = root?.querySelector('.vt-banner-wrap'); if (!w) return;
        const list = combatants(), act = active();
        if (act) {
            const t = S.tokens[act.id];
            const rem = t ? remainOf(act, t) : totalOf(act, null);
            w.innerHTML = `<div class="vt-banner" style="--c:${colorOf(act)}">
                <span class="vt-rnd">Runda <b>${CombatModule.getRound ? CombatModule.getRound() : ''}</b></span>
                <span class="vt-who"><span class="vt-dot"></span>${esc(act.name)}</span>
                ${isInt() && S.tokens[act.id] && !onCur(act.id) ? (() => { const L = G.d.levels.find(x => x.id === lvOf(S.tokens[act.id])); return L ? `<button data-golv="${esc(L.id)}" class="vt-lvtag" title="Pokaż to piętro"><i class="fa-solid fa-stairs"></i> ${esc(L.name)}</button>` : ''; })() : ''}
                <span class="vt-mv" title="Pozostały ruch w tej turze"><i class="fa-solid fa-shoe-prints"></i> ${rem}/${totalOf(act, t)} ft${t && t.dash === turnTag() ? ' · sprint' : ''}</span>
                <button data-v="next" class="vt-next">Następna tura <i class="fa-solid fa-forward-step"></i></button>
            </div>`;
        } else if (list.length) {
            w.innerHTML = `<div class="vt-banner idle"><span>${list.length} ${list.length === 1 ? 'uczestnik' : list.length < 5 ? 'uczestników' : 'uczestników'} na polu walki</span><button data-v="start" class="vt-next">Rozpocznij walkę <i class="fa-solid fa-khanda"></i></button></div>`;
        } else w.innerHTML = '';
    }

    function renderEmpty() {
        const w = root?.querySelector('.vt-empty-wrap'); if (!w) return;
        if (combatants().length || S.kind !== 'blank') { w.innerHTML = ''; return; }
        const n = window.Atlas?.fightScenes ? Atlas.fightScenes().length : 0;
        w.innerHTML = `<div class="vt-empty">
            <div class="vt-empty-ico"><i class="fa-solid fa-khanda"></i></div>
            <h3>Przygotuj pole walki</h3>
            <p>Przenieś miejsce z Atlasu — karczmę, loch, ulicę miasta — razem ze stworzeniami i drużyną, albo zacznij od czystej planszy.</p>
            <div class="vt-empty-acts">
                <button class="vt-btn gold" data-v="import"><i class="fa-solid fa-map-location-dot"></i> Lokacja z Atlasu${n ? ` <small>(${n})</small>` : ''}</button>
                <button class="vt-btn" data-v="image"><i class="fa-solid fa-image"></i> Obraz mapy</button>
                <button class="vt-btn" data-v="party"><i class="fa-solid fa-users"></i> Postaw drużynę</button>
            </div>
        </div>`;
    }

    // ---------- szablony obszarów ----------
    function tplShape(t) {
        const col = ELEMENTS[t.el]?.[1] || '#ff6a1a';
        const dx = t.x1 - t.x0, dy = t.y1 - t.y0, L = Math.hypot(dx, dy), ft = Math.round(L / G.cell) * 5;
        const ang = Math.atan2(dy, dx);
        let shape = '', lx = t.x1, ly = t.y1;
        if (t.type === 'sphere') shape = `<circle cx="${t.x0}" cy="${t.y0}" r="${L}"/>`;
        else if (t.type === 'cone') {
            const px1 = -Math.sin(ang) * L / 2, py1 = Math.cos(ang) * L / 2;
            shape = `<path d="M${t.x0} ${t.y0} L${t.x1 + px1} ${t.y1 + py1} L${t.x1 - px1} ${t.y1 - py1} Z"/>`;
        } else if (t.type === 'line') {
            const hw = G.cell / 2, nx = -Math.sin(ang) * hw, ny = Math.cos(ang) * hw;
            shape = `<path d="M${t.x0 + nx} ${t.y0 + ny} L${t.x1 + nx} ${t.y1 + ny} L${t.x1 - nx} ${t.y1 - ny} L${t.x0 - nx} ${t.y0 - ny} Z"/>`;
        } else if (t.type === 'cube') {
            const side = Math.max(Math.abs(dx), Math.abs(dy));
            const x = dx < 0 ? t.x0 - side : t.x0, y = dy < 0 ? t.y0 - side : t.y0;
            shape = `<rect x="${x}" y="${y}" width="${side}" height="${side}"/>`;
            lx = x + side; ly = y + side;
        }
        const label = t.type === 'cube' ? `${Math.round(Math.max(Math.abs(dx), Math.abs(dy)) / G.cell) * 5} ft` : `${ft} ft`;
        return { col, shape, label, lx, ly };
    }
    function inTpl(t, x, y) {
        const dx = t.x1 - t.x0, dy = t.y1 - t.y0, L = Math.hypot(dx, dy);
        if (L < 1) return false;
        const vx = x - t.x0, vy = y - t.y0;
        if (t.type === 'sphere') return Math.hypot(vx, vy) <= L + 0.5;
        const ux = dx / L, uy = dy / L, along = vx * ux + vy * uy, across = Math.abs(-vx * uy + vy * ux);
        if (t.type === 'cone') return along >= 0 && along <= L && across <= along / 2 + 0.5;
        if (t.type === 'line') return along >= 0 && along <= L && across <= G.cell / 2;
        if (t.type === 'cube') {
            const side = Math.max(Math.abs(dx), Math.abs(dy));
            const x0 = dx < 0 ? t.x0 - side : t.x0, y0 = dy < 0 ? t.y0 - side : t.y0;
            return x >= x0 && x <= x0 + side && y >= y0 && y <= y0 + side;
        }
        return false;
    }
    function tplTargets(t) {
        return combatants().filter(c => {
            const k = S.tokens[c.id]; if (!k || !onCur(c.id)) return false;
            const n = sizeOf(c);
            for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) if (inTpl(t, px(k.x + i) + G.cell / 2, py(k.y + j) + G.cell / 2)) return true;
            return false;
        });
    }
    function tplHits() {
        const out = new Set();
        S.tpl.forEach(t => tplTargets(t).forEach(c => out.add(c.id)));
        return out;
    }
    function tplSVG(t, extra = '') {
        const { col, shape, label, lx, ly } = tplShape(t);
        return `<g class="vt-t ${extra} ${ui.tplSel === t.id ? 'sel' : ''}" data-tpl="${t.id}" style="--c:${col}">
            <g class="vt-t-shape">${shape}</g>
            <circle class="vt-t-o" cx="${t.x0}" cy="${t.y0}" r="6"/>
            <text x="${lx}" y="${ly - 10}" class="vt-t-l">${label}</text></g>`;
    }
    function renderTpl() {
        const svg = root?.querySelector('.vt-tpl'); if (!svg) return;
        svg.innerHTML = `<defs><filter id="vt-blur"><feGaussianBlur stdDeviation="6"/></filter></defs>` + S.tpl.map(t => tplSVG(t, t.fresh ? 'fresh' : '')).join('');
        S.tpl.forEach(t => { delete t.fresh; });
    }

    // ---------- widok ----------
    function applyTransform() {
        const b = root?.querySelector('.vt-board'); if (!b) return;
        b.style.transform = `translate(${ui.panX}px, ${ui.panY}px) scale(${ui.zoom})`;
    }
    function clampPan() {
        const vp = root.querySelector('.vt-vp'); if (!vp) return;
        if (vp.clientWidth && ui.zoom < coverZ(vp)) ui.zoom = coverZ(vp);
        const bw = G.w * ui.zoom, bh = G.h * ui.zoom, vw = vp.clientWidth, vh = vp.clientHeight, m = 0;
        ui.panX = bw < vw ? (vw - bw) / 2 : Math.max(vw - bw - m, Math.min(m, ui.panX));
        ui.panY = bh < vh ? (vh - bh) / 2 : Math.max(vh - bh - m, Math.min(m, ui.panY));
    }
    const coverZ = (vp) => Math.max(vp.clientWidth / G.w, vp.clientHeight / G.h);
    function fit() {
        const vp = root?.querySelector('.vt-vp'); if (!vp || !vp.clientWidth) return;
        ui.zoom = coverZ(vp);   // plansza wypełnia okno — bez oddalania poza jej rozmiar
        ui.panX = (vp.clientWidth - G.w * ui.zoom) / 2; ui.panY = (vp.clientHeight - G.h * ui.zoom) / 2;
        ui.fitKey = sceneKey();
        applyTransform();
        if (ui.pop) placePop();
    }
    function zoomAt(z, cx, cy) {
        const vp = root.querySelector('.vt-vp');
        if (cx == null) { cx = vp.clientWidth / 2; cy = vp.clientHeight / 2; }
        const cz = coverZ(vp), nz = Math.max(cz, Math.min(Math.max(3, cz * 3), z));
        const bx = (cx - ui.panX) / ui.zoom, by = (cy - ui.panY) / ui.zoom;
        ui.zoom = nz; ui.panX = cx - bx * nz; ui.panY = cy - by * nz;
        clampPan(); applyTransform();
        if (ui.pop) placePop();
    }
    function centerOn(id, smooth = true) {
        const c = byId(id), t = S.tokens[id], vp = root?.querySelector('.vt-vp');
        if (!c || !t || !vp || !vp.clientWidth) return;
        const n = sizeOf(c);
        const bx = px(t.x) + n * G.cell / 2, by = py(t.y) + n * G.cell / 2;
        ui.panX = vp.clientWidth / 2 - bx * ui.zoom; ui.panY = vp.clientHeight / 2 - by * ui.zoom;
        clampPan();
        const b = root.querySelector('.vt-board');
        if (smooth && b) { b.classList.add('smooth'); setTimeout(() => b.classList.remove('smooth'), 420); }
        applyTransform();
    }
    function tokenVisible(id) {
        const t = S.tokens[id], vp = root?.querySelector('.vt-vp'); if (!t || !vp) return true;
        const sx = px(t.x) * ui.zoom + ui.panX, sy = py(t.y) * ui.zoom + ui.panY;
        return sx > 40 && sy > 60 && sx < vp.clientWidth - 40 && sy < vp.clientHeight - 40;
    }
    function boardPos(e) {
        const b = root.querySelector('.vt-board').getBoundingClientRect();
        return { x: (e.clientX - b.left) / ui.zoom, y: (e.clientY - b.top) / ui.zoom };
    }

    // ---------- synchronizacja z trackerem ----------
    function syncTokens() {
        if (!document.getElementById('vtt-container')) return;
        const before = loadedFor;
        sc();
        if (!root || before !== loadedFor || !root.querySelector('.vt-board')) { G = null; }
        if (!G) { renderAll(); }
        const list = combatants();
        const ids = new Set(list.map(c => c.id));
        let changed = false;
        if (ui.fitKey !== sceneKey()) fit();
        Object.keys(S.tokens).forEach(id => { if (!ids.has(id)) { delete S.tokens[id]; changed = true; } });
        const center = viewCenterCell();
        list.forEach(c => {
            if (S.tokens[c.id]) return;
            const p = freeCell(center.x, center.y, sizeOf(c), occupied(c.id));
            S.tokens[c.id] = { x: p.x, y: p.y, moved: 0, ...(isInt() ? { lv: curLv() } : {}) };
            changed = true;
        });
        const act = active();
        if ((act?.id || null) !== ui.lastTurn) {
            ui.lastTurn = act?.id || null;
            if (act && S.tokens[act.id] && S.tokens[act.id].tt !== turnTag()) { S.tokens[act.id].moved = 0; S.tokens[act.id].tt = turnTag(); changed = true; }
            if (act && ui.follow && root && S.tokens[act.id] && isInt() && !onCur(act.id)) switchLevel(lvOf(S.tokens[act.id]));
            if (act && ui.follow && root && !tokenVisible(act.id)) requestAnimationFrame(() => centerOn(act.id));
        }
        if (ui.sel && !ids.has(ui.sel)) { ui.sel = null; closePop(); }
        if (changed) save();
        renderTokens();
    }
    function resetTurnMovement() {
        const act = active();
        if (act && S?.tokens[act.id] && S.tokens[act.id].tt !== turnTag()) { S.tokens[act.id].moved = 0; S.tokens[act.id].tt = turnTag(); save(); renderTokens(); }
    }

    // ---------- popover żetonu ----------
    function popHTML(c) {
        const t = S.tokens[c.id] || {};
        const conds = (window.APIClient && APIClient.CONDITIONS) || Object.keys(COND_PL);
        const typeName = { pc: 'Bohater', player: 'Bohater', npc: 'NPC', monster: 'Przeciwnik' }[c.type] || '';
        return `<div class="vt-pop" data-pop="${esc(c.id)}" style="--c:${colorOf(c)}">
            <div class="vt-pop-head"><span class="vt-pop-face">${esc(initials(c.name))}</span><div><b>${esc(c.name)}</b><small>${typeName} · KP ${c.ac} · inicjatywa ${c.initiative}${c.speed ? ` · ${c.speed} ft` : ''}</small></div><button data-p="close" title="Zamknij">✕</button></div>
            <div class="vt-pop-hp">
                <div class="vt-pop-bar"><i style="width:${c.maxHp ? Math.max(0, Math.min(100, c.hp / c.maxHp * 100)) : 0}%"></i><span>${c.hp} / ${c.maxHp} PW</span></div>
                <div class="vt-pop-row"><input type="number" min="1" value="" placeholder="ile?" class="vt-pop-v" aria-label="Wartość"><button data-p="dmg" class="dmg"><i class="fa-solid fa-heart-crack"></i> Obrażenia</button><button data-p="heal" class="heal"><i class="fa-solid fa-heart"></i> Leczenie</button></div>
            </div>
            <div class="vt-pop-conds">${conds.map(k => `<button data-cond="${esc(k)}" class="${(c.conditions || []).includes(k) ? 'on' : ''}" title="${esc(window.getCondDesc ? getCondDesc(k) : '')}"><i class="fa-solid ${COND_ICON[k] || 'fa-circle'}"></i>${esc(COND_PL[k] || k)}</button>`).join('')}</div>
            <div class="vt-pop-row">
                <select data-p="size" title="Rozmiar żetonu">${SIZES.map((n, i) => `<option value="${i + 1}" ${sizeOf(c) === i + 1 ? 'selected' : ''}>${n}</option>`).join('')}</select>
                ${c.npcId && window.NPCsModule ? `<button onclick="NPCsModule.showSheet('${esc(c.npcId)}')" title="Karta NPC: ataki i rzuty"><i class="fa-solid fa-scroll"></i> Karta</button>` : ''}
                <button data-p="light" class="${t.light ? 'on' : ''}" title="Niesie pochodnię / światło (40 ft) — ważne przy mgle wojny w ciemności"><i class="fa-solid fa-fire"></i> ${t.light ? 'Światło ✓' : 'Światło'}</button>
                <button data-p="hide" title="Ukryj przed graczami">${c.hidden ? '<i class="fa-solid fa-eye"></i> Ujawnij' : '<i class="fa-solid fa-eye-slash"></i> Ukryj'}</button>
            </div>
            <div class="vt-pop-row">
                ${movedOf(t) ? `<button data-p="resetmove" title="Wyzeruj przebyty dystans"><i class="fa-solid fa-rotate-left"></i> Ruch (${movedOf(t)} ft)</button>` : ''}
                <button data-p="remove" class="danger"><i class="fa-solid fa-trash"></i> Usuń z walki</button>
            </div>
        </div>`;
    }
    function openPop(id) {
        const c = byId(id); if (!c) return;
        ui.sel = id; ui.pop = id;
        closePop(true);
        root.insertAdjacentHTML('beforeend', popHTML(c));
        placePop();
        renderTokens();
        if (window.CombatModule?.highlightCombatant) CombatModule.highlightCombatant(id);
    }
    function closePop(keep) {
        root?.querySelectorAll('.vt-pop').forEach(p => p.remove());
        if (!keep) ui.pop = null;
    }
    function refreshPop() {
        if (!ui.pop) return;
        const c = byId(ui.pop); if (!c) { closePop(); return; }
        const old = root.querySelector('.vt-pop'), val = old?.querySelector('.vt-pop-v')?.value;
        closePop(true);
        root.insertAdjacentHTML('beforeend', popHTML(c));
        if (val) root.querySelector('.vt-pop .vt-pop-v').value = val;
        placePop();
    }
    function placePop() {
        const p = root?.querySelector('.vt-pop'), tok = root?.querySelector(`.vt-tok[data-cid="${CSS.escape(ui.pop || '')}"]`);
        if (!p) return;
        if (!tok) { p.style.left = '70px'; p.style.top = '70px'; return; }
        const R = root.getBoundingClientRect(), T = tok.getBoundingClientRect();
        let x = T.right - R.left + 12, y = T.top - R.top - 10;
        if (x + p.offsetWidth > R.width - 8) x = T.left - R.left - p.offsetWidth - 12;
        x = Math.max(8, x);
        y = Math.max(56, Math.min(R.height - p.offsetHeight - 8, y));
        p.style.left = x + 'px'; p.style.top = y + 'px';
    }

    // ---------- interakcje ----------
    function bind() {
        if (root._vtBound) return;
        root._vtBound = true;

        root.addEventListener('click', (e) => {
            const b = (s) => e.target.closest(s);
            const pop = b('.vt-pop');
            if (pop) { popAction(e, pop.dataset.pop); return; }
            if (b('[data-tool]')) { ui.tool = b('[data-tool]').dataset.tool; ui.tplSel = null; renderAll(); return; }
            if (b('[data-golv]')) { switchLevel(b('[data-golv]').dataset.golv); const a = active(); if (a) requestAnimationFrame(() => centerOn(a.id)); return; }
            if (b('[data-stairs]')) { changeLevel(b('[data-stairs]').dataset.stairs); return; }
            if (b('[data-ter]')) { ui.ter = b('[data-ter]').dataset.ter; root.querySelectorAll('[data-ter]').forEach(x => x.classList.toggle('on', x === b('[data-ter]'))); return; }
            if (b('[data-el]')) { ui.el = b('[data-el]').dataset.el; root.querySelectorAll('[data-el]').forEach(x => x.classList.toggle('on', x === b('[data-el]'))); if (!['sphere', 'cone', 'line', 'cube'].includes(ui.tool)) { ui.tool = 'sphere'; renderAll(); } return; }
            if (b('[data-zoom]')) {
                const z = b('[data-zoom]').dataset.zoom;
                if (z === 'in') zoomAt(ui.zoom * 1.2); else if (z === 'out') zoomAt(ui.zoom / 1.2); else if (z === 'fit') fit();
                else if (active()) centerOn(active().id);
                return;
            }
            const v = b('[data-v]')?.dataset.v;
            if (!v) return;
            if (v === 'import') importDialog({});
            else if (v === 'image') root.querySelector('.vt-file').click();
            else if (v === 'blank') blankDialog();
            else if (v === 'gridpop') { ui.gridPop = !ui.gridPop; renderAll(); }
            else if (v === 'player') { ui.player = !ui.player; closePop(); renderAll(); }
            else if (v === 'full') {
                const el = document.querySelector('#tab-combat .combat-layout') || root;
                if (document.fullscreenElement) document.exitFullscreen(); else el.requestFullscreen?.().then(() => setTimeout(fit, 150)).catch(() => {});
            }
            else if (v === 'clearter') { Ask.confirm('Przeszkody, trudny teren i wzniesienia namalowane na tej planszy (tym piętrze) znikną.', { title: 'Wyczyścić teren?', ok: 'Wyczyść', danger: true }).then(ok => { if (ok) { const P = curPaint(); Object.keys(P).forEach(k => delete P[k]); terVer++; save(); renderAll(); } }); }
            else if (v === 'cleartpl') { S.tpl = []; ui.tplSel = null; save(); renderTpl(); renderTokens(); }
            else if (v === 'writeback') writeBack();
            else if (v === 'next') CombatModule.nextTurn();
            else if (v === 'start') CombatModule.startCombat();
            else if (v === 'party') { if (window.Enhancements?.partyToCombat) Enhancements.partyToCombat(); else document.getElementById('btn-add-party-combat')?.click(); }
        });

        root.addEventListener('change', (e) => {
            const t = e.target;
            if (t.classList.contains('vt-file')) { loadImage(t.files[0]); t.value = ''; return; }
            if (t.matches('[data-lvl]')) { switchLevel(t.value); return; }
            if (t.matches('[data-p="size"]')) { CombatModule.updateCombatant(ui.pop, { size: +t.value }); refreshPop(); return; }
            const g = t.dataset.g; if (!g) return;
            if (g === 'grid' || g === 'limit' || g === 'playersMove' || g === 'fog' || g === 'fogShare') S[g] = t.checked;
            else if (g === 'follow') ui.follow = t.checked;
            else if (g === 'diag' || g === 'bg') S[g] = t.value;
            else if (g === 'cols' || g === 'rows') S[g] = Math.max(6, Math.min(80, parseInt(t.value, 10) || 20));
            save(); renderAll();
        });
        root.addEventListener('input', (e) => {
            const t = e.target, g = t.dataset.g; if (!g) return;
            if (g === 'galpha') { S.galpha = +t.value / 100; root.querySelector('.vt-grid')?.style.setProperty('--ga', S.galpha); save(); return; }
            if (g === 'cell' || g === 'ox' || g === 'oy') {
                S[g] = +t.value;
                if (g === 'cell') { const b = t.parentElement.querySelector('b'); if (b) b.textContent = `${t.value}px`; }
                G = geo();
                const gr = root.querySelector('.vt-grid');
                if (gr) { gr.style.setProperty('--gs', G.cell + 'px'); gr.style.setProperty('--gx', G.ox + 'px'); gr.style.setProperty('--gy', G.oy + 'px'); }
                renderTokens(); renderTpl();
                clearTimeout(root._gs); root._gs = setTimeout(() => { save(); ui.fitKey = sceneKey(); }, 300);
            }
        });

        root.addEventListener('pointerdown', (e) => {
            const vp = e.target.closest('.vt-vp');
            if (!vp || e.target.closest('.vt-zoom, .vt-banner, .vt-empty')) return;
            if (!e.target.closest('.vt-pop')) closePop();
            if (e.target.closest('.vt-stair')) return;
            const tok = e.target.closest('.vt-tok');
            if (e.button === 1 || e.button === 2 || (e.button === 0 && ui.tool === 'select' && !tok && !e.target.closest('.vt-t'))) {
                ui.drag = { kind: 'pan', sx: e.clientX, sy: e.clientY, px: ui.panX, py: ui.panY, moved: false };
                vp.classList.add('panning');
                e.preventDefault();
                return;
            }
            if (e.button !== 0) return;
            const p = boardPos(e);
            if (ui.tool === 'select' && tok) {
                const id = tok.dataset.cid, t = S.tokens[id];
                ui.drag = { kind: 'tok', id, sx: e.clientX, sy: e.clientY, x0: t.x, y0: t.y, moved: false, el: tok };
                e.preventDefault();
                return;
            }
            if (ui.tool === 'select' && e.target.closest('.vt-t')) {
                ui.tplSel = +e.target.closest('.vt-t').dataset.tpl; renderTpl();
                App.showToast('Szablon zaznaczony — Delete usuwa', 'info');
                return;
            }
            if (ui.tool === 'ping') { ping(p.x, p.y); return; }
            if (ui.tool === 'terrain') { ui.drag = { kind: 'ter' }; paintTer(p); e.preventDefault(); return; }
            if (ui.tool === 'ruler') { ui.drag = { kind: 'ruler', x0: snapC(p.x, 'x'), y0: snapC(p.y, 'y'), x1: p.x, y1: p.y }; drawRuler(); e.preventDefault(); return; }
            if (['sphere', 'cone', 'line', 'cube'].includes(ui.tool)) {
                ui.drag = { kind: 'tpl', t: { id: Date.now(), type: ui.tool, el: ui.el, x0: snapI(p.x, 'x'), y0: snapI(p.y, 'y'), x1: p.x, y1: p.y } };
                e.preventDefault();
            }
        });
        window.addEventListener('pointermove', (e) => {
            const d = ui.drag; if (!d || !root.isConnected) return;
            if (d.kind === 'pan') {
                if (Math.abs(e.clientX - d.sx) + Math.abs(e.clientY - d.sy) > 3) d.moved = true;
                ui.panX = d.px + e.clientX - d.sx; ui.panY = d.py + e.clientY - d.sy; clampPan(); applyTransform();
                if (ui.pop) placePop();
                return;
            }
            const p = boardPos(e);
            if (d.kind === 'tok') {
                const dx = (e.clientX - d.sx) / ui.zoom, dy = (e.clientY - d.sy) / ui.zoom;
                if (!d.moved && Math.hypot(dx, dy) < 5) return;
                d.moved = true; d.el.classList.add('dragging');
                d.el.style.left = (px(d.x0) + dx) + 'px'; d.el.style.top = (py(d.y0) + dy) + 'px';
                d.nx = d.x0 + Math.round(dx / G.cell); d.ny = d.y0 + Math.round(dy / G.cell);
                drawMove(d, e.shiftKey);
                return;
            }
            if (d.kind === 'ter') { paintTer(p); return; }
            if (d.kind === 'ruler') { d.x1 = snapC(p.x, 'x'); d.y1 = snapC(p.y, 'y'); drawRuler(); return; }
            if (d.kind === 'tpl') {
                const raw = Math.hypot(p.x - d.t.x0, p.y - d.t.y0), Ls = Math.max(1, Math.round(raw / G.cell)) * G.cell, a = Math.atan2(p.y - d.t.y0, p.x - d.t.x0);
                if (d.t.type === 'cube') { const sd = Math.max(1, Math.round(Math.max(Math.abs(p.x - d.t.x0), Math.abs(p.y - d.t.y0)) / G.cell)) * G.cell; d.t.x1 = d.t.x0 + Math.sign(p.x - d.t.x0 || 1) * sd; d.t.y1 = d.t.y0 + Math.sign(p.y - d.t.y0 || 1) * sd; }
                else { d.t.x1 = d.t.x0 + Math.cos(a) * Ls; d.t.y1 = d.t.y0 + Math.sin(a) * Ls; }
                const over = root.querySelector('.vt-over');
                const n = tplTargets(d.t).length;
                over.innerHTML = tplSVG(d.t, 'preview') + `<text x="${d.t.x0}" y="${d.t.y0 - 16}" class="vt-t-l small">${n ? `cele: ${n}` : ''}</text>`;
            }
        });
        window.addEventListener('pointerup', (e) => {
            const d = ui.drag; if (!d) return;
            ui.drag = null;
            if (!root.isConnected) return;
            root.querySelector('.vt-vp')?.classList.remove('panning');
            const over = root.querySelector('.vt-over');
            if (d.kind === 'pan') { if (!d.moved && ui.tplSel != null) { ui.tplSel = null; renderTpl(); } return; }
            if (d.kind === 'ter') { save(); return; }
            if (d.kind === 'tok') {
                over.innerHTML = '';
                if (!d.moved) { openPop(d.id); return; }
                commitMove(d.id, d.nx, d.ny, e.shiftKey);
                return;
            }
            if (d.kind === 'ruler') { over.querySelectorAll('.vt-ruler').forEach(r => r.classList.add('fade')); setTimeout(() => { if (!ui.drag) over.innerHTML = ''; }, 1400); return; }
            if (d.kind === 'tpl') {
                over.innerHTML = '';
                if (Math.hypot(d.t.x1 - d.t.x0, d.t.y1 - d.t.y0) < G.cell * 0.9) return;
                d.t.fresh = true;
                S.tpl.push(d.t); save(); renderTpl(); renderTokens();
                const hit = tplTargets(d.t);
                App.showToast(`${TOOLS.find(t => t[0] === d.t.type)[2]} ${tplShape(d.t).label}${hit.length ? ` — w obszarze: ${hit.map(c => c.name).join(', ')}` : ' — nikt w obszarze'}`, hit.length ? 'warning' : 'info');
            }
        });
        root.addEventListener('contextmenu', (e) => {
            if (!e.target.closest('.vt-vp')) return;
            e.preventDefault();
            const t = e.target.closest('.vt-t');
            if (t && ui.drag == null) { S.tpl = S.tpl.filter(x => x.id !== +t.dataset.tpl); save(); renderTpl(); renderTokens(); }
        });
        root.addEventListener('wheel', (e) => {
            const vp = e.target.closest('.vt-vp'); if (!vp || e.target.closest('.vt-pop')) return;
            e.preventDefault();
            const r = vp.getBoundingClientRect();
            zoomAt(ui.zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12), e.clientX - r.left, e.clientY - r.top);
        }, { passive: false });
        root.addEventListener('dblclick', (e) => {
            if (!e.target.closest('.vt-vp') || e.target.closest('.vt-tok, .vt-zoom, .vt-banner, .vt-empty')) return;
            const p = boardPos(e); ping(p.x, p.y);
        });
        document.addEventListener('keydown', (e) => {
            if (!document.getElementById('tab-combat')?.classList.contains('active')) return;
            if (e.target.matches('input, textarea, select') || (document.getElementById('modal-backdrop') && !document.getElementById('modal-backdrop').classList.contains('hidden'))) return;
            if (e.key === 'Escape') { if (ui.pop) closePop(); else if (ui.tool !== 'select') { ui.tool = 'select'; renderAll(); } else if (ui.tplSel != null) { ui.tplSel = null; renderTpl(); } }
            else if ((e.key === 'Delete' || e.key === 'Backspace') && ui.tplSel != null) { S.tpl = S.tpl.filter(x => x.id !== ui.tplSel); ui.tplSel = null; save(); renderTpl(); renderTokens(); }
            else if (ui.sel && S.tokens[ui.sel] && e.key.startsWith('Arrow')) {
                e.preventDefault();
                const t = S.tokens[ui.sel], d = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] }[e.key];
                commitMove(ui.sel, t.x + d[0], t.y + d[1], e.shiftKey);
            }
        });
        window.addEventListener('resize', () => { if (root.isConnected && root.offsetWidth) { clampPan(); applyTransform(); } });
    }
    const snapI = (v, ax) => { const o = ax === 'x' ? G.ox : G.oy; return o + Math.round((v - o) / G.cell) * G.cell; };
    const snapC = (v, ax) => { const o = ax === 'x' ? G.ox : G.oy; return o + (Math.floor((v - o) / G.cell) + 0.5) * G.cell; };

    function moveCheck(id, nx, ny, free) {
        const c = byId(id), t = S.tokens[id], n = sizeOf(c);
        let dist = feet(nx - t.x, ny - t.y), path = null;
        if (areaBlocked(nx, ny, n)) return { ok: false, dist, why: whatBlocks(nx, ny, n) };
        if (!free && window.MapForge?.reach) {
            const r = reachFor(id)(nx, ny);
            if (!r) return { ok: false, dist, why: 'Nie da się tam dojść — przeszkody na drodze (Shift — przenieś mimo to)' };
            const rough = r.ft > dist;
            dist = r.ft; path = r.path;
            const act0 = active();
            if (S.limit !== false && combatActive() && act0 && act0.id === id && dist > remainOf(c, t)) return { ok: false, dist, path, rough, why: `Za daleko: ${dist} ft${rough ? ' (trudny teren)' : ''}, zostało ${remainOf(c, t)} ft (Shift — mimo to)` };
            return { ok: true, dist, path, rough };
        }
        const act = active();
        if (!free && S.limit !== false && combatActive() && act && act.id === id) {
            const rem = remainOf(c, t);
            if (dist > rem) return { ok: false, dist, why: `Za daleko: ${dist} ft, zostało ${rem} ft (Shift — mimo to)` };
        }
        return { ok: true, dist };
    }
    function drawMove(d, free) {
        const over = root.querySelector('.vt-over'), c = byId(d.id), n = sizeOf(c), h = n * G.cell / 2;
        const chk = moveCheck(d.id, d.nx, d.ny, free);
        const x0 = px(d.x0) + h, y0 = py(d.y0) + h, x1 = px(d.nx) + h, y1 = py(d.ny) + h;
        // zasięg ruchu aktywnej postaci (pola, do których jeszcze dojdzie)
        if (d.area == null) {
            d.area = '';
            const t = S.tokens[d.id], act = active();
            if (!free && window.MapForge?.reach && combatActive() && act && act.id === d.id && S.limit !== false) {
                const rem = remainOf(c, t), fn = reachFor(d.id); let r = '';
                for (let y = 0; y < G.rows; y++) for (let x = 0; x < G.cols; x++) { const v = fn.cost(x, y); if (v != null && v <= rem && v > 0) r += `M${px(x)} ${py(y)}h${G.cell}v${G.cell}h${-G.cell}z`; }
                d.area = r ? `<path class="vt-reach" d="${r}"/>` : '';
            }
        }
        const pts = chk.path && chk.path.length > 1 ? chk.path.filter((q, i, a) => i === 0 || i === a.length - 1 || (q.x - a[i - 1].x) !== (a[i + 1].x - q.x) || (q.y - a[i - 1].y) !== (a[i + 1].y - q.y)).map(q => `${px(q.x) + h},${py(q.y) + h}`).join(' ') : `${x0},${y0} ${x1},${y1}`;
        over.innerHTML = `${d.area}<g class="vt-path ${chk.ok ? 'ok' : 'bad'}">
            <rect x="${px(d.nx)}" y="${py(d.ny)}" width="${n * G.cell}" height="${n * G.cell}" rx="8" class="vt-ghost"/>
            <polyline points="${pts}" fill="none"/>
            <circle cx="${x0}" cy="${y0}" r="7"/>
            <text x="${x1}" y="${py(d.ny) - 10}">${chk.dist} ft${chk.rough ? ' · trudny teren' : ''}${chk.ok ? '' : ' ✕'}</text></g>`;
    }
    function commitMove(id, nx, ny, free) {
        const t = S.tokens[id]; if (!t) return;
        const chk = moveCheck(id, nx, ny, free);
        if (nx === t.x && ny === t.y) { renderTokens(); return; }
        if (!chk.ok) { App.showToast(chk.why, 'warning'); renderTokens(); return; }
        if (active()?.id === id) { t.moved = movedOf(t) + chk.dist; t.tt = turnTag(); }
        t.x = nx; t.y = ny;
        save(); renderTokens();
        window.CombatModule?.refreshFocus?.();
        const hz = G.kind === 'interior' ? MapForge.hazardAt(G.lv, nx, ny) : '';
        if (hz) App.showToast(`${byId(id)?.name || ''}: ${hz}`, 'warning');
    }
    function drawRuler() {
        const d = ui.drag, over = root.querySelector('.vt-over');
        const dist = feet((d.x1 - d.x0) / G.cell, (d.y1 - d.y0) / G.cell);
        over.innerHTML = `<g class="vt-ruler"><line x1="${d.x0}" y1="${d.y0}" x2="${d.x1}" y2="${d.y1}"/><circle cx="${d.x0}" cy="${d.y0}" r="6"/><circle cx="${d.x1}" cy="${d.y1}" r="6"/>
            <text x="${d.x1 + 14}" y="${d.y1 - 14}">${dist} ft</text></g>`;
    }
    function ping(x, y) {
        const over = root.querySelector('.vt-over'); if (!over) return;
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.setAttribute('class', 'vt-ping');
        g.innerHTML = `<circle cx="${x}" cy="${y}" r="${G.cell * 0.5}"/><circle cx="${x}" cy="${y}" r="${G.cell * 0.5}" class="d2"/><circle cx="${x}" cy="${y}" r="8" class="core"/>`;
        over.appendChild(g);
        setTimeout(() => g.remove(), 1700);
    }

    function popAction(e, id) {
        const b = (s) => e.target.closest(s);
        const c = byId(id); if (!c) { closePop(); return; }
        const val = () => Math.abs(parseInt(root.querySelector('.vt-pop .vt-pop-v')?.value, 10) || 0);
        if (b('[data-p="close"]')) { closePop(); ui.sel = null; renderTokens(); return; }
        if (b('[data-p="dmg"]') || b('[data-p="heal"]')) {
            const v = val(); if (!v) { root.querySelector('.vt-pop .vt-pop-v')?.focus(); return; }
            const heal = !!b('[data-p="heal"]');
            CombatModule.modifyHP(id, heal ? v : -v);
            floatText(id, heal ? `+${v}` : `−${v}`, heal ? 'heal' : 'dmg');
            root.querySelector('.vt-pop .vt-pop-v').value = '';
            refreshPop(); return;
        }
        if (b('[data-cond]')) {
            const k = b('[data-cond]').dataset.cond;
            if ((c.conditions || []).includes(k)) CombatModule.removeCondition(id, k); else CombatModule.addCondition(id, k);
            refreshPop(); return;
        }
        if (b('[data-p="hide"]')) { CombatModule.updateCombatant(id, { hidden: !c.hidden }); refreshPop(); return; }
        if (b('[data-p="light"]')) { const t = S.tokens[id]; if (t) { t.light = !t.light; save(); renderTokens(); refreshPop(); } return; }
        if (b('[data-p="resetmove"]')) { S.tokens[id].moved = 0; S.tokens[id].tt = turnTag(); save(); renderTokens(); refreshPop(); return; }
        if (b('[data-p="remove"]')) { closePop(); CombatModule.removeCombatant(id); return; }
    }
    function floatText(id, txt, cls) {
        const t = S.tokens[id], c = byId(id); if (!t || !c) return;
        const lay = root.querySelector('.vt-toks'); if (!lay) return;
        const f = document.createElement('div');
        f.className = `vt-float ${cls}`; f.textContent = txt;
        f.style.left = (px(t.x) + sizeOf(c) * G.cell / 2) + 'px'; f.style.top = py(t.y) + 'px';
        lay.parentElement.appendChild(f);
        setTimeout(() => f.remove(), 1300);
    }

    // ---------- sceny ----------
    function setScene(s, keepTokens) {
        const keep = { grid: S.grid, galpha: S.galpha, diag: S.diag, limit: S.limit };
        S = { ...DEF(), ...keep, ...s, tokens: keepTokens ? S.tokens : {}, tpl: [] };
        ui.fitKey = null; ui.tplSel = null; closePop(); ui.sel = null; ui.gridPop = false;
        G = null;
        save();
    }
    function loadImage(file) {
        if (!file) return;
        const rd = new FileReader();
        rd.onload = () => {
            const img = new Image();
            img.onload = () => {
                const k = Math.min(1, 3000 / Math.max(img.naturalWidth, img.naturalHeight));
                const w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
                const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
                cv.getContext('2d').drawImage(img, 0, 0, w, h);
                const url = cv.toDataURL('image/jpeg', 0.85);
                setScene({ kind: 'image', name: file.name.replace(/\.[^.]+$/, ''), url, w, h, cell: 70, ox: 0, oy: 0 });
                const ok = (StorageManager.get(KEY()) || {}).url === url;
                ui.gridPop = true;
                renderAll(); syncTokens();
                App.showToast(ok ? 'Mapa wczytana — dopasuj siatkę do kratek na obrazie' : 'Mapa wczytana, ale jest za duża, by ją zapamiętać po odświeżeniu', ok ? 'success' : 'warning');
            };
            img.src = rd.result;
        };
        rd.readAsDataURL(file);
    }
    function blankDialog() {
        App.showModal('Pusta plansza', `
            <div class="form-row">
                <div class="form-group"><label>Kolumny</label><input type="number" id="vt-b-c" min="6" max="80" value="${S.kind === 'blank' ? S.cols : 26}"></div>
                <div class="form-group"><label>Wiersze</label><input type="number" id="vt-b-r" min="6" max="80" value="${S.kind === 'blank' ? S.rows : 18}"></div>
                <div class="form-group"><label>Podłoże</label><select id="vt-b-bg">${Object.entries(BG).map(([k, v]) => `<option value="${k}" ${S.bg === k ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
            </div><p class="modal-hint">Uczestnicy walki zostaną na planszy, w miarę możliwości w tych samych polach.</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="vt-b-go"><i class="fa-solid fa-chess-board"></i> Ustaw planszę</button>`);
        document.getElementById('vt-b-go').onclick = () => {
            const cols = Math.max(6, Math.min(80, parseInt(document.getElementById('vt-b-c').value, 10) || 26));
            const rows = Math.max(6, Math.min(80, parseInt(document.getElementById('vt-b-r').value, 10) || 18));
            setScene({ kind: 'blank', name: 'Pusta plansza', cols, rows, bg: document.getElementById('vt-b-bg').value, cell: 70 }, true);
            Object.values(S.tokens).forEach(t => { t.x = Math.min(t.x, cols - 1); t.y = Math.min(t.y, rows - 1); });
            App.closeModal(); renderAll(); syncTokens();
        };
    }
    // widok MG przechodzi na inne piętro — żetony zostają tam, gdzie stoją
    function switchLevel(levelId) {
        if (isInt()) Object.values(S.tokens).forEach(t => { if (!t.lv) t.lv = G.d.levelId; });
        S.levelId = levelId; G = null; ui.fitKey = null; closePop(); save();
        renderAll();
        // żetony tego piętra, które stoją w ścianie, przestaw na najbliższe wolne pole
        combatants().forEach(c => { const t = S.tokens[c.id]; if (t && onCur(c.id) && areaBlocked(t.x, t.y, sizeOf(c))) { const p = freeCell(t.x, t.y, sizeOf(c), occupied(c.id)); t.x = p.x; t.y = p.y; } });
        if (ui.sel && !onCur(ui.sel)) ui.sel = null;
        save(); renderTokens();
        window.CombatModule?.refreshFocus?.();
    }
    // pełne piętra wnętrza (z elementami) — do schodów
    function interiorFull() {
        if (!isInt()) return null;
        return { levels: G.d.levels.map(L => L.id === G.d.levelId ? G.lv : (Atlas.fightData(S.mapId, L.id) || {}).lv).filter(Boolean) };
    }
    function stairsTo(id) {
        if (!isInt() || !window.MapForge?.stairsAt) return null;
        const t = S.tokens[id], c = byId(id); if (!t || !c) return null;
        const st = MapForge.stairsAt(G.lv, t.x, t.y, sizeOf(c)); if (!st) return null;
        const i = G.d.levels.findIndex(L => L.id === curLv()), L = G.d.levels[i + st.sd];
        return L ? { sd: st.sd, o: st.o, name: L.name, idx: i } : null;
    }
    function changeLevel(id) {
        const st = stairsTo(id), c = byId(id), t = S.tokens[id]; if (!st || !t) return;
        const it = interiorFull(); if (!it) return;
        const tgt = G.d.levels[st.idx + st.sd].id;
        const taken = (x, y, n) => Object.entries(S.tokens).some(([oid, o]) => oid !== id && byId(oid) && lvOf(o) === tgt && x < o.x + sizeOf(byId(oid)) && x + n > o.x && y < o.y + sizeOf(byId(oid)) && y + n > o.y);
        const land = MapForge.stairsLanding(it, st.idx, st.o, st.sd, sizeOf(c), taken, { secret: true, paint: (S.terL || {})[tgt] || {} });
        if (!land) { App.showToast('Na górze/dole nie ma wolnego miejsca przy schodach', 'warning'); return; }
        t.lv = land.levelId; t.x = land.x; t.y = land.y; save();
        App.showToast(`${c.name} ${st.sd > 0 ? 'wchodzi na' : 'schodzi do'}: ${land.name}`, 'info');
        switchLevel(land.levelId);
        requestAnimationFrame(() => centerOn(id));
    }
    const levelOf = (id) => { if (!S || S.kind !== 'atlas' || !G || G.kind !== 'interior') return null; const lv = lvOf(S.tokens[id]); const L = G.d.levels.find(x => x.id === lv); return L ? { id: L.id, name: L.name, here: L.id === curLv(), many: G.d.levels.length > 1 } : null; };

    // ---------- import z Atlasu ----------
    const d20 = () => Math.floor(Math.random() * 20) + 1;
    const abMod = (v) => Math.floor(((+v || 10) - 10) / 2);
    function thumb(sc0, levelId) {
        if (sc0.kind === 'interior') {
            const d = Atlas.fightData(sc0.id, levelId || sc0.ground);
            if (!d) return '';
            const u = URL.createObjectURL(new Blob([MapForge.svg(d.lv, { player: false })], { type: 'image/svg+xml' }));
            thumbUrls.push(u);
            return `<img src="${u}" alt="">`;
        }
        return `<img src="${esc(sc0.url)}" alt="">`;
    }
    let thumbUrls = [];
    function importDialog(pre = {}) {
        if (!window.Atlas?.fightScenes) { App.showToast('Atlas jest niedostępny', 'warning'); return; }
        const list = Atlas.fightScenes();
        thumbUrls.forEach(u => URL.revokeObjectURL(u)); thumbUrls = [];
        if (!list.length) {
            App.showModal('Lokacja z Atlasu', `<div class="vi-none"><p>W Atlasie nie ma jeszcze map, które można przenieść na pole walki.</p><p class="modal-hint">Otwórz <b>Kampania → Mapy</b>, wybierz miejsce (np. karczmę) i utwórz dla niego <b>wnętrze</b> w kuźni map albo mapę z obrazka. Potem wróć tutaj albo użyj przycisku <b>Walka tutaj</b> na mapie.</p></div>`,
                `<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button><button class="btn-primary" id="vi-goatlas"><i class="fa-solid fa-map"></i> Przejdź do map</button>`);
            document.getElementById('vi-goatlas').onclick = () => { App.closeModal(); App.switchTab('campaign', 'maps'); };
            return;
        }
        let sel = list.find(x => x.id === pre.mapId) || list.find(x => x.kind === 'interior') || list[0];
        let lvl = pre.mapId === sel.id && pre.levelId ? pre.levelId : sel.ground;
        const charsN = (StorageManager.getCharacters(cid()) || []).length;
        const kindLbl = { interior: 'Wnętrze', local: 'Mapa' };
        const card = (x) => `<button class="vi-card ${x.id === sel.id ? 'on' : ''}" data-vi="${esc(x.id)}">
            <span class="vi-th">${thumb(x)}</span>
            <span class="vi-tx"><b>${x.type && Atlas.TYPE_ICON ? Atlas.TYPE_ICON(x.type) : ''} ${esc(x.name)}</b><small>${kindLbl[x.kind]}${x.levels ? ` · ${x.levels.length} ${x.levels.length === 1 ? 'poziom' : 'poziomy'}` : ''}${x.where ? ` · ${esc(x.where)}` : ''}</small>${x.n ? `<em><i class="fa-solid fa-skull"></i> ${x.n}</em>` : ''}</span></button>`;
        const opts = () => {
            const d = Atlas.fightData(sel.id, lvl);
            const others = d?.tok?.others || [];
            const hostile = others.filter(o => o.disp === 'hostile').length, hidden = others.filter(o => o.hidden).length;
            const pt = d?.tok;
            const partyInfo = pt?.mode === 'split' && Object.keys(pt.chars || {}).length ? `według żetonów na mapie (${Object.keys(pt.chars).length})` : pt?.party ? 'wokół żetonu drużyny' : 'przy wejściu';
            return `<div class="vi-prev">${thumb(sel, lvl)}</div>
                ${sel.levels && sel.levels.length > 1 ? `<label class="vi-f"><span><i class="fa-solid fa-stairs"></i> Piętro</span><select id="vi-lvl">${sel.levels.map(L => `<option value="${esc(L.id)}" ${L.id === lvl ? 'selected' : ''}>${esc(L.name)}${L.n ? ` (${L.n})` : ''}</option>`).join('')}</select></label>` : ''}
                <label class="vi-c"><input type="checkbox" id="vi-cr" ${others.length ? 'checked' : 'disabled'}> Przenieś stworzenia z mapy <b>${others.length}</b>${others.length ? `<small>${hostile} wrogich${hidden ? ` · ${hidden} ukrytych` : ''}</small>` : ''}</label>
                <label class="vi-c sub"><input type="checkbox" id="vi-host" ${others.length ? '' : 'disabled'}> tylko wrogowie</label>
                <label class="vi-c sub"><input type="checkbox" id="vi-hid" ${hidden ? 'checked' : 'disabled'}> także ukryci (gracze ich nie zobaczą)</label>
                <label class="vi-c"><input type="checkbox" id="vi-pt" ${charsN ? 'checked' : 'disabled'}> Ustaw drużynę <b>${charsN}</b><small>${partyInfo}</small></label>
                <label class="vi-c"><input type="checkbox" id="vi-init" checked> Rzuć inicjatywę (wrogowie tego samego rodzaju razem)</label>
                <div class="vi-seg"><label><input type="radio" name="vi-mode" value="replace" ${combatants().length ? '' : 'checked'}> Nowa walka</label><label><input type="radio" name="vi-mode" value="add" ${combatants().length ? 'checked' : ''}> Dołącz do trwającej (${combatants().length})</label></div>`;
        };
        App.showModal('Przenieś lokację na pole walki', `<div class="vi">
                <div class="vi-list">${list.map(card).join('')}</div>
                <div class="vi-opts" id="vi-opts">${opts()}</div></div>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="vi-go"><i class="fa-solid fa-khanda"></i> Przenieś na pole walki</button>`);
        document.getElementById('modal')?.classList.add('modal-wide');
        const body = document.querySelector('.vi');
        body.addEventListener('click', (e) => {
            const c = e.target.closest('[data-vi]'); if (!c) return;
            sel = list.find(x => x.id === c.dataset.vi); lvl = sel.ground;
            body.querySelectorAll('.vi-card').forEach(x => x.classList.toggle('on', x === c));
            document.getElementById('vi-opts').innerHTML = opts();
        });
        body.addEventListener('change', (e) => { if (e.target.id === 'vi-lvl') { lvl = e.target.value; document.getElementById('vi-opts').innerHTML = opts(); } });
        document.getElementById('vi-go').onclick = () => {
            const q = (id) => document.getElementById(id);
            const res = doImport(sel.id, lvl, {
                creatures: q('vi-cr')?.checked, hostileOnly: q('vi-host')?.checked, hidden: q('vi-hid')?.checked,
                party: q('vi-pt')?.checked, roll: q('vi-init')?.checked, replace: document.querySelector('input[name="vi-mode"]:checked')?.value === 'replace'
            });
            App.closeModal();
            if (!res) return;
            App.switchTab('combat');
            setTimeout(() => { renderAll(); syncTokens(); fit(); }, 60);
            App.showToast(`${res.name} na polu walki${res.cr ? ` — stworzenia: ${res.cr}` : ''}${res.pc ? `, bohaterowie: ${res.pc}` : ''}`, 'success');
        };
    }

    function doImport(mapId, levelId, o) {
        const d = Atlas.fightData(mapId, levelId);
        if (!d) { App.showToast('Nie udało się wczytać tej mapy', 'error'); return null; }
        if (o.replace) CombatModule.clearCombatants();
        sc();
        // dołączanie z innego piętra tej samej lokacji: obecne żetony zostają na swoich piętrach
        const same = !o.replace && S.kind === 'atlas' && S.mapId === mapId && d.kind === 'interior';
        if (same) { G = geo(); if (isInt()) Object.values(S.tokens).forEach(t => { if (!t.lv) t.lv = G.d.levelId; }); S.levelId = d.levelId; G = null; save(); }
        else setScene({ kind: 'atlas', mapId, levelId: d.levelId || null, name: d.name, cell: d.grid.size, ox: d.grid.ox || 0, oy: d.grid.oy || 0 }, false);
        G = geo();
        const have = new Set(combatants().map(c => c.id));
        const add = [], pos = {};
        const groupInit = {};
        const others = (o.creatures ? d.tok.others || [] : []).filter(x => (!o.hostileOnly || x.disp === 'hostile') && (o.hidden || !x.hidden));
        others.forEach(x => {
            const id = `atl_${x.id}`;
            pos[id] = { x: x.x, y: x.y, n: x.size || 1 };
            if (have.has(id)) return;
            const g = (x.ref || String(x.name).replace(/\s*\d+$/, '')) + '|' + x.disp;
            if (o.roll && groupInit[g] == null) groupInit[g] = d20() + (x.dexMod || 0);
            add.push({ id, name: x.name, type: x.disp === 'hostile' ? 'monster' : 'npc', disp: x.disp, kind: x.kind, ref: x.ref,
                ac: x.ac || 10, hp: x.hp ?? x.max ?? 10, maxHp: x.max || x.hp || 10, size: x.size || 1, hidden: !!x.hidden,
                dexMod: x.dexMod || 0, speed: x.speed || 30, initiative: o.roll ? groupInit[g] : 0, src: { mapId, levelId: d.levelId || null, oid: x.id }, ...(x.kind === 'npc' && x.ref ? { npcId: x.ref } : {}) });
        });
        let pcs = 0;
        if (o.party) {
            const tok = d.tok;
            (StorageManager.getCharacters(cid()) || []).forEach(c => {
                const id = `char-${c.id}`;
                const p = tok.mode === 'split' ? tok.chars?.[c.id] : null;
                if (p) pos[id] = { x: p.x, y: p.y, n: 1 };
                else pos[id] = { anchor: true, n: 1 };
                pcs++;
                if (have.has(id)) return;
                add.push({ id, charId: c.id, name: c.name, type: 'pc', ac: c.ac || 10, hp: c.hp?.current ?? 10, maxHp: c.hp?.max ?? 10,
                    speed: parseInt(c.speed, 10) || 30, dexMod: abMod(c.abilityScores?.dex), initiative: o.roll ? d20() + abMod(c.abilityScores?.dex) : 0 });
            });
        }
        // towarzysze drużyny stają obok bohatera, który ich prowadzi
        if (o.party && window.Companions) Companions.combatants().forEach(cm => {
            const op = cm.ctrl ? pos[`char-${cm.ctrl}`] : null;
            pos[cm.id] = op && !op.anchor ? { x: op.x + 1, y: op.y, n: cm.size || 1 } : { anchor: true, n: cm.size || 1 };
            if (!have.has(cm.id)) add.push(cm);
        });
        // rozstaw żetony (każdy zapamiętuje piętro, na którym stoi)
        const lvTag = d.kind === 'interior' ? { lv: d.levelId } : {};
        if (!same) S.tokens = {};
        const taken = same ? occupied(null) : [];
        Object.entries(pos).filter(([id, p]) => !p.anchor && !(same && S.tokens[id])).forEach(([id, p]) => {
            const q = areaBlocked(p.x, p.y, p.n) || taken.some(t => p.x < t.x + t.n && p.x + p.n > t.x && p.y < t.y + t.n && p.y + p.n > t.y) ? freeCell(p.x, p.y, p.n, taken) : p;
            S.tokens[id] = { x: q.x, y: q.y, moved: 0, ...lvTag }; taken.push({ x: q.x, y: q.y, n: p.n });
        });
        const anchor = d.tok.party || entrance() || { x: Math.floor(G.cols / 2), y: Math.floor(G.rows / 2) };
        Object.entries(pos).filter(([id, p]) => p.anchor && !(same && S.tokens[id])).forEach(([id]) => {
            const q = freeCell(anchor.x, anchor.y, 1, taken);
            S.tokens[id] = { x: q.x, y: q.y, moved: 0, ...lvTag }; taken.push({ x: q.x, y: q.y, n: 1 });
        });
        save();
        if (add.length) CombatModule.addCombatants(add);
        else CombatModule.renderInitiativeList();
        return { name: d.name + (d.levels && d.levels.length > 1 ? ` (${d.levelName})` : ''), cr: others.length, pc: pcs };
    }
    function entrance() {
        if (G.kind !== 'interior') return null;
        const L = G.lv;
        for (let i = 0; i < L.walls.length; i++) {
            if (L.walls[i] !== 'D') continue;
            const x = i % L.cols, y = Math.floor(i / L.cols);
            if (x === 0 || y === 0 || x === L.cols - 1 || y === L.rows - 1) {
                const nx = x === 0 ? 1 : x === L.cols - 1 ? x - 1 : x, ny = y === 0 ? 1 : y === L.rows - 1 ? y - 1 : y;
                return { x: nx, y: ny };
            }
        }
        return null;
    }

    function writeBack() {
        if (S.kind !== 'atlas' || !window.Atlas?.fightWrite) return;
        const cur = G.kind === 'interior' ? G.d.levelId : null;
        const buckets = new Map();
        const put = (lvl, item) => { if (!buckets.has(lvl)) buckets.set(lvl, []); buckets.get(lvl).push(item); };
        combatants().forEach(c => {
            const k = S.tokens[c.id]; if (!k) return;
            const tl = G.kind === 'interior' ? lvOf(k) : null;
            if (c.type === 'pc' || c.type === 'player') { put(tl, { pc: true, c, k }); return; }
            // stworzenie przeszło na inne piętro — zabierz je ze starego, dopisz na nowym
            if (c.src && c.src.mapId === S.mapId && (c.src.levelId ?? null) !== tl && G.kind === 'interior') {
                Atlas.fightWrite(S.mapId, c.src.levelId ?? null, (t) => { t.others = t.others.filter(x => x.id !== c.src.oid); });
                put(tl, { c, k });
                return;
            }
            if (c.src && c.src.mapId === S.mapId) put(c.src.levelId ?? null, { c, k, oid: c.src.oid });
            else put(tl, { c, k });
        });
        let upd = 0, added = 0;
        const pending = [];
        buckets.forEach((items, lvl) => {
            const onThis = true;
            Atlas.fightWrite(S.mapId, lvl, (t) => {
                const pcs = [];
                items.forEach(({ pc, c, k, oid }) => {
                    if (pc) { pcs.push({ c, k }); return; }
                    const o = oid && t.others.find(x => x.id === oid);
                    if (o) {
                        if (onThis) { o.x = k.x; o.y = k.y; }
                        o.hp = c.hp; o.max = c.maxHp; o.hidden = !!c.hidden; o.size = sizeOf(c); upd++;
                    } else {
                        const nid = MapForge.uid();
                        t.others.push({ id: nid, kind: c.kind || 'custom', ref: c.ref || null, name: c.name, hp: c.hp, max: c.maxHp, ac: c.ac, size: sizeOf(c),
                            disp: c.disp || (c.type === 'monster' ? 'hostile' : 'neutral'), hidden: !!c.hidden, x: k.x, y: k.y, dexMod: c.dexMod || 0 });
                        pending.push([c.id, { src: { mapId: S.mapId, levelId: lvl, oid: nid } }]);
                        added++;
                    }
                });
                if (pcs.length) {
                    if (t.mode === 'split') pcs.forEach(({ c, k }) => { const ch = c.charId || String(c.id).replace(/^char-/, ''); t.chars[ch] = { x: k.x, y: k.y }; });
                    else { const alive = pcs.find(x => x.c.hp > 0) || pcs[0]; t.party = { x: alive.k.x, y: alive.k.y }; }
                }
            });
        });
        pending.forEach(([id, patch]) => CombatModule.updateCombatant(id, patch));
        App.showToast(`Zapisano w lokacji: ${upd} stworzeń zaktualizowanych${added ? `, ${added} dodanych` : ''}, pozycja drużyny zapamiętana`, 'success');
    }

    // ---------- API ----------
    function init() {
        root = document.getElementById('vtt-container');
        if (!root) return;
        renderAll();
    }
    function activate() {
        if (!root) init();
        sc();
        G = null;
        renderAll();
        syncTokens();
    }
    // stan pola walki zmieniony z zewnątrz (ruch gracza, drugi komputer MG)
    function reloadFromStorage() {
        if (!root || !S) return;
        const before = sceneKey();
        S = null; sc();
        if (ui.drag) return;
        if (sceneKey() !== before) { G = null; renderAll(); } else { G = geo(); renderTer(); renderTpl(); renderTokens(); }
        window.CombatModule?.refreshFocus?.();
    }

    function focusCombatant(id) {
        if (!S?.tokens[id]) return;
        if (isInt() && !onCur(id)) switchLevel(lvOf(S.tokens[id]));
        ui.sel = id;
        if (!tokenVisible(id)) centerOn(id);
        renderTokens();
    }
    function setMapBackground(url) {
        const img = new Image();
        img.onload = () => { setScene({ kind: 'image', name: 'Mapa', url, w: img.naturalWidth, h: img.naturalHeight, cell: 70 }); renderAll(); syncTokens(); };
        img.src = url;
    }

    return {
        init, activate, syncTokens, renderTokens, resetTurnMovement, setMapBackground, focusCombatant,
        importDialog, doImport, fit, writeBack, reloadFromStorage, levelOf, switchLevel,
        selectToken: (e, id) => focusCombatant(String(id).replace(/^tok_/, '')),
        get state() { return { scene: S, ui, geo: G }; }
    };
})();

window.VTTModule = VTTModule;
