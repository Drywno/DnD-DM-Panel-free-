/* ============================================
   Łupy po walce: monety z tabel skarbów osobistych (wg wyzwania stworzeń)
   + szansa na mikstury i zwykłe przedmioty. MG poprawia, co chce,
   i rozdaje bohaterom jednym przyciskiem.
   ============================================ */
const Loot = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const d = (n, s) => { let t = 0; for (let i = 0; i < n; i++) t += Math.floor(Math.random() * s) + 1; return t; };
    const COINS = [['pp', 'PM', 'platyny'], ['gp', 'SZ', 'złota'], ['ep', 'EL', 'elektrum'], ['sp', 'SR', 'srebra'], ['cp', 'MD', 'miedzi']];
    const crNum = (v) => { const s = String(v ?? '').trim(); if (!s) return null; if (s.includes('/')) { const [a, b] = s.split('/').map(Number); return b ? a / b : null; } const n = parseFloat(s); return Number.isFinite(n) ? n : null; };
    const crTxt = (n) => n == null ? '' : n === 0.125 ? '1/8' : n === 0.25 ? '1/4' : n === 0.5 ? '1/2' : String(n);

    // skarb osobisty jednego stworzenia
    function coinsFor(cr) {
        const r = d(1, 100), o = { cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 };
        if (cr <= 4) {
            if (r <= 30) o.cp = d(5, 6); else if (r <= 60) o.sp = d(4, 6); else if (r <= 70) o.ep = d(3, 6); else if (r <= 95) o.gp = d(3, 6); else o.pp = d(1, 6);
        } else if (cr <= 10) {
            if (r <= 30) { o.cp = d(4, 6) * 100; o.ep = d(1, 6) * 10; } else if (r <= 60) { o.sp = d(6, 6) * 10; o.gp = d(2, 6) * 10; } else if (r <= 70) { o.ep = d(3, 6) * 10; o.gp = d(2, 6) * 10; } else if (r <= 95) o.gp = d(4, 6) * 10; else { o.gp = d(2, 6) * 10; o.pp = d(3, 6); }
        } else if (cr <= 16) {
            if (r <= 20) { o.sp = d(4, 6) * 100; o.gp = d(1, 6) * 100; } else if (r <= 35) { o.ep = d(1, 6) * 100; o.gp = d(1, 6) * 100; } else if (r <= 75) { o.gp = d(2, 6) * 100; o.pp = d(1, 6) * 10; } else { o.gp = d(2, 6) * 100; o.pp = d(2, 6) * 10; }
        } else {
            if (r <= 15) { o.ep = d(2, 6) * 1000; o.gp = d(8, 6) * 100; } else if (r <= 55) { o.gp = d(1, 6) * 1000; o.pp = d(1, 6) * 100; } else { o.gp = d(1, 6) * 1000; o.pp = d(2, 6) * 100; }
        }
        return o;
    }
    const POTION = (cr) => cr <= 4 ? 'Mikstura leczenia' : cr <= 10 ? 'Większa mikstura leczenia' : cr <= 16 ? 'Wyborna mikstura leczenia' : 'Najwyższa mikstura leczenia';
    function itemsFor(cr) {
        const out = [];
        if (Math.random() < Math.min(0.6, 0.15 + cr * 0.03)) out.push(POTION(cr));
        if (window.ItemsDB && Math.random() < 0.3) {
            const pool = ItemsDB.all.filter(i => ['gear', 'weapon', 'tool', 'clothes', 'game', 'instrument', 'ammo'].includes(i.cat) && i.cost && i.cost !== '—');
            if (pool.length) out.push(pool[Math.floor(Math.random() * pool.length)].name);
        }
        return out;
    }

    // wyzwanie stworzenia z walki: z NPC, z bestiariusza albo nieznane
    async function crOf(c) {
        if (c.cr != null) return crNum(c.cr);
        const cid = App.getActiveCampaignId();
        if (c.npcId) { const n = (StorageManager.getNPCs(cid) || []).find(x => x.id === c.npcId); const v = crNum(String(n?.stats?.cr ?? '').split(' ')[0]); if (v != null) return v; }
        if (c.ref) { try { const m = await APIClient.getMonster(c.ref); if (m && m.challenge_rating != null) return +m.challenge_rating; } catch (e) {} }
        return null;
    }
    const isFoe = (c) => !['pc', 'player'].includes(c.type) && !String(c.id).startsWith('char-') && !String(c.id).endsWith('-druzyna') && c.disp !== 'friendly';

    let S = null;   // { foes: [{name, cr}], coins, items: [{name, qty, to}], split, announce }
    function roll() {
        const coins = { cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 }, items = {};
        S.foes.forEach(f => {
            const cr = f.cr ?? 0;
            const c = coinsFor(cr); Object.keys(coins).forEach(k => { coins[k] += c[k]; });
            itemsFor(cr).forEach(n => { items[n] = (items[n] || 0) + 1; });
        });
        S.coins = coins;
        const heroes = chars();
        S.items = Object.entries(items).map(([name, qty], i) => ({ name, qty, to: heroes.length ? heroes[i % heroes.length].id : '' }));
    }
    const chars = () => StorageManager.getCharacters(App.getActiveCampaignId()) || [];

    async function open(combatants) {
        const all = (combatants || []).filter(isFoe);
        const dead = all.filter(c => c.defeated || c.hp <= 0);
        const src = dead.length ? dead : all;
        const foes = await Promise.all(src.map(async c => ({ name: c.name, cr: await crOf(c) })));
        S = { foes, coins: null, items: [], split: 'even', announce: true };
        if (!foes.length) S.foes = [{ name: 'Stworzenie', cr: 1 }];
        roll();
        render();
    }

    function render() {
        const heroes = chars();
        const hOpt = (sel) => `${heroes.map(h => `<option value="${esc(h.id)}" ${sel === h.id ? 'selected' : ''}>${esc(h.name)}</option>`).join('')}<option value="" ${!sel ? 'selected' : ''}>— nikt (pomiń) —</option>`;
        const totalGp = (S.coins.pp * 10 + S.coins.gp + S.coins.ep / 2 + S.coins.sp / 10 + S.coins.cp / 100);
        App.showModal('Łupy po walce', `
            <div class="lt">
                <div class="lt-sec"><h4><i class="fa-solid fa-skull"></i> Pokonani <small>wyzwanie decyduje o łupach — popraw, jeśli trzeba</small></h4>
                    <div class="lt-foes">${S.foes.map((f, i) => `<label class="lt-foe"><span>${esc(f.name)}</span><input type="text" data-lcr="${i}" value="${esc(crTxt(f.cr))}" placeholder="CR" title="Wyzwanie (np. 1/4, 2, 5)"></label>`).join('')}</div>
                    <button class="btn-secondary btn-small" data-lroll><i class="fa-solid fa-dice"></i> Losuj ponownie</button></div>
                <div class="lt-sec"><h4><i class="fa-solid fa-coins"></i> Monety <small>razem ok. ${Math.round(totalGp).toLocaleString(window.LOC || 'pl-PL')} sz</small></h4>
                    <div class="lt-coins">${COINS.map(([k, s, n]) => `<label title="${n}"><span>${s}</span><input type="number" min="0" data-lcoin="${k}" value="${S.coins[k]}"></label>`).join('')}</div>
                    <label class="lt-split">Monety dostaje: <select data-lsplit><option value="even" ${S.split === 'even' ? 'selected' : ''}>po równo każdy bohater</option>${heroes.map(h => `<option value="${esc(h.id)}" ${S.split === h.id ? 'selected' : ''}>${esc(h.name)}</option>`).join('')}<option value="" ${S.split === '' ? 'selected' : ''}>— nikt —</option></select></label></div>
                <div class="lt-sec"><h4><i class="fa-solid fa-sack-dollar"></i> Przedmioty</h4>
                    <div class="lt-items">${S.items.length ? S.items.map((it, i) => `<div class="lt-item"><input type="text" data-lname="${i}" value="${esc(it.name)}" list="lt-dl"><input type="number" min="1" data-lqty="${i}" value="${it.qty}" title="Ile"><select data-lto="${i}">${hOpt(it.to)}</select><button class="btn-icon" data-ldel="${i}" title="Usuń"><i class="fa-solid fa-xmark"></i></button></div>`).join('') : '<p class="modal-hint">Tym razem bez przedmiotów.</p>'}</div>
                    <datalist id="lt-dl">${window.ItemsDB ? ItemsDB.all.map(i => `<option value="${esc(i.name)}">`).join('') : ''}</datalist>
                    <button class="btn-secondary btn-small" data-ladd><i class="fa-solid fa-plus"></i> Dodaj przedmiot</button></div>
                <label class="lt-ann"><input type="checkbox" data-lann ${S.announce ? 'checked' : ''}> Ogłoś łupy graczom w dzienniku stołu</label>
            </div>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Pomiń</button><button class="btn-primary" data-lgive><i class="fa-solid fa-hand-holding-dollar"></i> Rozdaj łupy</button>`);
        bind();
    }
    function readForm() {
        const q = (s) => [...document.querySelectorAll(s)];
        q('[data-lcr]').forEach(el => { S.foes[+el.dataset.lcr].cr = crNum(el.value); });
        q('[data-lcoin]').forEach(el => { S.coins[el.dataset.lcoin] = Math.max(0, parseInt(el.value, 10) || 0); });
        q('[data-lname]').forEach(el => { S.items[+el.dataset.lname].name = el.value.trim(); });
        q('[data-lqty]').forEach(el => { S.items[+el.dataset.lqty].qty = Math.max(1, parseInt(el.value, 10) || 1); });
        q('[data-lto]').forEach(el => { S.items[+el.dataset.lto].to = el.value; });
        const sp = document.querySelector('[data-lsplit]'); if (sp) S.split = sp.value;
        const an = document.querySelector('[data-lann]'); if (an) S.announce = an.checked;
    }
    function bind() {
        const body = document.getElementById('modal-body'), foot = document.getElementById('modal-footer');
        body.onclick = (e) => {
            const b = (s) => e.target.closest(s);
            if (b('[data-lroll]')) { readForm(); roll(); render(); return; }
            if (b('[data-ladd]')) { readForm(); S.items.push({ name: '', qty: 1, to: chars()[0]?.id || '' }); render(); setTimeout(() => document.querySelector(`[data-lname="${S.items.length - 1}"]`)?.focus(), 30); return; }
            if (b('[data-ldel]')) { readForm(); S.items.splice(+b('[data-ldel]').dataset.ldel, 1); render(); return; }
        };
        foot.querySelector('[data-lgive]').onclick = give;
    }
    function give() {
        readForm();
        const cid = App.getActiveCampaignId(), list = chars();
        if (!list.length) { App.showToast('Drużyna jest pusta — nie ma komu dać łupów', 'warning'); return; }
        const got = {};   // id → [opis]
        const note = (id, t) => { (got[id] = got[id] || []).push(t); };
        // monety
        const coinTargets = S.split === 'even' ? list : S.split ? list.filter(h => h.id === S.split) : [];
        if (coinTargets.length) {
            COINS.forEach(([k, , n]) => {
                const total = S.coins[k] || 0; if (!total) return;
                const each = Math.floor(total / coinTargets.length), rest = total - each * coinTargets.length;
                coinTargets.forEach((h, i) => {
                    const v = each + (i < rest ? 1 : 0); if (!v) return;
                    h.currency = h.currency || { cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 };
                    h.currency[k] = (parseInt(h.currency[k], 10) || 0) + v;
                    note(h.id, `${v} sz. ${n}`);
                });
            });
        }
        // przedmioty
        S.items.filter(it => it.name && it.to).forEach(it => {
            const h = list.find(x => x.id === it.to); if (!h) return;
            h.inventory = h.inventory || [];
            const db = window.ItemsDB && ItemsDB.find(it.name);
            const entry = db ? ItemsDB.toInv(db, it.qty) : { name: it.name, quantity: it.qty, weight: 0 };
            const same = h.inventory.find(x => x.name === entry.name);
            if (same) same.quantity = (parseInt(same.quantity, 10) || 0) + entry.quantity; else h.inventory.push(entry);
            note(h.id, `${entry.name}${it.qty > 1 ? ` ×${it.qty}` : ''}`);
        });
        StorageManager.saveCharacters(cid, list);
        const lines = list.filter(h => got[h.id]).map(h => `${h.name}: ${got[h.id].join(', ')}`);
        if (S.announce && lines.length && window.OnlineModule?.available?.()) {
            fetch('api/dziennik', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Panel': '1' }, body: JSON.stringify({ typ: 'wiad', tekst: `💰 Łupy — ${lines.join(' · ')}`.slice(0, 600) }) }).catch(() => {});
        }
        App.closeModal();
        App.showToast(lines.length ? `Rozdano łupy (${lines.length} ${lines.length === 1 ? 'bohater' : 'bohaterów'})` : 'Nic nie rozdano', lines.length ? 'success' : 'info');
        try { window.PartyModule?.render?.(); } catch (e) {}
    }

    return { open, coinsFor };
})();
window.Loot = Loot;
