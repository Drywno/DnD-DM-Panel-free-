/* =========================================================
   EquipmentModule — Equipment & Magic Item browsing
   ========================================================= */
const EquipmentModule = {

    /* ── state ───────────────────────────────────────────── */
    allEquipment: [],
    allMagicItems: [],
    filteredItems: [],
    loaded: false,
    loading: false,
    detailVisible: false,
    showingMagicItems: false,

    /* ── DOM refs ────────────────────────────────────────── */
    els: {},

    /* ── lifecycle ───────────────────────────────────────── */
    init() {
        this.els = {
            search:       document.getElementById('equipment-search'),
            catFilter:    document.getElementById('equipment-category-filter'),
            customOnly:   document.getElementById('equipment-custom-only'),
            list:         document.getElementById('equipment-list'),
            detail:       document.getElementById('equipment-detail'),
            btnAdd:       document.getElementById('btn-add-equipment'),
            btnToggle:    document.getElementById('btn-toggle-magic-items'),
        };

        /* events */
        this.els.search.addEventListener('input', () => this.renderList());
        this.els.catFilter.addEventListener('change', () => this.renderList());
        this.els.customOnly.addEventListener('change', () => this.renderList());

        this.els.btnAdd.addEventListener('click', () => this.showAddEquipmentModal());

        this.els.btnToggle.addEventListener('click', () => {
            this.showingMagicItems = !this.showingMagicItems;
            this.els.btnToggle.textContent = this.showingMagicItems ? '⚔️ Zwykły ekwipunek' : '🔮 Mag. przedmioty';
            this._populateCategoryFilter();
            this.renderList();
        });

        this.loadEquipment();
    },

    activate() {
        if (!this.loaded && !this.loading) this.loadEquipment();
    },

    /* ── data loading ────────────────────────────────────── */
    async loadEquipment() {
        this.loading = true;
        this._showLoading();

        let srdFailed = false;
        const srdSafe = (p) => p.catch(err => { console.warn('SRD offline:', err); srdFailed = true; return []; });
        try {
            const [apiEquip, apiMagic] = await Promise.all([
                srdSafe(APIClient.getEquipmentList()),
                srdSafe(APIClient.getMagicItemList()),
            ]);

            const custom = StorageManager.getCustomEquipment() || [];
            const customTagged = custom.map(i => ({ ...i, _custom: true }));

            /* split custom items into regular vs magic */
            const customRegular = customTagged.filter(i => !i._isMagic);
            const customMagic   = customTagged.filter(i => i._isMagic);

            // zwykły ekwipunek: pełna polska baza z Podręcznika Gracza (działa bez internetu); SRD tylko gdy bazy brak
            const db = window.ItemsDB ? ItemsDB.all.map(i => ({ ...i, _db: true, index: i.id, equipment_category: ItemsDB.CATS[i.cat][0], weight: i.w })) : apiEquip;
            this.allEquipment  = [...db, ...customRegular];
            this.allMagicItems = [...apiMagic, ...customMagic];

            this.loaded = !srdFailed; // retry SRD on next visit if offline
            if (srdFailed && !window.ItemsDB) App.showToast('Brak połączenia z SRD — widoczne są tylko własne przedmioty', 'warning');
            this._populateCategoryFilter();
            this.renderList();
        } catch (err) {
            console.error('[Equipment] load error:', err);
            App.showToast('Nie udało się pobrać ekwipunku z SRD — pokazuję tylko własne', 'error');
            this.els.list.innerHTML = this._emptyState('Nie udało się pobrać ekwipunku.');
        } finally {
            this.loading = false;
        }
    },

    /* ── category filter population ──────────────────────── */
    _populateCategoryFilter() {
        const source = this.showingMagicItems ? this.allMagicItems : this.allEquipment;
        const categories = new Set();

        source.forEach(item => {
            const cat = this._extractCategory(item);
            if (cat) categories.add(cat);
        });

        const select = this.els.catFilter;
        const current = select.value;
        select.innerHTML = `<option value="">Wszystkie Kategorie</option>`;
        [...categories].sort().forEach(c => {
            const opt = document.createElement('option');
            opt.value = c;
            opt.textContent = APIClient.translateStatic('categories', c);
            select.appendChild(opt);
        });
        select.value = current;
    },

    /* ── rendering ───────────────────────────────────────── */
    renderList() {
        const source     = this.showingMagicItems ? this.allMagicItems : this.allEquipment;
        const search     = (this.els.search.value || '').toLowerCase().trim();
        const catVal     = this.els.catFilter.value.toLowerCase();
        const customOnly = this.els.customOnly.checked;

        this.filteredItems = source.filter(item => {
            if (customOnly && !item._custom) return false;
            if (search && !(item.name || '').toLowerCase().includes(search) && !(item.en || '').toLowerCase().includes(search)) return false;
            const cat = this._extractCategory(item).toLowerCase();
            if (catVal && cat !== catVal) return false;
            return true;
        });

        if (this.filteredItems.length === 0) {
            const itemType = this.showingMagicItems ? 'magic items' : 'equipment';
            this.els.list.innerHTML = this._emptyState(`No ${itemType} match the current filters.`);
            return;
        }

        const frag = document.createDocumentFragment();
        this.filteredItems.forEach(item => {
            frag.appendChild(this.showingMagicItems ? this._renderMagicCard(item) : this._renderEquipCard(item));
        });
        this.els.list.innerHTML = '';
        this.els.list.appendChild(frag);
    },

    /* ── regular equipment card ──────────────────────────── */
    _renderEquipCard(item) {
        if (item._db) return this._renderDbCard(item);
        const card = document.createElement('div');
        card.className = 'data-card';
        if (item._custom) card.classList.add('custom-card');

        const category = this._extractCategory(item);
        const categoryPl = APIClient.translateStatic('categories', category);
        const cost     = this._formatCost(item);
        const weight   = item.weight != null ? `${item.weight} lb.` : '';

        /* extra stat for weapons / armor */
        let extraStat = '';
        if (item.damage && item.damage.damage_dice) {
            const dmgType = item.damage.damage_type ? (typeof item.damage.damage_type === 'string' ? item.damage.damage_type : item.damage.damage_type.name || '') : '';
            extraStat = `<span class="card-stat">⚔ ${item.damage.damage_dice}${dmgType ? ' ' + this._esc(dmgType) : ''}</span>`;
        }
        if (item.armor_class && item.armor_class.base) {
            extraStat = `<span class="card-stat">🛡 AC ${item.armor_class.base}${item.armor_class.dex_bonus ? ' + DEX' : ''}</span>`;
        }

        card.innerHTML = `
            <div class="card-name">${this._esc(item.name)}</div>
            <div class="card-subtitle">${this._esc(categoryPl)}</div>
            <div class="card-stats">
                ${cost ? `<span class="card-stat">${this._esc(cost)}</span>` : ''}
                ${weight ? `<span class="card-stat">${this._esc(weight)}</span>` : ''}
                ${extraStat}
            </div>
            ${item._custom ? '<div class="card-tags"><span class="card-tag tag-custom">Własny</span></div>' : ''}
        `;

        card.addEventListener('click', () => {
            this.showDetail(item.index || item._customId, !!item._custom, false);
        });

        return card;
    },

    /* ── przedmiot z polskiej bazy ───────────────────────── */
    _renderDbCard(item) {
        const card = document.createElement('div');
        card.className = `data-card eq-card c-${item.cat}`;
        const [catPl, icon] = ItemsDB.CATS[item.cat] || ItemsDB.CATS.gear;
        const info = window.I18N?.en ? I18N.t(ItemsDB.info(item)) : ItemsDB.info(item);
        card.innerHTML = `
            <div class="eq-head"><i class="fa-solid ${icon}"></i><div><div class="card-name">${this._esc(item.name)}</div><div class="card-subtitle">${this._esc(item.sub || catPl)}${item.en ? ` · <span>${this._esc(item.en)}</span>` : ''}</div></div></div>
            ${info ? `<div class="eq-info">${this._esc(info.length > 110 ? info.slice(0, 108) + '…' : info)}</div>` : ''}
            <div class="card-stats eq-stats">
                <span class="card-stat"><i class="fa-solid fa-coins"></i> ${this._esc(item.cost || '—')}</span>
                ${item.cat !== 'pack' && !item.noPack ? `<span class="card-stat"><i class="fa-solid fa-weight-hanging"></i> ${ItemsDB.fmtW(item.w)}</span>` : ''}
            </div>`;
        card.addEventListener('click', () => this.showDbDetail(item.id));
        return card;
    },

    showDbDetail(id) {
        const it = ItemsDB.find(id); if (!it) return;
        const PROP_DESC = {
            F: 'Finezyjna — do ataku i obrażeń użyj Siły albo Zręczności (tej samej do obu).',
            L: 'Lekka — nadaje się do walki dwiema brońmi.',
            T: 'Rzucana — możesz nią rzucić i atakować dystansowo tą samą cechą co wręcz.',
            '2': 'Dwuręczna — do ataku potrzebujesz obu rąk.',
            V: 'Wszechstronna — trzymana oburącz zadaje większe obrażenia.',
            H: 'Ciężka — Małe stworzenia atakują nią z utrudnieniem.',
            Z: 'Zasięg — dodaje 5 stóp do twojego zasięgu w walce wręcz.',
            A: 'Amunicja — każdy atak zużywa sztukę amunicji; po walce połowę zużytej odzyskasz, szukając przez minutę.',
            'Ł': 'Ładowanie — jeden pocisk na akcję, akcję dodatkową lub reakcję, bez względu na liczbę ataków.',
            S: 'Specjalna — zasady opisane przy broni.'
        };
        const [catPl, icon] = ItemsDB.CATS[it.cat] || ItemsDB.CATS.gear;
        const C = window.Codex;
        const tiles = [['Cena', this._esc(it.cost || '—')]];
        if (it.cat !== 'pack') tiles.push(['Waga', it.noPack ? '—' : ItemsDB.fmtW(it.w), it.qty > 1 ? `za sztukę · zwykle ${it.qty} szt.` : '']);
        const lines = [];
        const sections = [];
        if (it.cat === 'weapon') {
            tiles.push(['Obrażenia', it.dmg ? C.btn(it.dmg.replace('k', 'd'), `${it.name}: obrażenia`, this._esc(it.dmg)) : '—', [this._esc(it.dt), it.vers ? `oburącz ${this._esc(it.vers)}` : ''].filter(Boolean).join(' · ')]);
            if (it.range) tiles.push(['Zasięg', `${this._esc(it.range)} stóp`]);
            lines.push(['Właściwości', this._esc(ItemsDB.propsText(it)) || '—']);
            const pl = [...(it.props || '')].map(c => PROP_DESC[c] ? `<li>${PROP_DESC[c]}</li>` : '').join('');
            if (pl) sections.push({ title: 'Właściwości broni', icon: 'fa-list-check', html: `<ul class="cx-list">${pl}</ul>` });
        }
        if (it.cat === 'armor') {
            tiles.push(['Klasa pancerza', it.kind === 'S' ? '+2' : String(it.ac), ({ L: '+ mod. Zręczności', M: '+ mod. Zręczności (maks. 2)', H: 'bez Zręczności', S: '' })[it.kind]]);
            lines.push(['Wymagana Siła', it.str ? `${it.str} (inaczej −10 stóp szybkości)` : ''], ['Skradanie', it.stealth ? 'z utrudnieniem' : ''],
                ['Zakładanie / zdejmowanie', ({ L: '1 minuta / 1 minuta', M: '5 minut / 1 minuta', H: '10 minut / 5 minut', S: '1 akcja / 1 akcja' })[it.kind]]);
        }
        if (it.cat === 'pack') {
            const c = ItemsDB.packContents(it), tot = c.reduce((a, x) => a + (x.weight || 0) * x.quantity, 0);
            tiles.push(['Waga razem', ItemsDB.fmtW(tot)]);
            sections.push({ title: 'Zawartość', icon: 'fa-box-open', html: `<ul class="cx-list">${c.map(x => `<li>${this._esc(x.name)}${x.quantity > 1 ? ` ×${x.quantity}` : ''} <small>${ItemsDB.fmtW(x.weight * x.quantity)}</small></li>`).join('')}</ul>` });
        }
        if (it.heal) tiles.push(['Leczenie', C.btn(it.heal.replace(/k/g, 'd'), `${it.name}: leczenie`, this._esc(it.heal)), 'PW']);
        if (it.note) sections.push({ title: 'Zasady', icon: 'fa-gavel', html: C.paras(it.note, it.name) });
        if (it.desc) sections.push({ title: 'Opis', icon: 'fa-scroll', html: C.paras(it.desc, it.name) });
        const chars = (StorageManager.getCharacters(App.getActiveCampaignId()) || []);
        this.els.detail.classList.remove('hidden');
        this.detailVisible = true;
        this.els.detail.innerHTML = C.panel({
            kind: it.cat === 'potion' ? 'magic' : 'item', icon, title: it.name,
            meta: `${this._esc(it.sub || catPl)}${it.en ? ` · <i>${this._esc(it.en)}</i>` : ''}`,
            tiles, lines, sections,
            after: chars.length ? `<div class="cx-give"><h4><i class="fa-solid fa-user-plus"></i> ${window.PANEL_ROLA === 'gracz' ? 'Dodaj do mojego ekwipunku' : 'Dodaj do ekwipunku postaci'}</h4>
                <div class="eq-give-row"><select id="eq-give-char"${window.PANEL_ROLA === 'gracz' && chars.length === 1 ? ' hidden' : ''}>${chars.map(c => `<option value="${this._esc(c.id)}">${this._esc(c.name)}</option>`).join('')}</select>
                <input type="number" id="eq-give-n" min="1" value="${it.qty || 1}" title="Ile sztuk"><button class="btn-primary btn-small" id="eq-give-go"><i class="fa-solid fa-plus"></i> Dodaj</button></div></div>` : ''
        });
        this.els.detail.querySelector('.detail-close').onclick = () => this.closeDetail();
        const go = this.els.detail.querySelector('#eq-give-go');
        if (go) go.onclick = () => {
            const cid = App.getActiveCampaignId(), list = StorageManager.getCharacters(cid) || [];
            const ch = list.find(c => c.id === document.getElementById('eq-give-char').value); if (!ch) return;
            const qty = Math.max(1, parseInt(document.getElementById('eq-give-n').value, 10) || 1);
            const entries = it.cat === 'pack' ? Array.from({ length: qty }).flatMap(() => ItemsDB.packContents(it)) : [ItemsDB.toInv(it, qty)];
            ch.inventory = ch.inventory || [];
            entries.forEach(e => { const f = ch.inventory.find(i => i.name === e.name); if (f) { f.quantity = (parseInt(f.quantity, 10) || 0) + e.quantity; if (!f.weight) f.weight = e.weight; } else ch.inventory.push({ ...e }); });
            StorageManager.saveCharacter(cid, ch);
            App.showToast(window.PANEL_ROLA === 'gracz' ? `Dodano do ekwipunku: ${it.name}${qty > 1 ? ` ×${qty}` : ''}` : `${ch.name} dostaje: ${it.name}${qty > 1 ? ` ×${qty}` : ''}`, 'success');
        };
    },

    /* ── magic item card ─────────────────────────────────── */
    _renderMagicCard(item) {
        const card = document.createElement('div');
        card.className = 'data-card';
        if (item._custom) card.classList.add('custom-card');

        const category = this._extractCategory(item);
        const categoryPl = APIClient.translateStatic('categories', category);
        const rarity = item.rarity ? (typeof item.rarity === 'string' ? item.rarity : item.rarity.name || '') : '';

        card.innerHTML = `
            <div class="card-name">${this._esc(item.name)}</div>
            <div class="card-subtitle">${this._esc(categoryPl)}</div>
            <div class="card-tags">
                ${rarity ? `<span class="card-tag tag-type">${this._esc(rarity)}</span>` : ''}
                ${item._custom ? '<span class="card-tag tag-custom">Własny</span>' : ''}
            </div>
        `;

        card.addEventListener('click', () => {
            this.showDetail(item.index || item._customId, !!item._custom, true);
        });

        return card;
    },

    /* ── detail view ─────────────────────────────────────── */
    async showDetail(index, isCustom, isMagic) {
        this.els.detail.classList.remove('hidden');
        this.els.detail.innerHTML = this._spinnerHtml();
        this.detailVisible = true;

        try {
            let item;
            if (isCustom) {
                const customs = StorageManager.getCustomEquipment() || [];
                item = customs.find(c => c._customId === index);
                if (item) item._custom = true;
            } else if (isMagic) {
                item = await APIClient.getMagicItem(index);
            } else {
                item = await APIClient.getEquipment(index);
            }

            if (!item) { this.els.detail.innerHTML = this._emptyState('Nie znaleziono przedmiotu.'); return; }

            await this._translateEquipment(item);

            this.els.detail.innerHTML = isMagic ? this._buildMagicDetail(item) : this._buildEquipDetail(item);
            this._bindDetailEvents(item);
        } catch (err) {
            console.error('[Equipment] detail error:', err);
            this.els.detail.innerHTML = this._emptyState('Nie udało się wczytać szczegółów przedmiotu.');
        }
    },

    async _translateEquipment(item) {
        if (!item || item._translated) return;
        const keys = [];
        (Array.isArray(item.desc) ? item.desc : []).forEach((t, i) => { if (typeof t === 'string') keys.push([item.desc, i]); });
        if (item.description && !item.desc) keys.push([item, 'description']);
        const out = await APIClient.translateMany(keys.map(([o, k]) => o[k]));
        keys.forEach(([o, k], i) => { o[k] = out[i]; });
        item._translated = true;
    },

    _buildEquipDetail(item) {
        const C = window.Codex;
        const dt = (d) => d && d.damage_type ? (typeof d.damage_type === 'string' ? d.damage_type : d.damage_type.name || '') : '';
        const tiles = [['Cena', this._esc(this._formatCost(item) || '—')], ['Waga', item.weight != null ? `${item.weight} lb` : '—']];
        if (item.damage && item.damage.damage_dice) tiles.push(['Obrażenia', C.btn(item.damage.damage_dice, `${item.name}: obrażenia`, this._esc(item.damage.damage_dice.replace(/d/g, 'k'))), [this._esc(dt(item.damage)), item.two_handed_damage ? `oburącz ${this._esc((item.two_handed_damage.damage_dice || '').replace(/d/g, 'k'))}` : ''].filter(Boolean).join(' · ')]);
        const rng = item.range && (item.range.normal || item.range.long) ? `${item.range.normal || '—'}${item.range.long ? '/' + item.range.long : ''} stóp` : '';
        if (rng) tiles.push(['Zasięg', rng]);
        if (item.armor_class) tiles.push(['Klasa pancerza', String(item.armor_class.base || ''), item.armor_class.dex_bonus ? `+ mod. Zręczności${item.armor_class.max_bonus != null ? ` (maks. ${item.armor_class.max_bonus})` : ''}` : '']);
        const props = (item.properties || []).map(p => typeof p === 'string' ? p : p.name || '').join(', ');
        return C.panel({
            kind: 'item', icon: 'fa-sack-xmark', title: item.name, meta: this._esc(this._extractCategory(item)),
            tags: item._custom ? [{ t: 'własny', cls: 'own' }] : [],
            actions: item._custom ? '<button class="btn-danger btn-small btn-delete-equip" title="Usuń własny przedmiot"><i class="fa-solid fa-trash"></i> Usuń</button>' : '',
            tiles,
            lines: [['Rzut', item.throw_range && (item.throw_range.normal || item.throw_range.long) ? `${item.throw_range.normal || '—'}/${item.throw_range.long || '—'} stóp` : ''],
                ['Wymagana Siła', item.str_minimum ? String(item.str_minimum) : ''], ['Skradanie', item.stealth_disadvantage ? 'z utrudnieniem' : ''], ['Właściwości', this._esc(props)]],
            sections: [{ title: 'Opis', icon: 'fa-scroll', html: item.desc && item.desc.length ? C.paras(item.desc, item.name) : '' }]
        });
    },

    _buildMagicDetail(item) {
        const C = window.Codex;
        const rarity = item.rarity ? (typeof item.rarity === 'string' ? item.rarity : item.rarity.name || '') : '';
        const RAR = { common: 'pospolity', uncommon: 'niezwykły', rare: 'rzadki', 'very rare': 'bardzo rzadki', legendary: 'legendarny', artifact: 'artefakt', varies: 'różna' };
        const rarPl = RAR[String(rarity).toLowerCase()] || rarity;
        const att = item.requires_attunement ? (typeof item.requires_attunement === 'string' ? item.requires_attunement : 'tak') : '';
        return C.panel({
            kind: 'magic', icon: 'fa-gem', title: item.name, meta: this._esc(({ 'wondrous items': 'Przedmiot cudowny', 'wondrous item': 'Przedmiot cudowny', weapon: 'Broń', armor: 'Pancerz', potion: 'Mikstura', ring: 'Pierścień', rod: 'Berło', scroll: 'Zwój', staff: 'Kostur', wand: 'Różdżka', ammunition: 'Amunicja' })[String(this._extractCategory(item)).toLowerCase()] || this._extractCategory(item)),
            tags: [rarPl ? { t: this._esc(rarPl), cls: 'rar-' + String(rarity).toLowerCase().replace(/\s+/g, '-') } : null, att ? { t: '<i class="fa-solid fa-link"></i> dostrojenie', cls: 'att' } : null, item._custom ? { t: 'własny', cls: 'own' } : null].filter(Boolean),
            actions: item._custom ? '<button class="btn-danger btn-small btn-delete-equip" title="Usuń własny przedmiot"><i class="fa-solid fa-trash"></i> Usuń</button>' : '',
            tiles: [['Rzadkość', this._esc(rarPl || '—')], ['Dostrojenie', att ? this._esc(att === 'tak' ? 'wymagane' : att) : 'nie']],
            sections: [{ title: 'Opis', icon: 'fa-scroll', html: C.paras(item.desc || item.description || [], item.name) }]
        });
    },

    _bindDetailEvents(item) {
        const closeBtn = this.els.detail.querySelector('.detail-close');
        if (closeBtn) closeBtn.addEventListener('click', () => this.closeDetail());

        const delBtn = this.els.detail.querySelector('.btn-delete-equip');
        if (delBtn) {
            delBtn.addEventListener('click', async () => {
                if (await Ask.confirm('Tej operacji nie da się cofnąć.', { title: `Usunąć przedmiot „${item.name}”?`, ok: 'Usuń', danger: true })) {
                    StorageManager.deleteCustomEquipmentItem(item._customId);
                    App.showToast(`Usunięto: ${item.name}`, 'info');
                    this.closeDetail();
                    this.loadEquipment();
                }
            });
        }
    },

    closeDetail() {
        this.els.detail.classList.add('hidden');
        this.els.detail.innerHTML = '';
        this.detailVisible = false;
    },

    /* ── add custom equipment modal ──────────────────────── */
    showAddEquipmentModal() {
        const catOptions = [
            'Weapon','Armor','Adventuring Gear','Tool','Mount','Vehicle',
            'Trade Good','Wondrous Item','Potion','Ring','Rod','Scroll',
            'Staff','Wand','Other'
        ].map(c => `<option value="${c}">${c}</option>`).join('');

        const body = `
        <form id="form-add-equip" autocomplete="off">
            <div class="form-row">
                <div class="form-group">
                    <label for="equip-name">Name *</label>
                    <input id="equip-name" type="text" required placeholder="e.g. Crystal Dagger">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="equip-category">Category</label>
                    <select id="equip-category">${catOptions}</select>
                </div>
                <div class="form-group form-row-6">
                    <label><input id="equip-is-magic" type="checkbox"> Magic Item</label>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="equip-cost">Cost</label>
                    <input id="equip-cost" type="text" placeholder="e.g. 50 gp">
                </div>
                <div class="form-group form-row-6">
                    <label for="equip-weight">Weight (lb.)</label>
                    <input id="equip-weight" type="number" step="0.1" placeholder="1">
                </div>
            </div>
            <div id="equip-magic-fields" class="hidden">
                <div class="form-row">
                    <div class="form-group form-row-6">
                        <label for="equip-rarity">Rarity</label>
                        <select id="equip-rarity">
                            <option value="Common">Common</option>
                            <option value="Uncommon">Uncommon</option>
                            <option value="Rare">Rare</option>
                            <option value="Very Rare">Very Rare</option>
                            <option value="Legendary">Legendary</option>
                            <option value="Artifact">Artifact</option>
                        </select>
                    </div>
                    <div class="form-group form-row-6">
                        <label><input id="equip-attunement" type="checkbox"> Requires Attunement</label>
                    </div>
                </div>
            </div>
            <div id="equip-weapon-fields" class="hidden">
                <h4 class="form-section-title">Parametry broni</h4>
                <div class="form-row">
                    <div class="form-group form-row-6">
                        <label for="equip-damage">Damage Dice</label>
                        <input id="equip-damage" type="text" placeholder="e.g. 1d8">
                    </div>
                    <div class="form-group form-row-6">
                        <label for="equip-damage-type">Damage Type</label>
                        <input id="equip-damage-type" type="text" placeholder="e.g. Slashing">
                    </div>
                </div>
            </div>
            <div id="equip-armor-fields" class="hidden">
                <h4 class="form-section-title">Parametry pancerza</h4>
                <div class="form-row">
                    <div class="form-group form-row-6">
                        <label for="equip-ac">Base AC</label>
                        <input id="equip-ac" type="number" placeholder="15">
                    </div>
                    <div class="form-group form-row-6">
                        <label><input id="equip-dex-bonus" type="checkbox" checked> DEX Bonus</label>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="equip-desc">Description</label>
                <textarea id="equip-desc" rows="4" placeholder="Opisz przedmiot…"></textarea>
            </div>
        </form>`;

        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Cancel</button>
            <button class="btn-primary" id="btn-save-equip">Save Item</button>`;

        App.showModal('Add Custom Equipment', body, footer);

        setTimeout(() => {
            /* toggle conditional fields */
            const catSelect = document.getElementById('equip-category');
            const magicCheck = document.getElementById('equip-is-magic');
            const magicFields = document.getElementById('equip-magic-fields');
            const weaponFields = document.getElementById('equip-weapon-fields');
            const armorFields = document.getElementById('equip-armor-fields');

            const updateVisibility = () => {
                const cat = catSelect.value;
                magicFields.classList.toggle('hidden', !magicCheck.checked);
                weaponFields.classList.toggle('hidden', cat !== 'Weapon');
                armorFields.classList.toggle('hidden', cat !== 'Armor');
            };

            catSelect.addEventListener('change', updateVisibility);
            magicCheck.addEventListener('change', updateVisibility);
            updateVisibility();

            const saveBtn = document.getElementById('btn-save-equip');
            if (saveBtn) saveBtn.addEventListener('click', () => this._saveCustomEquipment());
        }, 50);
    },

    _saveCustomEquipment() {
        const name = document.getElementById('equip-name').value.trim();
        if (!name) { App.showToast('Podaj nazwę przedmiotu', 'error'); return; }

        const isMagic = document.getElementById('equip-is-magic').checked;
        const category = document.getElementById('equip-category').value;

        const item = {
            _customId: StorageManager.generateId(),
            _custom: true,
            _isMagic: isMagic,
            name,
            equipment_category: { name: category },
            weight: parseFloat(document.getElementById('equip-weight').value) || undefined,
            desc: document.getElementById('equip-desc').value.trim() ? [document.getElementById('equip-desc').value.trim()] : [],
        };

        /* cost */
        const costRaw = document.getElementById('equip-cost').value.trim();
        if (costRaw) {
            const match = costRaw.match(/^([\d,.]+)\s*(\w+)$/);
            if (match) {
                item.cost = { quantity: parseFloat(match[1].replace(',', '')), unit: match[2] };
            } else {
                item.cost = { quantity: 0, unit: costRaw };
            }
        }

        /* magic item specifics */
        if (isMagic) {
            item.rarity = { name: document.getElementById('equip-rarity').value };
            item.requires_attunement = document.getElementById('equip-attunement').checked;
        }

        /* weapon specifics */
        if (category === 'Weapon') {
            const dmgDice = document.getElementById('equip-damage').value.trim();
            const dmgType = document.getElementById('equip-damage-type').value.trim();
            if (dmgDice) {
                item.damage = {
                    damage_dice: dmgDice,
                    damage_type: { name: dmgType || 'Unknown' },
                };
            }
        }

        /* armor specifics */
        if (category === 'Armor') {
            const baseAC = parseInt(document.getElementById('equip-ac').value);
            if (baseAC) {
                item.armor_class = {
                    base: baseAC,
                    dex_bonus: document.getElementById('equip-dex-bonus').checked,
                };
            }
        }

        StorageManager.saveCustomEquipmentItem(item);
        App.closeModal();
        App.showToast(`${name} added to inventory`, 'success');
        this.loadEquipment();
    },

    /* ── extraction & formatting helpers ─────────────────── */
    _extractCategory(item) {
        if (item.equipment_category) {
            if (typeof item.equipment_category === 'string') return item.equipment_category;
            return item.equipment_category.name || '';
        }
        /* magic items may use a different field */
        if (item.category) {
            if (typeof item.category === 'string') return item.category;
            return item.category.name || '';
        }
        return 'Other';
    },

    _formatCost(item) {
        if (!item.cost) return '';
        if (typeof item.cost === 'string') return item.cost;
        const qty = item.cost.quantity != null ? item.cost.quantity : '';
        const unit = item.cost.unit || '';
        return `${qty} ${unit}`.trim();
    },

    /* ── UI helpers ──────────────────────────────────────── */
    _showLoading() {
        this.els.list.innerHTML = `<div class="loading-spinner"><div class="spinner"></div><p>Wczytuję ekwipunek…</p></div>`;
    },

    _spinnerHtml() {
        return `<div class="loading-spinner"><div class="spinner"></div></div>`;
    },

    _emptyState(msg) {
        return `<div class="empty-state empty-state-wide"><i class="fa-solid fa-feather"></i><span>${this._esc(msg)}</span></div>`;
    },

    _esc(str) {
        if (str == null) return '';
        const d = document.createElement('div');
        d.textContent = String(str);
        return d.innerHTML;
    },
};

window.EquipmentModule = EquipmentModule;
