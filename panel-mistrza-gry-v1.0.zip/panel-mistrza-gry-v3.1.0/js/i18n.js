/* ============================================
   Język panelu: polski (domyślnie) albo angielski.
   Każdy użytkownik wybiera sam — zapis w localStorage („panel_lang”).
   Panel jest pisany po polsku; w trybie EN ten moduł podmienia teksty
   na ekranie (węzły tekstowe i atrybuty) według słownika js/i18n-en.js.
   Language of the panel: Polish (default) or English, chosen per user.
   ============================================ */
(function () {
    'use strict';
    const KEY = 'panel_lang';
    let lang = null;
    try { lang = localStorage.getItem(KEY); } catch (e) {}
    if (lang !== 'pl' && lang !== 'en') {
        // pierwszy raz: polski, jeśli przeglądarka zna polski albo strefa czasowa jest polska; inaczej angielski
        const langs = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || '']).join(',');
        let tz = ''; try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
        lang = /(^|,)pl\b/i.test(langs) || tz === 'Europe/Warsaw' ? 'pl' : 'en';
    }
    const EN = lang === 'en';
    window.LANG = lang;
    window.LOC = EN ? 'en-GB' : 'pl-PL';
    document.documentElement.lang = lang;

    function setLang(l) {
        if (l !== 'pl' && l !== 'en') return;
        try { localStorage.setItem(KEY, l); } catch (e) {}
        if (l !== lang) location.reload();
    }
    // przełącznik PL/EN do wstawienia w dowolne miejsce
    function switchHTML(cls = '') {
        return `<span class="lang-sw ${cls}" data-no-i18n role="group" aria-label="Language / Język">` +
            `<button type="button" data-lang="pl" class="${lang === 'pl' ? 'on' : ''}" title="Polski">PL</button>` +
            `<button type="button" data-lang="en" class="${lang === 'en' ? 'on' : ''}" title="English">EN</button></span>`;
    }
    document.addEventListener('click', (e) => {
        const b = e.target.closest && e.target.closest('.lang-sw [data-lang]');
        if (b) { e.preventDefault(); setLang(b.dataset.lang); }
    }, true);

    const mark = () => document.querySelectorAll('.lang-sw [data-lang]').forEach((b) => b.classList.toggle('on', b.dataset.lang === lang));
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mark); else mark();
    const api = { lang, en: EN, set: setLang, switchHTML, mark, t: (s) => s };
    window.I18N = api;
    if (!EN) return;

    // ---------- tryb angielski ----------
    const base = (document.currentScript && document.currentScript.src) || '';
    if (!window.I18N_EN) {
        const src = base ? base.replace(/i18n\.js(\?.*)?$/, 'i18n-en.js?v=2') : 'js/i18n-en.js?v=2';
        try { document.write('<script src="' + src + '"><\/script>'); } catch (e) {}
    }

    let D = null, PATS = null, IDX = null;
    const cache = new Map();
    const norm = (s) => s.replace(/\s+/g, ' ').trim();
    const WORD = /[A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ]{3,}/g;
    const PLCH = /[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ]/;
    // kości: „2k6+3” → „2d6+3”
    const DICE = /(^|[^\wąćęłńóśźż])(\d*)k(4|6|8|10|12|20|100)(?![\wąćęłńóśźż])/g;

    function load() {
        if (D) { if (!mapsDone && window.PL && window.PL.MAPS) addMaps(); return true; }
        const src = window.I18N_EN; if (!src) return false;
        D = new Map(Object.entries(src.e));
        if (window.PL && window.PL.MAPS) addMaps();
        PATS = src.p.map(([rx, en, key]) => ({ rx: new RegExp(rx), en, key }));
        IDX = new Map();
        for (const p of PATS) { const a = IDX.get(p.key) || []; a.push(p); IDX.set(p.key, a); }
        return true;
    }
    // nazwy z podręcznika (plnames: klasy, rasy, czary…) zapisane po polsku → oryginał
    let mapsDone = false;
    function addMaps() {
        mapsDone = true;
        for (const m of Object.values(window.PL.MAPS)) for (const [en, pl] of Object.entries(m)) {
            if (typeof pl === 'string' && pl && !D.has(pl)) D.set(pl, en.replace(/(^|[\s-])\w/g, (c) => c.toUpperCase()));
        }
        cache.clear();
    }
    function lookup(s, depth) {
        const hit = D.get(s);
        if (hit !== undefined) return hit;
        const words = s.match(WORD);
        if (!words) return null;
        const seen = new Set();
        for (const w of words) {
            const list = IDX.get(w.toLowerCase());
            if (!list) continue;
            for (const p of list) {
                if (seen.has(p)) continue; seen.add(p);
                const m = p.rx.exec(s);
                if (m) return p.en.replace(/\{(\d+)\}/g, (x, k) => { const g = m[+k] ?? ''; if (depth >= 2 || !/[A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ]{2}/.test(g)) return g; const gt = g.trim(); const r = lookup(gt, depth + 1) ?? (depth < 1 ? pieces(gt) : null); return r == null ? g : g.replace(gt, r); });
            }
        }
        return null;
    }
    // gdy całość nie pasuje: przypadek wielkości liter, potem kawałki („Elf · Łotrzyk”, „1k8 cięte · lekka”)
    const flip = (s) => s.charAt(0) === s.charAt(0).toUpperCase() ? s.charAt(0).toLowerCase() + s.slice(1) : s.charAt(0).toUpperCase() + s.slice(1);
    const WRAP = /^([„“"'«(\[]+)(.+?)([”"'»)\]]*[.,:;!?…]*)$/;
    function caseLookup(s) {
        let t = lookup(s, 0); if (t != null) return t;
        const w = WRAP.exec(s);
        if (w && (w[1] || w[3])) { const inner = caseLookup(w[2]) ?? lookup(w[2] + w[3].replace(/^[”"'»)\]]+/, ''), 0); if (inner != null) return w[1].replace('„', '“') + inner + w[3]; }
        if (s.length > 2 && s === s.toUpperCase() && s !== s.toLowerCase()) {
            const low = s.toLowerCase(), cap = low.charAt(0).toUpperCase() + low.slice(1);
            const u = lookup(cap, 0) ?? lookup(low, 0) ?? (window.I18N_EN.w || {})[cap] ?? (window.I18N_EN.w || {})[low];
            if (u != null) return u.toUpperCase();
        }
        const f = flip(s); if (f === s) return null;
        t = lookup(f, 0); if (t == null) return null;
        return s.charAt(0) === s.charAt(0).toUpperCase() ? t.charAt(0).toUpperCase() + t.slice(1) : t.charAt(0).toLowerCase() + t.slice(1);
    }
    function wordLevel(p) {
        const W = window.I18N_EN.w || {};
        const toks = p.split(/(\s+)/); let any = false;
        for (let i = 0; i < toks.length; i++) {
            const k = toks[i];
            if (!k.trim() || !/[A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ]/.test(k) || /^[+\-−]?\d*[kd]\d+([+\-−]\d+)?$|^\d/.test(k)) continue;
            const t = W[k] ?? W[k.toLowerCase()] ?? caseLookup(k);
            if (t == null) {
                // dwa słowa razem („Makiety 3D”, „Broń żołnierska…”) — sprawdź pary
                return null;
            }
            toks[i] = t; any = true;
        }
        return any ? toks.join('') : null;
    }
    // podział na kawałki z poszanowaniem nawiasów: „Plecak, Lina (50 stóp), Pochodnia ×10”
    function splitTop(s, re) {
        const out = []; let depth = 0, last = 0;
        for (let i = 0; i < s.length; i++) {
            const c = s[i];
            if (c === '(' || c === '[') depth++;
            else if ((c === ')' || c === ']') && depth) depth--;
            else if (!depth) { re.lastIndex = i; const m = re.exec(s); if (m && m.index === i) { out.push(s.slice(last, i), m[0]); last = i + m[0].length; i = last - 1; } }
        }
        out.push(s.slice(last));
        return out;
    }
    const TOP = /\s+·\s*|\s+—\s+|\s+–\s+|,\s+|;\s+|:\s+|\s+\/\s+/y;
    function chunk(p, depth) {
        const W = window.I18N_EN.w || {};
        const core = p.trim(); if (!core || !/[A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ]/.test(core)) return p;
        let t = W[core] ?? caseLookup(core);
        if (t == null) { const m = /^(.*?)(\s*×\s*\d+|\s+\d+)$/.exec(core); if (m && m[1]) { const r = W[m[1]] ?? caseLookup(m[1]); if (r != null) t = r + m[2]; } }
        if (t == null) { const m = /^(.*?)\s*\((.*)\)(\s*×\s*\d+)?$/.exec(core); if (m && m[1] && depth < 3) { const a = chunk(m[1], depth + 1), b2 = chunk(m[2], depth + 1); if (a != null && b2 != null) t = `${a} (${b2})${m[3] || ''}`; } }
        if (t == null && depth < 3) { const m = /^\((.*)\)([.,;:]?)$/.exec(core); if (m) { const a = chunk(m[1], depth + 1); if (a != null) t = `(${a})${m[2]}`; } }
        if (t == null && depth < 3 && /[,·;:—]/.test(core)) t = pieces(core, depth + 1);
        if (t == null) t = wordLevel(core);
        return t == null ? null : p.replace(core, t);
    }
    function pieces(s, depth = 0) {
        const parts = splitTop(s, TOP);
        if (parts.length < 2) { const r = chunk(s, depth + 1); return r === s ? null : r; }
        let any = false, bad = false;
        const out = parts.map((p, i) => {
            if (i % 2 === 1 || !p.trim()) return p;
            if (!/[A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ]/.test(p)) return p;
            const t = chunk(p, depth + 1);
            if (t != null) { any = true; return t; }
            if (p.trim().split(/\s+/).length >= 4) bad = true;
            return p;
        });
        return any && !bad ? out.join('') : null;
    }
    function tr(raw) {
        if (!raw || raw.length > 2000) return null;
        const c = cache.get(raw);
        if (c !== undefined) return c;
        let out = null;
        const s = norm(raw);
        if (s && /[A-Za-ząćęłńóśźżĄĆĘŁŃÓŚŹŻ]/.test(s)) {
            let t = caseLookup(s);
            if (t == null) t = pieces(s);
            if (t == null && /\d*k\d/.test(s)) { const d = s.replace(DICE, '$1$2d$3'); if (d !== s) t = caseLookup(d) ?? pieces(d) ?? d; }
            if (t != null && t !== s) {
                if (DICE.test(t)) t = t.replace(DICE, '$1$2d$3');
                DICE.lastIndex = 0;
                const lead = raw.match(/^\s*/)[0], trail = raw.match(/\s*$/)[0];
                out = lead + t + trail;
            }
        }
        if (cache.size > 30000) cache.clear();
        cache.set(raw, out);
        return out;
    }
    api.t = (s) => { if (!load()) return s; const r = tr(String(s ?? '')); return r ?? s; };

    const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE', 'NOSCRIPT']);
    const ATTRS = ['title', 'placeholder', 'aria-label', 'alt', 'data-tip', 'data-title', 'data-label'];
    let done = new WeakMap();
    function skipEl(el, forAttrs) {
        for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
            if (forAttrs && e === el && (e.tagName === 'TEXTAREA' || e.tagName === 'svg' || e.tagName === 'SVG')) continue;
            if (SKIP.has(e.tagName) || e.isContentEditable || e.hasAttribute('data-no-i18n')) return true;
        }
        return false;
    }
    function textNode(n) {
        const v = n.data;
        if (done.get(n) === v) return;
        const p = n.parentElement;
        if (!p || skipEl(p)) return;
        const t = tr(v);
        if (t != null) { n.data = t; done.set(n, t); } else done.set(n, v);
    }
    function attrs(el) {
        for (const a of ATTRS) {
            const v = el.getAttribute(a);
            if (!v) continue;
            const t = tr(v);
            if (t != null) el.setAttribute(a, t);
        }
        if (el.tagName === 'INPUT' && (el.type === 'button' || el.type === 'submit') && el.value) {
            const t = tr(el.value); if (t != null) el.value = t;
        }
        if (el.tagName === 'META' && /description|title/.test(el.getAttribute('name') || el.getAttribute('property') || '')) {
            const t = tr(el.getAttribute('content') || ''); if (t != null) el.setAttribute('content', t);
        }
    }
    function walk(root) {
        if (root.nodeType === 3) { textNode(root); return; }
        if (root.nodeType !== 1 && root.nodeType !== 11) return;
        if (root.nodeType === 1) { if (skipEl(root, true)) return; attrs(root); if (SKIP.has(root.tagName)) return; }
        const w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
            acceptNode: (n) => n.nodeType === 1 && (n.hasAttribute('data-no-i18n') || n.isContentEditable) ? NodeFilter.FILTER_REJECT : n.nodeType === 1 && SKIP.has(n.tagName) ? (n.tagName === 'TEXTAREA' && attrs(n), NodeFilter.FILTER_REJECT) : NodeFilter.FILTER_ACCEPT
        });
        let n;
        while ((n = w.nextNode())) { if (n.nodeType === 3) textNode(n); else attrs(n); }
    }
    let pending = [];
    function flush() {
        if (!load()) return;
        const list = pending; pending = [];
        for (const r of list) {
            if (r.type === 'childList') r.addedNodes.forEach(walk);
            else if (r.type === 'characterData') textNode(r.target);
            else if (r.type === 'attributes') { const el = r.target; if (!skipEl(el, true)) attrs(el); }
        }
        if (document.title && !titleDone) { const t = tr(document.title); if (t) document.title = t; titleDone = true; }
    }
    let titleDone = false;
    const mo = new MutationObserver((recs) => { pending.push(...recs); flush(); });
    mo.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS.concat(['value']) });
    function full() { if (load()) { done = new WeakMap(); walk(document.documentElement); titleDone = false; flush(); } }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', full); else full();
    window.addEventListener('load', full);

    // okienka przeglądarki
    for (const fn of ['alert', 'confirm', 'prompt']) {
        const orig = window[fn];
        if (typeof orig !== 'function') continue;
        window[fn] = function (msg, ...rest) { return orig.call(window, msg == null ? msg : api.t(String(msg)), ...rest); };
    }
})();
