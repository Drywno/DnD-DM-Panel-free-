/* =========================================================
   SpellsModule — Spell browsing, filtering & detail views
   ========================================================= */
const SpellsModule = {

    /* ── state ───────────────────────────────────────────── */
    allSpells: [],
    filteredSpells: [],
    loaded: false,
    loading: false,
    detailVisible: false,

    /* ── DOM refs ────────────────────────────────────────── */
    els: {},

    /* ── lifecycle ───────────────────────────────────────── */
    init() {
        this.els = {
            search:        document.getElementById('spells-search'),
            levelFilter:   document.getElementById('spells-level-filter'),
            schoolFilter:  document.getElementById('spells-school-filter'),
            classFilter:   document.getElementById('spells-class-filter'),
            ritualOnly:    document.getElementById('spells-ritual-only'),
            concOnly:      document.getElementById('spells-concentration-only'),
            customOnly:    document.getElementById('spells-custom-only'),
            list:          document.getElementById('spells-list'),
            detail:        document.getElementById('spells-detail'),
            btnAdd:        document.getElementById('btn-add-spell'),
        };

        /* bind events */
        this.els.search.addEventListener('input', () => this.renderList());
        this.els.levelFilter.addEventListener('change', () => this.renderList());
        this.els.schoolFilter.addEventListener('change', () => this.renderList());
        this.els.classFilter.addEventListener('change', () => this.renderList());
        this.els.ritualOnly.addEventListener('change', () => this.renderList());
        this.els.concOnly.addEventListener('change', () => this.renderList());
        this.els.customOnly.addEventListener('change', () => this.renderList());

        this.els.btnAdd.addEventListener('click', () => this.showAddSpellModal());

        this.loadSpells();
    },

    activate() {
        if (!this.loaded && !this.loading) this.loadSpells();
    },

    /* ── data loading ────────────────────────────────────── */
    async loadSpells() {
        this.loading = true;
        this._showLoading();

        let srdFailed = false;
        const srdSafe = (p) => p.catch(err => { console.warn('SRD offline:', err); srdFailed = true; return []; });
        try {
            const apiSpells = await srdSafe(APIClient.getSpellList());
            const custom = StorageManager.getCustomSpells() || [];
            const customTagged = custom.map(s => ({ ...s, _custom: true }));

            this.allSpells = [...apiSpells, ...customTagged];
            this.loaded = !srdFailed; // retry SRD on next visit if offline
            if (srdFailed) App.showToast('Brak połączenia z SRD — widoczne są tylko własne czary', 'warning');
            this._populateFilterOptions();
            this.renderList();
        } catch (err) {
            console.error('[Spells] load error:', err);
            App.showToast('Nie udało się pobrać czarów z SRD — pokazuję tylko własne', 'error');
            this.els.list.innerHTML = this._emptyState('Nie udało się pobrać czarów.');
        } finally {
            this.loading = false;
        }
    },

    /* ── populate filter selects ─────────────────────────── */
    _populateFilterOptions() {
        const schools = new Set();
        const classes = new Set();

        this.allSpells.forEach(s => {
            const school = this._extractSchool(s);
            if (school) schools.add(school);

            const classList = this._extractClasses(s);
            classList.forEach(c => classes.add(c));
        });

        /* Level filter: 0 (cantrip) – 9 */
        const levels = [];
        for (let i = 0; i <= 9; i++) levels.push({ value: String(i), label: i === 0 ? 'Sztuczka' : `Poziom ${i}` });
        this._fillSelect(this.els.levelFilter, levels, 'Wszystkie Poziomy');
        this._fillSelect(this.els.schoolFilter, [...schools].sort().map(s => ({value: s, label: APIClient.translateStatic('schools', s)})), 'Wszystkie Szkoły');
        this._fillSelect(this.els.classFilter, [...classes].sort(), 'Wszystkie Klasy');
    },

    _fillSelect(select, items, defaultLabel) {
        const current = select.value;
        select.innerHTML = `<option value="">${defaultLabel}</option>`;
        items.forEach(item => {
            const opt = document.createElement('option');
            if (typeof item === 'object') { opt.value = item.value; opt.textContent = item.label; }
            else { opt.value = item; opt.textContent = item; }
            select.appendChild(opt);
        });
        select.value = current;
    },

    /* ── rendering ───────────────────────────────────────── */
    renderList() {
        const search     = (this.els.search.value || '').toLowerCase().trim();
        const levelVal   = this.els.levelFilter.value;
        const schoolVal  = this.els.schoolFilter.value.toLowerCase();
        const classVal   = this.els.classFilter.value.toLowerCase();
        const ritualOnly = this.els.ritualOnly.checked;
        const concOnly   = this.els.concOnly.checked;
        const customOnly = this.els.customOnly.checked;

        this.filteredSpells = this.allSpells.filter(s => {
            if (customOnly && !s._custom) return false;
            
            const school = this._extractSchool(s).toLowerCase();
            if (schoolVal && school !== schoolVal) return false;

            if (search) {
                const searchMatch = 
                    (s.name || '').toLowerCase().includes(search) || (window.PL ? PL.spell(s.name) : '').toLowerCase().includes(search) || 
                    (APIClient.translateStatic('schools', this._extractSchool(s)) || '').toLowerCase().includes(search);
                if (!searchMatch) return false;
            }

            if (levelVal !== '' && String(this._extractLevel(s)) !== levelVal) return false;

            if (classVal) {
                const classes = this._extractClasses(s).map(c => c.toLowerCase());
                if (!classes.includes(classVal)) return false;
            }

            if (ritualOnly && !s.ritual) return false;
            if (concOnly && !s.concentration) return false;

            return true;
        });

        if (this.filteredSpells.length === 0) {
            this.els.list.innerHTML = this._emptyState('Żaden czar nie pasuje do filtrów.');
            return;
        }

        const frag = document.createDocumentFragment();
        this.filteredSpells.forEach(s => frag.appendChild(this._renderCard(s)));
        this.els.list.innerHTML = '';
        this.els.list.appendChild(frag);
    },

    _renderCard(spell) {
        const card = document.createElement('div');
        card.className = 'data-card';
        if (spell._custom) card.classList.add('custom-card');

        const level = this._extractLevel(spell);
        const school = this._extractSchool(spell);
        const schoolPl = APIClient.translateStatic('schools', school);
        const levelLabel = level === 0 ? 'Sztuczka' : `Poziom ${level}`;
        const P = window.PL;
        const classes = (P ? P.classes(this._extractClasses(spell)) : this._extractClasses(spell)).join(', ');
        const plName = P ? P.spell(spell.name) : spell.name;

        card.innerHTML = `
            <div class="card-name">${this._esc(plName)}${plName !== spell.name ? `<small class="pl-en">${this._esc(spell.name)}</small>` : ''}</div>
            <div class="card-subtitle">${levelLabel} · ${this._esc(schoolPl)}</div>
            <div class="card-tags">
                <span class="card-tag tag-level">${levelLabel}</span>
                <span class="card-tag tag-school">${this._esc(schoolPl)}</span>
                ${spell.ritual ? '<span class="card-tag tag-ritual">Rytuał</span>' : ''}
                ${spell.concentration ? '<span class="card-tag tag-concentration">Konc.</span>' : ''}
                ${spell._custom ? '<span class="card-tag tag-custom">Własny</span>' : ''}
            </div>
            ${classes ? `<div class="card-stats"><span class="card-stat">${this._esc(classes)}</span></div>` : ''}
        `;

        card.addEventListener('click', () => {
            this.showDetail(spell.index || spell._customId, !!spell._custom);
        });

        return card;
    },

    /* ── detail view ─────────────────────────────────────── */
    async showDetail(index, isCustom) {
        this.els.detail.classList.remove('hidden');
        this.els.detail.innerHTML = this._spinnerHtml();
        this.detailVisible = true;

        try {
            let s;
            if (isCustom) {
                const customs = StorageManager.getCustomSpells() || [];
                s = customs.find(c => c._customId === index);
                if (s) s._custom = true;
            } else {
                s = await APIClient.getSpell(index);
            }
            if (!s) { this.els.detail.innerHTML = this._emptyState('Nie znaleziono czaru.'); return; }

            const tok = this._detTok = (this._detTok || 0) + 1;
            const draw = () => { this.els.detail.innerHTML = this._buildDetail(s); this._bindDetailEvents(s); };
            if (!s._translated && this._trTexts(s).some(t => !APIClient.isTranslated(t))) {
                draw();
                this.els.detail.querySelector('.cx-title h2, .stat-block-header, h2')?.insertAdjacentHTML('beforeend', '<span class="tr-badge"><i class="fa-solid fa-spinner fa-spin"></i> tłumaczę…</span>');
                await this._translateSpell(s);
                if (tok !== this._detTok || !this.detailVisible) return;
            } else await this._translateSpell(s);
            draw();
        } catch (err) {
            console.error('[Spells] detail error:', err);
            this.els.detail.innerHTML = this._emptyState('Nie udało się wczytać szczegółów czaru.');
        }
    },

    _trTexts(s) {
        return [...(Array.isArray(s.desc) ? s.desc : []), ...(Array.isArray(s.higher_level) ? s.higher_level : []), ...(s.description && !s.desc ? [s.description] : [])].filter(t => typeof t === 'string');
    },
    // opis i „na wyższych poziomach” jednym zapytaniem
    async _translateSpell(s) {
        if (!s || s._translated) return;
        const keys = [];
        ['desc', 'higher_level'].forEach(k => (Array.isArray(s[k]) ? s[k] : []).forEach((t, i) => { if (typeof t === 'string') keys.push([s[k], i]); }));
        if (s.description && !s.desc) keys.push([s, 'description']);
        const out = await APIClient.translateMany(keys.map(([o, k]) => o[k]));
        keys.forEach(([o, k], i) => { o[k] = out[i]; });
        s._translated = true;
    },

    _buildDetail(s) {
        const C = window.Codex;
        const level = this._extractLevel(s);
        const school = this._extractSchool(s);
        const schoolPl = APIClient.translateStatic('schools', school);
        const P = window.PL;
        const classes = P ? P.classes(this._extractClasses(s)) : this._extractClasses(s);
        const SCHOOL_IC = { Abjuration: 'fa-shield-halved', Conjuration: 'fa-hat-wizard', Divination: 'fa-eye', Enchantment: 'fa-heart', Evocation: 'fa-fire', Illusion: 'fa-masks-theater', Necromancy: 'fa-skull', Transmutation: 'fa-flask' };
        const higher = s.higher_level || s.at_higher_levels;
        return C.panel({
            kind: 'spell', icon: SCHOOL_IC[school] || 'fa-wand-magic-sparkles', title: P ? P.spell(s.name) : s.name,
            meta: `${level === 0 ? 'Sztuczka' : `Czar ${level}. kręgu`} · ${this._esc(schoolPl || school || '')}${P && P.spell(s.name) !== s.name ? ` · <i>${this._esc(s.name)}</i>` : ''}`,
            tags: [s.ritual ? { t: '<i class="fa-solid fa-book-open"></i> rytuał', cls: 'ritual' } : null, s.concentration ? { t: '<i class="fa-solid fa-brain"></i> koncentracja', cls: 'conc' } : null, s._custom ? { t: 'własny', cls: 'own' } : null].filter(Boolean),
            actions: s._custom ? '<button class="btn-danger btn-small btn-delete-spell" title="Usuń własny czar"><i class="fa-solid fa-trash"></i> Usuń</button>' : '',
            tiles: [
                ['Czas rzucania', this._esc((P ? P.time(s.casting_time) : s.casting_time) || '—')],
                ['Zasięg', this._esc((P ? P.range(s.range) : s.range) || '—')],
                ['Komponenty', Array.isArray(s.components) ? this._esc(s.components.map(c => ({ V: 'W', S: 'S', M: 'M' })[c] || c).join(', ')) : (this._formatComponents(s) || '—')],
                ['Czas trwania', this._esc((P ? P.duration(s.duration) : s.duration) || '—'), s.concentration ? 'koncentracja' : '']
            ],
            lines: [['Materiał', Array.isArray(s.components) && s.material ? this._esc(typeof s.material === 'string' ? s.material : s.material.raw || '') : ''], ['Klasy', this._esc(classes.join(', '))]],
            sections: [
                { title: 'Opis', icon: 'fa-scroll', html: C.paras(s.desc || s.description, s.name) },
                { title: 'Na wyższych poziomach', icon: 'fa-arrow-up-wide-short', html: higher ? C.paras(higher, s.name) : '' }
            ]
        });
    },

    _bindDetailEvents(spell) {
        const closeBtn = this.els.detail.querySelector('.detail-close');
        if (closeBtn) closeBtn.addEventListener('click', () => this.closeDetail());

        const delBtn = this.els.detail.querySelector('.btn-delete-spell');
        if (delBtn) {
            delBtn.addEventListener('click', async () => {
                if (await Ask.confirm('Tej operacji nie da się cofnąć.', { title: `Usunąć czar „${spell.name}”?`, ok: 'Usuń', danger: true })) {
                    StorageManager.deleteCustomSpell(spell._customId);
                    App.showToast(`Usunięto: ${spell.name}`, 'info');
                    this.closeDetail();
                    this.loadSpells();
                }
            });
        }
    },

    closeDetail() {
        this.els.detail.classList.add('hidden');
        this.els.detail.innerHTML = '';
        this.detailVisible = false;
    },

    /* ── add custom spell modal ──────────────────────────── */
    showAddSpellModal() {
        const schoolOptions = [
            'Abjuration','Conjuration','Divination','Enchantment',
            'Evocation','Illusion','Necromancy','Transmutation'
        ].map(s => `<option value="${s}">${s}</option>`).join('');

        const levelOptions = [
            '<option value="0">Cantrip</option>',
            ...Array.from({length:9},(_,i) => `<option value="${i+1}">Level ${i+1}</option>`)
        ].join('');

        const body = `
        <form id="form-add-spell" autocomplete="off">
            <div class="form-row">
                <div class="form-group">
                    <label for="spell-name">Name *</label>
                    <input id="spell-name" type="text" required placeholder="e.g. Arcane Barrage">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="spell-level">Level</label>
                    <select id="spell-level">${levelOptions}</select>
                </div>
                <div class="form-group form-row-6">
                    <label for="spell-school">School</label>
                    <select id="spell-school">${schoolOptions}</select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="spell-casting-time">Casting Time</label>
                    <input id="spell-casting-time" type="text" placeholder="1 action">
                </div>
                <div class="form-group form-row-6">
                    <label for="spell-range">Range</label>
                    <input id="spell-range" type="text" placeholder="120 feet">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label for="spell-components">Components</label>
                    <input id="spell-components" type="text" placeholder="V, S, M (a pinch of sand)">
                </div>
                <div class="form-group form-row-6">
                    <label for="spell-duration">Duration</label>
                    <input id="spell-duration" type="text" placeholder="Instantaneous">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-row-6">
                    <label><input id="spell-concentration" type="checkbox"> Concentration</label>
                </div>
                <div class="form-group form-row-6">
                    <label><input id="spell-ritual" type="checkbox"> Ritual</label>
                </div>
            </div>
            <div class="form-group">
                <label for="spell-classes">Classes (comma-separated)</label>
                <input id="spell-classes" type="text" placeholder="Wizard, Sorcerer">
            </div>
            <div class="form-group">
                <label for="spell-desc">Description *</label>
                <textarea id="spell-desc" rows="5" required placeholder="Opisz efekt czaru…"></textarea>
            </div>
            <div class="form-group">
                <label for="spell-higher">At Higher Levels</label>
                <textarea id="spell-higher" rows="3" placeholder="Gdy rzucasz ten czar z komórki wyższego poziomu…"></textarea>
            </div>
        </form>`;

        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Cancel</button>
            <button class="btn-primary" id="btn-save-spell">Save Spell</button>`;

        App.showModal('Add Custom Spell', body, footer);

        setTimeout(() => {
            const saveBtn = document.getElementById('btn-save-spell');
            if (saveBtn) saveBtn.addEventListener('click', () => this._saveCustomSpell());
        }, 50);
    },

    _saveCustomSpell() {
        const name = document.getElementById('spell-name').value.trim();
        const desc = document.getElementById('spell-desc').value.trim();
        if (!name) { App.showToast('Podaj nazwę czaru', 'error'); return; }
        if (!desc) { App.showToast('Podaj opis czaru', 'error'); return; }

        const classesRaw = document.getElementById('spell-classes').value.trim();
        const classesList = classesRaw ? classesRaw.split(',').map(c => c.trim()).filter(Boolean) : [];

        const spell = {
            _customId: StorageManager.generateId(),
            _custom: true,
            name,
            level: parseInt(document.getElementById('spell-level').value),
            school: { name: document.getElementById('spell-school').value },
            casting_time: document.getElementById('spell-casting-time').value.trim() || '1 action',
            range: document.getElementById('spell-range').value.trim() || 'Self',
            components: this._parseComponentsInput(document.getElementById('spell-components').value.trim()),
            duration: document.getElementById('spell-duration').value.trim() || 'Instantaneous',
            concentration: document.getElementById('spell-concentration').checked,
            ritual: document.getElementById('spell-ritual').checked,
            desc: [desc],
            higher_level: document.getElementById('spell-higher').value.trim() ? [document.getElementById('spell-higher').value.trim()] : [],
            classes: classesList.map(c => ({ name: c })),
        };

        StorageManager.saveCustomSpell(spell);
        App.closeModal();
        App.showToast(`${name} added to spellbook`, 'success');
        this.loadSpells();
    },

    _parseComponentsInput(raw) {
        if (!raw) return [];
        /* Simple parse: V, S, M (materials) */
        const components = [];
        if (/\bV\b/i.test(raw)) components.push('V');
        if (/\bS\b/i.test(raw)) components.push('S');
        const mMatch = raw.match(/M\s*\(([^)]+)\)/i);
        if (mMatch) {
            components.push('M');
            return { list: components, material: mMatch[1].trim(), raw };
        }
        if (/\bM\b/i.test(raw)) components.push('M');
        return { list: components, material: '', raw };
    },

    /* ── extraction helpers ──────────────────────────────── */
    _extractLevel(s) {
        if (s.level != null) return s.level;
        return 0;
    },

    _extractSchool(s) {
        if (!s.school) return '';
        if (typeof s.school === 'string') return s.school;
        return s.school.name || '';
    },

    _extractClasses(s) {
        if (!s.classes) return [];
        if (Array.isArray(s.classes)) return s.classes.map(c => typeof c === 'string' ? c : c.name || '');
        return [];
    },

    _formatComponents(s) {
        if (!s.components) return '—';

        /* Array format from API */
        if (Array.isArray(s.components)) {
            let str = s.components.join(', ');
            if (s.material) str += ` (${this._esc(typeof s.material === 'string' ? s.material : s.material.raw || '')})`;
            return str;
        }

        /* Object format from custom spells */
        if (s.components && s.components.list) {
            let str = s.components.list.join(', ');
            if (s.components.material) str += ` (${this._esc(s.components.material)})`;
            return str;
        }

        if (s.components && s.components.raw) return this._esc(s.components.raw);

        return this._esc(String(s.components));
    },

    _formatDescription(desc) {
        if (!desc) return '';
        if (Array.isArray(desc)) return desc.map(p => `<p>${this._esc(p)}</p>`).join('');
        return `<p>${this._esc(desc)}</p>`;
    },

    /* ── UI helpers ──────────────────────────────────────── */
    _showLoading() {
        this.els.list.innerHTML = `<div class="loading-spinner"><div class="spinner"></div><p>Wczytuję księgę czarów…</p></div>`;
    },

    _spinnerHtml() {
        return `<div class="loading-spinner"><div class="spinner"></div></div>`;
    },

    _emptyState(msg) {
        return `<div class="empty-state empty-state-wide"><i class="fa-solid fa-feather"></i><span>${this._esc(msg)}</span></div>`;
    },

    _esc(str) {
        if (str == null) return '';
        const d = document.createElement('div');
        d.textContent = String(str);
        return d.innerHTML;
    },
};

window.SpellsModule = SpellsModule;
