/* ============================================
   D&D 5e DM Panel — Kuźnia map (v2)
   Wnętrza wielopiętrowe: osobne warstwy podłogi i ścian,
   drzwi/kraty/przejścia sekretne, ~60 elementów wyposażenia,
   światło i mrok, żetony drużyny, NPC i potworów.
   ============================================ */

const MapForge = (() => {
    const CELL = 80;
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const uid = () => Math.random().toString(36).slice(2, 9);

    // ---------- podłogi ----------
    const FLOORS = {
        w: 'Dębowe deski', r: 'Zbutwiałe deski', s: 'Płyty kamienne', k: 'Bruk', m: 'Czarny marmur', x: 'Skała jaskini',
        d: 'Ubita ziemia', u: 'Błoto', g: 'Trawa', n: 'Piasek', c: 'Szkarłatny dywan', a: 'Mroczna woda', l: 'Lawa', p: 'Otchłań'
    };
    // ---------- ściany i przejścia ----------
    const WALLS = {
        '#': ['Mur kamienny', 'wall'], 'h': ['Ściana z bali', 'wall'], 'X': ['Lita skała', 'wall'],
        'D': ['Drzwi', 'door'], 'L': ['Drzwi zamknięte', 'door'], 'S': ['Sekretne przejście (MG)', 'door'],
        'V': ['Okno', 'door'], 'B': ['Kraty', 'door'], 'P': ['Brona', 'door']
    };
    const isSolid = (c) => c === '#' || c === 'h' || c === 'X';

    // ---------- rysunki elementów ----------
    const W0 = '#5c3a1c', WD = '#24140a', WL = '#7d5530', IRON = '#3b3b40', IRONL = '#6b6b72', STONE = '#4a4742', STONEL = '#6e6a62', BONE = '#d8ccb0';
    const R = (x, y, w, h, f, extra = '') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${f}" ${extra}/>`;
    const C = (cx, cy, r, f, extra = '') => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${f}" ${extra}/>`;
    const flame = (x, y, s = 1) => `<g transform="translate(${x} ${y}) scale(${s})" class="mf-flame"><ellipse rx="9" ry="13" fill="url(#mf-fire)"/><ellipse rx="4" ry="7" cy="3" fill="#fff3c0"/></g>`;
    const bone = (x, y, a) => `<g transform="translate(${x} ${y}) rotate(${a})"><rect x="-14" y="-2.5" width="28" height="5" rx="2" fill="${BONE}"/><circle cx="-14" cy="-3" r="3.5" fill="${BONE}"/><circle cx="-14" cy="3" r="3.5" fill="${BONE}"/><circle cx="14" cy="-3" r="3.5" fill="${BONE}"/><circle cx="14" cy="3" r="3.5" fill="${BONE}"/></g>`;
    const skull = (x, y, s = 1) => `<g transform="translate(${x} ${y}) scale(${s})"><path d="M-10 2a10 10 0 1 1 20 0v5h-4v4h-12v-4h-4z" fill="${BONE}" stroke="#7a6e55" stroke-width="1.5"/><circle cx="-4" cy="0" r="3" fill="#1a120b"/><circle cx="4" cy="0" r="3" fill="#1a120b"/></g>`;

    // [nazwa, szer., tył/wys., kategoria, rysunek(w,h), {light: promień w polach, dm: tylko dla MG, stairs: ±1}]
    const OBJ = {
        // --- karczma i dom ---
        table: ['Stół', 2, 1, 'home', (w, h) => R(-w / 2 + 6, -h / 2 + 10, w - 12, h - 20, W0, `rx="5" stroke="${WD}" stroke-width="3"`) + `<path d="M${-w / 2 + 10} -8H${w / 2 - 10}M${-w / 2 + 10} 8H${w / 2 - 10}" stroke="${WD}" stroke-width="1.5" opacity=".7"/>` + C(-28, -2, 8, '#b9a27a', `stroke="#4a2e14" stroke-width="2"`) + C(26, 4, 7, '#cfc0a0', `stroke="#4a2e14" stroke-width="2"`)],
        roundtable: ['Okrągły stół', 1, 1, 'home', () => C(0, 0, 31, W0, `stroke="${WD}" stroke-width="3"`) + C(0, 0, 22, 'none', `stroke="${WD}" stroke-width="1" opacity=".5"`) + C(-6, -5, 7, '#b9a27a', `stroke="#4a2e14" stroke-width="2"`)],
        chair: ['Krzesło', 1, 1, 'home', () => R(-15, -10, 30, 28, WL, `rx="3" stroke="${WD}" stroke-width="3"`) + R(-17, -22, 34, 10, W0, `rx="3" stroke="${WD}" stroke-width="3"`)],
        stool: ['Stołek', 1, 1, 'home', () => C(0, 0, 14, WL, `stroke="${WD}" stroke-width="3"`) + C(0, 0, 5, W0)],
        bench: ['Ława', 2, 1, 'home', (w) => R(-w / 2 + 8, -11, w - 16, 22, WL, `rx="3" stroke="${WD}" stroke-width="3"`)],
        bar: ['Lada', 4, 1, 'home', (w, h) => R(-w / 2 + 4, -h / 2 + 10, w - 8, h - 20, '#3f2410', `rx="4" stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 8, -h / 2 + 12, w - 16, 11, WL, 'rx="2"') + [-100, -40, 30, 95].map(x => R(x, 2, 12, 15, '#c9b07a', `rx="2" stroke="#3a220e" stroke-width="2"`)).join('')],
        barrel: ['Beczka', 1, 1, 'home', () => C(0, 0, 29, '#6e4423', `stroke="${WD}" stroke-width="3"`) + C(0, 0, 21, 'none', `stroke="${IRON}" stroke-width="4"`) + C(0, 0, 9, 'none', `stroke="${IRON}" stroke-width="3"`)],
        crate: ['Skrzynia', 1, 1, 'home', () => R(-27, -27, 54, 54, '#80562e', `stroke="${WD}" stroke-width="3"`) + `<path d="M-27 -27L27 27M27 -27L-27 27" stroke="${WD}" stroke-width="5"/>`],
        chest: ['Kufer', 1, 1, 'home', () => R(-27, -19, 54, 38, W0, `rx="4" stroke="${WD}" stroke-width="3"`) + `<path d="M-13 -19V19M13 -19V19" stroke="#a8862a" stroke-width="5"/>` + R(-6, -6, 12, 12, '#d4b04a', `stroke="#4a2e14" stroke-width="2"`)],
        bed: ['Łóżko', 1, 2, 'home', (w, h) => R(-w / 2 + 6, -h / 2 + 4, w - 12, h - 8, '#4a2c14', `rx="4" stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 11, -h / 2 + 9, w - 22, h - 18, '#c9bfa8', 'rx="3"') + R(-w / 2 + 15, -h / 2 + 13, w - 30, 22, '#e6dfcf', 'rx="7"') + R(-w / 2 + 11, -h / 2 + 50, w - 22, h - 59, '#5e1f1f', 'rx="3"')],
        wardrobe: ['Szafa', 2, 1, 'home', (w, h) => R(-w / 2 + 6, -h / 2 + 12, w - 12, h - 24, '#3f2410', `stroke="${WD}" stroke-width="3"`) + `<path d="M0 ${-h / 2 + 12}V${h / 2 - 12}" stroke="${WD}" stroke-width="3"/>` + C(-6, 0, 3, '#c9a227') + C(6, 0, 3, '#c9a227')],
        desk: ['Biurko', 2, 1, 'home', (w, h) => R(-w / 2 + 8, -h / 2 + 12, w - 16, h - 24, W0, `stroke="${WD}" stroke-width="3"`) + R(-40, -10, 30, 20, '#d9cba6', 'transform="rotate(-8)"') + `<path d="M20 -12l14 18" stroke="#1a120b" stroke-width="3"/>` + C(30, 8, 6, '#1a1a2a')],
        bookshelf: ['Regał z księgami', 2, 1, 'home', (w, h) => R(-w / 2 + 4, -h / 2 + 14, w - 8, h - 28, '#2e1a0b', `stroke="${WD}" stroke-width="3"`) + ['#6a1515', '#22365a', '#3a5a26', '#8a6a1a', '#4a2a5a', '#6a1515', '#22365a', '#7a4a1a', '#3a5a26', '#8a6a1a', '#4a2a5a', '#6a1515'].map((c, i) => R(-w / 2 + 10 + i * 12, -h / 2 + 19, 9, h - 38, c)).join('')],
        rug: ['Dywan', 3, 2, 'home', (w, h) => R(-w / 2 + 10, -h / 2 + 10, w - 20, h - 20, '#5a1414', `stroke="#a8862a" stroke-width="4"`) + R(-w / 2 + 24, -h / 2 + 24, w - 48, h - 48, 'none', `stroke="#a8862a" stroke-width="2" stroke-dasharray="8 6"`) + `<path d="M0 ${-h / 2 + 34}L${w / 2 - 50} 0L0 ${h / 2 - 34}L${-w / 2 + 50} 0Z" fill="#7a2020" stroke="#c9a227" stroke-width="2"/>`],
        fireplace: ['Kominek', 2, 1, 'home', (w, h) => R(-w / 2 + 4, -h / 2 + 4, w - 8, h - 8, STONE, `rx="3" stroke="#1f1c19" stroke-width="3"`) + R(-w / 2 + 26, -h / 2 + 18, w - 52, h - 26, '#0d0805', 'rx="5"') + flame(-14, 12, 1.1) + flame(10, 14, 0.9), { light: 4 }],
        kitchen: ['Palenisko z kotłem', 1, 1, 'home', () => C(0, 0, 30, STONE, `stroke="#1f1c19" stroke-width="3"`) + flame(0, 6, 0.8) + C(0, -4, 16, '#1a1a1e', `stroke="#555" stroke-width="2"`) + C(0, -4, 11, '#6a4a2a'), { light: 2.5 }],
        doublebed: ['Łoże małżeńskie', 2, 2, 'home', (w, h) => R(-w / 2 + 6, -h / 2 + 4, w - 12, h - 8, '#4a2c14', `rx="5" stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 12, -h / 2 + 10, w - 24, h - 20, '#c9bfa8', 'rx="4"') + R(-w / 2 + 18, -h / 2 + 14, w / 2 - 26, 26, '#efe8d6', 'rx="6"') + R(8, -h / 2 + 14, w / 2 - 26, 26, '#efe8d6', 'rx="6"') + R(-w / 2 + 12, -h / 2 + 52, w - 24, h - 62, '#6a1515', 'rx="4" opacity=".9"')],
        bunk: ['Prycza', 1, 2, 'home', (w, h) => R(-w / 2 + 8, -h / 2 + 4, w - 16, h - 8, '#5c3a1c', `stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 12, -h / 2 + 10, w - 24, h - 20, '#8a7a5a') + R(-w / 2 + 14, -h / 2 + 12, w - 28, 20, '#b8ad92', 'rx="4"')],
        nightstand: ['Szafka nocna', 1, 1, 'home', () => R(-18, -18, 36, 36, W0, `rx="3" stroke="${WD}" stroke-width="3"`) + C(0, 0, 4, '#c9a227') + flame(8, -8, 0.35)],
        dresser: ['Komoda', 2, 1, 'home', (w, h) => R(-w / 2 + 8, -h / 2 + 14, w - 16, h - 28, '#4a2c14', `stroke="${WD}" stroke-width="3"`) + [-30, 0, 30].map(x => C(x, 0, 4, '#c9a227')).join('')],
        cupboard: ['Kredens z naczyniami', 2, 1, 'home', (w, h) => R(-w / 2 + 6, -h / 2 + 12, w - 12, h - 24, '#3f2410', `stroke="${WD}" stroke-width="3"`) + [-48, -24, 0, 24, 48].map((x, i) => C(x, -4, 8, i % 2 ? '#d9cfb8' : '#8aa0b8', 'stroke="#2a1a0e" stroke-width="2"')).join('') + R(-w / 2 + 10, 10, w - 20, 4, WD)],
        armchair: ['Fotel', 1, 1, 'home', () => R(-24, -18, 48, 40, '#6a1515', `rx="8" stroke="${WD}" stroke-width="3"`) + R(-24, -26, 48, 14, '#4a0e0e', `rx="6" stroke="${WD}" stroke-width="2"`) + R(-16, -8, 32, 22, '#8a2020', 'rx="5"')],
        longtable: ['Długi stół biesiadny', 4, 1, 'home', (w, h) => R(-w / 2 + 6, -h / 2 + 12, w - 12, h - 24, W0, `rx="4" stroke="${WD}" stroke-width="3"`) + Array.from({ length: 7 }, (_, i) => C(-w / 2 + 30 + i * (w - 60) / 6, (i % 2 ? -8 : 8), 7, '#b9a27a', 'stroke="#4a2e14" stroke-width="2"')).join('') + flame(-40, 0, 0.4) + flame(40, 0, 0.4), { light: 1.5 }],
        oven: ['Piec chlebowy', 2, 1, 'home', (w, h) => `<path d="M${-w / 2 + 6} ${h / 2 - 8}V${-h / 2 + 30}Q0 ${-h / 2 - 14} ${w / 2 - 6} ${-h / 2 + 30}V${h / 2 - 8}Z" fill="${STONE}" stroke="#1f1c19" stroke-width="3"/>` + `<path d="M-22 ${h / 2 - 8}V0Q0 -22 22 0V${h / 2 - 8}Z" fill="#1a0d06"/>` + flame(0, 18, 0.7), { light: 2.5 }],
        tub: ['Balia', 1, 1, 'home', () => `<ellipse rx="30" ry="24" fill="#6e4423" stroke="${WD}" stroke-width="3"/><ellipse rx="22" ry="17" fill="#4f7a96"/><ellipse cx="-6" cy="-5" rx="8" ry="4" fill="#9cc4dc" opacity=".6"/>` + `<path d="M-30 -6H30M-30 6H30" stroke="${IRON}" stroke-width="2" opacity=".7"/>`],
        washbasin: ['Miednica na stojaku', 1, 1, 'home', () => C(0, 0, 20, W0, `stroke="${WD}" stroke-width="3"`) + C(0, 0, 14, '#cfd6dc') + C(0, 0, 9, '#7aa2bd')],
        cradle: ['Kołyska', 1, 1, 'home', () => `<ellipse rx="18" ry="28" fill="${WL}" stroke="${WD}" stroke-width="3"/><ellipse rx="12" ry="20" fill="#e8dfc6"/><circle cy="-10" r="6" fill="#f0d8c0"/>`],
        sacks: ['Worki z mąką', 1, 1, 'home', () => [[-12, -8], [10, -10], [0, 10]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="15" ry="13" fill="#d8c8a0" stroke="#7a6a4a" stroke-width="2.5"/><path d="M${x - 4} ${y - 11}l4 4 4-4" stroke="#7a6a4a" stroke-width="2" fill="none"/>`).join('')],
        bottles: ['Regał z butelkami', 2, 1, 'home', (w, h) => R(-w / 2 + 4, -h / 2 + 14, w - 8, h - 28, '#2e1a0b', `stroke="${WD}" stroke-width="3"`) + Array.from({ length: 10 }, (_, i) => C(-w / 2 + 16 + i * (w - 32) / 9, (i % 2 ? -6 : 6), 6, ['#2f6b3f', '#6a1515', '#8a6a1a', '#22365a'][i % 4], 'stroke="#000" stroke-width="1.5"')).join('')],
        kegs: ['Stojak z beczkami', 2, 1, 'home', (w, h) => R(-w / 2 + 4, -h / 2 + 8, w - 8, h - 16, '#3f2410', `stroke="${WD}" stroke-width="3"`) + [-40, 0, 40].map(x => C(x, 0, 18, '#6e4423', `stroke="${IRON}" stroke-width="3"`) + C(x, 0, 6, '#3a220e')).join('')],
        woodpile: ['Stos drewna', 1, 1, 'home', () => [[-14, 10], [0, 10], [14, 10], [-7, -2], [7, -2], [0, -14]].map(([x, y]) => C(x, y, 8, '#8a6a40', 'stroke="#3a220e" stroke-width="2.5"') + C(x, y, 3, '#5c3a1c')).join('')],
        plant: ['Donica z kwiatami', 1, 1, 'home', () => C(0, 0, 18, '#8a4a2a', 'stroke="#3a1a0a" stroke-width="3"') + C(-6, -4, 9, '#3f7a2a') + C(6, 2, 10, '#4a8a34') + C(0, -8, 4, '#e05a8a') + C(8, -2, 3, '#f3d382')],
        piano: ['Klawikord', 2, 1, 'home', (w, h) => R(-w / 2 + 8, -h / 2 + 12, w - 16, h - 24, '#1e120a', `rx="4" stroke="#000" stroke-width="3"`) + R(-w / 2 + 14, 6, w - 28, 12, '#efe8d6') + Array.from({ length: 13 }, (_, i) => R(-w / 2 + 18 + i * (w - 36) / 13, 6, 4, 7, '#111')).join('')],
        privy: ['Wychodek', 1, 1, 'home', () => R(-26, -26, 52, 52, '#6e4a26', `stroke="${WD}" stroke-width="3"`) + `<path d="M-6 -16a6 6 0 1 0 12 0" fill="#f3d382"/>` + C(0, 8, 9, '#1a0d06')],
        // --- warsztat, handel i straż ---
        forge: ['Palenisko kowalskie', 2, 2, 'craft', (w) => R(-w / 2 + 6, -w / 2 + 6, w - 12, w - 12, STONE, `rx="6" stroke="#1f1c19" stroke-width="4"`) + R(-30, -30, 60, 60, '#1a0d06', 'rx="8"') + flame(-10, 6, 1.3) + flame(12, 10, 1) + C(-w / 2 + 22, w / 2 - 22, 10, IRON), { light: 4, glow: '#ff7a2a' }],
        anvil: ['Kowadło', 1, 1, 'craft', () => `<path d="M-28 -8H20L28 -16V-8H24V6H8V16H14V22H-14V16H-8V6H-28Z" fill="${IRON}" stroke="#141418" stroke-width="2.5"/>` + R(-20, -6, 30, 4, IRONL)],
        grindstone: ['Toczydło', 1, 1, 'craft', () => R(-24, -8, 48, 16, W0, `stroke="${WD}" stroke-width="2"`) + `<ellipse rx="10" ry="24" fill="#8f8a7e" stroke="#3a3733" stroke-width="3"/>`],
        weaponrack: ['Stojak z bronią', 2, 1, 'craft', (w, h) => R(-w / 2 + 6, -6, w - 12, 12, W0, `stroke="${WD}" stroke-width="3"`) + [-50, -25, 0, 25, 50].map((x, i) => `<path d="M${x} -26V22" stroke="${i % 2 ? IRONL : '#a8a8b0'}" stroke-width="5"/><path d="M${x - 8} ${i % 2 ? 14 : -18}h16" stroke="#5c3a1c" stroke-width="5"/>`).join('')],
        armorstand: ['Stojak ze zbroją', 1, 1, 'craft', () => `<path d="M-20 -14Q0 -26 20 -14L16 18H-16Z" fill="${IRONL}" stroke="#141418" stroke-width="3"/>` + C(0, -20, 9, IRON, 'stroke="#141418" stroke-width="2"') + `<path d="M-8 -4H8M-6 6H6" stroke="${IRON}" stroke-width="3"/>`],
        dummy: ['Manekin ćwiczebny', 1, 1, 'craft', () => C(0, 0, 18, '#c8a868', 'stroke="#6a5014" stroke-width="3"') + `<path d="M-26 0H26" stroke="#8a6a40" stroke-width="7" stroke-linecap="round"/>` + C(0, 0, 8, '#a8863e') + `<path d="M-5 -5l10 10M5 -5l-10 10" stroke="#6a1515" stroke-width="3"/>`],
        target: ['Tarcza strzelnicza', 1, 1, 'craft', () => C(0, 0, 28, '#efe8d6', 'stroke="#3a220e" stroke-width="3"') + C(0, 0, 20, '#c0392b') + C(0, 0, 12, '#efe8d6') + C(0, 0, 5, '#c0392b') + `<path d="M4 -4l16 -14" stroke="#5c3a1c" stroke-width="3"/>`],
        stall: ['Stragan', 2, 1, 'craft', (w, h) => R(-w / 2 + 4, -h / 2 + 6, w - 8, h - 12, '#5c3a1c', `stroke="${WD}" stroke-width="3"`) + Array.from({ length: 6 }, (_, i) => R(-w / 2 + 4 + i * (w - 8) / 6, -h / 2 + 6, (w - 8) / 6, 18, i % 2 ? '#efe8d6' : '#a8261c')).join('') + [-40, -10, 22, 48].map((x, i) => C(x, 10, 8, ['#d9a24a', '#8fbf4a', '#c0392b', '#e8d36a'][i])).join('')],
        trough: ['Koryto', 2, 1, 'craft', (w, h) => R(-w / 2 + 10, -14, w - 20, 28, W0, `rx="6" stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 16, -8, w - 32, 16, '#4f7a96', 'rx="4"')],
        loom: ['Krosno', 2, 1, 'craft', (w, h) => R(-w / 2 + 8, -h / 2 + 14, w - 16, h - 28, 'none', `stroke="${W0}" stroke-width="6"`) + Array.from({ length: 12 }, (_, i) => `<path d="M${-w / 2 + 16 + i * (w - 32) / 11} ${-h / 2 + 16}V${h / 2 - 16}" stroke="#c9b48a" stroke-width="1.5"/>`).join('') + R(-w / 2 + 16, -6, w - 32, 12, '#6a1515', 'opacity=".8"')],
        spinwheel: ['Kołowrotek', 1, 1, 'craft', () => C(-4, -4, 20, 'none', `stroke="${W0}" stroke-width="4"`) + [0, 45, 90, 135].map(a => `<path d="M${-4 - Math.cos(a * Math.PI / 180) * 20} ${-4 - Math.sin(a * Math.PI / 180) * 20}L${-4 + Math.cos(a * Math.PI / 180) * 20} ${-4 + Math.sin(a * Math.PI / 180) * 20}" stroke="${WL}" stroke-width="2"/>`).join('') + R(4, 12, 22, 10, W0)],
        alchemy: ['Stół alchemika', 2, 1, 'craft', (w, h) => R(-w / 2 + 6, -h / 2 + 12, w - 12, h - 24, '#3f2410', `stroke="${WD}" stroke-width="3"`) + C(-40, 0, 9, '#3f8a30', 'stroke="#ddd" stroke-width="2"') + C(-14, -4, 7, '#7a4ad8', 'stroke="#ddd" stroke-width="2"') + `<path d="M12 10L22 -12L32 10Z" fill="#c0392b" stroke="#ddd" stroke-width="2"/>` + flame(52, 4, 0.45), { light: 1.5, glow: '#9a6aff' }],
        maptable: ['Stół z mapą', 2, 2, 'craft', (w) => R(-w / 2 + 8, -w / 2 + 8, w - 16, w - 16, W0, `rx="4" stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 20, -w / 2 + 20, w - 40, w - 40, '#d9cba6', 'transform="rotate(-4)"') + `<path d="M-40 -20Q-10 -40 20 -10T50 20M-30 30L10 10" stroke="#6a4a2a" stroke-width="3" fill="none"/>` + C(18, -6, 5, '#c0392b')],
        bookpile: ['Stos ksiąg', 1, 1, 'craft', () => [['#6a1515', -2], ['#22365a', 4], ['#3a5a26', -6], ['#8a6a1a', 2]].map(([c, r], i) => R(-20, -20 + i * 10, 40, 9, c, `transform="rotate(${r})" stroke="#000" stroke-width="1"`)).join('')],
        crates: ['Stos skrzyń', 2, 2, 'craft', () => [[-40, -40], [0, -40], [-40, 0], [10, 10]].map(([x, y]) => R(x - 2, y - 2, 34, 34, '#80562e', `stroke="${WD}" stroke-width="3"`) + `<path d="M${x - 2} ${y - 2}l34 34M${x + 32} ${y - 2}l-34 34" stroke="${WD}" stroke-width="3"/>`).join('')],
        fence: ['Płot', 2, 1, 'craft', (w) => `<path d="M${-w / 2 + 4} -6H${w / 2 - 4}M${-w / 2 + 4} 6H${w / 2 - 4}" stroke="${W0}" stroke-width="6"/>` + [-w / 2 + 8, -w / 4, 0, w / 4, w / 2 - 8].map(x => R(x - 4, -12, 8, 24, WL, `stroke="${WD}" stroke-width="2"`)).join('')],
        palisade: ['Palisada', 2, 1, 'craft', (w) => Array.from({ length: 8 }, (_, i) => C(-w / 2 + 10 + i * (w - 20) / 7, 0, 10, '#6e4423', `stroke="${WD}" stroke-width="2.5"`)).join('')],
        stocks: ['Dyby', 2, 1, 'craft', (w) => R(-w / 2 + 14, -10, w - 28, 20, W0, `stroke="${WD}" stroke-width="3"`) + [-30, 0, 30].map((x, i) => C(x, 0, i === 1 ? 8 : 5, '#1a0d06')).join('')],
        // --- loch ---
        stairsUp: ['Schody w górę', 2, 2, 'dungeon', (w, h) => R(-w / 2 + 4, -h / 2 + 4, w - 8, h - 8, '#3a3733', `stroke="#141210" stroke-width="3"`) + Array.from({ length: 7 }, (_, i) => R(-w / 2 + 8, -h / 2 + 8 + i * 21, w - 16, 17, `rgb(${70 + i * 14},${66 + i * 13},${60 + i * 12})`)).join('') + `<path d="M0 ${h / 2 - 22}V${-h / 2 + 26}M-14 ${-h / 2 + 42}L0 ${-h / 2 + 24}L14 ${-h / 2 + 42}" stroke="#e9c46a" stroke-width="5" fill="none"/>`, { stairs: 1 }],
        stairsDown: ['Schody w dół', 2, 2, 'dungeon', (w, h) => R(-w / 2 + 4, -h / 2 + 4, w - 8, h - 8, '#2a2724', `stroke="#141210" stroke-width="3"`) + Array.from({ length: 7 }, (_, i) => R(-w / 2 + 8, -h / 2 + 8 + i * 21, w - 16, 17, `rgb(${120 - i * 15},${114 - i * 14},${104 - i * 13})`)).join('') + `<path d="M0 ${-h / 2 + 22}V${h / 2 - 26}M-14 ${h / 2 - 42}L0 ${h / 2 - 24}L14 ${h / 2 - 42}" stroke="#e9c46a" stroke-width="5" fill="none"/>`, { stairs: -1 }],
        pillar: ['Kolumna', 1, 1, 'dungeon', () => C(0, 0, 30, STONE, `stroke="#1f1c19" stroke-width="3"`) + C(0, 0, 22, STONEL) + C(-8, -8, 7, '#8a867c', 'opacity=".7"')],
        rubble: ['Gruz', 1, 1, 'dungeon', () => `<path d="M-30 14L-22 -10L-6 -4L2 -22L20 -14L30 6L16 24L-12 26Z" fill="${STONE}" stroke="#1f1c19" stroke-width="3"/>` + C(-14, 8, 6, STONEL) + C(12, 2, 5, STONEL)],
        cage: ['Klatka', 1, 1, 'dungeon', () => R(-28, -28, 56, 56, 'rgba(0,0,0,.35)', `stroke="${IRON}" stroke-width="5"`) + [-14, 0, 14].map(x => `<path d="M${x} -28V28" stroke="${IRONL}" stroke-width="3"/>`).join('')],
        coffin: ['Trumna', 1, 2, 'dungeon', (w, h) => `<path d="M-18 ${-h / 2 + 8}L18 ${-h / 2 + 8}L28 ${-h / 2 + 40}L18 ${h / 2 - 8}L-18 ${h / 2 - 8}L-28 ${-h / 2 + 40}Z" fill="#2a1a0e" stroke="#0d0805" stroke-width="3"/><path d="M0 -30V20M-12 -14H12" stroke="#8a7a5a" stroke-width="4"/>`],
        sarcophagus: ['Sarkofag', 1, 2, 'dungeon', (w, h) => R(-30, -h / 2 + 6, 60, h - 12, '#5e5a52', `rx="6" stroke="#1f1c19" stroke-width="3"`) + R(-22, -h / 2 + 14, 44, h - 28, '#7a756a', 'rx="12"') + `<circle cy="${-h / 2 + 34}" r="10" fill="#8f8a7e"/><path d="M-12 0H12M0 -12V30" stroke="#5e5a52" stroke-width="3"/>`],
        bones: ['Kości', 1, 1, 'dungeon', () => bone(-6, -8, 20) + bone(8, 10, -35) + skull(10, -12, 0.9)],
        skulls: ['Stos czaszek', 1, 1, 'dungeon', () => skull(-12, 8) + skull(12, 8) + skull(0, -8, 1.1) + bone(0, 22, 5)],
        chains: ['Łańcuchy', 1, 1, 'dungeon', () => Array.from({ length: 5 }, (_, i) => `<ellipse cx="${-24 + i * 12}" cy="${(i % 2) * 6 - 3}" rx="7" ry="4" fill="none" stroke="${IRONL}" stroke-width="3"/>`).join('') + C(-30, -3, 5, IRON) + C(30, 3, 5, IRON)],
        rack: ['Łoże tortur', 1, 2, 'dungeon', (w, h) => R(-26, -h / 2 + 6, 52, h - 12, '#3f2410', `stroke="${WD}" stroke-width="3"`) + C(0, -h / 2 + 18, 10, IRON) + C(0, h / 2 - 18, 10, IRON) + `<path d="M-14 ${-h / 2 + 30}V${h / 2 - 30}M14 ${-h / 2 + 30}V${h / 2 - 30}" stroke="#7a2020" stroke-width="3"/>`],
        maiden: ['Żelazna dziewica', 1, 1, 'dungeon', () => `<path d="M-18 -26H18L24 26H-24Z" fill="${IRON}" stroke="#141418" stroke-width="3"/><circle cy="-12" r="7" fill="${IRONL}"/>` + [-10, 0, 10].map(x => `<path d="M${x} 0v14" stroke="#a33" stroke-width="2"/>`).join('')],
        web: ['Pajęczyna', 2, 2, 'dungeon', (w) => { const r = w / 2 - 6; let s = ''; for (let a = 0; a < 360; a += 45) s += `<path d="M0 0L${(Math.cos(a * Math.PI / 180) * r).toFixed(1)} ${(Math.sin(a * Math.PI / 180) * r).toFixed(1)}" stroke="#d6d2c8" stroke-width="1.5" opacity=".7"/>`; for (let k = 1; k <= 4; k++) s += `<circle r="${(r * k / 4).toFixed(1)}" fill="none" stroke="#d6d2c8" stroke-width="1.2" stroke-dasharray="6 3" opacity=".55"/>`; return s; }],
        blood: ['Plama krwi', 1, 1, 'dungeon', () => `<path d="M-20 -6Q-24 -22 -6 -20Q4 -30 16 -18Q30 -10 22 6Q26 24 6 22Q-10 30 -18 16Q-32 8 -20 -6Z" fill="#4a0a08" opacity=".85"/>` + C(24, -20, 4, '#4a0a08') + C(-26, 20, 3, '#4a0a08')],
        well: ['Studnia', 2, 2, 'dungeon', () => C(0, 0, 62, STONE, `stroke="#1f1c19" stroke-width="4"`) + C(0, 0, 44, '#0a0705') + C(0, 0, 36, '#0f1a24', 'opacity=".8"') + `<path d="M-62 0H62" stroke="${W0}" stroke-width="8"/>`],
        tombstone: ['Nagrobek', 1, 1, 'dungeon', () => `<path d="M-18 26V-6A18 18 0 0 1 18 -6V26Z" fill="${STONEL}" stroke="#1f1c19" stroke-width="3"/><path d="M0 -10V12M-8 -2H8" stroke="#3a3733" stroke-width="3"/>`],
        statue: ['Posąg', 1, 1, 'dungeon', () => R(-28, -28, 56, 56, STONE, `stroke="#1f1c19" stroke-width="3"`) + C(0, 2, 15, '#8f8a7e') + C(0, -8, 7, '#a7a296')],
        ladder: ['Drabina w górę', 1, 1, 'dungeon', () => `<path d="M-14 -30V30M14 -30V30" stroke="${W0}" stroke-width="5"/>` + [-20, -8, 4, 16].map(y => `<path d="M-14 ${y}H14" stroke="${WL}" stroke-width="4"/>`).join('') + `<path d="M-10 -22L0 -32L10 -22" stroke="#e9c46a" stroke-width="3" fill="none"/>`, { stairs: 1 }],
        trapdoor: ['Klapa w podłodze', 1, 1, 'dungeon', () => R(-28, -28, 56, 56, '#4a2c14', `stroke="${WD}" stroke-width="3"`) + `<path d="M-28 -9H28M-28 9H28" stroke="${WD}" stroke-width="2"/>` + C(14, 0, 5, 'none', `stroke="${IRONL}" stroke-width="3"`) + `<path d="M-8 14L0 24L8 14" stroke="#e9c46a" stroke-width="3" fill="none"/>`, { stairs: -1 }],
        spiral: ['Kręte schody', 2, 2, 'dungeon', (w) => C(0, 0, w / 2 - 6, '#3a3733', 'stroke="#141210" stroke-width="3"') + Array.from({ length: 10 }, (_, i) => { const a = i * 36 * Math.PI / 180, r = w / 2 - 10; return `<path d="M0 0L${(Math.cos(a) * r).toFixed(1)} ${(Math.sin(a) * r).toFixed(1)}" stroke="rgb(${90 + i * 9},${86 + i * 9},${80 + i * 8})" stroke-width="10"/>`; }).join('') + C(0, 0, 12, STONEL) + `<path d="M-10 -28L0 -38L10 -28" stroke="#e9c46a" stroke-width="4" fill="none"/>`, { stairs: 1 }],
        brokenpillar: ['Złamana kolumna', 1, 1, 'dungeon', () => C(0, 0, 26, STONE, 'stroke="#1f1c19" stroke-width="3"') + `<path d="M-18 -10L-4 -2L-10 12L8 4L16 16" stroke="#1f1c19" stroke-width="3" fill="none"/>` + C(24, 18, 8, STONEL)],
        lever: ['Dźwignia', 1, 1, 'dungeon', () => R(-14, -6, 28, 18, IRON, 'rx="3" stroke="#141418" stroke-width="2"') + `<path d="M0 2L14 -22" stroke="${IRONL}" stroke-width="5" stroke-linecap="round"/>` + C(14, -22, 6, '#c0392b')],
        spikes: ['Kolce', 1, 1, 'dungeon', () => R(-28, -28, 56, 56, 'rgba(0,0,0,.35)', `stroke="${IRON}" stroke-width="2"`) + Array.from({ length: 9 }, (_, i) => { const x = -18 + (i % 3) * 18, y = -18 + Math.floor(i / 3) * 18; return `<path d="M${x - 6} ${y + 6}L${x} ${y - 8}L${x + 6} ${y + 6}Z" fill="${IRONL}" stroke="#141418" stroke-width="1.5"/>`; }).join('')],
        portcullisLever: ['Kołowrót brony', 1, 1, 'dungeon', () => C(0, 0, 22, 'none', `stroke="${W0}" stroke-width="6"`) + [0, 60, 120].map(a => `<path d="M${(-Math.cos(a * Math.PI / 180) * 26).toFixed(1)} ${(-Math.sin(a * Math.PI / 180) * 26).toFixed(1)}L${(Math.cos(a * Math.PI / 180) * 26).toFixed(1)} ${(Math.sin(a * Math.PI / 180) * 26).toFixed(1)}" stroke="${WL}" stroke-width="5"/>`).join('') + C(0, 0, 7, IRON)],
        // --- świątynia i magia ---
        altar: ['Ołtarz', 2, 1, 'magic', (w, h) => R(-w / 2 + 8, -h / 2 + 12, w - 16, h - 24, '#5e5a52', `rx="3" stroke="#1f1c19" stroke-width="3"`) + R(-16, -14, 32, 28, '#4a0a08', 'opacity=".85"') + flame(-55, -4, 0.55) + flame(55, -4, 0.55), { light: 2.5 }],
        pentagram: ['Krąg rytualny', 2, 2, 'magic', (w) => { const r = w / 2 - 10; const pts = Array.from({ length: 5 }, (_, i) => { const a = -90 + i * 144; return `${(Math.cos(a * Math.PI / 180) * r * 0.9).toFixed(1)},${(Math.sin(a * Math.PI / 180) * r * 0.9).toFixed(1)}`; }).join(' '); return `<circle r="${r}" fill="none" stroke="#8a1a1a" stroke-width="4"/><circle r="${r - 8}" fill="none" stroke="#8a1a1a" stroke-width="1.5"/><polygon points="${pts}" fill="none" stroke="#b22222" stroke-width="3" class="mf-pulse"/>`; }, { light: 1.5 }],
        circle: ['Krąg magiczny', 2, 2, 'magic', (w) => `<circle r="${w / 2 - 8}" fill="rgba(80,120,255,.12)" stroke="#6fa3ff" stroke-width="4" class="mf-pulse"/><circle r="${w / 2 - 22}" fill="none" stroke="#9fc2ff" stroke-width="2" stroke-dasharray="4 8"/>` + Array.from({ length: 8 }, (_, i) => `<text x="${(Math.cos(i * Math.PI / 4) * (w / 2 - 15)).toFixed(0)}" y="${(Math.sin(i * Math.PI / 4) * (w / 2 - 15) + 5).toFixed(0)}" fill="#9fc2ff" font-size="14" text-anchor="middle">ᚱ</text>`).join(''), { light: 2 }],
        throne: ['Tron', 1, 1, 'magic', () => R(-24, -28, 48, 52, '#3a2a10', `rx="4" stroke="#0d0805" stroke-width="3"`) + R(-16, -12, 32, 30, '#6a1515', 'rx="3"') + `<path d="M-24 -28L-18 -38L-10 -28L0 -40L10 -28L18 -38L24 -28" fill="#c9a227" stroke="#5a3a10" stroke-width="2"/>`],
        banner: ['Sztandar', 1, 1, 'magic', () => `<path d="M-22 -26H22V18L0 28L-22 18Z" fill="#5a1414" stroke="#a8862a" stroke-width="3"/><path d="M0 -14L8 0L0 14L-8 0Z" fill="#c9a227"/><path d="M-26 -26H26" stroke="${IRON}" stroke-width="4"/>`],
        font: ['Chrzcielnica', 1, 1, 'magic', () => C(0, 0, 28, '#5e5a52', `stroke="#1f1c19" stroke-width="3"`) + C(0, 0, 19, '#1e3a52') + C(-5, -5, 5, '#6fa3c8', 'opacity=".7"')],
        crystal: ['Kryształy', 1, 1, 'magic', () => `<path d="M-6 22L-14 -10L-4 -24L4 -8Z" fill="#7a4ad8" stroke="#3a1a6a" stroke-width="2"/><path d="M4 22L8 -14L18 -2L16 20Z" fill="#9a6aff" stroke="#3a1a6a" stroke-width="2"/><path d="M-20 22L-22 4L-12 10Z" fill="#6a3ac8" stroke="#3a1a6a" stroke-width="2"/>`, { light: 2, glow: '#9a6aff' }],
        lectern: ['Pulpit z księgą', 1, 1, 'magic', () => R(-20, -14, 40, 28, '#3f2410', `stroke="${WD}" stroke-width="3"`) + R(-17, -11, 16, 22, '#d9cba6') + R(1, -11, 16, 22, '#cfc0a0')],
        cauldron: ['Kocioł wiedźmy', 1, 1, 'magic', () => C(0, 0, 27, '#1a1a1e', `stroke="#555" stroke-width="3"`) + C(0, 0, 19, '#3f8a30') + C(-6, -4, 5, '#8fe070') + C(7, 5, 3, '#8fe070'), { light: 1.5, glow: '#7fe060' }],
        pew: ['Ławka kościelna', 3, 1, 'magic', (w) => R(-w / 2 + 6, -14, w - 12, 28, W0, `rx="3" stroke="${WD}" stroke-width="3"`) + R(-w / 2 + 6, -18, w - 12, 8, '#3f2410', `stroke="${WD}" stroke-width="2"`)],
        portal: ['Portal', 2, 2, 'magic', (w) => `<ellipse rx="${w / 2 - 10}" ry="${w / 2 - 6}" fill="#1a0a3a" stroke="#5a4a9a" stroke-width="8"/><ellipse rx="${w / 2 - 22}" ry="${w / 2 - 18}" fill="rgba(140,90,255,.35)" class="mf-pulse"/><ellipse rx="${w / 4}" ry="${w / 3}" fill="rgba(200,170,255,.35)"/>`, { light: 3, glow: '#9a6aff' }],
        obelisk: ['Obelisk', 1, 1, 'magic', () => `<path d="M-14 26L-10 -16L0 -30L10 -16L14 26Z" fill="#2a2a32" stroke="#000" stroke-width="2.5"/><path d="M0 -20V18M-5 -4H5" stroke="#7fd0ff" stroke-width="2.5" opacity=".9"/>`, { light: 1, glow: '#7fd0ff' }],
        idol: ['Posążek bóstwa', 1, 1, 'magic', () => R(-24, 8, 48, 18, STONE, `stroke="#1f1c19" stroke-width="2"`) + `<path d="M-12 8V-12Q0 -30 12 -12V8Z" fill="#a8862a" stroke="#4a3a10" stroke-width="2.5"/>` + C(-4, -12, 2.5, '#c0392b') + C(4, -12, 2.5, '#c0392b')],
        fountain: ['Fontanna', 2, 2, 'magic', (w) => C(0, 0, w / 2 - 6, STONE, 'stroke="#1f1c19" stroke-width="4"') + C(0, 0, w / 2 - 16, '#3f6f8f') + C(0, 0, 16, STONEL, 'stroke="#1f1c19" stroke-width="2"') + C(0, 0, 7, '#9cc4dc') + C(-24, -18, 4, '#cfe6f3', 'opacity=".7"') + C(20, 22, 3, '#cfe6f3', 'opacity=".7"')],
        mirror: ['Magiczne zwierciadło', 1, 1, 'magic', () => `<ellipse rx="18" ry="26" fill="#3a2a10" stroke="#c9a227" stroke-width="4"/><ellipse rx="12" ry="19" fill="#9ab8d8"/><path d="M-6 -10L4 -14" stroke="#fff" stroke-width="3" opacity=".7"/>`, { light: 1, glow: '#9ab8d8' }],
        telescope: ['Luneta', 1, 1, 'magic', () => `<path d="M-18 18L0 0L-18 -4M0 0L14 18" stroke="${W0}" stroke-width="4"/>` + R(-6, -22, 34, 12, '#a8862a', 'transform="rotate(-30)" stroke="#4a3a10" stroke-width="2"')],
        // --- natura i obóz ---
        tree: ['Drzewo', 2, 2, 'nature', () => C(0, 0, 70, '#1a3312', 'opacity=".6"') + C(-18, -14, 40, '#2a4a1c') + C(22, -6, 38, '#335a22') + C(0, 22, 36, '#284516') + C(-6, -10, 14, '#4a7a34', 'opacity=".6"')],
        deadtree: ['Martwe drzewo', 2, 2, 'nature', () => C(0, 0, 12, '#3a2a1a') + [0, 70, 140, 200, 280].map(a => `<path d="M0 0L${(Math.cos(a * Math.PI / 180) * 60).toFixed(0)} ${(Math.sin(a * Math.PI / 180) * 60).toFixed(0)}" stroke="#3a2a1a" stroke-width="${6}" stroke-linecap="round"/>`).join('')],
        bush: ['Krzak', 1, 1, 'nature', () => C(-8, -6, 18, '#2a4a1c') + C(10, -2, 17, '#335a22') + C(0, 10, 16, '#284516')],
        rocks: ['Głazy', 1, 1, 'nature', () => `<path d="M-28 10L-18 -18L6 -26L26 -6L22 20L-8 26Z" fill="${STONE}" stroke="#1f1c19" stroke-width="3"/><path d="M-10 -10L8 -14L14 2" stroke="${STONEL}" stroke-width="3" fill="none"/>`],
        mushrooms: ['Świecące grzyby', 1, 1, 'nature', () => [[-12, 4, 10], [8, -6, 12], [12, 14, 7]].map(([x, y, r]) => `<rect x="${x - 2}" y="${y}" width="4" height="10" fill="#cfc6b0"/><ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r * 0.6}" fill="#3ad6c0" opacity=".9"/>`).join(''), { light: 1.5, glow: '#3ad6c0' }],
        campfire: ['Ognisko', 1, 1, 'nature', () => [0, 60, 120, 180, 240, 300].map(a => C((Math.cos(a * Math.PI / 180) * 24).toFixed(0), (Math.sin(a * Math.PI / 180) * 24).toFixed(0), 7, STONE)).join('') + `<path d="M-16 10L16 -10M-16 -10L16 10" stroke="#3a220e" stroke-width="6"/>` + flame(0, 0, 1.3), { light: 5 }],
        tent: ['Namiot', 2, 2, 'nature', (w) => `<path d="M${-w / 2 + 8} ${w / 2 - 8}L0 ${-w / 2 + 8}L${w / 2 - 8} ${w / 2 - 8}Z" fill="#6a5a3a" stroke="#2a2014" stroke-width="3"/><path d="M0 ${-w / 2 + 8}V${w / 2 - 8}" stroke="#2a2014" stroke-width="3"/><path d="M-14 ${w / 2 - 8}L0 10L14 ${w / 2 - 8}Z" fill="#1a140a"/>`],
        log: ['Kłoda', 2, 1, 'nature', (w) => R(-w / 2 + 8, -12, w - 16, 24, '#4a301a', `rx="12" stroke="${WD}" stroke-width="3"`) + `<ellipse cx="${w / 2 - 12}" rx="6" ry="11" fill="#8a6a40"/>`],
        cart: ['Wóz', 2, 1, 'nature', (w, h) => R(-w / 2 + 14, -h / 2 + 14, w - 28, h - 28, '#5c3a1c', `stroke="${WD}" stroke-width="3"`) + [-50, 50].map(x => `<rect x="${x - 6}" y="-34" width="12" height="68" rx="4" fill="#2a1a0e"/>`).join('')],
        hay: ['Siano', 1, 1, 'nature', () => R(-26, -20, 52, 40, '#b8963a', `rx="6" stroke="#6a5014" stroke-width="3"`) + `<path d="M-20 -8H20M-20 4H20" stroke="#8a6a1a" stroke-width="2"/>`],
        stump: ['Pniak', 1, 1, 'nature', () => C(0, 0, 20, '#6e4423', `stroke="${WD}" stroke-width="3"`) + C(0, 0, 14, '#b08a5a') + C(0, 0, 8, 'none', 'stroke="#8a6a40" stroke-width="2"') + C(0, 0, 3, '#8a6a40')],
        pond: ['Staw', 2, 2, 'nature', (w) => `<path d="M${-w / 2 + 10} 0Q${-w / 2 + 6} ${-w / 2 + 12} 0 ${-w / 2 + 10}Q${w / 2 - 4} ${-w / 2 + 16} ${w / 2 - 10} 4Q${w / 2 - 12} ${w / 2 - 8} 0 ${w / 2 - 10}Q${-w / 2 + 8} ${w / 2 - 10} ${-w / 2 + 10} 0Z" fill="#2f5a72" stroke="#3a5a26" stroke-width="6"/>` + C(-14, -10, 8, '#3f7a2a', 'opacity=".9"') + C(20, 14, 6, '#4a8a34')],
        flowers: ['Kwiaty', 1, 1, 'nature', () => [[-12, -10, '#e05a8a'], [10, -6, '#f3d382'], [-4, 10, '#9a6aff'], [14, 14, '#ff8a5a']].map(([x, y, c]) => C(x, y, 7, '#3f7a2a') + C(x, y, 3.5, c)).join('')],
        tallgrass: ['Wysoka trawa', 1, 1, 'nature', () => Array.from({ length: 9 }, (_, i) => `<path d="M${-24 + i * 6} 24Q${-26 + i * 6} 0 ${-20 + i * 6} ${-20 + (i % 3) * 6}" stroke="${i % 2 ? '#4a8a34' : '#3a6a26'}" stroke-width="4" fill="none"/>`).join('')],
        boulder: ['Wielki głaz', 2, 2, 'nature', (w) => `<path d="M${-w / 2 + 10} 20L${-w / 2 + 24} ${-w / 2 + 20}L10 ${-w / 2 + 8}L${w / 2 - 10} -10L${w / 2 - 18} ${w / 2 - 14}L-10 ${w / 2 - 8}Z" fill="${STONE}" stroke="#1f1c19" stroke-width="4"/><path d="M-20 -20L10 -30L30 -6" stroke="${STONEL}" stroke-width="5" fill="none"/>`],
        bridge: ['Kładka', 3, 1, 'nature', (w) => R(-w / 2 + 2, -26, w - 4, 52, '#6e4423', `stroke="${WD}" stroke-width="3"`) + Array.from({ length: 9 }, (_, i) => `<path d="M${-w / 2 + 2 + (i + 1) * (w - 4) / 10} -26V26" stroke="${WD}" stroke-width="2"/>`).join('') + `<path d="M${-w / 2 + 2} -26H${w / 2 - 2}M${-w / 2 + 2} 26H${w / 2 - 2}" stroke="#3a220e" stroke-width="5"/>`],
        // --- oświetlenie ---
        torch: ['Pochodnia ścienna', 1, 1, 'light', () => R(-4, -6, 8, 26, '#3a220e') + R(-7, -10, 14, 6, IRON) + flame(0, -18, 0.9), { light: 3.5 }],
        brazier: ['Kosz z żarem', 1, 1, 'light', () => C(0, 0, 22, '#1e1c1a', `stroke="#4a4742" stroke-width="3"`) + flame(0, 0, 1.2), { light: 4 }],
        candles: ['Świece', 1, 1, 'light', () => [[-12, 6], [2, -8], [12, 8]].map(([x, y]) => R(x - 3, y, 6, 14, '#e8dfc6') + flame(x, y - 4, 0.4)).join(''), { light: 2 }],
        chandelier: ['Żyrandol', 2, 2, 'light', (w) => C(0, 0, w / 2 - 20, 'none', `stroke="${IRON}" stroke-width="5"`) + Array.from({ length: 6 }, (_, i) => flame((Math.cos(i * Math.PI / 3) * (w / 2 - 20)).toFixed(0), (Math.sin(i * Math.PI / 3) * (w / 2 - 20)).toFixed(0), 0.5)).join('') + `<path d="M${-w / 2 + 20} 0H${w / 2 - 20}M0 ${-w / 2 + 20}V${w / 2 - 20}" stroke="${IRON}" stroke-width="3"/>`, { light: 5 }],
        lantern: ['Latarnia', 1, 1, 'light', () => R(-11, -14, 22, 28, '#ffc04a', `rx="3" stroke="#1a1a1a" stroke-width="4"`) + `<path d="M0 -14V14M-11 0H11" stroke="#1a1a1a" stroke-width="2"/>`, { light: 3.5 }],
        // --- MG ---
        trap: ['Pułapka (MG)', 1, 1, 'dm', () => R(-30, -30, 60, 60, 'rgba(160,20,20,.15)', `stroke="#c0392b" stroke-width="4" stroke-dasharray="10 6"`) + `<path d="M-14 -14L14 14M14 -14L-14 14" stroke="#c0392b" stroke-width="5"/>`, { dm: true }],
        pit: ['Zapadnia (MG)', 1, 1, 'dm', () => R(-28, -28, 56, 56, '#050302', `stroke="#c0392b" stroke-width="3" stroke-dasharray="6 6"`), { dm: true }],
        treasure: ['Skarb (MG)', 1, 1, 'dm', () => C(0, 0, 24, 'rgba(201,162,39,.2)', `stroke="#e9c46a" stroke-width="3" stroke-dasharray="6 5"`) + C(-6, 4, 8, '#e9c46a') + C(6, -4, 8, '#d4a537') + C(8, 8, 6, '#f3d382'), { dm: true }],
        note: ['Notatka MG', 1, 1, 'dm', () => R(-20, -24, 40, 48, '#d9c9a0', `stroke="#6a1515" stroke-width="3"`) + `<text y="12" text-anchor="middle" font-size="34" font-weight="700" fill="#6a1515">!</text>`, { dm: true }]
    };
    const CATS = { home: 'Karczma i dom', craft: 'Warsztat i handel', dungeon: 'Loch i krypta', magic: 'Świątynia i magia', nature: 'Natura i obóz', light: 'Oświetlenie', dm: 'Tylko MG' };
    const meta = (t) => OBJ[t]?.[5] || {};

    // ---------- dane ----------
    function level(name, cols, rows, fill = true) {
        const f = Array(cols * rows).fill('.'), w = Array(cols * rows).fill('.');
        if (fill) {
            for (let y = 1; y < rows - 1; y++) for (let x = 1; x < cols - 1; x++) f[y * cols + x] = 'w';
            for (let x = 0; x < cols; x++) { w[x] = '#'; w[(rows - 1) * cols + x] = '#'; }
            for (let y = 0; y < rows; y++) { w[y * cols] = '#'; w[y * cols + cols - 1] = '#'; }
        }
        return { id: uid(), name, cols, rows, floor: f.join(''), walls: w.join(''), objects: [], dark: 0 };
    }
    function blank(cols, rows) {
        const L = level('Parter', cols, rows);
        L.walls = L.walls.slice(0, (rows - 1) * cols + Math.floor(cols / 2)) + 'D' + L.walls.slice((rows - 1) * cols + Math.floor(cols / 2) + 1);
        return { v: 2, levels: [L] };
    }
    function migrate(it) {
        if (!it) return null;
        if (it.v === 2 && Array.isArray(it.levels)) { it.levels.forEach((L, i) => { if (!L.id) L.id = i === 0 ? 'l0' : uid(); }); return it; }
        return { v: 2, levels: [{ id: 'l0', name: 'Parter', cols: it.cols, rows: it.rows, floor: it.floor, walls: it.walls, objects: it.objects || [], dark: 0 }] };
    }
    function tavern() {
        const it = blank(30, 20), L = it.levels[0];
        const put = (lv, t, x, y, r = 0) => lv.objects.push({ id: uid(), t, x, y, r });
        put(L, 'bar', 3, 3); put(L, 'barrel', 1, 1); put(L, 'barrel', 2, 1); put(L, 'barrel', 1, 2); put(L, 'fireplace', 14, 1);
        put(L, 'table', 6, 9); put(L, 'table', 12, 9); put(L, 'table', 6, 14); put(L, 'table', 12, 14);
        [[5, 8], [8, 8], [5, 10], [8, 10], [11, 8], [14, 8], [11, 10], [14, 10]].forEach(([x, y]) => put(L, 'stool', x, y));
        put(L, 'roundtable', 20, 8); put(L, 'roundtable', 23, 12); put(L, 'chair', 19, 8); put(L, 'chair', 21, 8, 180);
        put(L, 'stairsUp', 26, 2); put(L, 'stairsDown', 26, 15); put(L, 'rug', 17, 15); put(L, 'chandelier', 9, 11); put(L, 'torch', 1, 9); put(L, 'torch', 28, 9);
        const U = level('Piętro — pokoje', 30, 20);
        for (let y = 1; y < 19; y++) U.walls = U.walls.slice(0, y * 30 + 10) + '#' + U.walls.slice(y * 30 + 11);
        for (let x = 1; x < 10; x++) { U.walls = U.walls.slice(0, 7 * 30 + x) + '#' + U.walls.slice(7 * 30 + x + 1); U.walls = U.walls.slice(0, 13 * 30 + x) + '#' + U.walls.slice(13 * 30 + x + 1); }
        [4, 10, 16].forEach(y => { U.walls = U.walls.slice(0, y * 30 + 10) + 'D' + U.walls.slice(y * 30 + 11); });
        put(U, 'bed', 2, 2); put(U, 'chest', 5, 2); put(U, 'bed', 2, 9); put(U, 'wardrobe', 6, 9); put(U, 'bed', 2, 15); put(U, 'desk', 5, 16);
        put(U, 'stairsDown', 26, 2); put(U, 'candles', 8, 3); put(U, 'lantern', 20, 10); put(U, 'rug', 15, 8);
        U.dark = 0.45;
        const B = level('Piwnica', 30, 20);
        for (let i = 0; i < B.floor.length; i++) if (B.floor[i] === 'w') B.floor = B.floor.slice(0, i) + 's' + B.floor.slice(i + 1);
        put(B, 'stairsUp', 26, 15); ['barrel', 'barrel', 'barrel', 'crate', 'crate', 'barrel'].forEach((t, i) => put(B, t, 2 + i * 2, 2));
        put(B, 'web', 1, 15); put(B, 'bones', 8, 12); put(B, 'chains', 14, 1); put(B, 'cage', 15, 1); put(B, 'torch', 1, 8); put(B, 'trap', 12, 8);
        B.dark = 0.75;
        it.levels = [B, L, U];
        it.ground = 1;
        return it;
    }
    const dims = (lv) => ({ w: lv.cols * CELL, h: lv.rows * CELL });
    const footprint = (o) => { const d = OBJ[o.t]; const w = d ? d[1] : 1, h = d ? d[2] : 1; return (o.r || 0) % 180 === 90 ? [h, w] : [w, h]; };
    // warstwy elementów: na jednym polu może stać tylko jeden element z danej warstwy
    // (dywan pod stołem — tak; krzesło na krześle — nie)
    const LAYER_AIR = new Set(['chandelier', 'torch']);
    const LAYER_FLAT = new Set(['rug', 'blood', 'pentagram', 'circle', 'web', 'flowers', 'bones', 'trapdoor', 'tallgrass']);
    const layerOf = (o) => OBJ[o.t]?.[3] === 'dm' || meta(o.t).dm ? 'dm' : LAYER_AIR.has(o.t) ? 'air' : LAYER_FLAT.has(o.t) ? 'flat' : 'solid';
    const LAYER_TOP = { air: 3, solid: 2, dm: 1, flat: 0 };
    function cellsOf(o, cols) { const [fw, fh] = footprint(o), out = []; for (let y = 0; y < fh; y++) for (let x = 0; x < fw; x++) out.push((o.y + y) * cols + o.x + x); return out; }
    // pierwszy element, z którym „o” by się nałożył (ta sama warstwa, wspólne pole)
    function overlaps(lv, o, ignoreId) {
        const L = layerOf(o), [fw, fh] = footprint(o);
        return (lv.objects || []).find(p => p !== o && p.id !== (ignoreId ?? o.id) && layerOf(p) === L && (() => {
            const [pw, ph] = footprint(p);
            return o.x < p.x + pw && p.x < o.x + fw && o.y < p.y + ph && p.y < o.y + fh;
        })()) || null;
    }

    // ---------- tekstury ----------
    const noise = (id, freq, rgb, alpha) => `<filter id="${id}" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="${freq}" numOctaves="3" seed="7"/><feColorMatrix values="0 0 0 0 ${rgb[0]} 0 0 0 0 ${rgb[1]} 0 0 0 0 ${rgb[2]} 0 0 0 ${alpha} 0"/><feComposite in2="SourceGraphic" operator="in"/></filter>`;
    const DEFS = `<defs>
        <pattern id="mf-w" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#4a2e17"/><rect width="80" height="19" fill="#533419"/><rect y="20" width="80" height="19" fill="#472b15"/><rect y="40" width="80" height="19" fill="#4f3118"/><rect y="60" width="80" height="19" fill="#432913"/><path d="M0 19.5H80M0 39.5H80M0 59.5H80M0 79.5H80" stroke="#1e1209" stroke-width="1.6"/><path d="M28 0V19M64 20V39M14 40V59M50 60V79" stroke="#1e1209" stroke-width="1.3"/><circle cx="6" cy="9" r="1.2" fill="#1e1209"/><circle cx="74" cy="49" r="1.2" fill="#1e1209"/></pattern>
        <pattern id="mf-r" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#2e2216"/><rect width="80" height="18" fill="#3a2a1a"/><rect y="20" width="62" height="18" fill="#33261a"/><rect y="40" width="80" height="18" fill="#382819"/><rect x="18" y="60" width="62" height="18" fill="#30231a"/><path d="M0 19H80M0 39H80M0 59H80M0 79H80" stroke="#120c07" stroke-width="2.5"/><path d="M62 20h18v18h-18z" fill="#0d0805"/><path d="M0 60h18v18H0z" fill="#0d0805"/></pattern>
        <pattern id="mf-s" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#1f1d1b"/><rect x="2" y="2" width="44" height="34" rx="3" fill="#3d3a36"/><rect x="48" y="2" width="30" height="34" rx="3" fill="#36332f"/><rect x="2" y="38" width="28" height="40" rx="3" fill="#393632"/><rect x="32" y="38" width="46" height="40" rx="3" fill="#423e39"/><path d="M8 10l10 6M54 52l8 10" stroke="#262320" stroke-width="1.5"/></pattern>
        <pattern id="mf-k" width="40" height="40" patternUnits="userSpaceOnUse"><rect width="40" height="40" fill="#1d1b19"/><ellipse cx="10" cy="10" rx="9" ry="8" fill="#45413b"/><ellipse cx="30" cy="11" rx="8" ry="8" fill="#3c3934"/><ellipse cx="20" cy="30" rx="9" ry="8" fill="#423e38"/><ellipse cx="0" cy="30" rx="8" ry="8" fill="#3a3732"/><ellipse cx="40" cy="30" rx="8" ry="8" fill="#3a3732"/></pattern>
        <pattern id="mf-m" width="160" height="160" patternUnits="userSpaceOnUse"><rect width="160" height="160" fill="#1c1a1f"/><rect width="80" height="80" fill="#26232a"/><rect x="80" y="80" width="80" height="80" fill="#26232a"/><path d="M10 30Q40 20 70 50M90 110Q120 100 150 130M100 20Q120 40 140 30" stroke="#4a4552" stroke-width="1.2" fill="none"/></pattern>
        <pattern id="mf-x" width="120" height="120" patternUnits="userSpaceOnUse"><rect width="120" height="120" fill="#2a2622"/><path d="M0 40L30 30L60 50L90 35L120 45M0 90L40 80L70 100L120 85" stroke="#1a1714" stroke-width="3" fill="none"/><circle cx="20" cy="70" r="8" fill="#332e29"/><circle cx="95" cy="15" r="10" fill="#332e29"/></pattern>
        <pattern id="mf-d" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#3a2a1c"/><circle cx="14" cy="18" r="3" fill="#2a1d12"/><circle cx="52" cy="10" r="2" fill="#4a3624"/><circle cx="64" cy="48" r="4" fill="#2a1d12"/><circle cx="26" cy="60" r="2.5" fill="#4a3624"/></pattern>
        <pattern id="mf-u" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#2a2216"/><ellipse cx="24" cy="26" rx="18" ry="9" fill="#1d1810" opacity=".8"/><ellipse cx="60" cy="62" rx="14" ry="7" fill="#1d1810" opacity=".8"/><ellipse cx="26" cy="24" rx="7" ry="3" fill="#4a4a3a" opacity=".5"/></pattern>
        <pattern id="mf-g" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#24361a"/><path d="M10 20l3-8 3 8M40 50l3-9 3 9M62 18l2-7 3 7M22 66l3-8 3 8M58 70l2-7 3 7" stroke="#16240e" stroke-width="2" fill="none"/><circle cx="34" cy="14" r="5" fill="#2e4520"/><circle cx="70" cy="40" r="6" fill="#2e4520"/></pattern>
        <pattern id="mf-n" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#6a5a3c"/><path d="M0 20Q20 14 40 20T80 20M0 52Q20 46 40 52T80 52" stroke="#5a4a30" stroke-width="2" fill="none"/><circle cx="14" cy="36" r="1.5" fill="#4a3c24"/><circle cx="62" cy="68" r="1.5" fill="#4a3c24"/></pattern>
        <pattern id="mf-c" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#3d0d0d"/><path d="M40 8L72 40L40 72L8 40Z" fill="none" stroke="#5e1a14" stroke-width="3"/><circle cx="40" cy="40" r="5" fill="#8a6a1a"/></pattern>
        <pattern id="mf-a" width="160" height="80" patternUnits="userSpaceOnUse"><rect width="160" height="80" fill="#0f2233"/><path d="M0 20Q20 10 40 20T80 20T120 20T160 20M0 60Q20 50 40 60T80 60T120 60T160 60" stroke="#24486a" stroke-width="3" fill="none" opacity=".8"/></pattern>
        <pattern id="mf-l" width="120" height="120" patternUnits="userSpaceOnUse"><rect width="120" height="120" fill="#5a0e02"/><path d="M0 30Q30 10 60 34T120 28M0 84Q34 64 70 90T120 80" stroke="#ff7a1a" stroke-width="7" fill="none"/><path d="M0 30Q30 10 60 34T120 28M0 84Q34 64 70 90T120 80" stroke="#ffd060" stroke-width="2" fill="none"/><circle cx="90" cy="56" r="10" fill="#2a0601"/><circle cx="24" cy="106" r="8" fill="#2a0601"/></pattern>
        <radialGradient id="mf-p"><stop offset="0" stop-color="#000"/><stop offset="1" stop-color="#0b0710"/></radialGradient>
        <pattern id="mf-wall" width="80" height="40" patternUnits="userSpaceOnUse"><rect width="80" height="40" fill="#141210"/><rect x="2" y="2" width="36" height="16" fill="#2f2c28"/><rect x="42" y="2" width="36" height="16" fill="#28251f"/><rect x="-18" y="22" width="36" height="16" fill="#28251f"/><rect x="22" y="22" width="36" height="16" fill="#33302b"/><rect x="62" y="22" width="36" height="16" fill="#2f2c28"/></pattern>
        <pattern id="mf-wwall" width="20" height="80" patternUnits="userSpaceOnUse"><rect width="20" height="80" fill="#2e1c0c"/><rect width="9" height="80" fill="#3a2410"/><path d="M19.5 0V80" stroke="#120a04" stroke-width="2"/></pattern>
        <pattern id="mf-rock" width="100" height="100" patternUnits="userSpaceOnUse"><rect width="100" height="100" fill="#1b1916"/><path d="M0 30L25 20L50 36L80 22L100 30L100 0L0 0Z" fill="#26231f"/><path d="M0 70L30 60L60 78L100 64L100 100L0 100Z" fill="#221f1b"/></pattern>
        <radialGradient id="mf-fire"><stop offset="0" stop-color="#fff3b0"/><stop offset=".4" stop-color="#ffb23a"/><stop offset=".8" stop-color="#d0461a"/><stop offset="1" stop-color="#d0461a" stop-opacity="0"/></radialGradient>
        <radialGradient id="mf-glow"><stop offset="0" stop-color="#ffb050" stop-opacity=".38"/><stop offset=".5" stop-color="#ff8a30" stop-opacity=".12"/><stop offset="1" stop-color="#ff8a30" stop-opacity="0"/></radialGradient>
        <radialGradient id="mf-light"><stop offset="0" stop-color="#000"/><stop offset=".45" stop-color="#000" stop-opacity=".9"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>
        <filter id="mf-shadow" x="-15%" y="-15%" width="130%" height="140%"><feDropShadow dx="0" dy="6" stdDeviation="5" flood-color="#000" flood-opacity=".7"/></filter>
        <filter id="mf-wallsh" x="-5%" y="-5%" width="110%" height="115%"><feDropShadow dx="0" dy="10" stdDeviation="7" flood-color="#000" flood-opacity=".85"/></filter>
    </defs>`;

    function runs(str, cols, rows, test, draw) {
        let out = '';
        for (let y = 0; y < rows; y++) {
            let x = 0;
            while (x < cols) {
                const ch = str[y * cols + x];
                if (!test(ch)) { x++; continue; }
                let e = x; while (e + 1 < cols && str[y * cols + e + 1] === ch) e++;
                out += draw(ch, x, y, e - x + 1);
                x = e + 1;
            }
        }
        return out;
    }

    function svg(lv, opts = {}) {
        const { cols, rows } = lv, { w, h } = dims(lv);
        const player = !!opts.player;
        const floors = runs(lv.floor, cols, rows, (c) => FLOORS[c], (c, x, y, n) => c === 'p'
            ? `<rect x="${x * CELL}" y="${y * CELL}" width="${n * CELL}" height="${CELL}" fill="url(#mf-p)"/>`
            : `<rect x="${x * CELL}" y="${y * CELL}" width="${n * CELL}" height="${CELL}" fill="url(#mf-${c})"/>`);
        const wallCh = (c) => (c === 'S' && player) ? '#' : c;
        const wstr = player ? lv.walls.replace(/S/g, '#') : lv.walls;
        const walls = runs(wstr, cols, rows, isSolid, (c, x, y, n) => `<rect x="${x * CELL}" y="${y * CELL}" width="${n * CELL}" height="${CELL}" fill="url(#${c === '#' ? 'mf-wall' : c === 'h' ? 'mf-wwall' : 'mf-rock'})" stroke="#050403" stroke-width="2"/><rect x="${x * CELL}" y="${y * CELL}" width="${n * CELL}" height="5" fill="rgba(255,230,190,.07)"/>`);
        let doors = '';
        for (let i = 0; i < wstr.length; i++) {
            const c = wallCh(lv.walls[i]); if (!WALLS[c] || WALLS[c][1] !== 'door') continue;
            const x = (i % cols) * CELL, y = Math.floor(i / cols) * CELL;
            const L = wstr[i - 1], Rr = wstr[i + 1];
            const horiz = (i % cols > 0 && isSolid(L)) || (i % cols < cols - 1 && isSolid(Rr));
            const g = horiz ? '' : ` transform="rotate(90 ${x + 40} ${y + 40})"`;
            if (c === 'D' || c === 'L') doors += `<g${g}><rect x="${x}" y="${y + 20}" width="80" height="40" fill="#0d0805"/><rect x="${x + 6}" y="${y + 25}" width="68" height="30" rx="2" fill="#4a2e17" stroke="#1a0f06" stroke-width="3"/><path d="M${x + 6} ${y + 33}H${x + 74}M${x + 6} ${y + 47}H${x + 74}" stroke="${IRON}" stroke-width="3"/>${c === 'L' ? `<rect x="${x + 33}" y="${y + 31}" width="14" height="18" rx="2" fill="#a8862a" stroke="#2a1a06" stroke-width="2"/><circle cx="${x + 40}" cy="${y + 38}" r="2.5" fill="#1a0f06"/>` : `<circle cx="${x + 64}" cy="${y + 40}" r="4" fill="#a8862a"/>`}</g>`;
            else if (c === 'S') doors += `<g${g}><rect x="${x}" y="${y}" width="80" height="80" fill="url(#mf-wall)"/><rect x="${x + 4}" y="${y + 24}" width="72" height="32" fill="none" stroke="#b07ad8" stroke-width="3" stroke-dasharray="8 5"/><text x="${x + 40}" y="${y + 47}" text-anchor="middle" font-size="16" fill="#cfb3ee" font-weight="700">S</text></g>`;
            else if (c === 'V') doors += `<g${g}><rect x="${x}" y="${y + 16}" width="80" height="48" fill="url(#mf-wall)" stroke="#050403" stroke-width="2"/><rect x="${x + 8}" y="${y + 32}" width="64" height="16" fill="#2a4a62" stroke="#0e1e2a" stroke-width="3"/><path d="M${x + 40} ${y + 32}V${y + 48}" stroke="#0e1e2a" stroke-width="3"/></g>`;
            else if (c === 'B') doors += `<g${g}>${[8, 22, 36, 50, 64].map(k => `<rect x="${x + k}" y="${y + 18}" width="6" height="44" fill="${IRONL}" stroke="#141418" stroke-width="1.5"/>`).join('')}<rect x="${x}" y="${y + 36}" width="80" height="6" fill="${IRON}"/></g>`;
            else if (c === 'P') doors += `<g${g}><rect x="${x}" y="${y + 20}" width="80" height="40" fill="#0d0805"/>${[10, 26, 42, 58].map(k => `<path d="M${x + k + 6} ${y + 18}V${y + 62}" stroke="${IRONL}" stroke-width="5"/>`).join('')}<path d="M${x} ${y + 30}H${x + 80}M${x} ${y + 50}H${x + 80}" stroke="${IRON}" stroke-width="4"/></g>`;
        }
        const lights = [];
        const objs = (lv.objects || []).slice().sort((a, b) => LAYER_TOP[layerOf(a)] - LAYER_TOP[layerOf(b)]).map(o => {
            const def = OBJ[o.t]; if (!def) return '';
            const mt = meta(o.t);
            if (mt.dm && player) return '';
            const [fw, fh] = footprint(o);
            const cx = (o.x + fw / 2) * CELL, cy = (o.y + fh / 2) * CELL;
            if (mt.light) lights.push({ cx, cy, r: mt.light * CELL, glow: mt.glow });
            return `<g class="mf-obj ${opts.sel === o.id ? 'sel' : ''} ${mt.dm ? 'dm' : ''}" data-oid="${o.id}" transform="translate(${cx} ${cy}) rotate(${o.r || 0})" filter="url(#mf-shadow)">${def[4](def[1] * CELL, def[2] * CELL)}${opts.sel === o.id ? `<rect x="${-def[1] * CELL / 2}" y="${-def[2] * CELL / 2}" width="${def[1] * CELL}" height="${def[2] * CELL}" fill="none" stroke="#e9c46a" stroke-width="4" stroke-dasharray="12 8"/>` : ''}</g>`;
        }).join('');
        const lavaGlow = lv.floor.includes('l') ? runs(lv.floor, cols, rows, c => c === 'l', (c, x, y, n) => `<rect x="${x * CELL - 20}" y="${y * CELL - 20}" width="${n * CELL + 40}" height="${CELL + 40}" fill="rgba(255,90,20,.12)" rx="30"/>`) : '';
        const glows = lights.map(l => `<circle cx="${l.cx}" cy="${l.cy}" r="${l.r}" fill="${l.glow ? `${l.glow}` : 'url(#mf-glow)'}" ${l.glow ? 'fill-opacity=".14"' : ''} class="mf-lightglow"/>`).join('');
        const dark = Math.max(0, Math.min(0.92, +lv.dark || 0));
        const mid = `mfd${Math.random().toString(36).slice(2, 7)}`;
        const darkness = dark ? `<mask id="${mid}"><rect width="${w}" height="${h}" fill="#fff"/>${lights.map(l => `<circle cx="${l.cx}" cy="${l.cy}" r="${l.r}" fill="url(#mf-light)" class="mf-lightmask"/>`).join('')}${lv.floor.includes('l') ? runs(lv.floor, cols, rows, c => c === 'l', (c, x, y, n) => `<rect x="${x * CELL}" y="${y * CELL}" width="${n * CELL}" height="${CELL}" fill="#000" opacity=".8"/>`) : ''}</mask><rect class="mf-dark" width="${w}" height="${h}" fill="#04020a" opacity="${dark}" mask="url(#${mid})"/>` : '';
        return `<svg class="mf-svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg">${opts.noDefs ? '' : DEFS}<rect width="${w}" height="${h}" fill="#07050a"/>${floors}${lavaGlow}<g filter="url(#mf-wallsh)">${walls}</g>${doors}${objs}<g style="mix-blend-mode:screen">${glows}</g>${darkness}</svg>`;
    }
    const preview = (t) => { const d = OBJ[t]; const w = d[1] * CELL, h = d[2] * CELL, m = Math.max(w, h); return `<svg viewBox="${-m / 2 - 4} ${-m / 2 - 4} ${m + 8} ${m + 8}" xmlns="http://www.w3.org/2000/svg">${d[4](w, h)}</svg>`; };
    const floorSw = (k) => `<svg viewBox="0 0 80 80">${k === 'p' ? '<rect width="80" height="80" fill="#050308"/>' : `<rect width="80" height="80" fill="url(#mf-${k})"/>`}</svg>`;
    const wallSw = (k) => {
        const fake = { cols: 3, rows: 1, floor: 'sss', walls: WALLS[k][1] === 'door' ? `#${k}#` : k + k + k, objects: [] };
        return `<svg viewBox="80 0 80 80">${svg(fake, { noDefs: true }).replace(/^<svg[^>]*>/, '').replace(/<\/svg>$/, '')}</svg>`;
    };

    // ---------- siatka ----------
    function gridHTML(g) {
        if (!g || !g.show) return '';
        return `<div class="mf-grid" style="--gs:${g.size}px; --gx:${g.ox || 0}px; --gy:${g.oy || 0}px; --ga:${g.alpha ?? 0.35}"></div>`;
    }

    // ---------- żetony ----------
    const SIZE = { Tiny: 1, Small: 1, Medium: 1, Large: 2, Huge: 3, Gargantuan: 4 };
    const DISP = { friendly: ['Przyjazny', '#3f8f4a'], neutral: ['Neutralny', '#a8862a'], hostile: ['Wrogi', '#a32a1e'] };
    function tokensHTML(tok, g, chars, opts = {}) {
        if (!tok || !g) return '';
        const size = g.size, ox = g.ox || 0, oy = g.oy || 0;
        const at = (p, n = 1) => `left:${ox + (p.x + n / 2) * size}px; top:${oy + (p.y + n / 2) * size}px; --ts:${size * n}px`;
        let out = '';
        (tok.others || []).forEach(t => {
            if (t.hidden && opts.player) return;
            const n = t.size || 1, col = DISP[t.disp]?.[1] || '#a32a1e';
            const pct = t.max ? Math.max(0, Math.min(100, Math.round((t.hp ?? t.max) / t.max * 100))) : 100;
            const ini = String(t.name || '?').replace(/\d+$/, '').trim().split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase();
            const num = (String(t.name).match(/(\d+)$/) || [])[1];
            out += `<div class="mf-token other k-${t.kind} d-${t.disp} ${t.hidden ? 'hid' : ''} ${(t.hp ?? 1) <= 0 ? 'down' : ''} ${opts.sel === t.id ? 'tsel' : ''}" data-tok="o:${esc(t.id)}" style="${at(t, n)}; --tc:${col}; --hp:${pct}%" title="${esc(t.name)}${t.max ? ` · ${t.hp}/${t.max} PW` : ''}"><span class="mf-tok-face">${t.kind === 'monster' ? `<i class="fa-solid fa-skull"></i>` : esc(ini)}${num ? `<b class="mf-tok-num">${num}</b>` : ''}</span><span class="mf-tok-name">${esc(t.name)}</span></div>`;
        });
        if (tok.mode !== 'split' && tok.party) {
            out += `<div class="mf-token party" data-tok="party" style="${at(tok.party)}" title="Drużyna"><span class="mf-tok-face"><i class="fa-solid fa-flag"></i><b>${chars.length}</b></span><span class="mf-tok-name">Drużyna</span></div>`;
        }
        if (tok.mode === 'split') {
            Object.entries(tok.chars || {}).forEach(([id, p]) => {
                const c = chars.find(x => x.id === id); if (!c) return;
                const ck = window.Kits ? Kits.classKey(c.class) : '';
                const color = (window.Kits && Kits.CLASS_META[ck]?.color) || '#b08a4a';
                const pct = c.hp?.max ? Math.max(0, Math.min(100, Math.round(c.hp.current / c.hp.max * 100))) : 100;
                const ini = String(c.name || '?').split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase();
                out += `<div class="mf-token ${c.hp?.current <= 0 ? 'down' : ''}" data-tok="${esc(id)}" style="${at(p)}; --tc:${color}; --hp:${pct}%" title="${esc(c.name)} · ${c.hp?.current ?? '?'}/${c.hp?.max ?? '?'} PW"><span class="mf-tok-face">${esc(ini)}${window.Portrait && (c.portrait || c.pv) ? Portrait.img(c.portrait || Portrait.url(c.id, c.pv)) : ''}</span><span class="mf-tok-name">${esc(String(c.name).split(' ')[0])}</span></div>`;
            });
        }
        out += companionsHTML(tok, chars, opts, at);
        return out;
    }
    /* Towarzysze drużyny na mapie: kto ma prowadzącego — stoi krok obok niego (idzie za nim),
       kto idzie osobno — stoi tam, gdzie go postawiono (tok.comp[id]) albo obok drużyny. */
    function companionsHTML(tok, chars, opts, at) {
        const comps = opts.comps || []; if (!comps.length) return '';
        const occ = [];
        (tok.others || []).forEach(t => occ.push({ x: t.x, y: t.y, n: t.size || 1 }));
        if (tok.mode !== 'split' && tok.party) occ.push({ x: tok.party.x, y: tok.party.y, n: 1 });
        if (tok.mode === 'split') Object.entries(tok.chars || {}).forEach(([id, p]) => { if (chars.some(c => c.id === id)) occ.push({ x: p.x, y: p.y, n: 1 }); });
        const T = opts.lv ? terrain(opts.lv, opts.lv.cols, opts.lv.rows, {}, { player: opts.player }) : null;
        const hit = (x, y, n) => occ.some(o => x < o.x + o.n && x + n > o.x && y < o.y + o.n && y + n > o.y);
        const ok = (x, y, n) => { if (x < 0 || y < 0) return false; if (T) for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) if (T.at(x + i, y + j) === 3) return false; return !hit(x, y, n); };
        const near = (p, n) => {
            const R = [[0, 1], [-1, 0], [1, 0], [-1, 1], [1, 1], [0, -1], [-1, -1], [1, -1]];
            for (let r = 1; r <= 4; r++) for (const [dx, dy] of R) { const x = p.x + dx * r, y = p.y + dy * r; if (ok(x, y, n)) return { x, y }; }
            for (let r = 1; r <= 6; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) if (Math.max(Math.abs(dx), Math.abs(dy)) === r && ok(p.x + dx, p.y + dy, n)) return { x: p.x + dx, y: p.y + dy };
            return null;
        };
        const anyParty = tok.mode === 'split' ? Object.entries(tok.chars || {}).find(([id]) => chars.some(c => c.id === id))?.[1] : tok.party;
        let out = '';
        comps.forEach(cp => {
            const n = Math.max(1, Math.min(4, cp.size || 1));
            let p = null, follow = false;
            if (cp.owner) {
                const op = tok.mode === 'split' ? tok.chars?.[cp.owner] : tok.party;
                if (op) { p = near(op, n); follow = true; }
            } else if (tok.comp && tok.comp[cp.id]) p = tok.comp[cp.id];
            else if (anyParty) p = near(anyParty, n);
            if (!p) return;
            occ.push({ x: p.x, y: p.y, n });
            const ini = String(cp.name || '?').split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
            const lead = cp.owner ? (chars.find(c => c.id === cp.owner) || {}).name : '';
            out += `<div class="mf-token comp ${follow ? 'follow' : ''}" data-tok="${follow ? `f:${esc(cp.id)}` : `n:${esc(cp.id)}`}" style="${at(p, n)}; --tc:#3f8f4a; --hp:${cp.hp && cp.hp.max ? Math.max(0, Math.min(100, Math.round(cp.hp.current / cp.hp.max * 100))) : 100}%" title="${esc(cp.name)} — towarzysz${lead ? ` (idzie za: ${esc(lead)})` : ' (idzie osobno)'}"><span class="mf-tok-face">${esc(ini)}<i class="mf-tok-comp fa-solid fa-handshake-angle"></i></span><span class="mf-tok-name">${esc(String(cp.name).split(' ')[0])}</span></div>`;
        });
        return out;
    }
    function freeCell(tok, x, y, n = 1) {
        const taken = [tok.party, ...Object.values(tok.chars || {}), ...(tok.others || [])].filter(Boolean);
        const hit = (cx, cy) => taken.some(t => { const s = t.size || 1; return cx < t.x + s && cx + n > t.x && cy < t.y + s && cy + n > t.y; });
        for (let r = 0; r < 8; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
            if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
            const c = { x: x + dx * n, y: y + dy * n };
            if (c.x >= 0 && c.y >= 0 && !hit(c.x, c.y)) return c;
        }
        return { x, y };
    }

    // ---------- teren: co blokuje ruch, co go utrudnia (wspólne: MG, gracz i serwer) ----------
    // 0 zwykły · 1 trudny teren (ruch ×2) · 2 wzniesienie/meble (wspinaczka, ruch ×2) · 3 przeszkoda (nie da się wejść)
    const TER = [['free', 'Zwykły teren'], ['hard', 'Trudny teren'], ['high', 'Wzniesienie'], ['block', 'Przeszkoda']];
    const TER_CODE = { f: 0, h: 1, e: 2, b: 3 };
    const OBJ_TER = {
        fireplace: 3, kitchen: 3, wardrobe: 3, bookshelf: 3, pillar: 3, cage: 3, maiden: 3, well: 3, statue: 3, tree: 3, deadtree: 3, tent: 3,
        tombstone: 3, font: 3, crystal: 3, cauldron: 3, brazier: 3, banner: 3,
        table: 2, roundtable: 2, bar: 2, barrel: 2, crate: 2, chest: 2, bed: 2, desk: 2, altar: 2, sarcophagus: 2, coffin: 2, rack: 2, throne: 2, cart: 2, rocks: 2, log: 2,
        chair: 1, stool: 1, bench: 1, rubble: 1, web: 1, hay: 1, bush: 1, skulls: 1, campfire: 1, lectern: 1,
        cupboard: 3, oven: 3, kegs: 3, bottles: 3, piano: 3, privy: 3, forge: 3, weaponrack: 3, armorstand: 3, dummy: 3, target: 3, loom: 3, crates: 3, fence: 3, palisade: 3,
        bridge: -1, brokenpillar: 3, obelisk: 3, idol: 3, fountain: 3, mirror: 3, boulder: 3, pond: 1, portal: 0, stocks: 3, spinwheel: 1, telescope: 1,
        doublebed: 2, bunk: 2, dresser: 3, nightstand: 2, longtable: 2, tub: 2, stall: 2, trough: 2, alchemy: 2, maptable: 2, anvil: 2, stump: 2, pew: 2,
        armchair: 1, washbasin: 1, cradle: 1, sacks: 1, woodpile: 1, plant: 1, grindstone: 1, bookpile: 1, spikes: 1, tallgrass: 1, lever: 1, portcullisLever: 1
    };
    const FLOOR_TER = { a: 1, u: 1, l: 1, p: 3 };
    const HAZARD = { l: 'Lawa — obrażenia od ognia', p: 'Otchłań — upadek', a: 'Głęboka woda — pływanie' };
    const WALL_BLOCK = '#hXLPBV';
    const objTer = (o) => (o && o.ter != null && TER_CODE[o.ter] != null) ? TER_CODE[o.ter] : (OBJ_TER[o?.t] || 0);
    const objTerAuto = (t) => OBJ_TER[t] || 0;
    /* Siatka terenu: lv — poziom wnętrza (lub null), paint — {"x,y": "b|h|e|f"} malowane przez MG na polu walki.
       opts.secret: true = sekretne przejścia są otwarte (MG). */
    function terrain(lv, cols, rows, paint, opts = {}) {
        const g = new Uint8Array(cols * rows);
        if (lv) {
            for (let y = 0; y < Math.min(rows, lv.rows); y++) for (let x = 0; x < Math.min(cols, lv.cols); x++) {
                const i = y * lv.cols + x, w = lv.walls[i] || '.';
                if (WALL_BLOCK.includes(w) || (w === 'S' && !opts.secret)) g[y * cols + x] = 3;
                else g[y * cols + x] = FLOOR_TER[lv.floor[i]] || 0;
            }
            (lv.objects || []).forEach(o => {
                if (opts.player && meta(o.t).dm) return;
                const v = objTer(o); if (!v) return;
                const [fw, fh] = footprint(o);
                for (let j = 0; j < fh; j++) for (let k = 0; k < fw; k++) {
                    const x = o.x + k, y = o.y + j;
                    if (x < 0 || y < 0 || x >= cols || y >= rows) continue;
                    const i = y * cols + x;
                    if (v < 0) { if (!WALL_BLOCK.includes(lv.walls[y * lv.cols + x] || '.')) g[i] = 0; }   // kładka nad wodą/otchłanią
                    else if (g[i] < 3) g[i] = Math.max(g[i], v);
                }
            });
        }
        Object.entries(paint || {}).forEach(([key, v]) => {
            const [x, y] = key.split(',').map(Number);
            if (x >= 0 && y >= 0 && x < cols && y < rows && TER_CODE[v] != null) g[y * cols + x] = TER_CODE[v];
        });
        return { g, cols, rows, at: (x, y) => (x < 0 || y < 0 || x >= cols || y >= rows) ? 3 : g[y * cols + x] };
    }
    const hazardAt = (lv, x, y) => lv && x >= 0 && y >= 0 && x < lv.cols && y < lv.rows ? HAZARD[lv.floor[y * lv.cols + x]] || '' : '';
    /* Najtańsza droga po siatce (Dijkstra). Wchodzisz na pole: 5 ft (ukos 5 ft albo 5/10 przy zasadzie „alt”),
       trudny teren i wspinaczka ×2, przeszkody omijasz, po ukosie nie ścinasz rogu ściany.
       Zwraca funkcję do(x,y) → { ft, path } albo null, gdy się nie da dojść. */
    function reach(T, sx, sy, n = 1, diag = 'phb', maxFt = 2000) {
        const { cols, rows } = T, alt = diag === 'alt', S2 = alt ? 2 : 1;
        const area = (x, y) => { let m = 0; for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) { const v = T.at(x + i, y + j); if (v === 3) return 3; if (v > m) m = v; } return m; };
        const N = cols * rows * S2, dist = new Float64Array(N).fill(Infinity), prev = new Int32Array(N).fill(-1);
        const id = (x, y, p) => (y * cols + x) * S2 + p;
        const heap = [];
        const push = (d, k) => { heap.push([d, k]); let i = heap.length - 1; while (i > 0) { const pa = (i - 1) >> 1; if (heap[pa][0] <= heap[i][0]) break; [heap[pa], heap[i]] = [heap[i], heap[pa]]; i = pa; } };
        const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
        const s0 = id(sx, sy, 0); dist[s0] = 0; push(0, s0);
        const D = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
        while (heap.length) {
            const [d, k] = pop(); if (d > dist[k]) continue;
            const p = k % S2, c = (k - p) / S2, x = c % cols, y = (c - x) / cols;
            for (const [dx, dy] of D) {
                const nx = x + dx, ny = y + dy;
                if (nx < 0 || ny < 0 || nx + n > cols || ny + n > rows) continue;
                const a = area(nx, ny); if (a === 3) continue;
                const dg = dx && dy;
                if (dg && (area(x + dx, y) === 3 || area(x, y + dy) === 3)) continue;
                let step = 5, np = p;
                if (dg && alt) { step = p ? 10 : 5; np = 1 - p; }
                if (a) step *= 2;
                const nd = d + step + (dg ? 0.001 : 0); if (nd > maxFt + 0.5) continue;
                const nk = id(nx, ny, np);
                if (nd < dist[nk]) { dist[nk] = nd; prev[nk] = k; push(nd, nk); }
            }
        }
        const go = (tx, ty) => {
            if (tx < 0 || ty < 0 || tx >= cols || ty >= rows) return null;
            let best = -1;
            for (let p = 0; p < S2; p++) { const k = id(tx, ty, p); if (dist[k] < Infinity && (best < 0 || dist[k] < dist[best])) best = k; }
            if (best < 0) return null;
            const path = []; for (let k = best; k >= 0; k = prev[k]) { const c = (k - k % S2) / S2; path.unshift({ x: c % cols, y: Math.floor(c / cols) }); }
            return { ft: Math.round(dist[best]), path };
        };
        go.cost = (tx, ty) => { if (tx < 0 || ty < 0 || tx >= cols || ty >= rows) return null; let m = Infinity; for (let p = 0; p < S2; p++) m = Math.min(m, dist[id(tx, ty, p)]); return m < Infinity ? Math.round(m) : null; };
        return go;
    }

    // ---------- schody między piętrami (walka i wędrówka) ----------
    function stairsAt(lv, x, y, n = 1) {
        if (!lv) return null;
        for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
            const o = objectAt(lv, x + i, y + j), sd = o && meta(o.t).stairs;
            if (sd) return { sd, o };
        }
        return null;
    }
    /* Gdzie stanąć po przejściu schodami: przy schodach prowadzących z powrotem (najbliższych),
       a gdy ich nie ma — w tym samym miejscu. taken(x, y, n) → true, gdy pole zajęte przez inny żeton. */
    function stairsLanding(it, fromIdx, o, sd, n = 1, taken = () => false, opts = {}) {
        const L = it?.levels?.[fromIdx + sd]; if (!L) return null;
        const T = terrain(L, L.cols, L.rows, opts.paint || {}, opts);
        const [ofw, ofh] = footprint(o), ocx = o.x + ofw / 2, ocy = o.y + ofh / 2;
        const cands = (L.objects || []).filter(q => meta(q.t).stairs).sort((a, b) => {
            const pa = meta(a.t).stairs === -sd ? 0 : 1, pb = meta(b.t).stairs === -sd ? 0 : 1;
            if (pa !== pb) return pa - pb;
            const [aw, ah] = footprint(a), [bw, bh] = footprint(b);
            return Math.hypot(a.x + aw / 2 - ocx, a.y + ah / 2 - ocy) - Math.hypot(b.x + bw / 2 - ocx, b.y + bh / 2 - ocy);
        });
        const free = (x, y) => { for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) if (T.at(x + i, y + j) === 3) return false; return !taken(x, y, n); };
        const base = cands[0] || { x: o.x, y: o.y, t: o.t };
        const [bw, bh] = cands[0] ? footprint(base) : [ofw, ofh];
        for (let y = base.y; y < base.y + bh; y++) for (let x = base.x; x < base.x + bw; x++) if (free(x, y)) return { levelId: L.id, levelIdx: fromIdx + sd, name: L.name, x, y };
        for (let r = 1; r < 8; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
            if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
            const x = base.x + dx, y = base.y + dy;
            if (free(x, y)) return { levelId: L.id, levelIdx: fromIdx + sd, name: L.name, x, y };
        }
        return null;
    }

    // ---------- widzenie: mgła wojny (linia wzroku, światło, ciemność) ----------
    // co zasłania widok: ściany i zamknięte przejścia (okna i kraty — nie), wysokie meble, namalowane przeszkody
    const SIGHT_WALL = '#hXLPS';
    const SIGHT_OBJ = new Set(['pillar', 'wardrobe', 'bookshelf', 'statue', 'tree', 'deadtree', 'tent', 'boulder', 'obelisk', 'cupboard', 'kegs', 'bottles', 'crates', 'palisade', 'fireplace', 'oven', 'forge', 'idol', 'armorstand', 'weaponrack', 'loom']);
    function sightGrid(lv, cols, rows, paint, opts = {}) {
        const O = new Uint8Array(cols * rows);
        if (lv) {
            for (let y = 0; y < Math.min(rows, lv.rows); y++) for (let x = 0; x < Math.min(cols, lv.cols); x++) {
                const w = lv.walls[y * lv.cols + x] || '.';
                if (SIGHT_WALL.includes(w)) O[y * cols + x] = 1;
            }
            (lv.objects || []).forEach(o => {
                if (!SIGHT_OBJ.has(o.t) || o.ter === 'f' || o.ter === 'h') return;
                if (opts.player && meta(o.t).dm) return;
                const [fw, fh] = footprint(o);
                for (let j = 0; j < fh; j++) for (let k = 0; k < fw; k++) { const x = o.x + k, y = o.y + j; if (x >= 0 && y >= 0 && x < cols && y < rows) O[y * cols + x] = 1; }
            });
        }
        Object.entries(paint || {}).forEach(([key, v]) => { if (v !== 'b') return; const [x, y] = key.split(',').map(Number); if (x >= 0 && y >= 0 && x < cols && y < rows) O[y * cols + x] = 1; });
        return O;
    }
    function lightsOf(lv) {
        return (lv?.objects || []).filter(o => meta(o.t).light).map(o => { const [fw, fh] = footprint(o); return { x: o.x + fw / 2, y: o.y + fh / 2, r: meta(o.t).light + 0.5 }; });
    }
    // czy z punktu (ax, ay) widać środek pola (tx, ty) — współrzędne w polach
    const CORNERS = [[0.5, 0.5], [0.12, 0.12], [0.88, 0.12], [0.12, 0.88], [0.88, 0.88]];
    function los(O, cols, rows, ax, ay, tx, ty) {
        for (const [ux, uy] of CORNERS) if (los1(O, cols, rows, ax, ay, tx, ty, ux, uy)) return true;
        return false;
    }
    function los1(O, cols, rows, ax, ay, tx, ty, ux, uy) {
        const bx = tx + ux, by = ty + uy, dx = bx - ax, dy = by - ay;
        const steps = Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) * 3) || 1;
        const sx0 = Math.floor(ax), sy0 = Math.floor(ay);
        for (let k = 1; k < steps; k++) {
            const x = Math.floor(ax + dx * k / steps), y = Math.floor(ay + dy * k / steps);
            if ((x === tx && y === ty) || (x === sx0 && y === sy0)) continue;
            if (x < 0 || y < 0 || x >= cols || y >= rows) return false;
            if (O[y * cols + x]) return false;
        }
        return true;
    }
    /* Widoczne pola. viewers: [{ x, y, n, dv (widzenie w ciemności, w polach), light (niesione światło, w polach) }]
       opts: { dark: 0..1 (ciemność poziomu), lights: [{x, y, r}], range } */
    function vision(O, cols, rows, viewers, opts = {}) {
        const V = new Uint8Array(cols * rows);
        const dark = (+opts.dark || 0) >= 0.45;
        let lit = null;
        if (dark) {
            lit = new Uint8Array(cols * rows);
            (opts.lights || []).forEach(L => {
                const r = Math.ceil(L.r);
                for (let y = Math.max(0, Math.floor(L.y - r)); y < Math.min(rows, Math.ceil(L.y + r)); y++) for (let x = Math.max(0, Math.floor(L.x - r)); x < Math.min(cols, Math.ceil(L.x + r)); x++) {
                    if (lit[y * cols + x]) continue;
                    if (Math.hypot(x + 0.5 - L.x, y + 0.5 - L.y) <= L.r && los(O, cols, rows, L.x, L.y, x, y)) lit[y * cols + x] = 1;
                }
            });
        }
        viewers.forEach(v => {
            const n = Math.max(1, v.n || 1), cx = v.x + n / 2, cy = v.y + n / 2;
            // nawet w ciemności widać to, co stoi tuż obok (5 ft)
            const own = Math.max(v.light || 0, dark ? (v.dv || 0) : 0, 1.5);
            for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
                const i = y * cols + x; if (V[i] === 1) continue;
                if (x >= v.x && x < v.x + n && y >= v.y && y < v.y + n) { V[i] = 1; continue; }
                const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
                if (opts.range && d > opts.range) continue;
                if (dark && !lit[i] && d > own + 0.5) continue;
                if (los(O, cols, rows, cx, cy, x, y)) V[i] = dark && !lit[i] && d > (v.light || 0) + 0.5 ? 2 : 1;
            }
        });
        return V;
    }
    // widzenie w ciemności z rasy bohatera (w polach po 5 ft)
    function darkvisionOf(race, senses) {
        if (senses && +senses.darkvision) return Math.round(+senses.darkvision / 5);
        const r = String(race || '').toLowerCase();
        if (/drow|mroczn/.test(r)) return 24;
        return /krasnolud|elf|gnom|półork|polork|ork|tiefling|diabl|dwarf|gnome|orc|aasimar|genasi|goliat|tabaxi/.test(r) ? 12 : 0;
    }
    // zapis pól (pamięć odkrytych) jako tekst: 1 bit na pole, base64
    const packBits = (A) => { let s = ''; for (let i = 0; i < A.length; i += 8) { let b = 0; for (let k = 0; k < 8; k++) if (A[i + k]) b |= 1 << k; s += String.fromCharCode(b); } return (typeof btoa === 'function') ? btoa(s) : Buffer.from(s, 'binary').toString('base64'); };
    const unpackBits = (str, len) => { const A = new Uint8Array(len); if (!str) return A; let s; try { s = (typeof atob === 'function') ? atob(str) : Buffer.from(str, 'base64').toString('binary'); } catch (e) { return A; } for (let i = 0; i < len; i++) A[i] = (s.charCodeAt(i >> 3) >> (i & 7)) & 1; return A; };
    // nakładka SVG mgły z miękkimi krawędziami: nieznane — czarne, zapamiętane — przygaszone, widziane w ciemności — półcień
    let fogN = 0;
    function fogSVG(V, seen, cols, rows, cell, ox = 0, oy = 0) {
        const runs = (test) => {
            let d = '';
            for (let y = 0; y < rows; y++) {
                let x = 0;
                while (x < cols) {
                    if (!test(y * cols + x)) { x++; continue; }
                    let e = x; while (e < cols && test(y * cols + e)) e++;
                    d += `M${ox + x * cell} ${oy + y * cell}h${(e - x) * cell}v${cell}h${-(e - x) * cell}z`;
                    x = e;
                }
            }
            return d;
        };
        const vis = runs(i => V[i] > 0), known = runs(i => V[i] > 0 || (seen && seen[i])), dv = runs(i => V[i] === 2);
        const u = `fg${(++fogN).toString(36)}${Math.random().toString(36).slice(2, 5)}`;
        const W = cols * cell, H = rows * cell, m = cell, blur = Math.max(4, cell * 0.28);
        const box = `x="${ox - m}" y="${oy - m}" width="${W + 2 * m}" height="${H + 2 * m}"`;
        return `<defs>
            <filter id="${u}f" ${box} filterUnits="userSpaceOnUse"><feGaussianBlur stdDeviation="${blur}"/></filter>
            <mask id="${u}k" maskUnits="userSpaceOnUse" ${box}><rect ${box} fill="#fff"/>${known ? `<path d="${known}" fill="#000" filter="url(#${u}f)"/>` : ''}</mask>
            <mask id="${u}v" maskUnits="userSpaceOnUse" ${box}><rect ${box} fill="#fff"/>${vis ? `<path d="${vis}" fill="#000" filter="url(#${u}f)"/>` : ''}</mask>
            <pattern id="${u}p" width="${cell / 2}" height="${cell / 2}" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="${cell / 2}" height="${cell / 2}" fill="#060504"/><rect width="${cell / 8}" height="${cell / 2}" fill="#0c0a08"/></pattern>
        </defs>
        <rect ${box} fill="url(#${u}p)" mask="url(#${u}k)"/>
        <rect ${box} fill="rgba(9,9,16,.6)" mask="url(#${u}v)"/>
        ${dv ? `<path d="${dv}" fill="rgba(4,6,14,.34)" filter="url(#${u}f)"/>` : ''}`;
    }
    function tokenPop(t) {
        return `<div class="mf-pop" data-pop="${esc(t.id)}">
            <div class="mf-pop-head"><b>${esc(t.name)}</b><button data-pop-close title="Zamknij">✕</button></div>
            ${t.max ? `<div class="mf-pop-hp"><span>PW</span><button data-pop-hp="-1">−</button><input type="number" id="mf-pop-v" value="1" min="1"><button data-pop-hp="1">+</button><b>${t.hp}/${t.max}</b></div>` : ''}
            <div class="mf-pop-row">${Object.entries(DISP).map(([k, v]) => `<button data-pop-disp="${k}" class="${t.disp === k ? 'on' : ''}" style="--c:${v[1]}">${v[0]}</button>`).join('')}</div>
            <div class="mf-pop-row"><select data-pop-size>${[1, 2, 3, 4].map(n => `<option value="${n}" ${(t.size || 1) === n ? 'selected' : ''}>${['Średni / mały', 'Duży (2×2)', 'Wielki (3×3)', 'Gigantyczny (4×4)'][n - 1]}</option>`).join('')}</select></div>
            <div class="mf-pop-row">
                <button data-pop-hide>${t.hidden ? '<i class="fa-solid fa-eye"></i> Ujawnij graczom' : '<i class="fa-solid fa-eye-slash"></i> Ukryj przed graczami'}</button>
            </div>
            <div class="mf-pop-row">
                <button data-pop-fight><i class="fa-solid fa-khanda"></i> Do walki</button>
                ${t.ref ? '<button data-pop-open><i class="fa-solid fa-book"></i> Karta</button>' : ''}
                <button data-pop-del class="danger"><i class="fa-solid fa-trash"></i></button>
            </div>
        </div>`;
    }

    // ---------- paleta budowy ----------
    function paletteHTML(ui, it, li, canUndo, canRedo) {
        const lv = it.levels[li];
        const tool = (k, ic, label) => `<button class="mf-tool ${ui.tool === k ? 'on' : ''}" data-tool="${k}" title="${label}"><i class="fa-solid ${ic}"></i><span>${label}</span></button>`;
        const selObj = ui.sel ? (lv.objects || []).find(o => o.id === ui.sel) : null;
        const cat = ui.cat || 'home';
        const q = (ui.q || '').toLowerCase();
        const list = Object.entries(OBJ).filter(([, v]) => q ? v[0].toLowerCase().includes(q) : v[3] === cat);
        return `
        <div class="mf-pal-head"><i class="fa-solid fa-dungeon"></i><div><h3>Kuźnia lochów</h3><p>${esc(lv.name)} · ${lv.cols}×${lv.rows} pól · pole = 5 stóp</p></div>
            <div class="mf-undo"><button data-undo ${canUndo ? '' : 'disabled'} title="Cofnij (Ctrl+Z)"><i class="fa-solid fa-rotate-left"></i></button><button data-redo ${canRedo ? '' : 'disabled'} title="Ponów (Ctrl+Y)"><i class="fa-solid fa-rotate-right"></i></button></div></div>
        <div class="mf-sec"><h4>Piętra</h4>
            <div class="mf-levels">${it.levels.map((L, i) => ({ L, i })).reverse().map(({ L, i }) => `<button class="${i === li ? 'on' : ''}" data-lvl="${i}">${esc(L.name)}</button>`).join('')}</div>
            <div class="mf-lvl-act"><button data-lvladd="up" title="Dodaj piętro wyżej"><i class="fa-solid fa-arrow-up"></i> Piętro</button><button data-lvladd="down" title="Dodaj poziom niżej"><i class="fa-solid fa-arrow-down"></i> Podziemia</button><button data-lvlren title="Zmień nazwę"><i class="fa-solid fa-pen"></i></button>${it.levels.length > 1 ? '<button data-lvldel class="danger" title="Usuń piętro"><i class="fa-solid fa-trash"></i></button>' : ''}</div>
        </div>
        <div class="mf-sec"><h4>Narzędzia</h4><div class="mf-tools">
            ${tool('room', 'fa-vector-square', 'Komnata')}${tool('floor', 'fa-paint-roller', 'Podłoga')}${tool('fill', 'fa-fill-drip', 'Wypełnij')}${tool('wall', 'fa-trowel-bricks', 'Ściana')}
            ${tool('select', 'fa-arrow-pointer', 'Wybierz')}${tool('erase', 'fa-eraser', 'Gumka')}${tool('token', 'fa-chess-knight', 'Postacie')}${tool('pan', 'fa-hand', 'Przesuń')}
        </div>
        ${['floor', 'wall', 'erase'].includes(ui.tool) ? `<div class="mf-brush"><span>Pędzel</span>${[1, 2, 3].map(n => `<button data-brush="${n}" class="${(ui.brush || 1) === n ? 'on' : ''}">${n}×${n}</button>`).join('')}</div>` : ''}
        ${ui.tool === 'erase' ? `<div class="mf-brush"><span>Ściera</span>${[['all', 'Co na wierzchu'], ['obj', 'Elementy'], ['wall', 'Ściany'], ['floor', 'Podłogę']].map(([k, l]) => `<button data-etarget="${k}" class="${(ui.etarget || 'all') === k ? 'on' : ''}">${l}</button>`).join('')}</div>` : ''}
        </div>
        <div class="mf-sec"><h4>Podłogi <small>warstwa niezależna od ścian</small></h4><div class="mf-swatches">${Object.entries(FLOORS).map(([k, v]) => `<button class="mf-sw ${ui.floor === k ? 'on' : ''}" data-floor="${k}" title="${v}">${floorSw(k)}<span>${v}</span></button>`).join('')}</div></div>
        <div class="mf-sec"><h4>Ściany i przejścia</h4><div class="mf-swatches">${Object.entries(WALLS).map(([k, v]) => `<button class="mf-sw ${ui.wall === k ? 'on' : ''}" data-wall="${k}" title="${v[0]}">${wallSw(k)}<span>${v[0]}</span></button>`).join('')}</div></div>
        <div class="mf-sec"><h4>Gotowe pomieszczenia <small>kliknij na mapie — ściany, drzwi i wyposażenie</small></h4>
            <div class="mf-rooms">${Object.entries(ROOMS).map(([k, r]) => `<button class="mf-room ${ui.tool === 'prefab' && ui.prefab === k ? 'on' : ''}" data-prefab="${k}" title="${esc(r[0])} — ${r[2]}×${r[3]} pól wnętrza"><i class="fa-solid ${r[1]}"></i><span>${esc(r[0])}</span><small>${r[2]}×${r[3]}</small></button>`).join('')}</div></div>
        <div class="mf-sec"><h4>Wyposażenie</h4>
            <input class="mf-osearch" placeholder="Szukaj elementu…" value="${esc(ui.q || '')}">
            ${q ? '' : `<div class="mf-cats">${Object.entries(CATS).map(([k, v]) => `<button data-ocat="${k}" class="${cat === k ? 'on' : ''}">${v}</button>`).join('')}</div>`}
            <div class="mf-objs">${list.map(([k, v]) => `<button class="mf-ob ${ui.tool === 'object' && ui.obj === k ? 'on' : ''}" data-obj="${k}" title="${v[0]} (${v[1]}×${v[2]})">${preview(k)}<span>${v[0]}</span></button>`).join('') || '<p class="ai-muted">Nic nie znaleziono</p>'}</div>
            <div class="mf-rot"><button data-rot><i class="fa-solid fa-rotate-right"></i> Obróć (R)</button><span>${ui.rot || 0}°</span></div></div>
        ${selObj ? `<div class="mf-sec mf-selbox"><h4>Zaznaczone: ${esc(OBJ[selObj.t][0])}</h4><div class="mf-rot"><button data-srot><i class="fa-solid fa-rotate-right"></i> Obróć</button><button data-sdup><i class="fa-solid fa-clone"></i> Powiel</button><button data-sdel class="danger"><i class="fa-solid fa-trash"></i></button></div>
            <div class="mf-ter"><span>Ruch w walce</span>${[['', `Auto · ${TER[Math.max(0, objTerAuto(selObj.t))][1]}`], ['b', 'Przeszkoda'], ['e', 'Wzniesienie'], ['h', 'Trudny'], ['f', 'Bez utrudnień']].map(([k, l]) => `<button data-ster="${k}" class="${(selObj.ter || '') === k ? 'on' : ''}">${l}</button>`).join('')}</div>
            <p class="ai-muted">Przeciągnij, aby przesunąć.</p></div>` : ''}
        <div class="mf-sec"><h4>Mrok na tym piętrze <small>światło dają pochodnie, ogień, kryształy</small></h4>
            <label class="mf-range"><span>Ciemność</span><input type="range" id="mf-dark" min="0" max="90" value="${Math.round((lv.dark || 0) * 100)}"><b>${Math.round((lv.dark || 0) * 100)}%</b></label></div>
        <div class="mf-sec"><h4>Rozmiar piętra</h4><div class="mf-size"><label>Szer.<input type="number" id="mf-cols" min="6" max="60" value="${lv.cols}"></label><label>Wys.<input type="number" id="mf-rows" min="6" max="60" value="${lv.rows}"></label><button data-resize>Zmień</button></div></div>
        <div class="ai-actions"><button class="btn-secondary btn-small" data-clear><i class="fa-solid fa-broom"></i> Wyczyść piętro</button><button class="btn-secondary btn-small" data-tpl><i class="fa-solid fa-beer-mug-empty"></i> Wzór karczmy</button><button class="btn-primary btn-small" data-done><i class="fa-solid fa-check"></i> Gotowe</button></div>
        <p class="mf-hint">Lewy — maluj / stawiaj · prawy lub „Przesuń” — widok · kółko — zoom · R — obrót · Del — usuń · Ctrl+Z — cofnij</p>`;
    }


    // ---------- gotowe pomieszczenia (ściany, podłoga, drzwi i wyposażenie) ----------
    // [nazwa, ikona, szer., wys. (wnętrze bez ścian), podłoga, ściana, [[element, x, y, obrót]], drzwi: 'S' dół / 'N' góra / 'W' / 'E', ciemność]
    const ROOMS = {
        tavernhall: ['Sala karczmy', 'fa-beer-mug-empty', 10, 8, 'w', 'h', [['bar', 1, 0], ['kegs', 6, 0], ['fireplace', 8, 0], ['roundtable', 1, 3], ['stool', 0, 3], ['stool', 2, 3], ['roundtable', 4, 3], ['stool', 3, 3], ['stool', 5, 3], ['roundtable', 8, 3], ['stool', 7, 3], ['stool', 9, 3], ['longtable', 3, 6], ['bench', 3, 5], ['bench', 5, 5], ['torch', 0, 6], ['torch', 9, 6]], 'S'],
        guestroom: ['Pokój gościnny', 'fa-bed', 4, 4, 'w', 'h', [['bed', 0, 0], ['nightstand', 1, 0], ['chest', 3, 0], ['washbasin', 0, 3], ['stool', 3, 3], ['candles', 2, 0]], 'S'],
        bedroom: ['Sypialnia', 'fa-bed', 6, 5, 'w', '#', [['doublebed', 0, 0], ['nightstand', 2, 0], ['dresser', 4, 0], ['rug', 2, 2], ['armchair', 0, 4], ['chest', 5, 4], ['candles', 3, 0]], 'S'],
        house: ['Chata', 'fa-house', 6, 5, 'w', 'h', [['bed', 0, 0], ['chest', 1, 0], ['kitchen', 5, 0], ['table', 2, 2], ['stool', 2, 3], ['stool', 3, 3], ['barrel', 0, 4], ['woodpile', 5, 4], ['candles', 4, 2]], 'S'],
        kitchen: ['Kuchnia', 'fa-utensils', 7, 5, 'k', '#', [['oven', 0, 0], ['kitchen', 3, 0], ['cupboard', 5, 0], ['table', 2, 2], ['stool', 1, 2], ['stool', 4, 2], ['sacks', 0, 4], ['woodpile', 6, 2], ['barrel', 6, 4]], 'S'],
        storage: ['Spiżarnia / magazyn', 'fa-boxes-stacked', 6, 5, 'd', '#', [['kegs', 0, 0], ['bottles', 2, 0], ['crates', 4, 0], ['sacks', 0, 4], ['sacks', 1, 4], ['crate', 3, 4], ['barrel', 5, 4], ['lantern', 3, 2]], 'S'],
        shop: ['Sklep', 'fa-store', 7, 5, 'w', 'h', [['bottles', 0, 0], ['cupboard', 3, 0], ['crates', 5, 0], ['bar', 1, 2], ['chest', 6, 4], ['sacks', 0, 4], ['lantern', 3, 4], ['plant', 6, 2]], 'S'],
        smithy: ['Kuźnia', 'fa-hammer', 7, 6, 'k', '#', [['forge', 0, 0], ['anvil', 3, 1], ['grindstone', 5, 0], ['woodpile', 6, 2], ['trough', 2, 4], ['armorstand', 0, 5], ['weaponrack', 5, 5]], 'S'],
        library: ['Biblioteka', 'fa-book', 7, 6, 'w', '#', [['bookshelf', 0, 0], ['bookshelf', 2, 0], ['bookshelf', 4, 0], ['lectern', 6, 0], ['desk', 1, 3], ['chair', 1, 4], ['armchair', 4, 5], ['bookpile', 6, 5], ['candles', 0, 5], ['rug', 3, 2]], 'S'],
        lab: ['Pracownia maga', 'fa-flask', 7, 6, 'm', '#', [['alchemy', 0, 0], ['bookshelf', 3, 0], ['cauldron', 6, 0], ['circle', 3, 3], ['crystal', 0, 5], ['lectern', 6, 5], ['candles', 0, 3], ['mirror', 6, 3]], 'S'],
        chapel: ['Kaplica', 'fa-place-of-worship', 7, 8, 's', '#', [['banner', 0, 0], ['candles', 1, 0], ['altar', 2, 0], ['candles', 4, 0], ['idol', 5, 0], ['banner', 6, 0], ['font', 3, 2], ['pew', 0, 4], ['pew', 4, 4], ['pew', 0, 6], ['pew', 4, 6]], 'S'],
        throne: ['Sala tronowa', 'fa-crown', 9, 9, 'm', '#', [['banner', 2, 0], ['throne', 4, 0], ['banner', 6, 0], ['brazier', 1, 1], ['brazier', 7, 1], ['rug', 3, 2], ['rug', 3, 4], ['pillar', 1, 3], ['pillar', 7, 3], ['pillar', 1, 6], ['pillar', 7, 6]], 'S'],
        barracks: ['Koszary', 'fa-shield-halved', 8, 6, 's', '#', [['bunk', 0, 0], ['chest', 1, 0], ['bunk', 2, 0], ['chest', 3, 0], ['bunk', 4, 0], ['chest', 5, 0], ['bunk', 6, 0], ['chest', 7, 0], ['table', 3, 3], ['weaponrack', 0, 5], ['armorstand', 3, 5], ['dummy', 6, 4], ['torch', 7, 2]], 'S'],
        crypt: ['Krypta', 'fa-skull', 7, 7, 's', 'X', [['statue', 3, 0], ['sarcophagus', 1, 1], ['sarcophagus', 5, 1], ['candles', 3, 3], ['sarcophagus', 1, 4], ['sarcophagus', 5, 4], ['bones', 0, 6], ['web', 5, 5]], 'S', 0.5],
        cell: ['Cela więzienna', 'fa-lock', 3, 3, 's', '#', [['bunk', 0, 0], ['chains', 2, 0], ['hay', 2, 2], ['bones', 1, 2]], 'S', 0.4, 'B'],
        stable: ['Stajnia', 'fa-horse', 8, 5, 'd', 'h', [['trough', 0, 0], ['trough', 3, 0], ['trough', 6, 0], ['fence', 0, 2], ['fence', 6, 2], ['hay', 0, 4], ['hay', 1, 4], ['hay', 7, 4], ['woodpile', 4, 4]], 'S'],
        guard: ['Wartownia', 'fa-tower-observation', 5, 4, 's', '#', [['table', 1, 1], ['stool', 1, 0], ['stool', 2, 2], ['weaponrack', 3, 3], ['brazier', 4, 0], ['chest', 0, 3]], 'S']
    };
    function stampRoom(lv, key, cx, cy) {
        const R0 = ROOMS[key]; if (!R0) return null;
        const [, , iw, ih, floor, wall, objs, door, dark, doorCh] = R0;
        const W = iw + 2, Hh = ih + 2;
        const x0 = Math.max(0, Math.min(lv.cols - W, cx - Math.floor(W / 2))), y0 = Math.max(0, Math.min(lv.rows - Hh, cy - Math.floor(Hh / 2)));
        if (W > lv.cols || Hh > lv.rows) return null;
        let f = lv.floor, w = lv.walls;
        for (let y = 0; y < Hh; y++) for (let x = 0; x < W; x++) {
            const i = (y0 + y) * lv.cols + x0 + x, edge = x === 0 || y === 0 || x === W - 1 || y === Hh - 1;
            f = f.slice(0, i) + floor + f.slice(i + 1);
            const corner = (x === 0 || x === W - 1) && (y === 0 || y === Hh - 1);
            // istniejące drzwi na krawędzi zostają (łączenie pomieszczeń)
            const keep = edge && !corner && WALLS[w[i]] && WALLS[w[i]][1] === 'door';
            w = w.slice(0, i) + (edge ? (keep ? w[i] : wall) : '.') + w.slice(i + 1);
        }
        const dpos = door === 'N' ? [x0 + Math.floor(W / 2), y0] : door === 'W' ? [x0, y0 + Math.floor(Hh / 2)] : door === 'E' ? [x0 + W - 1, y0 + Math.floor(Hh / 2)] : [x0 + Math.floor(W / 2), y0 + Hh - 1];
        const di = dpos[1] * lv.cols + dpos[0]; w = w.slice(0, di) + (doorCh || 'D') + w.slice(di + 1);
        lv.floor = f; lv.walls = w;
        // nowe pomieszczenie zastępuje wszystko, co stało w jego obrysie (także elementy wystające poza niego)
        lv.objects = (lv.objects || []).filter(o => { const [fw, fh] = footprint(o); return !(o.x < x0 + W && x0 < o.x + fw && o.y < y0 + Hh && y0 < o.y + fh); });
        objs.forEach(([t, x, y, r]) => { if (OBJ[t]) lv.objects.push({ id: uid(), t, x: x0 + 1 + x, y: y0 + 1 + y, r: r || 0 }); });
        if (dark && !(+lv.dark)) lv.dark = dark;
        return { x: x0, y: y0, w: W, h: Hh };
    }

    // ---------- operacje ----------
    const setAt = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);
    function brushCells(cx, cy, n) { const out = [], o = Math.floor((n - 1) / 2); for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) out.push([cx - o + x, cy - o + y]); return out; }
    function paint(lv, ui, cx, cy, from) {
        const { cols, rows } = lv;
        const inb = (x, y) => x >= 0 && y >= 0 && x < cols && y < rows;
        if (!inb(cx, cy)) return false;
        const n = ui.brush || 1;
        switch (ui.tool) {
            case 'floor': brushCells(cx, cy, n).forEach(([x, y]) => { if (inb(x, y)) lv.floor = setAt(lv.floor, y * cols + x, ui.floor || 'w'); }); return true;
            case 'wall': brushCells(cx, cy, n).forEach(([x, y]) => { if (inb(x, y)) lv.walls = setAt(lv.walls, y * cols + x, ui.wall || '#'); }); return true;
            case 'fill': {
                const start = lv.floor[cy * cols + cx], to = ui.floor || 'w';
                if (start === to) return false;
                const stack = [[cx, cy]], seen = new Set();
                let arr = lv.floor.split('');
                while (stack.length) {
                    const [x, y] = stack.pop(); const i = y * cols + x;
                    if (!inb(x, y) || seen.has(i) || arr[i] !== start || isSolid(lv.walls[i])) continue;
                    seen.add(i); arr[i] = to;
                    stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
                }
                lv.floor = arr.join(''); return true;
            }
            case 'erase': {
                // „Co na wierzchu”: zdejmuje tylko najwyższą warstwę — element, a gdy go nie ma, ścianę, a dopiero potem podłogę.
                // Warstwę wybiera pierwsze pole pociągnięcia, a pola spod zdjętego elementu są w tym pociągnięciu nietykalne
                // (gumka na krześle nie zetrze podłogi pod nim ani dywanu obok).
                const t = ui.etarget || 'all';
                const E = ui._erase || (ui._erase = { layer: null, done: {} });
                brushCells(cx, cy, n).forEach(([x, y]) => {
                    if (!inb(x, y)) return;
                    const i = y * cols + x;
                    if (E.done[i]) return;
                    let layer = t;
                    if (t === 'all') {
                        if (!E.layer) E.layer = objectAt(lv, x, y) ? 'obj' : lv.walls[i] !== '.' ? 'wall' : lv.floor[i] !== '.' ? 'floor' : null;
                        if (!E.layer) return;
                        layer = E.layer;
                    }
                    if (layer === 'obj') { const hit = objectAt(lv, x, y); if (hit) { lv.objects = lv.objects.filter(o => o !== hit); cellsOf(hit, cols).forEach(j => { E.done[j] = 1; }); } return; }
                    if (layer === 'wall') { lv.walls = setAt(lv.walls, i, '.'); return; }
                    if (layer === 'floor') lv.floor = setAt(lv.floor, i, '.');
                });
                return true;
            }
            case 'room': {
                if (!from) return false;
                const x0 = Math.min(from.x, cx), x1 = Math.max(from.x, cx), y0 = Math.min(from.y, cy), y1 = Math.max(from.y, cy);
                for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
                    const j = y * cols + x, edge = x === x0 || x === x1 || y === y0 || y === y1;
                    if (edge) { if (!WALLS[lv.walls[j]] || isSolid(lv.walls[j]) || lv.walls[j] === '.') lv.walls = setAt(lv.walls, j, isSolid(ui.wall) ? ui.wall : '#'); }
                    else { lv.floor = setAt(lv.floor, j, ui.floor || 'w'); if (isSolid(lv.walls[j])) lv.walls = setAt(lv.walls, j, '.'); }
                }
                return true;
            }
        }
        return false;
    }
    // element na wierzchu pola: żyrandol > mebel > znacznik MG > dywan (przy remisie — później postawiony)
    function objectAt(lv, cx, cy) {
        const list = lv.objects || [];
        let best = null, bs = -1;
        for (let k = 0; k < list.length; k++) {
            const o = list[k], [fw, fh] = footprint(o);
            if (!(cx >= o.x && cx < o.x + fw && cy >= o.y && cy < o.y + fh)) continue;
            const s = LAYER_TOP[layerOf(o)];
            if (s >= bs) { best = o; bs = s; }
        }
        return best;
    }
    function resize(lv, cols, rows) {
        cols = Math.max(6, Math.min(60, cols)); rows = Math.max(6, Math.min(60, rows));
        let f = '', w = '';
        for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
            const inOld = x < lv.cols && y < lv.rows, i = y * lv.cols + x;
            f += inOld ? lv.floor[i] : '.'; w += inOld ? lv.walls[i] : '.';
        }
        lv.floor = f; lv.walls = w; lv.cols = cols; lv.rows = rows;
        lv.objects = (lv.objects || []).filter(o => o.x < cols && o.y < rows);
    }

    return { CELL, FLOORS, WALLS, OBJ, CATS, SIZE, DISP, level, blank, tavern, migrate, dims, svg, gridHTML, tokensHTML, tokenPop, freeCell, paletteHTML, paint, objectAt, footprint, overlaps, layerOf, resize, meta, uid, TER, OBJ_TER, objTer, terrain, reach, hazardAt, ROOMS, stampRoom, stairsAt, stairsLanding, sightGrid, lightsOf, vision, darkvisionOf, packBits, unpackBits, fogSVG };
})();

window.MapForge = MapForge;
