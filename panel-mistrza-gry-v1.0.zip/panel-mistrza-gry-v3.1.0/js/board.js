/* ============================================
   Tablica karczmy na Pulpicie: kredą wypisane „dziś podajemy”, cennik
   wg Podręcznika Gracza (posiłki, napitki, nocleg) i plotka dnia na przygodę.
   Losowane raz na dzień (zapamiętane), „Nowe menu” losuje od nowa.
   ============================================ */
const TavernBoard = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    // ceny jak w PHB (Jedzenie, napoje i nocleg); mm/ms/mz = miedziaki/srebrniki/złote
    const DISHES = [
        ['Gulasz z królika z kaszą', 'skromny posiłek', '3 ms'], ['Pieczony dzik w miodzie', 'wystawny posiłek', '8 ms'], ['Chleb z serem i cebulą', 'ubogi posiłek', '6 mm'],
        ['Polewka grzybowa z chlebem', 'ubogi posiłek', '6 mm'], ['Pstrąg z rożna z ziołami', 'wygodny posiłek', '5 ms'], ['Kiełbasa krasnoludzka z kapustą', 'skromny posiłek', '3 ms'],
        ['Pasztet z dziczyzny', 'wygodny posiłek', '5 ms'], ['Pieczona kaczka ze śliwkami', 'wystawny posiłek', '8 ms'], ['Zupa z soczewicy i boczku', 'ubogi posiłek', '6 mm'],
        ['Pieróg z baraniną', 'skromny posiłek', '3 ms'], ['Udziec sarni w sosie z jałowca', 'arystokratyczny posiłek', '2 mz'], ['Owsianka z jabłkiem', 'nędzny posiłek', '3 mm'],
        ['Placki ziemniaczane ze śmietaną', 'skromny posiłek', '3 ms'], ['Pieczeń wołowa z chrzanem', 'wygodny posiłek', '5 ms'], ['Kawał mięsa z rożna', 'kawał mięsa', '3 ms'],
        ['Bochenek chleba', 'chleb', '2 mm'], ['Gomółka sera', 'ser', '1 ms']
    ];
    const DRINKS = [
        ['Ale z beczki', 'kufel', '4 mm'], ['Ale z beczki', 'dzban (galon)', '2 ms'], ['Wino stołowe', 'dzban', '2 ms'], ['Wino elfie, rocznik', 'butelka', '10 mz'],
        ['Miód pitny', 'kufel', '4 mm'], ['Krasnoludzki porter', 'kufel', '4 mm'], ['Grzaniec z korzeniami', 'kufel', '4 mm'], ['Cydr jabłkowy', 'dzban', '2 ms'],
        ['Niziołcza nalewka', 'kieliszek', '1 ms'], ['Smocza gorzałka („na odwagę”)', 'kieliszek', '1 ms']
    ];
    const ROOMS = [['Siennik we wspólnej izbie', 'nędzny', '7 mm'], ['Łóżko w izbie wspólnej', 'ubogi', '1 ms'], ['Pokój dla dwojga', 'skromny', '5 ms'], ['Pokój z kominkiem', 'wygodny', '8 ms'], ['Apartament z widokiem', 'wystawny', '2 mz']];
    const RUMORS = [
        'Młynarz zza rzeki przysięga, że coś wyje nocą przy starym kurhanie — i że to nie wilk.',
        'Kupiecka karawana z południa spóźnia się już trzeci dzień. Gildia płaci za wieści.',
        'W lochach pod kaplicą ktoś widział światło, choć wejście zamurowano przed laty.',
        'Kowal szuka śmiałków, którzy przyniosą mu rudę z opuszczonej kopalni na przełęczy.',
        'Mówią, że stary bard przy kominku zna drogę do zatopionej wieży — za kufel opowie.',
        'Na rozstajach znaleziono wóz bez koni, pełny złota. Nikt nie odważył się go ruszyć.',
        'Córka sołtysa zniknęła w Szepczącym Lesie. Ojciec obiecuje nagrodę w srebrze.',
        'Nocą nad bagnami tańczą błędne ognie. Każdy, kto za nimi poszedł, wrócił odmieniony… albo wcale.',
        'Straż miejska wypatruje złodzieja w masce lisa — okradł już trzech radnych.',
        'Druid z gór wypytuje o „kamień, który śpiewa”. Płaci ziołami, które leczą każdą gorączkę.',
        'W ruinach zamku ktoś rozpalił ognisko. Pasterze widzieli sztandar z czarnym krukiem.',
        'Karczmarz ma w piwnicy beczkę, której nikt nie potrafi otworzyć. Podobno coś w niej puka.',
        'Krasnoludzki kupiec sprzedaje mapę „do skarbu smoka”. Trzecią w tym miesiącu.',
        'Most na trakcie runął w nocy. Przewoźnik żąda podwójnej ceny i podejrzanie się uśmiecha.',
        'Zakon paladynów szuka ochotników do eskorty relikwii przez Pustkowia Grozy.',
        'Ktoś rozwiesza na tablicy ogłoszeń listy gończe z twarzami… gości tej karczmy.',
        'W studni na rynku słychać szepty. Kapłanka twierdzi, że to modlitwa w zapomnianym języku.',
        'Wiedźma z mokradeł kupuje włosy, paznokcie i — ostatnio — imiona.',
        'Goblińskie bębny niosły się nocą od wzgórz. Pierwszy raz od dziesięciu lat.',
        'Nieznajomy w szarym płaszczu płaci złotem za każdą wiadomość o pierścieniu z pieczęcią węża.'
    ];
    const pick = (a, n) => { const c = a.slice(), out = []; while (out.length < n && c.length) out.push(c.splice(Math.floor(Math.random() * c.length), 1)[0]); return out; };
    const today = () => new Date().toISOString().slice(0, 10);
    const KEY = 'dnd5e_ui_board';
    function load() { try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); if (s && (s.d === today() || s.own)) return s; } catch (e) {} return roll(); }
    function roll() {
        const s = { d: today(), dishes: pick(DISHES, 3), drinks: pick(DRINKS, 3), room: pick(ROOMS, 2), rumor: pick(RUMORS, 1)[0] };
        try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
        return s;
    }
    let S = null;
    // łupek z kredą — ten sam u MG (Pulpit) i u graczy (pokaz + zakładka Tablica ogłoszeń)
    function slateHTML(B, cls = '') {
        const row = ([n, k, p]) => `<li><span>${esc(n)}<small>${esc(k)}</small></span><i></i><b>${esc(p)}</b></li>`;
        const L = (a) => (a || []).map(row).join('');
        const sec = (t, a) => (a || []).length ? `<h4>${t}</h4><ul>${L(a)}</ul>` : '';
        return `<div class="tb-slate ${cls}">
            <div class="tb-col">${sec('Dziś podajemy', B.dishes) || '<h4>Dziś podajemy</h4><p class="tb-empty">— kuchnia zamknięta —</p>'}</div>
            <div class="tb-col">${sec('Do picia', B.drinks)}${sec('Nocleg', B.room)}</div>
            <div class="tb-col tb-rumor">${B.rumor ? `<h4>Plotka dnia</h4><p>„${esc(B.rumor)}”</p>` : ''}<small class="tb-note">1 mz = 10 ms = 100 mm</small></div>
        </div>`;
    }
    function render() {
        const el = document.getElementById('dash-board-content'); if (!el) return;
        S = S || load();
        el.innerHTML = slateHTML(S);
    }
    function text() {
        S = S || load();
        const l = (a) => a.map(([n, k, p]) => `• ${n} (${k}) — ${p}`).join('\n');
        return `DZIŚ PODAJEMY\n${l(S.dishes)}\n\nDO PICIA\n${l(S.drinks)}\n\nNOCLEG\n${l(S.room)}\n\nPLOTKA DNIA\n„${S.rumor}”`;
    }
    // ręczna edycja tablicy przed pokazaniem graczom (zapamiętana na dziś, „Nowe menu” losuje od nowa)
    const SECS = [['dishes', 'Dziś podajemy', 'np. Gulasz z dzika', 'skromny posiłek', '3 ms'], ['drinks', 'Do picia', 'np. Ale z beczki', 'kufel', '4 mm'], ['room', 'Nocleg', 'np. Pokój z kominkiem', 'wygodny', '8 ms']];
    function rowHTML(r = ['', '', ''], ph) {
        return `<div class="tbe-row"><input type="text" class="tbe-n" maxlength="80" value="${esc(r[0])}" placeholder="${esc(ph[0])}" aria-label="Nazwa"><input type="text" class="tbe-k" maxlength="60" value="${esc(r[1])}" placeholder="${esc(ph[1])}" aria-label="Opis"><input type="text" class="tbe-p" maxlength="20" value="${esc(r[2])}" placeholder="${esc(ph[2])}" aria-label="Cena"><button type="button" class="tbe-del" title="Usuń pozycję" aria-label="Usuń pozycję"><i class="fa-solid fa-xmark"></i></button></div>`;
    }
    function edit(thenSend) {
        S = S || load();
        const body = `<div class="tbe">
            <p class="modal-hint">Wpisz własne dania, ceny i plotkę albo popraw wylosowane. Ceny w Podręczniku Gracza: 1 mz = 10 ms = 100 mm.</p>
            ${SECS.map(([k, t, ...ph]) => `<div class="tbe-sec" data-sec="${k}"><h4>${t}</h4><div class="tbe-rows">${(S[k] || []).map(r => rowHTML(r, ph)).join('')}</div>
                <div class="tbe-acts"><button type="button" class="btn-secondary btn-small" data-tbe-add="${k}"><i class="fa-solid fa-plus"></i> Dodaj</button><button type="button" class="btn-secondary btn-small" data-tbe-roll="${k}" title="Wylosuj tę część od nowa"><i class="fa-solid fa-dice"></i> Losuj</button></div></div>`).join('')}
            <div class="tbe-sec"><h4>Plotka dnia</h4><textarea id="tbe-rumor" rows="3" maxlength="500" placeholder="Co dziś szepczą przy kominku?">${esc(S.rumor)}</textarea>
                <div class="tbe-acts"><button type="button" class="btn-secondary btn-small" data-tbe-roll="rumor"><i class="fa-solid fa-dice"></i> Inna plotka</button></div></div>
        </div>`;
        App.showModal('Tablica karczmy — edycja', body, `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-secondary" id="tbe-save"><i class="fa-solid fa-floppy-disk"></i> Zapisz</button><button class="btn-primary" id="tbe-send"><i class="fa-solid fa-eye"></i> Zapisz i pokaż graczom</button>`);
        document.getElementById('modal')?.classList.add('modal-wide');
        const root = document.querySelector('#modal-body .tbe');
        const ph = (k) => SECS.find(x => x[0] === k).slice(2);
        root.addEventListener('click', (e) => {
            const del = e.target.closest('.tbe-del'); if (del) { del.closest('.tbe-row').remove(); return; }
            const add = e.target.closest('[data-tbe-add]');
            if (add) { const k = add.dataset.tbeAdd, box = root.querySelector(`[data-sec="${k}"] .tbe-rows`); box.insertAdjacentHTML('beforeend', rowHTML(undefined, ph(k))); box.lastElementChild.querySelector('input').focus(); return; }
            const rl = e.target.closest('[data-tbe-roll]');
            if (rl) {
                const k = rl.dataset.tbeRoll;
                if (k === 'rumor') { root.querySelector('#tbe-rumor').value = pick(RUMORS.filter(x => x !== root.querySelector('#tbe-rumor').value), 1)[0]; return; }
                const src = { dishes: [DISHES, 3], drinks: [DRINKS, 3], room: [ROOMS, 2] }[k];
                root.querySelector(`[data-sec="${k}"] .tbe-rows`).innerHTML = pick(src[0], src[1]).map(r => rowHTML(r, ph(k))).join('');
            }
        });
        const read = () => {
            const out = { d: today(), own: true };
            SECS.forEach(([k]) => { out[k] = [...root.querySelectorAll(`[data-sec="${k}"] .tbe-row`)].map(r => [r.querySelector('.tbe-n').value.trim(), r.querySelector('.tbe-k').value.trim(), r.querySelector('.tbe-p').value.trim()]).filter(r => r[0]); });
            out.rumor = root.querySelector('#tbe-rumor').value.trim();
            return out;
        };
        const save = () => { S = read(); try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} render(); App.closeModal(); };
        document.getElementById('tbe-save').onclick = () => { save(); App.showToast('Tablica zapisana', 'success'); };
        document.getElementById('tbe-send').onclick = () => { save(); send(); };
        if (thenSend) document.getElementById('tbe-send').focus();
    }
    async function send() {
        S = S || load();
        try {
            const r = await fetch('api/online/live', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Panel': '1' }, body: JSON.stringify({ kind: 'tablica', title: 'Tablica karczmy', text: text(), board: { dishes: S.dishes, drinks: S.drinks, room: S.room, rumor: S.rumor } }) });
            if (!r.ok) throw new Error();
            App.showToast('Tablica pokazana graczom', 'success');
        } catch (er) { App.showToast('Nie udało się pokazać graczom — czy serwer gry działa?', 'warning'); }
    }
    function bind() {
        document.getElementById('dash-board')?.addEventListener('click', async (e) => {
            const b = e.target.closest('[data-board]'); if (!b) return;
            S = S || load();
            if (b.dataset.board === 'new') { S = roll(); render(); return; }
            if (b.dataset.board === 'edit') { edit(); return; }
            if (b.dataset.board === 'send') send();
        });
    }
    return { render, bind, slateHTML, edit, send };
})();
window.TavernBoard = TavernBoard;
document.addEventListener('DOMContentLoaded', () => setTimeout(() => { try { TavernBoard.bind(); TavernBoard.render(); } catch (e) {} }, 300));
