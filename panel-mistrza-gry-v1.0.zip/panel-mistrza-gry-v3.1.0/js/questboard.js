/* ============================================
   D&D 5e DM Panel — Tablica zleceń (Zadania)
   Kartki przybite do tablicy ogłoszeń, pieczęcie statusu,
   inny wygląd dla zadań głównych, pobocznych, osobistych
   i listów gończych.
   ============================================ */

const QuestBoard = (() => {
    const TYPES = {
        main:     { label: 'Zadanie główne', short: 'Główne', icon: 'fa-crown' },
        side:     { label: 'Zlecenie',        short: 'Poboczne', icon: 'fa-scroll' },
        personal: { label: 'Sprawa osobista', short: 'Osobiste', icon: 'fa-feather' },
        bounty:   { label: 'List gończy',     short: 'Listy gończe', icon: 'fa-skull' }
    };
    // stary zapis statusów zostaje ('Brak', 'Przyjęte', 'Zaliczone', 'Odrzucone')
    const STATUS = {
        'Nieznane':  { label: 'Nieodkryte', stamp: 'NIEODKRYTE', cls: 'unknown', icon: 'fa-eye-slash', hint: 'Gracze jeszcze o nim nie wiedzą' },
        'Brak':      { label: 'Do wzięcia', stamp: '', cls: 'open', icon: 'fa-hand-pointer', hint: 'Wisi na tablicy, nikt go nie przyjął' },
        'Przyjęte':  { label: 'W trakcie', stamp: 'PRZYJĘTE', cls: 'active', icon: 'fa-person-running', hint: 'Drużyna je realizuje' },
        'Zaliczone': { label: 'Wykonane', stamp: 'WYKONANE', cls: 'done', icon: 'fa-circle-check', hint: 'Zakończone sukcesem' },
        'Nieudane':  { label: 'Nieudane', stamp: 'NIEUDANE', cls: 'failed', icon: 'fa-heart-crack', hint: 'Zakończone porażką' },
        'Odrzucone': { label: 'Odrzucone', stamp: 'ODRZUCONE', cls: 'rejected', icon: 'fa-ban', hint: 'Drużyna odmówiła' }
    };
    const CLOSED = ['Zaliczone', 'Nieudane', 'Odrzucone'];
    const NOTE_MAX_W = 300;

    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const statusOf = (q) => STATUS[q.status] ? q.status : 'Brak';
    const typeOf = (q) => TYPES[q.type] ? q.type : 'side';
    const cid = () => App.getActiveCampaignId();

    let filter = 'all', query = '', lastStamped = null, lastAnim = null, view = 'board', archFilter = 'all';

    // deterministyczny „los” na podstawie id — kartka zawsze wisi tak samo
    function rng(id) {
        let seed = 0; for (const ch of String(id)) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
        return () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
    }
    function torn(id, rough = 1) {
        const r = rng(id + 'edge'), pts = [], step = 5;
        for (let x = 0; x <= 100; x += step) pts.push(`${x}% ${(r() * 1.4 * rough).toFixed(2)}%`);
        for (let y = step; y <= 100; y += step) pts.push(`${(100 - r() * 1.2 * rough).toFixed(2)}% ${y}%`);
        for (let x = 100 - step; x >= 0; x -= step) pts.push(`${x}% ${(100 - r() * 2.2 * rough).toFixed(2)}%`);
        for (let y = 100 - step; y > 0; y -= step) pts.push(`${(r() * 1.2 * rough).toFixed(2)}% ${y}%`);
        return `polygon(${pts.join(',')})`;
    }

    function objectivesOf(q) {
        return Array.isArray(q.objectives) ? q.objectives.filter(o => o && o.text) : [];
    }

    // ---------- kartka ----------
    function card(q, opts = {}) {
        const st = statusOf(q), ty = typeOf(q), S = STATUS[st], T = TYPES[ty];
        const r = rng(q.id);
        const tilt = ((r() - 0.5) * 7).toFixed(2);
        const objs = objectivesOf(q);
        const doneCount = objs.filter(o => o.done).length;
        const anim = !opts.archive && lastAnim && (lastAnim.id === q.id || lastAnim.id === '*') ? `anim-${lastAnim.kind}` : '';
        const dim = !opts.archive && !matches(q) ? 'is-dim' : '';
        const breeze = opts.archive ? '' : `--bdur:${(9 + r() * 14).toFixed(1)}s; --bdel:${(-r() * 20).toFixed(1)}s; --bamp:${(0.6 + r() * 1.1).toFixed(2)}deg;`;
        const pos = opts.archive ? '' : `left:calc(${q.pos?.x ?? 0} * (100% - ${NOTE_MAX_W}px)); top:${q.pos?.y ?? 0}px; z-index:${(q.pos?.z || 1) + (ty === 'bounty' ? 400 : 0)};`;

        const fastener = ty === 'bounty' ? '<span class="qp-dagger" aria-hidden="true"></span>'
            : ty === 'main' ? '<span class="qp-nail l"></span><span class="qp-nail r"></span>'
            : '<span class="qp-nail c"></span>';

        return `
        <article class="qp qp-${ty} st-${S.cls} ${anim} ${dim} ${opts.archive ? 'in-archive' : ''}" data-qid="${esc(q.id)}" style="--tilt:${tilt}deg; ${breeze} ${pos}" tabindex="0" aria-label="${esc(q.title)} — ${S.label}">
          <div class="qp-flip">
            <div class="qp-paper" style="clip-path:${torn(q.id, ty === 'main' ? 0.6 : 1)}"></div>
            ${fastener}
            <div class="qp-inner">
                <div class="qp-kind"><i class="fa-solid ${T.icon}"></i> ${ty === 'bounty' ? 'Poszukiwany' : T.label}</div>
                <h4 class="qp-title">${esc(q.title || 'Bez tytułu')}</h4>
                ${ty === 'bounty' ? '<div class="qp-wanted-sub">żywy lub martwy</div>' : ''}
                ${(q.giver || q.location) ? `<div class="qp-meta">
                    ${q.giver ? `<span><i class="fa-solid fa-user-tie"></i> ${esc(q.giver)}</span>` : ''}
                    ${q.location ? `<span><i class="fa-solid fa-location-dot"></i> ${esc(q.location)}</span>` : ''}
                </div>` : ''}
                ${q.acceptedBy && st === 'Przyjęte' ? `<div class="qp-by"><i class="fa-solid fa-handshake"></i> Przyjął: ${esc(q.acceptedBy.char || q.acceptedBy.name)}</div>` : ''}
                ${q.reported && st === 'Przyjęte' ? `<div class="qp-reported" title="Zgłosił: ${esc(q.reported.char || q.reported.name)}"><i class="fa-solid fa-bell"></i> Gracze zgłaszają wykonanie</div>` : ''}
                ${q.description ? `<p class="qp-desc">${esc(q.description)}</p>` : ''}
                ${objs.length ? `<ul class="qp-objs">${objs.map((o, i) => `
                    <li class="${o.done ? 'done' : ''}">${opts.player ? '<span class="qp-tick"></span>' : `<button class="qp-tick" data-obj="${i}" title="${o.done ? 'Odznacz' : 'Oznacz jako wykonany'}"></button>`}<span>${esc(o.text)}</span></li>`).join('')}
                    </ul><div class="qp-progress"><div style="width:${Math.round(doneCount / objs.length * 100)}%"></div><span>${doneCount}/${objs.length}</span></div>` : ''}
                ${q.reward ? `<div class="qp-reward"><span>Nagroda</span><b>${esc(q.reward)}</b></div>` : ''}
            </div>
            ${ty === 'main' ? '<span class="qp-seal" aria-hidden="true"><i class="fa-solid fa-crown"></i></span>' : ''}
            ${S.stamp ? `<span class="qp-stamp" aria-hidden="true">${S.stamp}</span>` : ''}
            ${st === 'Nieznane' ? '<span class="qp-unknown-mark" aria-hidden="true">?</span>' : ''}
          </div>
            ${opts.archive ? `
            <div class="qa-foot">
                <span>${q.closedAt ? new Date(q.closedAt).toLocaleDateString(window.LOC || 'pl-PL') : ''}</span>
                <button data-restore title="Przybij z powrotem na tablicę"><i class="fa-solid fa-rotate-left"></i> Na tablicę</button>
                <button data-purge title="Usuń na zawsze"><i class="fa-solid fa-trash"></i></button>
            </div>` : opts.player ? '' : `
            <div class="qp-actions" role="toolbar" aria-label="Zmień stan">
                ${Object.entries(STATUS).filter(([k]) => k !== st).map(([k, v]) => `<button data-status="${k}" title="${v.label}"><i class="fa-solid ${v.icon}"></i><span>${v.label}</span></button>`).join('')}
            </div>`}
        </article>`;
    }

    function matches(q) {
        const t = query.trim().toLowerCase();
        return (filter === 'all' || typeOf(q) === filter) &&
            (!t || [q.title, q.description, q.giver, q.location, q.reward].some(v => String(v || '').toLowerCase().includes(t)));
    }

    // wolne miejsce na tablicy dla kartek bez pozycji
    let boardW = 1100;
    const SLOT_DY = 400;
    function placeMissing(list) {
        const span = Math.max(1, boardW - NOTE_MAX_W);
        const cols = Math.max(2, Math.floor((boardW + 24) / (NOTE_MAX_W + 24)));
        const xs = Array.from({ length: cols }, (_, i) => i / (cols - 1));
        const taken = list.filter(q => q.pos);
        let changed = false;
        list.filter(q => !q.pos).forEach(q => {
            for (let row = 0; row < 60; row++) {
                const slot = xs.map(x => ({ x, y: 46 + row * SLOT_DY })).find(sl => !taken.some(t => Math.abs(t.pos.x - sl.x) * span < NOTE_MAX_W - 20 && Math.abs(t.pos.y - sl.y) < 300));
                if (slot) {
                    const r = rng(q.id + 'pos');
                    q.pos = { x: Math.min(1, Math.max(0, slot.x + (r() - 0.5) * 12 / span)), y: slot.y + Math.round(r() * 24), z: 1 };
                    taken.push(q); changed = true;
                    break;
                }
            }
        });
        return changed;
    }

    // resztki starych ogłoszeń, dziury po gwoździach, rysy — dekoracja tablicy
    function decor(h) {
        const r = rng('board-decor');
        const out = [];
        const rows = Math.max(3, Math.round(h / 260));
        for (let i = 0; i < rows * 3; i++) {
            const x = (r() * 96).toFixed(1), y = Math.round(r() * (h - 60));
            const kind = r();
            if (kind > 0.93) { out.push(`<i class="qb-knot" style="left:${x}%;top:${y}px;--s:${0.7 + r() * 0.8}"></i>`); continue; }
            if (kind < 0.38) out.push(`<i class="qb-scrap" style="left:${x}%;top:${y}px;--w:${30 + Math.round(r() * 50)}px;--h:${16 + Math.round(r() * 26)}px;--r:${Math.round((r() - 0.5) * 50)}deg"></i>`);
            else if (kind < 0.8) out.push(`<i class="qb-hole" style="left:${x}%;top:${y}px"></i>`);
            else out.push(`<i class="qb-scratch" style="left:${x}%;top:${y}px;--r:${Math.round((r() - 0.5) * 70)}deg;--w:${40 + Math.round(r() * 60)}px"></i>`);
        }
        out.push(`<i class="qb-carve" style="left:${(70 + r() * 20).toFixed(1)}%;top:${Math.round(h * (0.55 + r() * 0.3))}px">B + E</i>`);
        return `<div class="qb-decor" aria-hidden="true">${out.join('')}</div>`;
    }

    // żywe tło: kurz w świetle, ćma, pająk, przeciąg, cień przechodnia, kominek
    function ambient() {
        const r = rng('ambient');
        const dust = Array.from({ length: 22 }, (_, i) => {
            const nearLamp = i < 14;
            const x = nearLamp ? 2 + r() * 30 : r() * 100, y = nearLamp ? 2 + r() * 40 : r() * 90;
            return `<i class="qb-dust" style="left:${x.toFixed(1)}%;top:${y.toFixed(1)}%;--d:${(9 + r() * 12).toFixed(1)}s;--dl:${(-r() * 20).toFixed(1)}s;--dx:${Math.round((r() - 0.3) * 120)}px;--dy:${Math.round(-40 - r() * 120)}px;--sz:${(1.5 + r() * 2.5).toFixed(1)}px"></i>`;
        }).join('');
        return `<div class="qb-ambient" aria-hidden="true">
            <i class="qb-hearth"></i>
            ${dust}
            <i class="qb-moth"><i></i></i>
            <i class="qb-spider"><i class="qb-thread"></i><i class="qb-spider-body"></i></i>
            <i class="qb-web"></i>
            <i class="qb-passer"></i>
        </div>`;
    }

    // ---------- widok ----------
    function render() {
        if (!cid()) return '<div class="empty-state">Najpierw wybierz kampanię</div>';
        const all = StorageManager.getQuests(cid()) || [];
        const board = all.filter(q => !CLOSED.includes(statusOf(q)));
        const archived = all.filter(q => CLOSED.includes(statusOf(q)));
        if (placeMissing(board)) StorageManager.saveQuests(cid(), all);
        const count = (k) => board.filter(x => k === 'all' || typeOf(x) === k).length;
        const height = Math.max(820, ...board.map(q => (q.pos?.y || 0) + 520));

        const tools = view === 'board' ? `
            <div class="qb-filters">${[['all', 'Wszystkie', 'fa-border-all'], ...Object.entries(TYPES).map(([k, v]) => [k, v.short, v.icon])]
                .map(([k, l, ic]) => `<button class="${filter === k ? 'on' : ''}" data-filter="${k}"><i class="fa-solid ${ic}"></i> ${l} <small>${count(k)}</small></button>`).join('')}</div>
            <input type="search" class="qb-search" placeholder="Szukaj na tablicy…" value="${esc(query)}" aria-label="Szukaj zlecenia">
            <button class="qb-tool" data-arrange title="Ułóż kartki równo"><i class="fa-solid fa-table-cells-large"></i> Uporządkuj</button>`
            : `<div class="qb-filters">${[['all', 'Wszystkie'], ['Zaliczone', 'Wykonane'], ['Nieudane', 'Nieudane'], ['Odrzucone', 'Odrzucone']]
                .map(([k, l]) => `<button class="${archFilter === k ? 'on' : ''}" data-archfilter="${k}">${l} <small>${k === 'all' ? archived.length : archived.filter(q => q.status === k).length}</small></button>`).join('')}</div>`;

        lastStamped = null;
        const out = `
        <div class="qb view-${view}">
            <div class="qb-tools">
                ${tools}
                <button class="qb-tool qb-archive-btn ${view === 'archive' ? 'on' : ''}" data-view="${view === 'archive' ? 'board' : 'archive'}">
                    <i class="fa-solid ${view === 'archive' ? 'fa-chalkboard' : 'fa-box-archive'}"></i> ${view === 'archive' ? 'Wróć do tablicy' : 'Archiwum'} <small class="qb-arch-count">${archived.length}</small>
                </button>
            </div>
            ${view === 'board' ? `
            <div class="qb-frame">
                <div class="qb-roof" aria-hidden="true"></div>
                <div class="qb-lantern" aria-hidden="true"><i class="qb-lantern-chain"></i><i class="qb-lantern-body"></i><i class="qb-lantern-glow"></i></div>
                <div class="qb-sign" aria-hidden="true"><i class="qb-chain l"></i><i class="qb-chain r"></i><span>Zlecenia</span><small>· tablica ogłoszeń ·</small></div>
                <i class="qb-corner tl"></i><i class="qb-corner tr"></i><i class="qb-corner bl"></i><i class="qb-corner br"></i>
                <div class="qb-board qb-free" style="height:${height}px">
                    ${decor(height)}
                    ${board.length ? board.map(q => card(q)).join('') : '<div class="qb-empty-board"><i class="fa-solid fa-thumbtack"></i><p>Tablica jest pusta.<br>Przybij pierwsze ogłoszenie przyciskiem „Nowe zadanie”.</p></div>'}
                    <div class="qb-hint"><i class="fa-solid fa-hand"></i> Przeciągaj kartki, by je układać · kliknij, by edytować</div>
                </div>
                <div class="qb-ledge" aria-hidden="true"><i class="qb-candle"><i class="qb-smoke s1"></i><i class="qb-smoke s2"></i><i class="qb-smoke s3"></i></i><i class="qb-mug"></i></div>
                ${ambient()}
            </div>` : `
            <div class="qa">
                <div class="qa-head"><i class="fa-solid fa-book-bookmark"></i><div><h3>Księga zamkniętych zleceń</h3><p>Wykonane, nieudane i odrzucone zadania tej kampanii</p></div></div>
                <div class="qa-grid">${archived.filter(q => archFilter === 'all' || q.status === archFilter)
                    .sort((a, b) => String(b.closedAt || '').localeCompare(String(a.closedAt || '')))
                    .map(q => card(q, { archive: true })).join('') || '<p class="qa-empty">Archiwum jest puste — tu trafią zakończone zlecenia.</p>'}</div>
            </div>`}
        </div>`;
        lastAnim = null;
        return out;
    }

    // ---------- ta sama tablica dla gracza (tylko do oglądania; kliknięcie kartki otwiera podgląd w aplikacji gracza) ----------
    function renderPlayer(list, opts = {}) {
        const all = (list || []).map(q => ({ ...q, objectives: (q.objectives || []).map(o => ({ ...o })), pos: q.pos ? { ...q.pos } : null }));
        // u gracza zakończone zlecenia wiszą na tablicy z pieczątką (opts.closed)
        const board = opts.closed ? all.filter(q => statusOf(q) !== 'Nieznane') : all.filter(q => !CLOSED.includes(statusOf(q)));
        const keep = filter; filter = 'all';
        boardW = 1100; placeMissing(board);
        const height = Math.max(820, ...board.map(q => (q.pos?.y || 0) + 520));
        const html = `
        <div class="qb qb-player view-board">
            <div class="qb-frame">
                <div class="qb-roof" aria-hidden="true"></div>
                <div class="qb-lantern" aria-hidden="true"><i class="qb-lantern-chain"></i><i class="qb-lantern-body"></i><i class="qb-lantern-glow"></i></div>
                <div class="qb-sign" aria-hidden="true"><i class="qb-chain l"></i><i class="qb-chain r"></i><span>Zlecenia</span><small>· tablica ogłoszeń ·</small></div>
                <i class="qb-corner tl"></i><i class="qb-corner tr"></i><i class="qb-corner bl"></i><i class="qb-corner br"></i>
                <div class="qb-board qb-free" style="height:${height}px">
                    ${decor(height)}
                    ${board.length ? board.map(q => card(q, { player: true })).join('') : '<div class="qb-empty-board"><i class="fa-solid fa-thumbtack"></i><p>Tablica jest pusta.<br>Gdy pojawią się zlecenia, zobaczycie je tutaj.</p></div>'}
                    ${board.length && opts.hint ? `<div class="qb-hint"><i class="fa-solid fa-hand"></i> ${opts.hint}</div>` : ''}
                </div>
                <div class="qb-ledge" aria-hidden="true"><i class="qb-candle"><i class="qb-smoke s1"></i><i class="qb-smoke s2"></i><i class="qb-smoke s3"></i></i><i class="qb-mug"></i></div>
                ${ambient()}
            </div>
        </div>`;
        filter = keep;
        return html;
    }

    // ---------- zapis ----------
    function update(id, fn) {
        const all = StorageManager.getQuests(cid()) || [];
        const q = all.find(x => x.id === id);
        if (!q) return null;
        fn(q, all);
        StorageManager.saveQuests(cid(), all);
        return q;
    }

    const EXIT = { 'Zaliczone': 'done', 'Nieudane': 'burn', 'Odrzucone': 'crumple' };
    function setStatus(id, status) {
        const all = StorageManager.getQuests(cid()) || [];
        const before = all.find(x => x.id === id);
        if (!before || statusOf(before) === status) return;
        const prev = statusOf(before);
        const q = update(id, x => {
            x.status = status; x.updatedAt = new Date().toISOString(); if (status !== 'Przyjęte') delete x.reported;
            if (CLOSED.includes(status)) x.closedAt = x.updatedAt; else delete x.closedAt;
            if (!CLOSED.includes(status) && CLOSED.includes(prev)) delete x.pos;
        });
        App.showToast(`„${q.title}” — ${STATUS[status].label.toLowerCase()}`, status === 'Zaliczone' ? 'success' : status === 'Nieudane' || status === 'Odrzucone' ? 'warning' : 'info');
        transition(id, prev, status);
    }

    // animacja przejścia między stanami
    function transition(id, prev, status) {
        const el = document.querySelector(`.qb-free .qp[data-qid="${CSS.escape(id)}"]`);
        if (CLOSED.includes(status) && el) {
            // 1) pieczęć, 2) kartka schodzi z tablicy do archiwum
            el.classList.remove('st-unknown', 'st-open', 'st-active');
            el.classList.add(`st-${STATUS[status].cls}`, 'anim-stamp');
            el.querySelector('.qp-stamp')?.remove();
            el.querySelector('.qp-unknown-mark')?.remove();
            el.querySelector('.qp-flip').insertAdjacentHTML('beforeend', `<span class="qp-stamp">${STATUS[status].stamp}</span>`);
            const btn = document.querySelector('.qb-archive-btn');
            setTimeout(() => {
                if (btn) {
                    const a = el.getBoundingClientRect(), b = btn.getBoundingClientRect();
                    el.style.setProperty('--fx', `${b.left + b.width / 2 - (a.left + a.width / 2)}px`);
                    el.style.setProperty('--fy', `${b.top + b.height / 2 - (a.top + a.height / 2)}px`);
                }
                el.classList.add(`exit-${EXIT[status]}`);
            }, 900);
            setTimeout(() => {
                refresh();
                const nb = document.querySelector('.qb-archive-btn');
                if (nb) { nb.classList.add('receive'); setTimeout(() => nb.classList.remove('receive'), 700); }
            }, 900 + (status === 'Nieudane' ? 1300 : 1000));
            return;
        }
        let kind = 'stamp';
        if (prev === 'Nieznane' && status !== 'Nieznane') kind = 'reveal';
        else if (status === 'Nieznane') kind = 'hide';
        else if (status === 'Przyjęte') kind = 'accept';
        else if (status === 'Brak') kind = 'post';
        lastAnim = { id, kind };
        refresh();
    }

    let refresh = () => {};

    // ---------- edytor ----------
    function editor(id, presetStatus) {
        const all = StorageManager.getQuests(cid()) || [];
        const q = id ? all.find(x => x.id === id) : null;
        const cur = q || { type: 'side', status: presetStatus || 'Przyjęte', objectives: [] };
        const locs = (StorageManager.getLocations(cid()) || []).map(l => l.name).filter(Boolean);
        const objText = objectivesOf(cur).map(o => (o.done ? '[x] ' : '') + o.text).join('\n');

        App.showModal(q ? 'Kartka zlecenia' : 'Nowe ogłoszenie', `
            <div class="qe">
                <div class="qe-field"><span>Rodzaj kartki</span>
                    <div class="qe-chips" data-group="type">${Object.entries(TYPES).map(([k, v]) => `<button type="button" class="qe-type qe-type-${k} ${typeOf(cur) === k ? 'on' : ''}" data-v="${k}"><i class="fa-solid ${v.icon}"></i> ${v.short}</button>`).join('')}</div>
                </div>
                <div class="qe-field"><span>Stan</span>
                    <div class="qe-chips" data-group="status">${Object.entries(STATUS).map(([k, v]) => `<button type="button" class="qe-st st-${v.cls} ${statusOf(cur) === k ? 'on' : ''}" data-v="${k}" title="${v.hint}"><i class="fa-solid ${v.icon}"></i> ${v.label}</button>`).join('')}</div>
                </div>
                <label class="qe-field"><span>Tytuł</span><input type="text" id="qe-title" value="${esc(cur.title || '')}" placeholder="np. Wilkołak z Brodu Wierzbowego"></label>
                <div class="qe-grid">
                    <label class="qe-field"><span>Zleceniodawca</span><input type="text" id="qe-giver" value="${esc(cur.giver || '')}" placeholder="np. sołtys Hareth"></label>
                    <label class="qe-field"><span>Miejsce</span><input type="text" id="qe-location" list="qe-locs" value="${esc(cur.location || '')}" placeholder="np. Szeptany Las"><datalist id="qe-locs">${locs.map(l => `<option value="${esc(l)}">`).join('')}</datalist></label>
                    <label class="qe-field"><span>Nagroda</span><input type="text" id="qe-reward" value="${esc(cur.reward || '')}" placeholder="np. 200 sz i przysługa"></label>
                </div>
                <label class="qe-field"><span>Treść ogłoszenia</span><textarea id="qe-desc" rows="4" placeholder="Co trzeba zrobić, co wiadomo…">${esc(cur.description || '')}</textarea></label>
                <label class="qe-field"><span>Cele (jeden w linii, „[x]” = wykonany)</span><textarea id="qe-objs" rows="3" placeholder="Odnaleźć legowisko&#10;Przynieść łeb bestii">${esc(objText)}</textarea></label>
                <label class="qe-field"><span><i class="fa-solid fa-eye-slash"></i> Sekret Mistrza Gry (nie widać na kartce)</span><textarea id="qe-secret" rows="2" placeholder="Prawda o zleceniu, zwroty akcji…">${esc(cur.secret || '')}</textarea></label>
            </div>`,
            `${q ? '<button class="btn-danger" id="qe-del" style="margin-right:auto"><i class="fa-solid fa-trash"></i> Zerwij kartkę</button>' : ''}
             <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="btn-primary" id="qe-save"><i class="fa-solid fa-thumbtack"></i> ${q ? 'Zapisz' : 'Przybij do tablicy'}</button>`);

        const pick = { type: typeOf(cur), status: statusOf(cur) };
        document.querySelectorAll('.qe-chips').forEach(g => g.addEventListener('click', (e) => {
            const b = e.target.closest('button[data-v]');
            if (!b) return;
            pick[g.dataset.group] = b.dataset.v;
            g.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b));
        }));
        document.getElementById('qe-save').onclick = () => {
            const title = document.getElementById('qe-title').value.trim();
            if (!title) { App.showToast('Podaj tytuł zlecenia', 'warning'); return; }
            const objectives = document.getElementById('qe-objs').value.split('\n').map(l => l.trim()).filter(Boolean)
                .map(l => ({ done: /^\[x\]\s*/i.test(l), text: l.replace(/^\[[x ]?\]\s*/i, '') }));
            const data = {
                ...(q || { id: StorageManager.generateId(), createdAt: new Date().toISOString() }),
                title, type: pick.type, status: pick.status,
                giver: document.getElementById('qe-giver').value.trim(),
                location: document.getElementById('qe-location').value.trim(),
                reward: document.getElementById('qe-reward').value.trim(),
                description: document.getElementById('qe-desc').value.trim(),
                secret: document.getElementById('qe-secret').value.trim(),
                objectives, updatedAt: new Date().toISOString()
            };
            const prev = q ? statusOf(q) : null;
            if (CLOSED.includes(data.status) && prev !== data.status) data.closedAt = data.updatedAt;
            if (!CLOSED.includes(data.status)) delete data.closedAt;
            if (prev && CLOSED.includes(prev) && !CLOSED.includes(data.status)) delete data.pos;
            StorageManager.saveQuest(cid(), data);
            App.closeModal();
            App.showToast(q ? 'Kartka zaktualizowana' : (CLOSED.includes(data.status) ? 'Zlecenie trafiło do archiwum' : 'Ogłoszenie przybite do tablicy'), 'success');
            if (!q) { lastAnim = { id: data.id, kind: data.status === 'Przyjęte' ? 'accept' : 'post' }; refresh(); }
            else if (prev !== data.status) transition(data.id, prev, data.status);
            else refresh();
        };
        const del = document.getElementById('qe-del');
        if (del) del.onclick = () => {
            StorageManager.deleteQuest(cid(), q.id);
            App.closeModal();
            App.showToast('Kartka zerwana z tablicy', 'info');
            refresh();
        };
        setTimeout(() => document.getElementById('qe-title')?.focus(), 80);
    }

    // ---------- przeciąganie i zdarzenia ----------
    function arrange() {
        const all = StorageManager.getQuests(cid()) || [];
        const order = { main: 0, bounty: 1, side: 2, personal: 3 };
        const board = all.filter(q => !CLOSED.includes(statusOf(q)))
            .sort((a, b) => (statusOf(a) === 'Nieznane') - (statusOf(b) === 'Nieznane') || order[typeOf(a)] - order[typeOf(b)]);
        board.forEach(q => delete q.pos);
        placeMissing(board);
        StorageManager.saveQuests(cid(), all);
        lastAnim = { id: '*', kind: 'post' };
        refresh();
    }

    function bind(container, rerender) {
        refresh = rerender;
        const root = container.querySelector('.qb');
        if (!root) return;
        const boardEl = root.querySelector('.qb-free');
        if (boardEl && boardEl.clientWidth) boardW = boardEl.clientWidth;

        root.addEventListener('click', async (e) => {
            const f = e.target.closest('[data-filter]');
            if (f) { filter = f.dataset.filter; rerender(); return; }
            const af = e.target.closest('[data-archfilter]');
            if (af) { archFilter = af.dataset.archfilter; rerender(); return; }
            const v = e.target.closest('[data-view]');
            if (v) { view = v.dataset.view; rerender(); return; }
            if (e.target.closest('[data-arrange]')) { arrange(); return; }
            const card = e.target.closest('.qp');
            if (!card) return;
            const id = card.dataset.qid;
            if (e.target.closest('[data-restore]')) { setStatus(id, 'Brak'); return; }
            if (e.target.closest('[data-purge]')) {
                if (!await Ask.confirm('Zlecenie zniknie z tablicy na zawsze.', { title: 'Usunąć zlecenie?', ok: 'Usuń', danger: true })) return;
                StorageManager.deleteQuest(cid(), id); rerender(); return;
            }
            const st = e.target.closest('[data-status]');
            if (st) { e.stopPropagation(); setStatus(id, st.dataset.status); return; }
            const tick = e.target.closest('[data-obj]');
            if (tick) {
                e.stopPropagation();
                update(id, x => { const o = x.objectives[+tick.dataset.obj]; if (o) o.done = !o.done; });
                rerender();
                return;
            }
            if (card.classList.contains('in-archive')) { editor(id); return; }
            if (card._dragged) { card._dragged = false; return; }
            editor(id);
        });
        root.addEventListener('keydown', (e) => {
            const card = e.target.closest('.qp');
            if (card && e.target === card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); editor(card.dataset.qid); }
        });
        const search = root.querySelector('.qb-search');
        if (search) search.addEventListener('input', (e) => {
            query = e.target.value;
            root.querySelectorAll('.qb-free .qp').forEach(c => {
                const q = (StorageManager.getQuests(cid()) || []).find(x => x.id === c.dataset.qid);
                c.classList.toggle('is-dim', !!q && !matches(q));
            });
        });

        // swobodne przesuwanie kartek
        if (!boardEl) return;
        let drag = null;
        boardEl.addEventListener('pointerdown', (e) => {
            const card = e.target.closest('.qp');
            if (!card || e.button !== 0 || e.target.closest('button, input, a')) return;
            const b = boardEl.getBoundingClientRect(), c = card.getBoundingClientRect();
            drag = { card, id: card.dataset.qid, sx: e.clientX, sy: e.clientY, ox: c.left - b.left, oy: card.offsetTop, moved: false, pid: e.pointerId };
        });
        boardEl.addEventListener('pointermove', (e) => {
            if (!drag) return;
            const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
            if (!drag.moved && Math.hypot(dx, dy) < 5) return;
            if (!drag.moved) {
                drag.moved = true;
                drag.card.setPointerCapture(drag.pid);
                drag.card.classList.add('dragging');
                const maxZ = Math.max(1, ...[...boardEl.querySelectorAll('.qp')].map(n => (+n.style.zIndex || 1) - (n.classList.contains('qp-bounty') ? 400 : 0)));
                drag.card.style.zIndex = maxZ + 1 + (drag.card.classList.contains('qp-bounty') ? 400 : 0);
            }
            const bw = boardEl.clientWidth;
            const left = Math.max(0, Math.min(bw - drag.card.offsetWidth, drag.ox + dx));
            const top = Math.max(0, drag.oy + dy);
            drag.card.style.left = `${left}px`;
            drag.card.style.top = `${top}px`;
            if (top + drag.card.offsetHeight + 120 > boardEl.offsetHeight) boardEl.style.height = `${top + drag.card.offsetHeight + 160}px`;
        });
        const end = () => {
            if (!drag) return;
            const { card, id, moved } = drag;
            drag = null;
            if (!moved) return;
            card._dragged = true;
            card.classList.remove('dragging');
            card.classList.add('dropped');
            setTimeout(() => card.classList.remove('dropped'), 450);
            const span = Math.max(1, boardEl.clientWidth - NOTE_MAX_W);
            const x = Math.max(0, Math.min(1, parseFloat(card.style.left) / span));
            const y = Math.round(parseFloat(card.style.top));
            const z = (+card.style.zIndex || 1) - (card.classList.contains('qp-bounty') ? 400 : 0);
            update(id, q => { q.pos = { x, y, z }; });
            card.style.left = `calc(${x} * (100% - ${NOTE_MAX_W}px))`;
        };
        boardEl.addEventListener('pointerup', end);
        boardEl.addEventListener('pointercancel', end);
    }

    return { render, renderPlayer, bind, editor, setStatus, STATUS, TYPES, NOTE_MAX_W };
})();

window.QuestBoard = QuestBoard;
