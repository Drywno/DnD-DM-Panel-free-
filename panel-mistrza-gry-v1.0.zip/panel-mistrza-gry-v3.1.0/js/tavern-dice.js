/* ============================================
   Kości 3D na blacie stołu do gier (karczma)
   Sześcienna kość z CSS 3D: wpada na blat z krawędzi stołu, koziołkuje
   i kładzie się wynikiem do góry. Wynik jest znany z góry, więc ten sam
   rzut wygląda identycznie u Mistrza Gry i u graczy.
   ============================================ */
const TavernDice = (() => {
    const PIPS = { 1: [5], 2: [1, 9], 3: [1, 5, 9], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
    // obrót, który kładzie daną ściankę wynikiem do patrzącego: [rotateX, rotateY]
    const ROT = { 1: [0, 0], 2: [0, -90], 3: [-90, 0], 4: [90, 0], 5: [0, 90], 6: [0, 180] };
    const DUR = 1650;
    const seen = new Set();
    const hash = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h); };
    const light = (hex) => { const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return true; const n = parseInt(m[1], 16); return ((n >> 16) * .299 + ((n >> 8) & 255) * .587 + (n & 255) * .114) > 150; };
    const face = (n) => `<div class="td-f td-f${n}">${Array.from({ length: 9 }, (_, i) => `<i class="${PIPS[n].includes(i + 1) ? 'on' : ''}"></i>`).join('')}</div>`;
    const FACES = [1, 2, 3, 4, 5, 6].map(face).join('');
    // key: identyfikator tego konkretnego rzutu — nowy klucz = kość wpada na stół z animacją
    function cube(v, opts = {}) {
        v = Math.max(1, Math.min(6, +v || 1));
        const color = opts.color || '#f2ead8';
        const isNew = !!opts.key && !seen.has(opts.key);
        if (opts.key) seen.add(opts.key);
        const [vx, vy] = ROT[v];
        const tw = (hash(opts.key || ('' + v + color)) % 50) - 25;
        return `<div class="td-cube ${isNew ? 'td-new' : ''} ${light(color) ? 'td-light' : 'td-dark'} ${opts.cls || ''}" style="--die:${color};--vx:${vx}deg;--vy:${vy}deg;--tw:${tw}deg" data-v="${v}"><div class="td-rot">${FACES}</div></div>`;
    }
    // uruchom animację nowych kości (po wstawieniu HTML do strony):
    // kość wylatuje z ręki gracza, kilka razy odbija się od blatu (coraz niżej), toczy się po nim
    // i zatrzymuje wynikiem do góry; cień zostaje na stole i rośnie, gdy kość opada
    function play(root = document) {
        root.querySelectorAll('.td-cube.td-new').forEach((el, i) => {
            el.classList.remove('td-new');
            const rot = el.querySelector('.td-rot'); if (!rot || !el.animate) return;
            const R = (a, b) => a + Math.random() * (b - a);
            const cs = getComputedStyle(el), size = parseFloat(cs.width) || 60;
            const vx = parseFloat(cs.getPropertyValue('--vx')) || 0, vy = parseFloat(cs.getPropertyValue('--vy')) || 0, tw = parseFloat(cs.getPropertyValue('--tw')) || 0;
            // skąd leci: z dołu stołu (strona graczy), raz z lewej, raz z prawej
            const side = (i % 2 ? 1 : -1) * (Math.random() < .5 ? 1 : -1);
            const sx = side * R(160, 300), sy = R(130, 210), dist = Math.hypot(sx, sy);
            const dx = -sx / dist, dy = -sy / dist;                       // kierunek lotu
            const ax = -dy, ay = dx;                                       // oś toczenia (prostopadła do ruchu)
            const turns = Math.max(1, Math.round(dist / (size * 3.2)));
            const T = 360 * turns, sX = 360 * (Math.random() < .5 ? -1 : 1), sY = 360 * (Math.random() < .5 ? -1 : 1) * (turns > 1 ? 1 : 2), tw0 = R(-70, 70);
            const bounces = [[0, .3, 74], [.3, .52, 28], [.52, .67, 11], [.67, .77, 3.5]];
            const hAt = (t) => { for (const [a, b, H] of bounces) if (t >= a && t <= b) { const u = (t - a) / (b - a); return 4 * H * u * (1 - u); } return 0; };
            const N = 40, cube = [], spin = [], shadow = [];
            for (let k = 0; k <= N; k++) {
                const t = k / N, p = 1 - Math.pow(1 - t, 2.3), q = Math.min(1, t / .55), qe = 1 - Math.pow(1 - q, 2);
                const h = hAt(t), th = -T * (1 - p);
                cube.push({ offset: t, transform: `translate(${(sx * (1 - p)).toFixed(1)}px, ${(sy * (1 - p)).toFixed(1)}px)`, opacity: t < .06 ? t / .06 : 1 });
                spin.push({ offset: t, transform: `translateY(${(-h).toFixed(1)}px) scale(${(1 + h / 380).toFixed(3)}) rotateX(26deg) rotateZ(${(tw + tw0 * (1 - p)).toFixed(1)}deg) rotate3d(${ax.toFixed(3)}, ${ay.toFixed(3)}, 0, ${th.toFixed(1)}deg) rotateX(${(vx + sX * (1 - qe)).toFixed(1)}deg) rotateY(${(vy + sY * (1 - qe)).toFixed(1)}deg)` });
                shadow.push({ offset: t, opacity: Math.max(.15, 1 - h / 90).toFixed(2), transform: `scale(${Math.max(.45, 1 - h / 140).toFixed(2)})` });
            }
            const opt = { duration: DUR, delay: i * 120, easing: 'linear', fill: 'backwards' };
            el.animate(cube, opt); rot.animate(spin, opt);
            try { el.animate(shadow, { ...opt, pseudoElement: '::after' }); } catch (e) {}
        });
    }
    return { cube, play, DUR };
})();
window.TavernDice = TavernDice;
