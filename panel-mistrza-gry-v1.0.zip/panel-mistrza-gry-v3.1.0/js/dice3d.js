/* ============================================
   D&D 5e DM Panel — Kości 3D (fizyka, rzut na blat)
   Oparte na bibliotece @3d-dice/dice-box (js/dice-box.bundle.js).
   Wynik pochodzi z fizyki — to, co widać na stole, trafia do historii.
   Gdy 3D nie jest dostępne (plik otwarty z dysku, brak WebGL),
   panel używa dotychczasowej animacji 2D.
   ============================================ */

const Dice3D = (() => {
    const LS = (k) => StorageManager.PREFIX + 'ui_' + k;
    const get = (k, d) => { try { const v = localStorage.getItem(LS(k)); return v === null ? d : JSON.parse(v); } catch (e) { return d; } };
    const set = (k, v) => { try { localStorage.setItem(LS(k), JSON.stringify(v)); } catch (e) {} };

    const COLORS = [
        { id: 'krew', name: 'Krwisty', color: '#8b1a1a', alt: '#d9b25f' },
        { id: 'kosc', name: 'Kość słoniowa', color: '#e8dcc0', alt: '#8b1a1a' },
        { id: 'szmaragd', name: 'Szmaragd', color: '#1f6b45', alt: '#d9b25f' },
        { id: 'szafir', name: 'Szafir', color: '#1f3f7a', alt: '#e8dcc0' },
        { id: 'obsydian', name: 'Obsydian', color: '#1b1714', alt: '#c9a35c' },
        { id: 'zloto', name: 'Złoto', color: '#b8892e', alt: '#1b1714' },
        { id: 'ametyst', name: 'Ametyst', color: '#5a2a7a', alt: '#e8dcc0' }
    ];
    const SUPPORTED = [4, 6, 8, 10, 12, 20, 100];

    let box = null, initPromise = null, failed = false, failReason = '', initRetries = 0;
    let tray, resultEl, hideTimer = null, busy = false;

    // Kości 3D są włączone przy każdym uruchomieniu panelu.
    // Wyłączenie przełącznikiem działa tylko do zamknięcia / odświeżenia strony.
    let sessionEnabled = true;
    try { localStorage.removeItem(LS('dice3d')); } catch (e) {}
    const enabled = () => sessionEnabled;
    const setEnabled = (on) => { sessionEnabled = !!on; renderSettings(); if (sessionEnabled) warmUp(); };
    const colorDef = () => COLORS.find(c => c.id === get('diceColor', 'krew')) || COLORS[0];
    const available = () => enabled() && !failed && location.protocol !== 'file:' && typeof DiceBoxModule !== 'undefined';

    // ---------------------------------------------------------------
    // Init
    // ---------------------------------------------------------------
    function ensureInit() {
        if (initPromise) return initPromise;
        if (location.protocol === 'file:') { failed = true; failReason = 'file'; return Promise.reject(new Error('file://')); }
        if (typeof DiceBoxModule === 'undefined') { failed = true; failReason = 'lib'; return Promise.reject(new Error('no lib')); }
        const DiceBox = DiceBoxModule.default;
        const origin = new URL('.', location.href).href.replace(/\/$/, '');
        box = new DiceBox({
            container: '#dice-box-container',
            id: 'dice-canvas-3d',
            origin,
            assetPath: '/assets/dice-box/',
            theme: 'default',
            themeColor: colorDef().color,
            scale: 5.5,
            gravity: 1.6,
            mass: 1,
            friction: 0.8,
            restitution: 0.1,
            linearDamping: 0.5,
            angularDamping: 0.4,
            spinForce: 5,
            throwForce: 4.8,
            startingHeight: 6,
            settleTimeout: 5000,
            delay: 10,
            lightIntensity: 1.1,
            shadowTransparency: 0.6,
            enableShadows: true,
            offscreen: get('dice3dOffscreen', true)
        });
        initPromise = Promise.race([
            box.init(),
            new Promise((_, rej) => setTimeout(() => rej(new Error('init timeout')), 30000))
        ]).then(() => { box.hide('dice-hidden'); return box; })
          .catch(err => {
              console.warn('[Dice3D] start nieudany:', err);
              // np. przeglądarka była zajęta przy starcie — spróbuj ponownie przy następnym rzucie (maks. 2 razy)
              initRetries++;
              if (initRetries <= 2 && /timeout/i.test(err && err.message)) {
                  initPromise = null;
                  try { const c = document.getElementById('dice-canvas-3d'); c && c.remove(); } catch (e) {}
              } else { failed = true; failReason = 'init'; }
              throw err;
          });
        return initPromise;
    }

    // ---------------------------------------------------------------
    // Tray (blat) + result scroll
    // ---------------------------------------------------------------
    function buildTray() {
        tray = document.createElement('div');
        tray.id = 'dice-tray';
        tray.className = 'dice-tray';
        tray.innerHTML = `<div class="dice-tray-felt"></div><div class="dice-tray-hint">kliknij, aby zabrać kości</div>`;
        document.body.appendChild(tray);
        resultEl = document.createElement('div');
        resultEl.className = 'dice-tray-result';
        resultEl.setAttribute('aria-live', 'polite');
        document.body.appendChild(resultEl);
        resultEl.addEventListener('mousedown', () => { if (!busy) hideTray(); });
        // Tło jest przezroczyste i nie blokuje aplikacji — kliknięcie gdziekolwiek zabiera kości
        document.addEventListener('mousedown', (e) => { if (!busy && tray.classList.contains('show') && !e.target.closest('#dice-fab, #dice-roller')) hideTray(); }, true);
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && tray.classList.contains('show') && !busy) hideTray(); }, true);
    }

    function showTray() {
        if (!tray) buildTray();
        clearTimeout(hideTimer);
        resultEl.className = 'dice-tray-result';
        resultEl.innerHTML = '';
        tray.classList.add('show');
        // nowy rzut zaraz po poprzednim: zdejmij wygaszanie, inaczej kości są niewidoczne
        const cv = document.getElementById('dice-canvas-3d');
        if (cv) cv.classList.remove('fading', 'dice-hidden');
        document.body.classList.add('dice-rolling');
        box.show();
        box.clear();
    }

    function hideTray() {
        clearTimeout(hideTimer);
        if (!tray) return;
        tray.classList.remove('show');
        document.body.classList.remove('dice-rolling');
        resultEl && resultEl.classList.remove('show');
        const c = document.getElementById('dice-canvas-3d');
        if (c) c.classList.add('fading');
        setTimeout(() => {
            if (!tray.classList.contains('show') && box) { box.clear(); box.hide('dice-hidden'); c && c.classList.remove('fading'); }
        }, 350);
    }

    function showResult(result, detailHtml) {
        resultEl.innerHTML = `
            <div class="dtr-expr">${App.esc(result.expression)}</div>
            <div class="dtr-total">${result.total}</div>
            <div class="dtr-detail">${detailHtml}</div>
            ${result.isCritical ? '<div class="dtr-flag crit">Naturalna 20!</div>' : ''}
            ${result.isFumble ? '<div class="dtr-flag fumble">Krytyczna porażka</div>' : ''}`;
        resultEl.classList.add('show');
        if (result.isCritical) resultEl.classList.add('crit');
        if (result.isFumble) resultEl.classList.add('fumble');
        hideTimer = setTimeout(hideTray, result.isCritical || result.isFumble ? 4500 : 3200);
    }

    // ---------------------------------------------------------------
    // Rolling
    // ---------------------------------------------------------------
    function parse(expr) {
        const parts = expr.replace(/\s+/g, '').toLowerCase().split(/(?=[+-])/).filter(Boolean);
        const groups = []; let modifier = 0;
        for (let p of parts) {
            const sign = p[0] === '-' ? -1 : 1;
            if (p[0] === '+' || p[0] === '-') p = p.slice(1);
            if (p.includes('d')) {
                const [c, s] = p.split('d');
                const count = c ? parseInt(c, 10) : 1, sides = parseInt(s, 10);
                if (isNaN(count) || isNaN(sides) || count < 1) return null;
                groups.push({ count, sides, sign });
            } else {
                const m = parseInt(p, 10);
                if (isNaN(m)) return null;
                modifier += sign * m;
            }
        }
        return { groups, modifier };
    }

    function canRoll3D(parsed) {
        if (!parsed || !parsed.groups.length) return false;
        const totalDice = parsed.groups.reduce((s, g) => s + g.count, 0);
        return totalDice <= 15 && parsed.groups.every(g => SUPPORTED.includes(g.sides));
    }

    // Rzut grupami dla gier (karczma): [{qty, sides, color}] → [[wartości], ...]
    // Nie dopisuje do historii rzutów MG i nie pokazuje zwoju — gra ma własny wynik.
    async function rollGroups(groups, { hideAfter = 2600 } = {}) {
        if (!available()) throw new Error('3D niedostępne');
        await ensureInit();
        if (busy) throw new Error('busy');
        busy = true;
        showTray();
        let rolled;
        try {
            rolled = await Promise.race([
                box.roll(groups.map(g => ({ qty: g.qty, sides: g.sides, themeColor: g.color || colorDef().color }))),
                new Promise((_, rej) => setTimeout(() => rej(new Error('roll timeout')), 20000))
            ]);
        } catch (e) {
            busy = false;
            hideTray();
            throw e;
        }
        busy = false;
        const byGroup = {};
        rolled.forEach(r => { (byGroup[r.groupId] = byGroup[r.groupId] || []).push(r.value === 0 && r.sides === 100 ? 100 : r.value); });
        const ids = Object.keys(byGroup).map(Number).sort((a, b) => a - b);
        clearTimeout(hideTimer);
        hideTimer = setTimeout(hideTray, hideAfter);
        return ids.map(id => byGroup[id]);
    }

    async function roll(expr, mode = 'normal') {
        let parsed;
        try { parsed = DiceRoller.parseExpr(expr); } catch (e) { return null; }
        if (!canRoll3D(parsed)) return null; // caller falls back to 2D
        await ensureInit();
        busy = true;
        showTray();
        const col = colorDef();
        let result;
        try {
            result = await DiceRoller.computeRoll(expr, mode, async (specs) => {
                // drugi komplet (ułatwienie/utrudnienie) w kolorze dodatkowym
                const rolled = await Promise.race([
                    box.roll(specs.map(sp => ({ qty: sp.qty, sides: sp.sides, themeColor: sp.set ? col.alt : col.color }))),
                    new Promise((_, rej) => setTimeout(() => rej(new Error('roll timeout')), 20000))
                ]);
                const byGroup = {};
                rolled.forEach(r => { (byGroup[r.groupId] = byGroup[r.groupId] || []).push(r.value === 0 && r.sides === 100 ? 100 : r.value); });
                return Object.keys(byGroup).map(Number).sort((x, y) => x - y).map(id => byGroup[id]);
            });
        } finally {
            busy = false;
        }
        showResult(result, DiceRoller.describe(result));
        return result;
    }

    // ---------------------------------------------------------------
    // Hook into the existing DiceRoller
    // ---------------------------------------------------------------
    function hook() {
        const origExpr = DiceRoller.rollExpression.bind(DiceRoller);
        const origRoll = DiceRoller.roll.bind(DiceRoller);

        DiceRoller.rollExpression = async function (expr, mode = 'normal', label = '') {
            if (!available() || this.isRolling) return origExpr(expr, mode, label);
            let parsed;
            try { parsed = DiceRoller.parseExpr(expr); } catch (e) { return origExpr(expr, mode, label); }
            if (!canRoll3D(parsed)) return origExpr(expr, mode, label);
            this.isRolling = true;
            try {
                const result = await roll(expr, mode);
                if (!result) { this.isRolling = false; return origExpr(expr, mode, label); }
                if (label) result.label = String(label).slice(0, 90);
                this._updateHistoryAndToast(result);
                this.addToHistory(result);
                return result;
            } catch (e) {
                console.warn('[Dice3D] rzut 3D nieudany, używam 2D', e);
                if (tray) hideTray();
                this.isRolling = false;
                return origExpr(expr, mode, label);
            } finally {
                this.isRolling = false;
            }
        };

        // Single-die buttons honour advantage/disadvantage through the 3D path too
        DiceRoller.roll = async function (count, sides) {
            if (!available()) return origRoll(count, sides);
            const mode = document.querySelector('input[name="roll-mode"]:checked')?.value || 'normal';
            const modVal = parseInt(document.getElementById('dice-modifier')?.value, 10) || 0;
            const modStr = modVal === 0 ? '' : (modVal > 0 ? `+${modVal}` : `${modVal}`);
            return this.rollExpression(`${count}d${sides}${modStr}`, mode);
        };
    }

    // ---------------------------------------------------------------
    // Settings row inside the dice panel
    // ---------------------------------------------------------------
    function renderSettings() {
        const panel = document.getElementById('dice-roller');
        if (!panel) return;
        let row = document.getElementById('dice3d-settings');
        if (!row) {
            row = document.createElement('div');
            row.id = 'dice3d-settings';
            row.className = 'dice3d-settings';
            panel.querySelector('.dice-result')?.before(row);
            row.addEventListener('click', (e) => {
                const sw = e.target.closest('[data-dcolor]');
                if (sw) {
                    set('diceColor', sw.dataset.dcolor);
                    if (box) box.updateConfig({ themeColor: colorDef().color }).catch(() => {});
                    renderSettings();
                    return;
                }
                if (e.target.closest('[data-d3toggle]')) {
                    setEnabled(!enabled());
                }
            });
        }
        const fileMode = location.protocol === 'file:';
        const cur = colorDef().id;
        row.innerHTML = `
            <div class="d3-head">
                <span>Kości 3D</span>
                <button class="d3-toggle ${enabled() && !fileMode ? 'on' : ''}" data-d3toggle ${fileMode ? 'disabled' : ''} title="Włącz / wyłącz rzut na stół"><span></span></button>
            </div>
            ${fileMode ? `<div class="d3-note">Rzut na stół działa, gdy panel jest uruchomiony przez <b>Uruchom panel.bat</b>. Teraz panel jest otwarty prosto z pliku, więc kości są w 2D.</div>`
              : failed && failReason === 'init' ? `<div class="d3-note">Ta przeglądarka nie obsługuje grafiki 3D (WebGL). Używam animacji 2D.</div>`
              : `<div class="d3-swatches">${COLORS.map(c => `<button class="d3-swatch${c.id === cur ? ' active' : ''}" data-dcolor="${c.id}" title="${c.name}" style="--c:${c.color};--a:${c.alt}"></button>`).join('')}</div>`}`;
    }

    function warmUp() {
        if (!available()) return;
        const go = () => ensureInit().then(renderSettings).catch(renderSettings);
        if ('requestIdleCallback' in window) requestIdleCallback(go, { timeout: 4000 }); else setTimeout(go, 1500);
    }

    function init() {
        hook();
        renderSettings();
        warmUp();
    }

    return { init, roll, rollGroups, available, isBusy: () => busy, colors: COLORS, ensureInit, refresh: () => { renderSettings(); if (enabled()) warmUp(); }, setEnabled, enabled };
})();

window.Dice3D = Dice3D;
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => { try { Dice3D.init(); } catch (e) { console.error('[Dice3D]', e); } }, 250);
});
