/* ============================================
   D&D 5e DM Panel — Gracze przy stole (tryb online)
   Miejsca graczy z linkami logowania, udostępnianie w sieci,
   hasło MG, „pokaż graczom”, dziennik rzutów i wiadomości,
   odbiór zmian od graczy na żywo.
   ============================================ */

const OnlineModule = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const H = { 'Content-Type': 'application/json', 'X-Panel': '1' };
    let info = null, log = [], es = null, connected = false, onlineNow = { mg: false, gracze: [] };
    const SEAT_COLORS = ['#c0392b', '#2e86c1', '#27ae60', '#8e44ad', '#d68910', '#16a085', '#c2185b', '#6d4c41'];

    const available = () => StorageManager.syncAvailable() && (StorageManager._sync.proto || 0) >= 3;
    async function api(path, body) {
        const r = await fetch(path, body ? { method: 'POST', headers: H, body: JSON.stringify(body), cache: 'no-store' } : { cache: 'no-store' });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || j.ok === false) throw new Error(j.error || `Serwer odpowiedział ${r.status}`);
        return j;
    }

    // ---------- połączenie na żywo ----------
    function connect() {
        if (es || !available()) return;
        es = new EventSource(`api/events?klient=${encodeURIComponent(StorageManager._sync.klient)}`);
        es.addEventListener('hello', (e) => { connected = true; const d = JSON.parse(e.data); onlineNow = d.online || onlineNow; badge(); loadLog(); });
        es.addEventListener('ops', (e) => {
            const d = JSON.parse(e.data);
            StorageManager.applyRemote(d.keys, d.version);
        });
        es.addEventListener('online', (e) => { onlineNow = JSON.parse(e.data); badge(); if (isOpen()) renderSeatsOnly(); });
        es.addEventListener('log', (e) => {
            const entry = JSON.parse(e.data);
            log.push(entry); if (log.length > 200) log = log.slice(-200);
            // dziennik jest na ekranie — bez dymków, które by go zasłaniały
            if (entry.szept && entry.dla === 'mg') App.showToast(`🤫 ${entry.postac || entry.kto} (prywatnie): ${entry.typ === 'rzut' ? `${entry.opis ? entry.opis + ' — ' : ''}${entry.rzut.total}${critTxt(entry.rzut)}` : entry.tekst}`, 'info');
            else if (entry.rola === 'gracz' && !chatOpen()) App.showToast(entry.typ === 'rzut' ? `🎲 ${entry.kto}${entry.postac ? ` (${entry.postac})` : ''}: ${entry.opis ? entry.opis + ' — ' : ''}${entry.rzut.total}${critTxt(entry.rzut)}` : `💬 ${entry.kto}: ${entry.tekst}`, 'info');
            if (entry.rola === 'gracz' && !chatOpen()) { unread++; chatBadge(); }
            renderLog();
            if (entry.typ === 'rzut') window.dispatchEvent(new Event('panel-log'));
        });
        es.addEventListener('ping', (e) => { try { window.dispatchEvent(new CustomEvent('panel-ping', { detail: JSON.parse(e.data) })); } catch (er) {} });
        es.addEventListener('nastroj', (e) => { try { const d = JSON.parse(e.data); window.Nastroj?.apply(d); mood.now = d && d.kind !== 'stop' ? d : null; if (isOpen()) renderMood(); } catch (er) {} });
        es.addEventListener('live', (e) => { const d = JSON.parse(e.data); if (info) info.live = d.clear ? null : d; if (isOpen()) renderLive(); });
        es.onerror = () => { connected = false; badge(); };
    }
    const critTxt = (r) => r.crit === 'max' ? ' (naturalne 20!)' : r.crit === 'min' ? ' (naturalna 1)' : '';

    // odśwież moduły, gdy dane zmieniły się z zewnątrz
    let pend = new Set(), t = null;
    window.addEventListener('panel-remote', (e) => {
        (e.detail?.keys || []).forEach(k => pend.add(k));
        clearTimeout(t); t = setTimeout(refreshModules, 120);
    });
    function refreshModules() {
        const keys = [...pend]; pend.clear();
        const has = (part) => keys.some(k => k.includes(part));
        try {
            if (has('combat_state') && window.CombatModule?.reloadFromStorage) CombatModule.reloadFromStorage();
            if (has('vtt_') && window.VTTModule?.reloadFromStorage) VTTModule.reloadFromStorage();
            if (has('characters_') && window.CharactersModule?.refreshFromStorage) CharactersModule.refreshFromStorage();
            if (App.currentTab === 'dashboard') App.updateDashboard();
            if (App.currentTab === 'campaign' && (has('quests_') || has('locations_') || has('atlas_') || has('sessions_') || has('notes_'))) {
                const a = document.activeElement;
                if (!(a && a.matches('input, textarea, select')) && window.CampaignsModule?.openSubtab && CampaignsModule.getSubtab) CampaignsModule.openSubtab(CampaignsModule.getSubtab());
            }
            if (isOpen() && has('characters_')) renderSeatsOnly();
        } catch (err) { console.warn('[online] odświeżanie', err); }
    }

    function badge() {
        const n = (onlineNow.gracze || []).length;
        const el = document.getElementById('nav-online-count');
        if (el) { el.textContent = n ? String(n) : ''; el.hidden = !n; }
        const dot = document.getElementById('online-conn');
        if (dot) { dot.className = `on-conn ${connected ? 'ok' : 'off'}`; dot.title = connected ? 'Połączono z serwerem' : 'Brak połączenia na żywo'; }
    }

    // ---------- zakładka ----------
    const root = () => document.getElementById('online-content');
    const isOpen = () => App.currentTab === 'online' && root();
    function chars() { const cid = App.getActiveCampaignId(); return cid ? (StorageManager.getCharacters(cid) || []) : []; }
    function baseUrl() {
        if (!info) return location.origin;
        if (info.url) return info.url;
        if (info.tryb === 'serwer') return location.origin;
        const host = location.hostname;
        if (host !== 'localhost' && host !== '127.0.0.1') return location.origin;
        if (info.siec && info.adresy?.length) return `http://${lanIp()}:${info.port}`;
        return location.origin;
    }
    const lanIp = () => (info?.adresy || [])[info?.adrIdx || 0] || (info?.adresy || [])[0] || location.hostname;
    const linkOf = (g) => `${baseUrl()}/gracz?kod=${encodeURIComponent(g.kod)}`;
    const reachable = () => info && (info.tryb === 'serwer' || info.siec || !['localhost', '127.0.0.1'].includes(location.hostname) || info.url);

    async function activate() {
        const el = root(); if (!el) return;
        if (!StorageManager.syncAvailable()) { el.innerHTML = noServer('Panel otwarto prosto z pliku. Uruchom go ikoną „Panel Mistrza Gry”, żeby gracze mogli dołączyć.'); return; }
        el.innerHTML = '<div class="on-loading"><i class="fa-solid fa-spinner fa-spin"></i> Wczytuję…</div>';
        try { info = { ...(info || {}), ...(await api('api/online')) }; }
        catch (e) {
            el.innerHTML = noServer(/404/.test(e.message) || /Nie ma takiego/.test(e.message)
                ? 'Działa jeszcze stara wersja serwera panelu. Zamknij panel, zakończ proces „Node.js” w Menedżerze zadań i uruchom panel ponownie ikoną.'
                : e.message);
            return;
        }
        if (!es) connect();
        // wybrany adres w sieci (zapamiętany), domyślnie najlepszy — Wi‑Fi / Ethernet
        let saved = null; try { saved = localStorage.getItem('dnd5e_meta_lan_ip'); } catch (e) {}
        const idx = (info.adresy || []).indexOf(saved);
        info.adrIdx = idx >= 0 ? idx : 0;
        onlineNow = info.online || onlineNow;
        render();
        loadLog();
    }
    const noServer = (msg) => `<div class="on-card on-warn"><i class="fa-solid fa-plug-circle-xmark"></i><div><b>Tryb dla graczy jest niedostępny</b><p>${esc(msg)}</p></div></div>`;

    function render() {
        const el = root(); if (!el || !info) return;
        el.innerHTML = `
        <div class="on-cq"><div class="on-grid">
            <div class="on-main">
                <div id="on-access">${accessHTML()}</div>
                <div class="on-sec-head"><h3><i class="fa-solid fa-chair"></i> Miejsca przy stole</h3><span class="on-sub">Każdy gracz dostaje własny link — widzi swoją postać, drużynę, mapę i walkę.</span></div>
                <div class="on-seats" id="on-seats">${seatsHTML()}</div>
            </div>
            <aside class="on-side">
                <button type="button" class="on-card on-chat-open" data-on="chat"><i class="fa-solid fa-comments"></i><span><b>Czat i rzuty graczy</b><small>Okienko obok kości w prawym dolnym rogu — dostępne w każdej zakładce</small></span><i class="fa-solid fa-arrow-right"></i></button>
                <div class="on-card" id="on-live">${liveHTML()}</div>
                <div class="on-card on-mood" id="on-mood">${moodHTML()}</div>
            </aside>
        </div></div>`;
        bind();
        renderLog();
        badge();
        if (info.siec) checkLan();
    }
    async function checkLan() {
        const box = document.getElementById('on-check'); if (!box || !info?.siec) return;
        const ip = lanIp();
        box.className = 'on-check wait'; box.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Sprawdzam ${esc(ip)}…`;
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 3500);
        try {
            const r = await fetch(`http://${ip}:${info.port}/api/ping?t=${Date.now()}`, { cache: 'no-store', signal: ctl.signal });
            if (!r.ok) throw new Error(String(r.status));
            box.className = 'on-check ok'; box.innerHTML = `<i class="fa-solid fa-circle-check"></i> Panel odpowiada pod <b>http://${esc(ip)}:${info.port}</b> — gracze w tej sieci mogą wejść przez swoje linki.`;
        } catch (e) {
            box.className = 'on-check bad';
            box.innerHTML = `<i class="fa-solid fa-circle-xmark"></i> Panel nie odpowiada pod adresem ${esc(ip)}. ${info.nasluch === '127.0.0.1' ? 'Uruchom panel ponownie.' : 'Wybierz inny adres z listy albo zezwól „Node.js” w Zaporze systemu Windows (Panel sterowania → Zapora → Zezwalaj aplikacji…, zaznacz „Prywatne”).'}`;
        } finally { clearTimeout(t); }
    }

    function renderSeatsOnly() { const s = document.getElementById('on-seats'); if (s && info) { info.online = onlineNow; s.innerHTML = seatsHTML(); } refreshTo(); }
    // wiadomości prywatne: wybór adresata
    let sayTo = '';
    function seatName(g) { const c = chars().find(x => x.id === g.charId); return c ? `${c.name} (${g.name})` : g.name; }
    function toOptions() {
        const list = (info?.gracze || []);
        if (sayTo && !list.some(g => g.id === sayTo)) sayTo = '';
        return `<option value="">Do wszystkich</option>${list.map(g => `<option value="${esc(g.id)}" ${sayTo === g.id ? 'selected' : ''}>🤫 ${esc(seatName(g))}</option>`).join('')}`;
    }
    function refreshTo() {
        const s = document.getElementById('on-to'); if (!s) return;
        s.innerHTML = toOptions(); s.value = sayTo;
        const f = document.getElementById('on-say'); if (f) f.classList.toggle('priv', !!sayTo);
        const i = document.getElementById('on-say-t'); if (i) i.placeholder = sayTo ? 'Prywatnie do gracza… albo rzut tylko dla niego' : 'Napisz do graczy… albo rzut, np. 2k6+3';
    }
    function renderLive() { const s = document.getElementById('on-live'); if (s) s.innerHTML = liveHTML(); }
    // ---------- muzyka i nastrój ----------
    const mood = { now: null, files: [], vol: 0.8, loaded: false };
    async function loadMood() { try { const j = await api('api/audio'); mood.files = j.pliki || []; mood.now = j.nastroj || null; if (mood.now) mood.vol = mood.now.vol ?? 0.8; mood.loaded = true; renderMood(); } catch (e) {} }
    function moodHTML() {
        if (!window.Nastroj) return '';
        if (!mood.loaded) setTimeout(loadMood, 0);
        const n = mood.now;
        const on = (kind, id) => n && n.kind === kind && n.id === id;
        const sz = (b) => b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.round(b / 1024)} KB`;
        return `<div class="on-sec-head"><h3><i class="fa-solid fa-music"></i> Muzyka i nastrój</h3>${n ? '<button class="btn-secondary btn-small" data-on="mood-stop"><i class="fa-solid fa-stop"></i> Wycisz wszystkich</button>' : ''}</div>
            <p class="on-muted">Wgraj własne nagrania — zagrają u wszystkich graczy (każdy ma u siebie suwak głośności). Kliknij ponownie, by zatrzymać.</p>
            <div class="on-mood-files">
                <div class="on-mood-fh"><b>Twoje nagrania</b><button class="btn-secondary btn-small" data-on="mood-up"><i class="fa-solid fa-upload"></i> Wgraj (mp3, ogg…)</button><input type="file" id="on-mood-file" accept="audio/*" multiple hidden></div>
                ${mood.files.length ? mood.files.map(f => `<div class="on-mood-f ${on('plik', f.id) ? 'on' : ''}"><button class="on-mood-play" data-on="mood-file" data-id="${esc(f.id)}" title="${on('plik', f.id) ? 'Zatrzymaj' : 'Odtwórz u wszystkich'}"><i class="fa-solid ${on('plik', f.id) ? 'fa-stop' : 'fa-play'}"></i></button><span>${esc(f.nazwa)}</span><small>${sz(f.rozmiar || 0)}</small><button class="btn-icon" data-on="mood-del" data-id="${esc(f.id)}" title="Usuń nagranie"><i class="fa-solid fa-trash"></i></button></div>`).join('') : '<p class="on-muted">Wgraj własną muzykę — trafi na ten komputer i zagra u graczy.</p>'}
            </div>
            <label class="on-mood-vol">Głośność dla wszystkich <input type="range" min="0.05" max="1" step="0.05" value="${mood.vol}" id="on-mood-vol"></label>`;
    }
    function renderMood() { const s = document.getElementById('on-mood'); if (s) s.innerHTML = moodHTML(); }
    async function setMood(body) { try { const j = await api('api/nastroj', body); mood.now = j.nastroj; window.Nastroj?.apply(j.nastroj || { kind: 'stop', t: Date.now() }); renderMood(); } catch (e) { App.showToast(e.message, 'error'); } }
    async function uploadAudio(files) {
        for (const f of files) {
            if (f.size > 40 * 1024 * 1024) { App.showToast(`${f.name}: plik jest za duży (maks. 40 MB)`, 'warning'); continue; }
            App.showToast(`Wgrywam: ${f.name}…`, 'info');
            try {
                const r = await fetch(`api/audio?nazwa=${encodeURIComponent(f.name)}`, { method: 'POST', headers: { 'Content-Type': f.type || 'audio/mpeg', 'X-Panel': '1' }, body: f });
                const j = await r.json().catch(() => ({}));
                if (!r.ok || j.ok === false) throw new Error(j.error || `Błąd ${r.status}`);
                mood.files.push(j.plik);
            } catch (e) { App.showToast(`${f.name}: ${e.message}`, 'error'); }
        }
        renderMood();
    }

    function accessHTML() {
        const pw = info.hasDm;
        const lan = info.tryb !== 'serwer' && ['localhost', '127.0.0.1'].includes(location.hostname);
        let where;
        if (info.tryb === 'serwer' || !lan) where = `<p>Panel działa pod adresem <b>${esc(baseUrl())}</b>. Gracze wchodzą przez swoje linki z dowolnego miejsca.</p>`;
        else if (info.siec) where = `<p>Panel jest dostępny w sieci domowej. Gracze podłączeni do tego samego Wi‑Fi wchodzą przez swoje linki.</p>
            <div class="on-adr-row"><span>Adres dla graczy:</span>${(info.adresyInfo || info.adresy.map(ip => ({ ip, name: '' }))).length > 1
                ? `<select id="on-adr">${(info.adresyInfo || info.adresy.map(ip => ({ ip, name: '' }))).map((a, i) => `<option value="${i}" ${(info.adrIdx || 0) === i ? 'selected' : ''}>${esc(a.ip)}${a.name ? ` — ${esc(a.name)}` : ''}${a.virtual ? ' (wirtualna/VPN)' : ''}</option>`).join('')}</select>`
                : `<b>${esc(lanIp())}</b>`}
                <button class="btn-secondary btn-small" data-on="check"><i class="fa-solid fa-signal"></i> Sprawdź połączenie</button></div>
            <div class="on-check" id="on-check"></div>
            ${info.https ? `<p class="on-muted"><i class="fa-solid fa-lock"></i> Aplikacja na telefon: gracz stuka w swoim panelu <b>Więcej → Zainstaluj aplikację</b> i przechodzi na bezpieczny adres <b>https://${esc((info.https.hosty || [])[info.adrIdx || 0] || (info.https.hosty || [])[0] || '')}:${info.https.port}</b>. Pierwsze uruchomienie po udostępnieniu może potrwać chwilę (pobieranie certyfikatu).</p>` : '<p class="on-muted"><i class="fa-solid fa-lock-open"></i> Bezpieczny adres do instalacji aplikacji na telefonach jeszcze nie działa — komputer potrzebuje internetu, by pobrać certyfikat (zrobi to sam).</p>'}
            ${info.nasluch === '127.0.0.1' ? '<p class="on-warn-line"><i class="fa-solid fa-triangle-exclamation"></i> Serwer wciąż nasłuchuje tylko na tym komputerze. Zamknij panel i uruchom go ponownie ikoną.</p>' : ''}
            <p class="on-muted">Wybierz adres karty <b>Wi‑Fi</b> albo <b>Ethernet</b> (zwykle 192.168.…). Adresy VPN (np. Radmin 26.…) działają tylko dla graczy w tej samej sieci VPN. Przy pierwszym udostępnieniu Windows może zapytać o zaporę dla „Node.js” — zaznacz sieci prywatne i kliknij „Zezwól”.</p>`;
        else where = `<p>Teraz panel działa <b>tylko na tym komputerze</b>. Aby gracze mogli dołączyć z telefonów i laptopów w tym samym Wi‑Fi, udostępnij go w sieci domowej.</p>`;
        return `<div class="on-card on-access ${info.siec || !lan ? 'live' : ''}">
            <div class="on-access-ico"><i class="fa-solid ${info.siec || !lan ? 'fa-tower-broadcast' : 'fa-house-laptop'}"></i></div>
            <div class="on-access-body">
                <h3>${info.siec || !lan ? 'Stół jest otwarty dla graczy' : 'Stół jest zamknięty'}</h3>
                ${where}
                <div class="on-access-acts">
                    ${lan && info.siecZmienna ? (info.siec
                        ? '<button class="btn-secondary btn-small" data-on="lan-off"><i class="fa-solid fa-lock"></i> Zamknij dostęp z sieci</button>'
                        : `<button class="btn-primary btn-small" data-on="lan-on" ${pw ? '' : 'disabled title="Najpierw ustaw hasło MG"'}><i class="fa-solid fa-tower-broadcast"></i> Udostępnij w sieci domowej</button>`) : ''}
                    <button class="btn-secondary btn-small" data-on="pw"><i class="fa-solid fa-key"></i> ${pw ? 'Zmień hasło MG' : 'Ustaw hasło MG'}</button>
                    ${pw ? '<button class="btn-secondary btn-small" data-on="mgsess"><i class="fa-solid fa-laptop"></i> Urządzenia MG</button>' : ''}
                    <button class="btn-secondary btn-small" data-on="help"><i class="fa-solid fa-server"></i> Na własnym serwerze</button>
                    ${info.lokalny ? '' : '<button class="btn-secondary btn-small" data-on="logout"><i class="fa-solid fa-right-from-bracket"></i> Wyloguj MG</button>'}
                </div>
                ${pw ? '' : '<p class="on-warn-line"><i class="fa-solid fa-triangle-exclamation"></i> Ustaw hasło Mistrza Gry — bez niego nikt spoza tego komputera nie powinien mieć dostępu do panelu MG.</p>'}
            </div>
        </div>`;
    }

    function seatsHTML() {
        const cs = chars(), list = info.gracze || [];
        const on = new Set((onlineNow.gracze || []).map(g => g.id));
        const taken = new Set(list.map(g => g.charId).filter(Boolean));
        const empty = list.filter(g => !g.charId && !on.has(g.id)).length;
        const head = `<div class="on-seats-bar">
            <span><b>${list.length}</b> ${list.length === 1 ? 'gracz' : list.length > 1 && list.length < 5 ? 'graczy' : 'graczy'} · ${on.size} połączonych · najwyżej 8</span>
            ${empty > 1 ? `<button class="btn-secondary btn-small" data-on="del-empty"><i class="fa-solid fa-broom"></i> Usuń puste miejsca (${empty})</button>` : ''}
        </div>
        ${!reachable() && list.length ? '<p class="on-note"><i class="fa-solid fa-circle-info"></i> Linki zadziałają na innych urządzeniach dopiero po udostępnieniu stołu w sieci (przycisk wyżej).</p>' : ''}`;
        const rows = list.map((g, i) => {
            const ch = cs.find(c => c.id === g.charId);
            const isOn = on.has(g.id);
            const otherCamp = g.charId && g.campaignId && g.campaignId !== App.getActiveCampaignId();
            return `<div class="on-seat ${isOn ? 'online' : ''}" data-seat="${esc(g.id)}" style="--sc:${SEAT_COLORS[i % SEAT_COLORS.length]}">
                <span class="on-seat-av" title="${isOn ? 'Połączony' : 'Niepołączony'}">${esc((g.name || '?').slice(0, 1).toUpperCase())}<i class="on-dot"></i></span>
                <div class="on-seat-who">
                    <input class="on-seat-name" data-f="name" value="${esc(g.name)}" maxlength="40" aria-label="Imię gracza">
                    <small class="${isOn ? 'is-on' : ''}">${isOn ? 'przy stole' : 'nie połączony'}</small>
                </div>
                <div class="on-seat-char">
                    <select data-f="charId" aria-label="Postać gracza"><option value="">— bez postaci —</option>${cs.map(c => `<option value="${esc(c.id)}" ${c.id === g.charId ? 'selected' : ''} ${taken.has(c.id) && c.id !== g.charId ? 'disabled' : ''}>${esc(c.name)} · ${esc(c.class || '')} ${c.level || 1}</option>`).join('')}</select>
                    <small>${otherCamp ? 'postać z innej kampanii' : ch ? `${ch.hp?.current ?? '?'}/${ch.hp?.max ?? '?'} PW · KP ${ch.ac ?? '?'}` : 'wybierz postać dla gracza'}</small>
                </div>
                <div class="on-seat-code" title="Kod do wpisania na stronie logowania"><span>kod</span><b>${esc(g.kod)}</b></div>
                <div class="on-seat-acts">
                    <button class="btn-primary btn-small" data-on="copy" title="Kopiuj link dla gracza"><i class="fa-solid fa-link"></i> Link</button>
                    <button class="on-ib" data-on="qr" title="Kod QR"><i class="fa-solid fa-qrcode"></i><span>QR</span></button>
                    <button class="on-ib" data-on="preview" title="Zobacz widok tego gracza"><i class="fa-solid fa-eye"></i><span>Podgląd</span></button>
                    <button class="on-ib" data-on="regen" title="Nowy kod — stary link przestanie działać"><i class="fa-solid fa-rotate"></i><span>Nowy kod</span></button>
                    <button class="on-ib danger" data-on="del" title="Usuń gracza"><i class="fa-solid fa-user-xmark"></i><span>Usuń</span></button>
                </div>
            </div>`;
        }).join('');
        const add = list.length < 8
            ? `<button class="on-add" data-on="add"><i class="fa-solid fa-user-plus"></i> Dodaj gracza</button>`
            : '<p class="on-note">Osiągnięto limit 8 graczy — usuń kogoś, aby dodać nowe miejsce.</p>';
        return head + `<div class="on-seat-list">${rows || '<p class="on-empty-seats">Nikt jeszcze nie siedzi przy stole. Dodaj pierwszego gracza.</p>'}</div>` + add;
    }

    function liveHTML() {
        const L = info?.live;
        return `<div class="on-sec-head"><h3><i class="fa-solid fa-tv"></i> Pokaż graczom</h3>${L ? '<button class="btn-secondary btn-small" data-on="live-clear"><i class="fa-solid fa-xmark"></i> Zakończ pokaz</button>' : ''}</div>
            ${L ? `<div class="on-live-now"><i class="fa-solid fa-${L.kind === 'obraz' ? 'image' : L.kind === 'mapa' ? 'map' : 'book-open-reader'}"></i><div><b>${esc(L.title || (L.kind === 'mapa' ? 'Mapa' : 'Tekst'))}</b><small>Gracze widzą to teraz na swoich ekranach</small></div></div>` : ''}
            <input id="on-live-title" maxlength="160" placeholder="Tytuł, np. Karczma Pod Złamanym Ostrzem">
            <textarea id="on-live-text" rows="3" placeholder="Tekst do odczytania graczom…"></textarea>
            <div class="on-live-acts">
                <button class="btn-primary btn-small" data-on="live-text"><i class="fa-solid fa-book-open-reader"></i> Pokaż tekst</button>
                <button class="btn-secondary btn-small" data-on="live-img"><i class="fa-solid fa-image"></i> Pokaż obraz…</button>
                <input type="file" id="on-live-file" accept="image/*" hidden>
            </div>
            <p class="on-muted">Tekst z lokacji wyślesz też z Atlasu, a mapę — przyciskiem „Pokaż graczom” na mapie.</p>`;
    }

    // ---------- dziennik ----------
    async function loadLog() {
        if (!available()) return;
        try { const j = await api('api/dziennik'); log = j.wpisy || []; renderLog(); window.dispatchEvent(new Event('panel-log')); } catch (e) {}
    }
    function rollHTML(r) {
        const parts = r.parts.map(p => p.die ? `${p.sign < 0 ? '−' : ''}${p.die} [${p.rolls.join(', ')}${p.dropped != null ? ` <s>${p.dropped}</s>` : ''}]` : `${p.mod < 0 ? '−' : '+'}${Math.abs(p.mod)}`).join(' ');
        return `<span class="on-roll ${r.crit ? 'c-' + r.crit : ''}"><b>${r.total}</b><small>${esc(r.expr)}${r.mode === 'adv' ? ' z ułatwieniem' : r.mode === 'dis' ? ' z utrudnieniem' : ''}: ${parts}</small></span>`;
    }
    function renderLog() {
        const el = document.getElementById('on-log'); if (!el) return;
        if (!log.length) { el.innerHTML = '<p class="on-muted on-empty">Tu pojawią się rzuty i wiadomości graczy.</p>'; return; }
        el.innerHTML = log.slice(-120).map(e => `<div class="on-entry r-${e.rola} t-${e.typ} ${e.tylkoMG && !e.szept ? 'secret' : ''} ${e.szept ? 'whisper' : ''}" style="--who:${/^#[0-9a-f]{6}$/i.test(e.kolor || '') ? e.kolor : '#c9a35c'}">
            <div class="on-entry-h"><i class="who-dot">${esc(String(e.postac || e.kto || '?').trim().charAt(0).toUpperCase())}${e.av && window.Portrait ? Portrait.img(Portrait.fromAv(e.av)) : ''}</i><b>${esc(e.postac || e.kto)}</b>${e.postac ? `<span>${esc(e.kto)}</span>` : ''}<time>${new Date(e.t).toLocaleTimeString(window.LOC || 'pl-PL', { hour: '2-digit', minute: '2-digit' })}</time>${e.tylkoMG && !e.szept ? '<i class="fa-solid fa-eye-slash" title="Tylko MG"></i>' : ''}</div>
            ${e.szept ? `<div class="on-whisper-tag"><i class="fa-solid fa-user-secret"></i> ${e.dla === 'mg' ? 'prywatnie do ciebie' : `prywatnie do: ${esc(e.dlaKto || 'gracza')}`}${e.dla === 'mg' && e.pid ? ` <button type="button" class="on-reply" data-on="reply" data-pid="${esc(e.pid)}"><i class="fa-solid fa-reply"></i> Odpowiedz</button>` : ''}</div>` : ''}
            ${e.typ === 'rzut' ? `<div>${e.opis ? `<em>${esc(e.opis)}</em> ` : ''}${rollHTML(e.rzut)}</div>` : `<div class="on-entry-t">${esc(e.tekst)}</div>`}
        </div>`).join('');
        el.scrollTop = el.scrollHeight;
    }

    // ---------- akcje ----------
    let saveT = null;
    function bind() {
        const el = root();
        el.onclick = async (e) => {
            const b = e.target.closest('[data-on]'); if (!b) return;
            const act = b.dataset.on, seat = b.closest('[data-seat]')?.dataset.seat;
            if (act === 'mood-file') { const kind = 'plik', id = b.dataset.id; if (mood.now && mood.now.kind === kind && mood.now.id === id) setMood({ stop: true }); else setMood({ kind, id, vol: mood.vol }); return; }
            if (act === 'mood-stop') { setMood({ stop: true }); return; }
            if (act === 'mood-up') { document.getElementById('on-mood-file')?.click(); return; }
            if (act === 'mood-del') { const f = mood.files.find(x => x.id === b.dataset.id); if (f && await Ask.confirm('Nagranie zniknie z tego komputera.', { title: `Usunąć „${f.nazwa}”?`, ok: 'Usuń', danger: true })) { try { await api('api/audio/usun', { id: f.id }); mood.files = mood.files.filter(x => x !== f); if (mood.now?.id === f.id) { mood.now = null; window.Nastroj?.apply({ kind: 'stop', t: Date.now() }); } renderMood(); } catch (er) { App.showToast(er.message, 'error'); } } return; }
            if (act === 'chat') { toggleChat(true); return; }
            const g = seat ? (info.gracze || []).find(x => x.id === seat) : null;
            try {
                if (act === 'add') {
                    const n = (info.gracze || []).length + 1;
                    const j = await api('api/online/gracz', { name: `Gracz ${n}`, campaignId: App.getActiveCampaignId() });
                    info.gracze = [...(info.gracze || []), j.gracz]; renderSeatsOnly();
                    document.querySelector(`[data-seat="${j.gracz.id}"] .on-seat-name`)?.select();
                } else if (act === 'del') {
                    confirmDelete([g]);
                } else if (act === 'del-empty') {
                    const on = new Set((onlineNow.gracze || []).map(x => x.id));
                    confirmDelete((info.gracze || []).filter(x => !x.charId && !on.has(x.id)));
                } else if (act === 'regen') {
                    const j = await api('api/online/gracz/kod', { id: g.id });
                    Object.assign(g, j.gracz); renderSeatsOnly();
                    App.showToast('Nowy kod gotowy — stary link już nie działa', 'success');
                } else if (act === 'copy') {
                    const url = linkOf(g);
                    try { await navigator.clipboard.writeText(url); App.showToast('Link skopiowany — wyślij go graczowi', 'success'); }
                    catch (er) { App.showModal(`Link dla: ${g.name}`, `<p>Skopiuj ten link i wyślij graczowi:</p><input class="on-copybox" readonly value="${esc(url)}" onclick="this.select()">`, '<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>'); }
                } else if (act === 'qr') showQR(g);
                else if (act === 'preview') window.open(`/gracz?jako=${encodeURIComponent(g.id)}`, '_blank');
                else if (act === 'lan-on' || act === 'lan-off') {
                    const j = await api('api/online/siec', { wlacz: act === 'lan-on' });
                    App.showToast(j.siec ? 'Stół otwarty dla graczy w sieci domowej' : 'Dostęp z sieci zamknięty', 'success');
                    setTimeout(activate, 700);
                } else if (act === 'pw') passwordDialog();
                else if (act === 'mgsess') mgSessions();
                else if (act === 'help') helpDialog();
                else if (act === 'logout') { await StorageManager.flushSync(); await api('api/logout', {}); location.href = '/logowanie'; }
                else if (act === 'live-text') {
                    const title = document.getElementById('on-live-title').value.trim(), text = document.getElementById('on-live-text').value.trim();
                    if (!text && !title) { App.showToast('Wpisz tekst do pokazania', 'warning'); return; }
                    await showText(title, text);
                } else if (act === 'live-img') document.getElementById('on-live-file').click();
                else if (act === 'live-clear') { await api('api/online/live', { clear: true }); info.live = null; renderLive(); }
            } catch (er) { App.showToast(er.message, 'error'); }
        };
        el.onchange = (e) => {
            if (e.target.id === 'on-adr') { info.adrIdx = +e.target.value; try { localStorage.setItem('dnd5e_meta_lan_ip', lanIp()); } catch (er) {} render(); checkLan(); return; }
            if (e.target.id === 'on-mood-file') { const fs = [...e.target.files]; e.target.value = ''; if (fs.length) uploadAudio(fs); return; }
            if (e.target.id === 'on-mood-vol') { mood.vol = +e.target.value; if (mood.now) setMood({ kind: mood.now.kind, id: mood.now.id, vol: mood.vol, onlyVol: true }); return; }
            if (e.target.id === 'on-live-file') { const f = e.target.files[0]; e.target.value = ''; if (f) sendImage(f); return; }
            const f = e.target.dataset.f, seat = e.target.closest('[data-seat]')?.dataset.seat;
            if (!f || !seat) return;
            saveSeat(seat, f === 'charId');
        };
        el.oninput = (e) => {
            if (e.target.dataset.f !== 'name') return;
            const seat = e.target.closest('[data-seat]').dataset.seat;
            clearTimeout(saveT); saveT = setTimeout(() => saveSeat(seat, false), 600);
        };
    }
    function confirmDelete(list) {
        if (!list.length) return;
        const on = new Set((onlineNow.gracze || []).map(x => x.id));
        const one = list.length === 1 ? list[0] : null;
        App.showModal(one ? `Usunąć gracza „${one.name}”?` : `Usunąć ${list.length} puste miejsca?`, `
            <p>${one ? 'Jego link i kod przestaną działać' : 'Linki i kody tych miejsc przestaną działać'}${list.some(x => on.has(x.id)) ? ', a połączony gracz zostanie od razu rozłączony' : ''}.</p>
            <p class="modal-hint">Postać zostaje w drużynie — usuwasz tylko miejsce przy stole. Zawsze możesz dodać gracza ponownie.</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-danger" id="on-del-go"><i class="fa-solid fa-user-xmark"></i> Usuń</button>`);
        document.getElementById('on-del-go').onclick = async () => {
            try {
                for (const g of list) await api('api/online/gracz/usun', { id: g.id });
                const ids = new Set(list.map(x => x.id));
                info.gracze = (info.gracze || []).filter(x => !ids.has(x.id));
                App.closeModal(); renderSeatsOnly();
                App.showToast(one ? `Usunięto: ${one.name}` : `Usunięto ${list.length} miejsca`, 'success');
            } catch (er) { App.showToast(er.message, 'error'); }
        };
    }
    async function saveSeat(id, rerender) {
        const card = document.querySelector(`[data-seat="${id}"]`); if (!card) return;
        const g = info.gracze.find(x => x.id === id); if (!g) return;
        const body = { id, name: card.querySelector('[data-f="name"]').value, charId: card.querySelector('[data-f="charId"]').value || null, campaignId: App.getActiveCampaignId() };
        try { const j = await api('api/online/gracz', body); Object.assign(g, j.gracz); if (rerender) renderSeatsOnly(); }
        catch (er) { App.showToast(er.message, 'error'); }
    }
    function showQR(g) {
        const url = linkOf(g);
        App.showModal(`Kod QR — ${g.name}`, `<div class="on-qr"><div id="on-qr-box"></div><p>Gracz skanuje kod aparatem telefonu i od razu jest przy stole.</p><code>${esc(url)}</code></div>`, '<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>');
        const box = document.getElementById('on-qr-box');
        if (window.QRCode) { new QRCode(box, { text: url, width: 220, height: 220, colorDark: '#1a0f05', colorLight: '#f6ead0' }); }
        else box.innerHTML = '<p class="on-muted">Kod QR potrzebuje internetu przy pierwszym użyciu. Skopiuj link zamiast tego.</p>';
    }
    function passwordDialog() {
        const need = info.hasDm && !info.lokalny;
        App.showModal(info.hasDm ? 'Zmień hasło Mistrza Gry' : 'Ustaw hasło Mistrza Gry', `
            ${need ? '<div class="form-group"><label>Obecne hasło</label><input type="password" id="on-pw0" autocomplete="current-password"></div>' : ''}
            <div class="form-group"><label>Nowe hasło (min. 8 znaków)</label><input type="password" id="on-pw1" autocomplete="new-password"><div class="on-pw-meter"><i id="on-pw-bar"></i></div><small id="on-pw-msg" class="on-pw-msg"></small></div>
            <div class="form-group"><label>Powtórz hasło</label><input type="password" id="on-pw2" autocomplete="new-password"></div>
            <p class="modal-hint">Hasłem logujesz się do panelu MG z innego urządzenia albo gdy panel stoi na serwerze. Na tym komputerze panel otwiera się bez hasła.
            Po zmianie hasła wszystkie inne urządzenia MG zostaną wylogowane. Po 5 błędnych hasłach logowanie MG z danego adresu blokuje się na kilka minut (coraz dłużej).</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="on-pw-go"><i class="fa-solid fa-key"></i> Zapisz hasło</button>`);
        // podpowiedź siły hasła (długość + różne rodzaje znaków)
        const pw1 = document.getElementById('on-pw1');
        pw1.addEventListener('input', () => {
            const v = pw1.value; let sc = 0;
            if (v.length >= 8) sc++; if (v.length >= 12) sc++; if (v.length >= 16) sc++;
            if (/[a-ząćęłńóśźż]/.test(v) && /[A-ZĄĆĘŁŃÓŚŹŻ]/.test(v)) sc++; if (/\d/.test(v)) sc++; if (/[^\w\sąćęłńóśźżĄĆĘŁŃÓŚŹŻ]/.test(v)) sc++;
            const lvl = v.length < 8 ? 0 : Math.min(3, Math.floor(sc / 2));
            const bar = document.getElementById('on-pw-bar'); bar.style.width = `${v ? 15 + lvl * 28 : 0}%`; bar.dataset.l = lvl;
            document.getElementById('on-pw-msg').textContent = !v ? '' : ['Za krótkie — co najmniej 8 znaków', 'Słabe — dodaj długości albo cyfr i znaków', 'Dobre', 'Mocne'][lvl];
        });
        document.getElementById('on-pw-go').onclick = async () => {
            const a = document.getElementById('on-pw1').value, b = document.getElementById('on-pw2').value;
            if (a !== b) { App.showToast('Hasła się różnią', 'warning'); return; }
            try { await api('api/online/haslo', { haslo: a, stare: document.getElementById('on-pw0')?.value || '' }); App.closeModal(); App.showToast('Hasło MG zapisane', 'success'); activate(); }
            catch (er) { App.showToast(er.message, 'error'); }
        };
    }
    // gdzie MG jest zalogowany + wylogowanie pozostałych urządzeń
    async function mgSessions() {
        let L = [];
        try { L = (await api('api/online/mg-sesje')).sesje || []; } catch (er) { App.showToast(er.message, 'error'); return; }
        const dev = (ua) => { ua = ua || ''; const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iPhone / iPad' : /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : 'urządzenie';
            const br = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'przeglądarka'; return `${br} · ${os}`; };
        const when = (t) => t ? new Date(t).toLocaleString(window.LOC || 'pl-PL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
        App.showModal('Urządzenia zalogowane jako Mistrz Gry', `
            <p class="modal-hint">Ten komputer z panelem nie potrzebuje logowania i nie ma go na liście. Sesja MG wygasa po 14 dniach albo po 3 dniach nieużywania.</p>
            <div class="on-sess">${L.length ? L.map(x => `<div class="on-sess-row ${x.to ? 'me' : ''}"><i class="fa-solid ${/Android|iPhone|iPad/.test(x.ua || '') ? 'fa-mobile-screen' : 'fa-laptop'}"></i><div><b>${esc(dev(x.ua))}${x.to ? ' <small>(to urządzenie)</small>' : ''}</b><small>adres ${esc(x.ip || '?')} · zalogowano ${when(x.od)} · ostatnio ${when(x.ostatnio)}</small></div></div>`).join('') : '<p class="ai-muted">Nikt nie jest zalogowany jako MG z innego urządzenia.</p>'}</div>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>${L.some(x => !x.to) ? '<button class="btn-primary" id="on-sess-out"><i class="fa-solid fa-right-from-bracket"></i> Wyloguj pozostałe</button>' : ''}`);
        const b = document.getElementById('on-sess-out');
        if (b) b.onclick = async () => { try { const j = await api('api/online/mg-wyloguj', {}); App.closeModal(); App.showToast(`Wylogowano urządzenia: ${j.n}`, 'success'); } catch (er) { App.showToast(er.message, 'error'); } };
    }
    function helpDialog() {
        App.showModal('Panel na własnym serwerze', `<div class="on-help">
            <p>Panel można postawić na dowolnym serwerze z <b>Node.js 18+</b> (VPS, Raspberry Pi, NAS) albo w Dockerze i wejść na niego pod własnym adresem, np. <code>https://dnd.twojadomena.pl</code>.</p>
            <ol>
                <li>Skopiuj cały folder panelu na serwer (bez folderów <i>kopie</i> i <i>dane</i>, jeśli chcesz zacząć od zera — albo z nimi, żeby przenieść kampanie).</li>
                <li>Uruchom: <code>PANEL_TRYB=serwer PANEL_HASLO_MG=twoje-haslo PANEL_URL=https://dnd.twojadomena.pl node serwer.js</code></li>
                <li>Postaw przed nim serwer z HTTPS (np. Caddy) kierujący na port 8080.</li>
            </ol>
            <p>Dokładna instrukcja (Docker, Caddy, nginx, autostart) jest w pliku <b>SERWER.md</b> w folderze panelu.</p></div>`,
            '<button class="btn-primary" onclick="App.closeModal()">Rozumiem</button>');
    }

    // ---------- „pokaż graczom” (używane też z Atlasu) ----------
    async function showText(title, text) {
        if (!available()) { App.showToast('Gracze nie są połączeni — uruchom panel przez serwer', 'warning'); return false; }
        const j = await api('api/online/live', { kind: 'tekst', title, text });
        if (info) info.live = j.live; renderLive();
        App.showToast('Gracze widzą tekst na swoich ekranach', 'success');
        return true;
    }
    async function showMap(mapId, levelId, title) {
        if (!available()) return false;
        try { const j = await api('api/online/live', { kind: 'mapa', mapId, levelId: levelId || null, title: title || '' }); if (info) info.live = j.live; renderLive(); return true; }
        catch (e) { return false; }
    }
    // mapa, na której MG teraz prowadzi grę — gracze z włączonym „podążaj” przechodzą na nią sami
    let lastScene = '';
    async function setScene(mapId, levelId, lead = true) {
        if (!available()) return false;
        const key = `${mapId}|${levelId || ''}|${lead}`;
        if (key === lastScene) return true;
        lastScene = key;
        try { await api('api/online/scena', { mapId, levelId: levelId || null, lead }); return true; }
        catch (e) {
            lastScene = '';
            if (/adresu|404/i.test(e.message) && !setScene.warned) { setScene.warned = true; App.showToast('Serwer ma starą wersję — zamknij go i uruchom panel ponownie, żeby gracze widzieli Twoją mapę', 'warning'); }
            return false;
        }
    }
    async function ping(mapId, levelId, x, y) {
        if (!available()) return false;
        try { await api('api/wskaz', { mapId, levelId: levelId || null, x, y }); return true; } catch (e) { return false; }
    }
    function sendImage(file) {
        const rd = new FileReader();
        rd.onload = () => {
            const img = new Image();
            img.onload = async () => {
                const k = Math.min(1, 1800 / Math.max(img.naturalWidth, img.naturalHeight));
                const cv = document.createElement('canvas'); cv.width = Math.round(img.naturalWidth * k); cv.height = Math.round(img.naturalHeight * k);
                cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
                try {
                    const j = await api('api/online/live', { kind: 'obraz', title: document.getElementById('on-live-title')?.value.trim() || file.name.replace(/\.[^.]+$/, ''), url: cv.toDataURL('image/jpeg', 0.85) });
                    if (info) info.live = j.live; renderLive();
                    App.showToast('Gracze widzą obraz', 'success');
                } catch (e) { App.showToast(e.message, 'error'); }
            };
            img.src = rd.result;
        };
        rd.readAsDataURL(file);
    }

    // ---------- okienko czatu z graczami: okrągły przycisk obok kości (tylko u MG) ----------
    let unread = 0;
    const chatOpen = () => document.body.classList.contains('chat-open');
    function chatMount() {
        if (document.getElementById('chat-fab') || !available()) return;
        const fab = document.createElement('button');
        fab.id = 'chat-fab'; fab.className = 'dice-fab chat-fab'; fab.type = 'button'; fab.title = 'Czat i rzuty graczy (C)';
        fab.innerHTML = '<i class="fa-solid fa-comments"></i><span id="chat-fab-n" class="chat-fab-n" hidden></span>';
        const pop = document.createElement('div');
        pop.id = 'chat-pop'; pop.className = 'dice-popover chat-pop'; pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-label', 'Czat z graczami');
        pop.innerHTML = `<div class="dice-popover-head"><h3 class="dice-title"><i class="fa-solid fa-comments"></i> Czat i rzuty stołu <span id="online-conn" class="on-conn"></span></h3><button class="dice-popover-close" data-chat-close title="Zamknij (Esc)"><i class="fa-solid fa-xmark"></i></button></div>
            <div class="on-log" id="on-log"></div>
            <form class="on-say ${sayTo ? 'priv' : ''}" id="on-say"><select id="on-to" title="Do kogo: wszyscy albo prywatnie do jednego gracza">${toOptions()}</select><input id="on-say-t" maxlength="600" autocomplete="off" placeholder="Napisz do graczy… albo rzut, np. 2k6+3"><button class="btn-primary btn-small" type="submit" title="Wyślij"><i class="fa-solid fa-paper-plane"></i></button></form>
            <label class="on-chk"><input type="checkbox" id="on-hidden"> rzuty MG ukryte przed graczami</label>`;
        document.body.append(pop, fab);
        fab.onclick = () => toggleChat();
        pop.addEventListener('click', (e) => {
            if (e.target.closest('[data-chat-close]')) { toggleChat(false); return; }
            const r = e.target.closest('[data-on="reply"]');
            if (r) { sayTo = r.dataset.pid; refreshTo(); document.getElementById('on-say-t')?.focus(); }
        });
        pop.addEventListener('change', (e) => { if (e.target.id === 'on-to') { sayTo = e.target.value; refreshTo(); document.getElementById('on-say-t')?.focus(); } });
        pop.querySelector('#on-say').onsubmit = async (e) => {
            e.preventDefault();
            const inp = document.getElementById('on-say-t'), v = inp.value.trim(); if (!v) return;
            const isRoll = /^[+-]?\d*[kd]\d+([+-](\d*[kd]\d+|\d+))*$/i.test(v.replace(/\s+/g, ''));
            try {
                const priv = sayTo ? { szept: true, dla: sayTo } : {};
                await api('api/dziennik', isRoll ? { typ: 'rzut', wyr: v, ukryty: document.getElementById('on-hidden').checked, ...priv } : { typ: 'wiad', tekst: v, ...priv });
                inp.value = '';
            } catch (er) { App.showToast(er.message, 'error'); }
        };
        // zamykanie: klik obok albo Esc; skrót C otwiera
        document.addEventListener('mousedown', (e) => { if (chatOpen() && !e.target.closest('#chat-pop, #chat-fab, .modal, .modal-backdrop, .ask-bg')) toggleChat(false); });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && chatOpen()) { toggleChat(false); return; }
            if (e.key.toLowerCase() === 'c' && !e.ctrlKey && !e.metaKey && !e.altKey && !e.target.closest('input, textarea, select, [contenteditable]')) { e.preventDefault(); toggleChat(); }
        });
        refreshTo(); renderLog(); badge();
    }
    function toggleChat(force) {
        const open = force === undefined ? !chatOpen() : force;
        if (open && document.body.classList.contains('dice-open')) document.querySelector('#dice-roller [data-action="toggle-dice"]')?.click();
        document.body.classList.toggle('chat-open', open);
        if (open) { unread = 0; chatBadge(); renderLog(); setTimeout(() => { if (matchMedia('(pointer: fine)').matches) document.getElementById('on-say-t')?.focus(); }, 80); }
    }
    function chatBadge() { const n = document.getElementById('chat-fab-n'); if (n) { n.hidden = !unread; n.textContent = unread > 9 ? '9+' : String(unread); } }

    function init() {
        if (!StorageManager.syncAvailable()) return;
        const go = () => { if ((StorageManager._sync.proto || 0) >= 3) { connect(); chatMount(); } };
        window.addEventListener('panel-sync-ready', go);
        if (!StorageManager._sync.hold) go();
    }
    document.addEventListener('DOMContentLoaded', () => setTimeout(init, 200));

    return { toggleChat, activate, showText, showMap, setScene, ping, available, connect, rolls: () => log.filter(e => e.typ === 'rzut'), get onlineNow() { return onlineNow; } };
})();

window.OnlineModule = OnlineModule;
