// ============================================================
// CampaignsModule — Campaign management subtabs
// ============================================================
const CampaignsModule = (() => {
    let currentSubtab = 'overview';
    let currentMapView = 'world';
    let currentMapZoom = 1;
    let mapEditMode = 'view'; // 'view', 'move', 'link-solid', 'link-dashed'
    let linkStartPin = null;

    const MapIcons = {
        capital: { name: 'Stolica', icon: '<i class="fa-solid fa-chess-rook"></i>' },
        city: { name: 'Miasto', icon: '<i class="fa-solid fa-city"></i>' },
        town: { name: 'Miasteczko', icon: '<i class="fa-solid fa-house-chimney-window"></i>' },
        village: { name: 'Wioska', icon: '<i class="fa-solid fa-house"></i>' },
        fortress: { name: 'Twierdza', icon: '<i class="fa-brands fa-fort-awesome"></i>' },
        castle: { name: 'Zamek', icon: '<i class="fa-solid fa-chess-rook"></i>' },
        ruin: { name: 'Ruiny', icon: '<i class="fa-solid fa-monument"></i>' },
        cave: { name: 'Jaskinia', icon: '<i class="fa-solid fa-mound"></i>' },
        forest: { name: 'Las', icon: '<i class="fa-solid fa-tree"></i>' },
        mountain: { name: 'Góra', icon: '<i class="fa-solid fa-mountain"></i>' },
        sea: { name: 'Morze', icon: '<i class="fa-solid fa-water"></i>' },
        temple: { name: 'Świątynia', icon: '<i class="fa-solid fa-place-of-worship"></i>' },
        market: { name: 'Rynek', icon: '<i class="fa-solid fa-scale-balanced"></i>' },
        guild: { name: 'Gildia', icon: '<i class="fa-solid fa-shield-halved"></i>' },
        tavern: { name: 'Karczma', icon: '<i class="fa-solid fa-beer-mug-empty"></i>' },
        hideout: { name: 'Kryjówka', icon: '<i class="fa-solid fa-mask"></i>' },
        dungeon: { name: 'Loch', icon: '<i class="fa-solid fa-dungeon"></i>' },
        wilderness: { name: 'Dzicz', icon: '<i class="fa-solid fa-leaf"></i>' },
        plane: { name: 'Inny Wymiar', icon: '<i class="fa-solid fa-meteor"></i>' },
        other: { name: 'Inne', icon: '<i class="fa-solid fa-location-dot"></i>' }
    };

    // ── Public API ──────────────────────────────────────────
    function init() {
        // Subtab switching
        document.querySelectorAll('[data-campaign-tab]').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('[data-campaign-tab]').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentSubtab = btn.dataset.campaignTab;
                renderSubtab(currentSubtab);
            });
        });

        // Add session / location buttons
        const btnAddSession = document.getElementById('btn-add-session');
        if (btnAddSession) btnAddSession.addEventListener('click', showAddSessionModal);

        const btnAddLocation = document.getElementById('btn-add-location');
        if (btnAddLocation) btnAddLocation.addEventListener('click', () => Atlas.addHere());

        const btnAddQuest = document.getElementById('btn-add-quest');
        if (btnAddQuest) btnAddQuest.addEventListener('click', showAddQuestModal);
    }

    function activate() {
        renderSubtab(currentSubtab);
    }

    // ── Subtab router ───────────────────────────────────────
    function renderSubtab(tab) {
        currentSubtab = tab;
        const container = document.getElementById('campaign-content');
        if (!container) return;

        switch (tab) {
            case 'overview':    container.innerHTML = renderOverview();   break;
            case 'maps':        container.innerHTML = Atlas.renderMap();  break;
            case 'sessions':    container.innerHTML = renderSessions();   break;
            case 'locations':   container.innerHTML = Atlas.renderGazetteer(); break;
            case 'quests':      container.innerHTML = renderQuests();     break;
            case 'plot':        container.innerHTML = renderPlot();       break;
            case 'campaign-notes': container.innerHTML = renderNotes();   break;
            default:            container.innerHTML = renderOverview();
        }

        // Post-render bindings
        _bindAfterRender(tab);

        // Auto-inject mock locations if maps or locations are empty
        if (tab === 'maps' || tab === 'locations') {
            injectMockLocationsIfNeeded();
        }
    }

    function injectMockLocationsIfNeeded(force) {
        const cId = App.getActiveCampaignId();
        const P = window.PANEL_PAKIET;
        if (!cId || !P || typeof P.lokacje !== 'function') return;
        // Przykładowy świat z pakietu dopisujemy automatycznie tylko do jego kampanii;
        // w innych kampaniach można go wczytać przyciskiem.
        if (!force && cId !== P.kampania) return;
        const locs = P.lokacje(StorageManager.getLocations(cId) || []);
        if (locs) {
            StorageManager.saveLocations(cId, locs);
            App.showToast('Wygenerowano/Zaktualizowano Lokacje Kampanii', 'success');
            if (currentSubtab === 'maps' || currentSubtab === 'locations') renderSubtab(currentSubtab);
        }
    }

    // ── Overview ────────────────────────────────────────────
    function renderOverview() {
        const cId = App.getActiveCampaignId();
        if (!cId) return _emptyState('Najpierw wybierz kampanię');

        const campaigns = StorageManager.getCampaigns();
        const campaign = campaigns.find(c => c.id === cId);
        if (!campaign) return _emptyState('Nie znaleziono kampanii');

        const sessions   = StorageManager.getSessions(cId)   || [];
        const characters = StorageManager.getCharacters(cId)  || [];
        const npcs       = StorageManager.getNPCs(cId)        || [];

        const created = campaign.createdAt
            ? new Date(campaign.createdAt).toLocaleDateString(window.LOC || 'pl-PL')
            : '—';

        return `
            <div class="campaign-overview" style="background: linear-gradient(145deg, rgba(20,20,20,0.8) 0%, rgba(30,10,10,0.8) 100%); padding: 20px; border-radius: var(--border-radius); border: 1px solid var(--border-color); box-shadow: 0 4px 15px rgba(0,0,0,0.5);">
                <h2 style="color: var(--text-gold); font-family: var(--font-heading); text-shadow: 0 0 10px rgba(255, 186, 8, 0.3); border-bottom: 1px dashed var(--border-color); padding-bottom: 10px;">${_esc(campaign.name)}</h2>
                <p style="color: var(--text-parchment); line-height: 1.6; margin-top: 15px;">${_esc(campaign.description || 'Brak opisu.')}</p>
                <div class="form-row" style="margin-top:1.5rem; gap: 20px;">
                    <div class="form-group" style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; border-left: 4px solid var(--sapphire-light);">
                        <label style="color: var(--sapphire-light);">Świat</label>
                        <span style="font-size: 1.2rem; font-weight: bold; color: white;">${_esc(campaign.world || '—')}</span>
                    </div>
                    <div class="form-group" style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; border-left: 4px solid var(--emerald-light);">
                        <label style="color: var(--emerald-light);">Utworzona</label>
                        <span style="font-size: 1.2rem; font-weight: bold; color: white;">${created}</span>
                    </div>
                </div>
                <div class="form-row" style="margin-top:1rem; gap: 20px;">
                    <div class="form-group" style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; border-top: 3px solid var(--gold-light); text-align: center;">
                        <label style="color: var(--gold-light);">Sesje</label>
                        <span style="font-size: 1.8rem; font-weight: bold; color: white;">${sessions.length}</span>
                    </div>
                    <div class="form-group" style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; border-top: 3px solid var(--crimson-light); text-align: center;">
                        <label style="color: var(--crimson-light);">Bohaterowie</label>
                        <span style="font-size: 1.8rem; font-weight: bold; color: white;">${characters.length}</span>
                    </div>
                    <div class="form-group" style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; border-top: 3px solid var(--amethyst-light); text-align: center;">
                        <label style="color: var(--amethyst-light);">NPC</label>
                        <span style="font-size: 1.8rem; font-weight: bold; color: white;">${npcs.length}</span>
                    </div>
                </div>
            </div>`;
    }

    // ── Sessions ────────────────────────────────────────────
    function renderSessions() {
        const cId = App.getActiveCampaignId();
        if (!cId) return _emptyState('Najpierw wybierz kampanię');

        const sessions = StorageManager.getSessions(cId) || [];

        if (sessions.length === 0) {
            return _emptyState('Brak sesji. Kliknij <b>+ Nowa sesja</b>, aby dodać pierwszą.');
        }

        // Sort newest first
        const sorted = [...sessions].sort((a, b) => (b.date || '').localeCompare(a.date || ''));

        return sorted.map((s, i) => {
            // Alternate colors for sessions
            const colors = ['var(--blood-red)', 'var(--sapphire-light)', 'var(--gold-light)', 'var(--emerald-light)', 'var(--amethyst-light)'];
            const stripeColor = colors[i % colors.length];
            return `
            <div class="session-entry" data-session-id="${s.id}" style="border-left: 4px solid ${stripeColor}; background: rgba(0,0,0,0.2); transition: all 0.3s ease;">
                <div class="session-date" style="color: ${stripeColor}; font-weight: bold;">${_esc(s.date || '')}</div>
                <div class="session-title" style="color: var(--text-parchment); font-size: 1.1rem; text-shadow: 0 0 5px rgba(255,255,255,0.1);">${_esc(s.title || 'Untitled Session')}</div>
                <div class="session-summary" style="color: var(--text-muted); margin-top: 5px;">${_esc(s.summary || '')}</div>
                <div class="session-actions hidden" style="margin-top: 15px; padding-top: 10px; border-top: 1px dashed var(--border-color);">
                    <div class="form-group">
                        <label>Data</label>
                        <input type="date" class="edit-session-date" value="${_esc(s.date || '')}">
                    </div>
                    <div class="form-group">
                        <label>Tytuł</label>
                        <input type="text" class="edit-session-title" value="${_esc(s.title || '')}">
                    </div>
                    <div class="form-group">
                        <label>Podsumowanie</label>
                        <textarea class="edit-session-summary" rows="4">${_esc(s.summary || '')}</textarea>
                    </div>
                    <div style="display:flex;gap:.5rem;margin-top:.5rem;">
                        <button class="btn-primary btn-small btn-save-session">Zapisz</button>
                        <button class="btn-danger btn-small btn-delete-session">Usuń</button>
                    </div>
                </div>
            </div>`;
        }).join('');
    }

    // ── Plot ────────────────────────────────────────────────
    function renderPlot() {
        const cId = App.getActiveCampaignId();
        if (!cId) return _emptyState('Najpierw wybierz kampanię');

        const campaigns = StorageManager.getCampaigns();
        const campaign = campaigns.find(c => c.id === cId);
        const plotContent = campaign ? (campaign.plot || '') : '';

        return `
            <div class="form-group">
                <h3 class="form-section-title">Plot Notes & Story Arcs</h3>
                <textarea id="plot-textarea" rows="18" style="width:100%;resize:vertical;"
                    placeholder="Wątki fabularne, łuki opowieści, linie zadań…">${_esc(plotContent)}</textarea>
                <button class="btn-primary btn-small" id="btn-save-plot" style="margin-top:.5rem;">Zapisz fabułę</button>
            </div>`;
    }

    // ── Campaign Notes ──────────────────────────────────────
    function renderNotes() {
        const cId = App.getActiveCampaignId();
        if (!cId) return _emptyState('Najpierw wybierz kampanię');

        const campaigns = StorageManager.getCampaigns();
        const campaign = campaigns.find(c => c.id === cId);
        const notesContent = campaign ? (campaign.dmNotes || '') : '';

        return `
            <div class="form-group">
                <h3 class="form-section-title">Notatki MG</h3>
                <textarea id="dm-notes-textarea" rows="18" style="width:100%;resize:vertical;"
                    placeholder="Ogólne notatki, przypomnienia, sekrety…">${_esc(notesContent)}</textarea>
                <button class="btn-primary btn-small" id="btn-save-dm-notes" style="margin-top:.5rem;">Zapisz notatki</button>
            </div>`;
    }

    // ── Quests ──────────────────────────────────────────────
    function renderQuests() {
        return QuestBoard.render();
    }

    function showAddQuestModal() {
        if (!App.getActiveCampaignId()) { App.showToast('Najpierw wybierz kampanię', 'warning'); return; }
        QuestBoard.editor(null);
    }

    function _bindQuestInteractions() {
        const container = document.getElementById('campaign-content');
        if (container) QuestBoard.bind(container, () => renderSubtab('quests'));
    }

    // ── Add Session Modal ───────────────────────────────────
    function showAddSessionModal() {
        const cId = App.getActiveCampaignId();
        if (!cId) { App.showToast('Najpierw wybierz kampanię', 'warning'); return; }

        const today = new Date().toISOString().slice(0, 10);

        const body = `
            <div class="form-group">
                <label for="modal-session-date">Data</label>
                <input type="date" id="modal-session-date" value="${today}">
            </div>
            <div class="form-group">
                <label for="modal-session-title">Tytuł</label>
                <input type="text" id="modal-session-title" placeholder="Tytuł sesji…">
            </div>
            <div class="form-group">
                <label for="modal-session-summary">Podsumowanie</label>
                <textarea id="modal-session-summary" rows="5" placeholder="Co się wydarzyło…"></textarea>
            </div>`;

        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-primary" id="btn-confirm-add-session">Dodaj sesję</button>`;

        App.showModal('Add Session', body, footer);

        // Wait for DOM then bind
        setTimeout(() => {
            const btn = document.getElementById('btn-confirm-add-session');
            if (btn) btn.addEventListener('click', _handleAddSession);
        }, 50);
    }

    function _handleAddSession() {
        const cId = App.getActiveCampaignId();
        const date    = document.getElementById('modal-session-date').value;
        const title   = document.getElementById('modal-session-title').value.trim();
        const summary = document.getElementById('modal-session-summary').value.trim();

        if (!title) { App.showToast('Tytuł jest wymagany', 'error'); return; }

        const session = {
            id: StorageManager.generateId(),
            date,
            title,
            summary
        };

        StorageManager.saveSession(cId, session);
        App.closeModal();
        App.showToast('Sesja dodana', 'success');
        renderSubtab('sessions');
    }

    // ── Post-render bindings ────────────────────────────────
    function _bindAfterRender(tab) {
        if (tab === 'sessions') _bindSessionInteractions();
        if (tab === 'locations') Atlas.bindGazetteer(document.getElementById('campaign-content'), () => renderSubtab('locations'));
        if (tab === 'quests') _bindQuestInteractions();
        if (tab === 'plot') _bindPlotSave();
        if (tab === 'campaign-notes') _bindNotesSave();
        if (tab === 'maps') Atlas.bindMap(document.getElementById('campaign-content'), () => renderSubtab('maps'));

        // Header: title + only the action that fits the current view
        const titles = {
            overview: ['fa-eye', 'Przegląd kampanii'], maps: ['fa-map', 'Atlas — mapy'], sessions: ['fa-calendar-days', 'Sesje'],
            locations: ['fa-location-dot', 'Lokacje'], plot: ['fa-book-open', 'Fabuła'], quests: ['fa-scroll', 'Zadania'],
            'campaign-notes': ['fa-pen-to-square', 'Notatki Mistrza Gry']
        };
        const [icon, label] = titles[tab] || titles.overview;
        const h2 = document.querySelector('#tab-campaign .tab-header h2');
        if (h2) h2.innerHTML = `<i class="fa-solid ${icon}"></i> ${label}`;
        const show = (id, on) => document.getElementById(id)?.classList.toggle('hidden', !on);
        show('btn-add-session', tab === 'sessions' || tab === 'overview');
        show('btn-add-location', tab === 'locations' || tab === 'maps');
        show('btn-add-quest', tab === 'quests');
        if (window.App && App.markNav && App.currentTab === 'campaign') App.markNav('campaign', tab);
    }

    function _bindSessionInteractions() {
        document.querySelectorAll('.session-entry').forEach(entry => {
            // Click title/date area to toggle edit
            const titleEl = entry.querySelector('.session-title');
            if (titleEl) {
                titleEl.style.cursor = 'pointer';
                titleEl.addEventListener('click', () => {
                    const actions = entry.querySelector('.session-actions');
                    if (actions) actions.classList.toggle('hidden');
                });
            }

            // Save
            const saveBtn = entry.querySelector('.btn-save-session');
            if (saveBtn) {
                saveBtn.addEventListener('click', () => {
                    const cId = App.getActiveCampaignId();
                    const sId = entry.dataset.sessionId;
                    const sessions = StorageManager.getSessions(cId) || [];
                    const session = sessions.find(s => s.id === sId);
                    if (!session) return;

                    session.date    = entry.querySelector('.edit-session-date').value;
                    session.title   = entry.querySelector('.edit-session-title').value.trim();
                    session.summary = entry.querySelector('.edit-session-summary').value.trim();

                    StorageManager.saveSessions(cId, sessions);
                    App.showToast('Sesja zaktualizowana', 'success');
                    renderSubtab('sessions');
                });
            }

            // Delete
            const delBtn = entry.querySelector('.btn-delete-session');
            if (delBtn) {
                delBtn.addEventListener('click', () => {
                    const cId = App.getActiveCampaignId();
                    const sId = entry.dataset.sessionId;
                    const sessions = (StorageManager.getSessions(cId) || []).filter(s => s.id !== sId);
                    StorageManager.saveSessions(cId, sessions);
                    App.showToast('Sesja usunięta', 'success');
                    renderSubtab('sessions');
                });
            }
        });
    }

    function _bindPlotSave() {
        const btn = document.getElementById('btn-save-plot');
        if (btn) {
            btn.addEventListener('click', () => {
                const cId = App.getActiveCampaignId();
                const campaigns = StorageManager.getCampaigns();
                const c = campaigns.find(x => x.id === cId);
                if (c) {
                    c.plot = document.getElementById('campaign-plot-editor').value;
                    StorageManager.saveCampaigns(campaigns);
                    App.showToast('Zapisano fabułę', 'success');
                }
            });
        }
    }

    function _bindNotesSave() {
        const btn = document.getElementById('btn-save-notes');
        if (btn) {
            btn.addEventListener('click', () => {
                const cId = App.getActiveCampaignId();
                const campaigns = StorageManager.getCampaigns();
                const c = campaigns.find(x => x.id === cId);
                if (c) {
                    c.dmNotes = document.getElementById('campaign-notes-editor').value;
                    StorageManager.saveCampaigns(campaigns);
                    App.showToast('Zapisano notatki', 'success');
                }
            });
        }
    }

    
    function _emptyState(message) {
        return `<div style="padding:40px 20px; text-align:center; color:var(--text-muted); font-style:italic; background:rgba(0,0,0,0.2); border-radius:8px;">${message}</div>`;
    }
    
    function _esc(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function openSubtab(tab) {
        document.querySelectorAll('[data-campaign-tab]').forEach(b => b.classList.toggle('active', b.dataset.campaignTab === tab));
        renderSubtab(tab);
    }

    return {
        init,
        activate,
        openSubtab,
        getSubtab: () => currentSubtab,
        loadSampleWorld: () => { injectMockLocationsIfNeeded(true); renderSubtab(currentSubtab); }
    };
})();
window.CampaignsModule = CampaignsModule;
