/* ============================================
   Muzyka i nastrój: tła dźwiękowe sterowane przez Mistrza Gry.
   - MG wgrywa własne nagrania (mp3/ogg…) — leżą na jego serwerze,
   - stan idzie do wszystkich przez serwer (zdarzenie „nastroj”); każdy słuchacz
     ma swoją głośność i wyciszenie (zapamiętane w przeglądarce).
   ============================================ */
const Nastroj = (() => {
    const PRESETS = {};   // wbudowane nastroje usunięte — gra tylko muzyka wgrana przez MG
    let audioEl = null, state = null;
    const pref = (k, d) => { try { const v = localStorage.getItem('nastroj_' + k); return v == null ? d : v; } catch (e) { return d; } };
    const setPref = (k, v) => { try { localStorage.setItem('nastroj_' + k, String(v)); } catch (e) {} };
    let myVol = +pref('vol', 0.7), muted = pref('mute', '0') === '1';
    const listeners = new Set();
    const emit = () => listeners.forEach(f => { try { f(info()); } catch (e) {} });

    const outVol = () => muted ? 0 : (state?.vol ?? 0.8) * myVol;

    // ---------- odtwarzanie ----------
    function stopAll(fade = 1) {
        if (audioEl) { const a = audioEl; audioEl = null; const v0 = a.volume, t0 = Date.now(); const iv = setInterval(() => { const k = Math.min(1, (Date.now() - t0) / (fade * 1000)); a.volume = Math.max(0, v0 * (1 - k)); if (k >= 1) { clearInterval(iv); a.pause(); a.src = ''; } }, 50); }
    }
    let blocked = false;
    async function start() {
        if (!state || state.kind === 'stop') return;
        if (state.kind === 'plik' && state.id) {
            const a = new Audio(`api/audio/plik?id=${encodeURIComponent(state.id)}`);
            a.loop = state.loop !== false; a.volume = 0; a.preload = 'auto';
            audioEl = a;
            try { await a.play(); blocked = false; } catch (e) { blocked = true; emit(); return; }
            const target = outVol(), t0 = Date.now(); const iv = setInterval(() => { if (audioEl !== a) { clearInterval(iv); return; } const k = Math.min(1, (Date.now() - t0) / 1500); a.volume = Math.min(1, target * k); if (k >= 1) clearInterval(iv); }, 50);
        }
        emit();
    }
    // nowy stan od serwera
    function apply(s) {
        const same = state && s && state.kind === s.kind && state.id === s.id && state.t === s.t;
        const prevVol = state?.vol;
        state = s && s.kind === 'plik' ? s : null;
        if (same) { if (prevVol !== s.vol) refreshVol(); emit(); return; }
        stopAll(1.2);
        if (state && pref('on', '1') !== '0') setTimeout(start, 250);
        emit();
    }
    function refreshVol() {
        if (audioEl) audioEl.volume = Math.min(1, outVol());
        emit();
    }
    // klik słuchacza odblokowuje dźwięk (przeglądarki nie grają bez kliknięcia)
    async function unlock() { blocked = false; stopAll(0.1); await start(); }
    function setVolume(v) { myVol = Math.max(0, Math.min(1, +v)); setPref('vol', myVol); refreshVol(); }
    function setMuted(m) { muted = !!m; setPref('mute', muted ? '1' : '0'); refreshVol(); }
    const info = () => ({ state, playing: !!audioEl && !blocked, blocked, muted, vol: myVol, label: state ? (state.name || 'Nagranie') : null, icon: 'fa-music' });

    // mały pasek dla słuchacza (gracz i MG): co gra, głośność, wycisz
    function chipHTML() {
        const i = info(); if (!i.state) return '';
        return `<div class="nst-chip ${i.blocked ? 'blocked' : ''} ${i.muted ? 'muted' : ''}">
            ${i.blocked ? `<button class="nst-unlock" data-nst="unlock"><i class="fa-solid fa-volume-high"></i> Mistrz Gry włączył: ${i.label} — kliknij, by słyszeć</button>` : `<i class="fa-solid ${i.icon} nst-ic"></i><span class="nst-l">${i.label}</span>
            <button class="nst-b" data-nst="mute" title="${i.muted ? 'Włącz dźwięk' : 'Wycisz u siebie'}"><i class="fa-solid ${i.muted ? 'fa-volume-xmark' : 'fa-volume-low'}"></i></button>
            <input type="range" min="0" max="1" step="0.05" value="${i.vol}" data-nst="vol" title="Głośność u Ciebie">`}
        </div>`;
    }
    function mountChip(host) {
        const draw = () => { host.innerHTML = chipHTML(); host.hidden = !info().state; };
        listeners.add(draw); draw();
        host.addEventListener('click', (e) => { const b = e.target.closest('[data-nst]'); if (!b) return; if (b.dataset.nst === 'unlock') unlock(); if (b.dataset.nst === 'mute') setMuted(!muted); });
        host.addEventListener('input', (e) => { if (e.target.dataset.nst === 'vol') { myVol = +e.target.value; setPref('vol', myVol); if (audioEl) audioEl.volume = Math.min(1, outVol()); } });
    }
    // podgląd u MG bez wysyłania graczom (np. odsłuch nagrania)
    return { PRESETS, apply, unlock, setVolume, setMuted, info, onChange: (f) => listeners.add(f), mountChip, chipHTML };
})();
window.Nastroj = Nastroj;
// pasek „co gra” w rogu ekranu — u MG i u graczy
document.addEventListener('DOMContentLoaded', () => {
    const host = document.createElement('div');
    host.id = 'nst-host'; host.className = 'nst-host'; host.hidden = true;
    document.body.appendChild(host);
    Nastroj.mountChip(host);
});
