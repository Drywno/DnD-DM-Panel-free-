/* ============================================
   Okienka w stylu aplikacji zamiast systemowych confirm()/prompt() przeglądarki.
   Ask.confirm(tekst, {title, ok, cancel, danger}) → Promise<boolean>
   Ask.prompt(etykieta, wartość, {title, ok, type}) → Promise<string|null>
   ============================================ */
const Ask = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    function open({ title, text, input, ok = 'OK', cancel = 'Anuluj', danger = false, icon }) {
        return new Promise((resolve) => {
            document.querySelector('.ask-bg')?.remove();
            const bg = document.createElement('div');
            bg.className = 'ask-bg';
            bg.innerHTML = `<div class="ask" role="dialog" aria-modal="true">
                <div class="ask-h"><span class="ask-ic ${danger ? 'danger' : ''}"><i class="fa-solid ${icon || (danger ? 'fa-triangle-exclamation' : input ? 'fa-pen' : 'fa-circle-question')}"></i></span><b>${esc(title || (danger ? 'Na pewno?' : input ? 'Wpisz' : 'Potwierdź'))}</b></div>
                ${text ? `<p class="ask-t">${esc(text)}</p>` : ''}
                ${input ? `<label class="ask-l">${input.label ? `<span>${esc(input.label)}</span>` : ''}<input class="ask-in" type="${input.type || 'text'}" value="${esc(input.value ?? '')}"></label>` : ''}
                <div class="ask-f"><button type="button" class="btn-secondary" data-a="no">${esc(cancel)}</button><button type="button" class="${danger ? 'btn-danger' : 'btn-primary'}" data-a="yes">${esc(ok)}</button></div>
            </div>`;
            const done = (v) => { document.removeEventListener('keydown', key, true); bg.classList.add('out'); setTimeout(() => bg.remove(), 140); resolve(v); };
            const yes = () => done(input ? bg.querySelector('.ask-in').value : true);
            const no = () => done(input ? null : false);
            const key = (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); no(); } else if (e.key === 'Enter' && (input || document.activeElement?.closest?.('.ask'))) { e.preventDefault(); e.stopPropagation(); yes(); } };
            bg.addEventListener('click', (e) => { if (e.target === bg) no(); const a = e.target.closest('[data-a]')?.dataset.a; if (a === 'yes') yes(); else if (a === 'no') no(); });
            document.addEventListener('keydown', key, true);
            document.body.appendChild(bg);
            requestAnimationFrame(() => { const f = bg.querySelector('.ask-in') || bg.querySelector('[data-a="yes"]'); f?.focus(); if (f?.select) f.select(); });
        });
    }
    return {
        confirm: (text, o = {}) => open({ ...o, text }),
        prompt: (label, value = '', o = {}) => open({ ...o, text: o.text, input: { label, value, type: o.type } })
    };
})();
window.Ask = Ask;
