/* ============================================
   D&D 5e — baza przedmiotów (Podręcznik Gracza / SRD), po polsku
   Każdy przedmiot ma cenę, wagę (lb) i swoje parametry: kości obrażeń
   i właściwości broni, KP i wymagania pancerzy, zawartość zestawów.
   Działa bez internetu; używają jej karta postaci, kompendium i zestawy klas.
   Ceny: sz — sztuka złota, ss — srebra, sm — miedzi.
   ============================================ */
const ItemsDB = (() => {
    const CATS = {
        weapon: ['Broń', 'fa-khanda'],
        armor: ['Pancerze i tarcze', 'fa-shield-halved'],
        ammo: ['Amunicja', 'fa-bullseye'],
        gear: ['Wyposażenie', 'fa-sack-xmark'],
        focus: ['Fokusy i symbole', 'fa-wand-sparkles'],
        clothes: ['Stroje', 'fa-shirt'],
        tool: ['Narzędzia', 'fa-screwdriver-wrench'],
        instrument: ['Instrumenty', 'fa-music'],
        game: ['Gry', 'fa-dice'],
        pack: ['Zestawy', 'fa-box-open'],
        potion: ['Mikstury i mikstury magiczne', 'fa-flask'],
        food: ['Jedzenie i napoje', 'fa-utensils'],
        tack: ['Uprząż i siodła', 'fa-horse-head'],
        mount: ['Wierzchowce i pojazdy', 'fa-horse']
    };
    const PROP = { F: 'finezyjna', L: 'lekka', T: 'rzucana', '2': 'dwuręczna', V: 'wszechstronna', H: 'ciężka', Z: 'zasięg', A: 'amunicja', Ł: 'ładowanie', S: 'specjalna' };
    const list = [];
    let n = 0;
    const add = (o) => { o.id = o.id || 'i' + (++n).toString(36); list.push(o); return o; };

    // ---------- broń: nazwa, ang., grupa, cena, obrażenia, typ, waga, właściwości, zasięg, wszechstronna ----------
    const W = (name, en, sub, cost, dmg, dt, w, props = '', range = '', vers = '', extra = {}) =>
        add({ name, en, cat: 'weapon', sub, cost, dmg, dt, w, props, range, vers, ...extra });
    W('Pałka', 'Club', 'Prosta broń do walki wręcz', '1 ss', '1k4', 'obuchowe', 2, 'L');
    W('Sztylet', 'Dagger', 'Prosta broń do walki wręcz', '2 sz', '1k4', 'kłute', 1, 'FLT', '20/60');
    W('Maczuga', 'Greatclub', 'Prosta broń do walki wręcz', '2 ss', '1k8', 'obuchowe', 10, '2');
    W('Toporek', 'Handaxe', 'Prosta broń do walki wręcz', '5 sz', '1k6', 'cięte', 2, 'LT', '20/60');
    W('Oszczep', 'Javelin', 'Prosta broń do walki wręcz', '5 ss', '1k6', 'kłute', 2, 'T', '30/120');
    W('Lekki młot', 'Light hammer', 'Prosta broń do walki wręcz', '2 sz', '1k4', 'obuchowe', 2, 'LT', '20/60');
    W('Buzdygan', 'Mace', 'Prosta broń do walki wręcz', '5 sz', '1k6', 'obuchowe', 4);
    W('Kostur', 'Quarterstaff', 'Prosta broń do walki wręcz', '2 ss', '1k6', 'obuchowe', 4, 'V', '', '1k8');
    W('Sierp', 'Sickle', 'Prosta broń do walki wręcz', '1 sz', '1k4', 'cięte', 2, 'L');
    W('Włócznia', 'Spear', 'Prosta broń do walki wręcz', '1 sz', '1k6', 'kłute', 3, 'TV', '20/60', '1k8');
    W('Kusza lekka', 'Crossbow, light', 'Prosta broń dystansowa', '25 sz', '1k8', 'kłute', 5, 'AŁ2', '80/320');
    W('Strzałka', 'Dart', 'Prosta broń dystansowa', '5 sm', '1k4', 'kłute', 0.25, 'FT', '20/60');
    W('Łuk krótki', 'Shortbow', 'Prosta broń dystansowa', '25 sz', '1k6', 'kłute', 2, 'A2', '80/320');
    W('Proca', 'Sling', 'Prosta broń dystansowa', '1 ss', '1k4', 'obuchowe', 0, 'A', '30/120');
    W('Topór bojowy', 'Battleaxe', 'Broń żołnierska do walki wręcz', '10 sz', '1k8', 'cięte', 4, 'V', '', '1k10');
    W('Korbacz', 'Flail', 'Broń żołnierska do walki wręcz', '10 sz', '1k8', 'obuchowe', 2);
    W('Glewia', 'Glaive', 'Broń żołnierska do walki wręcz', '20 sz', '1k10', 'cięte', 6, 'HZ2');
    W('Topór dwuręczny', 'Greataxe', 'Broń żołnierska do walki wręcz', '30 sz', '1k12', 'cięte', 7, 'H2');
    W('Miecz dwuręczny', 'Greatsword', 'Broń żołnierska do walki wręcz', '50 sz', '2k6', 'cięte', 6, 'H2');
    W('Halabarda', 'Halberd', 'Broń żołnierska do walki wręcz', '20 sz', '1k10', 'cięte', 6, 'HZ2');
    W('Kopia', 'Lance', 'Broń żołnierska do walki wręcz', '10 sz', '1k12', 'kłute', 6, 'ZS', '', '', { note: 'Z utrudnieniem, gdy atakujesz cel w odległości 5 stóp. Bez dosiadu wymaga obu rąk.' });
    W('Miecz długi', 'Longsword', 'Broń żołnierska do walki wręcz', '15 sz', '1k8', 'cięte', 3, 'V', '', '1k10');
    W('Młot dwuręczny', 'Maul', 'Broń żołnierska do walki wręcz', '10 sz', '2k6', 'obuchowe', 10, 'H2');
    W('Morgensztern', 'Morningstar', 'Broń żołnierska do walki wręcz', '15 sz', '1k8', 'kłute', 4);
    W('Pika', 'Pike', 'Broń żołnierska do walki wręcz', '5 sz', '1k10', 'kłute', 18, 'HZ2');
    W('Rapier', 'Rapier', 'Broń żołnierska do walki wręcz', '25 sz', '1k8', 'kłute', 2, 'F');
    W('Sejmitar', 'Scimitar', 'Broń żołnierska do walki wręcz', '25 sz', '1k6', 'cięte', 3, 'FL');
    W('Miecz krótki', 'Shortsword', 'Broń żołnierska do walki wręcz', '10 sz', '1k6', 'kłute', 2, 'FL');
    W('Trójząb', 'Trident', 'Broń żołnierska do walki wręcz', '5 sz', '1k6', 'kłute', 4, 'TV', '20/60', '1k8');
    W('Nadziak', 'War pick', 'Broń żołnierska do walki wręcz', '5 sz', '1k8', 'kłute', 2);
    W('Młot bojowy', 'Warhammer', 'Broń żołnierska do walki wręcz', '15 sz', '1k8', 'obuchowe', 2, 'V', '', '1k10');
    W('Bicz', 'Whip', 'Broń żołnierska do walki wręcz', '2 sz', '1k4', 'cięte', 3, 'FZ');
    W('Dmuchawka', 'Blowgun', 'Broń żołnierska dystansowa', '10 sz', '1', 'kłute', 1, 'AŁ', '25/100');
    W('Kusza ręczna', 'Crossbow, hand', 'Broń żołnierska dystansowa', '75 sz', '1k6', 'kłute', 3, 'ALŁ', '30/120');
    W('Kusza ciężka', 'Crossbow, heavy', 'Broń żołnierska dystansowa', '50 sz', '1k10', 'kłute', 18, 'AHŁ2', '100/400');
    W('Łuk długi', 'Longbow', 'Broń żołnierska dystansowa', '50 sz', '1k8', 'kłute', 2, 'AH2', '150/600');
    W('Sieć', 'Net', 'Broń żołnierska dystansowa', '1 sz', '', '', 3, 'ST', '5/15', '', { note: 'Trafione stworzenie (Duże lub mniejsze) jest unieruchomione, dopóki się nie uwolni (test Siły ST 10) albo sieć nie zostanie zniszczona (5 PW, KP 10).' });

    // ---------- pancerze: nazwa, ang., rodzaj, cena, KP, waga, wymagana Siła, skradanie z utrudnieniem ----------
    const A = (name, en, kind, cost, ac, w, str = 0, stealth = false) => add({ name, en, cat: 'armor', sub: { L: 'Pancerz lekki', M: 'Pancerz średni', H: 'Pancerz ciężki', S: 'Tarcza' }[kind], kind, cost, ac, w, str, stealth });
    A('Przeszywanica', 'Padded', 'L', '5 sz', 11, 8, 0, true);
    A('Zbroja skórzana', 'Leather', 'L', '10 sz', 11, 10);
    A('Zbroja ćwiekowana', 'Studded leather', 'L', '45 sz', 12, 13);
    A('Zbroja ze skór', 'Hide', 'M', '10 sz', 12, 12);
    A('Kaftan kolczy', 'Chain shirt', 'M', '50 sz', 13, 20);
    A('Zbroja łuskowa', 'Scale mail', 'M', '50 sz', 14, 45, 0, true);
    A('Napierśnik', 'Breastplate', 'M', '400 sz', 14, 20);
    A('Półpłytówka', 'Half plate', 'M', '750 sz', 15, 40, 0, true);
    A('Zbroja kółkowa', 'Ring mail', 'H', '30 sz', 14, 40, 0, true);
    A('Kolczuga', 'Chain mail', 'H', '75 sz', 16, 55, 13, true);
    A('Zbroja paskowa', 'Splint', 'H', '200 sz', 17, 60, 15, true);
    A('Płytówka', 'Plate', 'H', '1500 sz', 18, 65, 15, true);
    A('Tarcza', 'Shield', 'S', '10 sz', 2, 6);

    // ---------- pozostałe: kategoria, nazwa, ang., cena, waga, opis, domyślna ilość ----------
    const G = (cat, name, en, cost, w, desc = '', qty = 1, extra = {}) => add({ cat, name, en, cost, w, desc, qty, ...extra });
    // amunicja (waga i cena za sztukę, dodaje się paczką)
    G('ammo', 'Strzały', 'Arrows', '1 sz / 20 szt.', 0.05, 'Do łuków.', 20);
    G('ammo', 'Bełty', 'Crossbow bolts', '1 sz / 20 szt.', 0.075, 'Do kusz.', 20);
    G('ammo', 'Pociski do procy', 'Sling bullets', '4 sm / 20 szt.', 0.075, 'Do procy.', 20);
    G('ammo', 'Igły do dmuchawki', 'Blowgun needles', '1 sz / 50 szt.', 0.02, 'Do dmuchawki.', 50);
    // wyposażenie
    G('gear', 'Liczydło', 'Abacus', '2 sz', 2);
    G('gear', 'Kwas (fiolka)', 'Acid (vial)', '25 sz', 1, 'Akcja: rzut fiolką do 20 stóp (atak dystansowy, broń improwizowana). Trafienie: 2k6 obrażeń od kwasu.');
    G('gear', 'Ogień alchemiczny (flaszka)', "Alchemist's fire", '50 sz', 1, 'Akcja: rzut do 20 stóp. Trafienie: cel płonie — 1k4 obrażeń od ognia na początku każdej tury, dopóki akcją nie zgasi (test Zręczności ST 10).');
    G('gear', 'Antidotum (fiolka)', 'Antitoxin', '50 sz', 0, 'Po wypiciu: ułatwienie w rzutach obronnych przeciw truciźnie przez 1 godzinę.');
    G('gear', 'Plecak', 'Backpack', '2 sz', 5, 'Mieści 1 stopę sześcienną / 30 lb ekwipunku.');
    G('gear', 'Kulki łożyskowe (worek 1000)', 'Ball bearings', '1 sz', 2, 'Rozsypane pokrywają kwadrat 10×10 stóp — kto wchodzi, rzut obronny Zręczności ST 10 albo pada powalony.');
    G('gear', 'Beczka', 'Barrel', '2 sz', 70, 'Mieści 40 galonów płynu albo 4 stopy sześcienne ładunku.');
    G('gear', 'Kosz', 'Basket', '4 ss', 2, 'Mieści 2 stopy sześcienne / 40 lb.');
    G('gear', 'Śpiwór', 'Bedroll', '1 sz', 7);
    G('gear', 'Dzwonek', 'Bell', '1 sz', 0);
    G('gear', 'Koc', 'Blanket', '5 ss', 3);
    G('gear', 'Wielokrążek', 'Block and tackle', '1 sz', 5, 'Pozwala podnieść czterokrotnie większy ciężar niż zwykle.');
    G('gear', 'Księga', 'Book', '25 sz', 5, 'Np. poezja, kronika, traktat albo modlitewnik.');
    G('gear', 'Butelka szklana', 'Bottle, glass', '2 sz', 2);
    G('gear', 'Wiadro', 'Bucket', '5 sm', 2);
    G('gear', 'Kolczatki (worek 20)', 'Caltrops', '1 sz', 2, 'Pokrywają kwadrat 5×5 stóp — kto wchodzi, rzut obronny Zręczności ST 15 albo 1 obrażenie kłute i −10 stóp szybkości.');
    G('gear', 'Świeca', 'Candle', '1 sm', 0, 'Jasne światło w promieniu 5 stóp przez 1 godzinę.');
    G('gear', 'Futerał na bełty', 'Case, crossbow bolt', '1 sz', 1, 'Mieści 20 bełtów.');
    G('gear', 'Tuba na mapy i zwoje', 'Case, map or scroll', '1 sz', 1, 'Mieści 10 zwiniętych arkuszy.');
    G('gear', 'Łańcuch (10 stóp)', 'Chain', '5 sz', 10, '10 PW; rozerwanie: test Siły ST 20.');
    G('gear', 'Kreda (kawałek)', 'Chalk', '1 sm', 0);
    G('gear', 'Skrzynia', 'Chest', '5 sz', 25, 'Mieści 12 stóp sześciennych / 300 lb.');
    G('gear', 'Zestaw wspinaczkowy', "Climber's kit", '25 sz', 12, 'Kolce, buty z kolcami, rękawice i uprząż. Akcja: zakotwicz się — nie spadniesz dalej niż 25 stóp.');
    G('gear', 'Sakiewka komponentów', 'Component pouch', '25 sz', 2, 'Komponenty materialne do czarów (bez podanej ceny).');
    G('gear', 'Łom', 'Crowbar', '2 sz', 5, 'Ułatwienie w testach Siły, gdzie dźwignia pomaga.');
    G('gear', 'Sprzęt wędkarski', 'Fishing tackle', '1 sz', 4);
    G('gear', 'Flaszka lub kufel', 'Flask or tankard', '2 sm', 1);
    G('gear', 'Kotwiczka', 'Grappling hook', '2 sz', 4);
    G('gear', 'Młotek', 'Hammer', '1 sz', 3);
    G('gear', 'Młot kowalski', 'Hammer, sledge', '2 sz', 10);
    G('gear', 'Zestaw uzdrowiciela', "Healer's kit", '5 sz', 3, '10 użyć. Akcja: ustabilizuj stworzenie z 0 PW bez testu Mądrości (Medycyna).');
    G('gear', 'Woda święcona (flaszka)', 'Holy water', '25 sz', 1, 'Akcja: rzut do 20 stóp. Trafienie bies lub nieumarły: 2k6 obrażeń promienistych.');
    G('gear', 'Klepsydra', 'Hourglass', '25 sz', 1);
    G('gear', 'Sidła myśliwskie', 'Hunting trap', '5 sz', 25, 'Szczęki: rzut obronny Zręczności ST 13 albo 1k4 obrażeń kłutych i unieruchomienie (uwolnienie: test Siły ST 13).');
    G('gear', 'Butelka atramentu', 'Ink (1 ounce bottle)', '10 sz', 0);
    G('gear', 'Pióro', 'Ink pen', '2 sm', 0);
    G('gear', 'Dzban', 'Jug or pitcher', '2 sm', 4, 'Mieści 1 galon płynu.');
    G('gear', 'Drabina (10 stóp)', 'Ladder', '1 ss', 25);
    G('gear', 'Lampa', 'Lamp', '5 ss', 1, 'Jasne światło 15 stóp, przyćmione kolejne 30 stóp; 6 godzin na flaszce oleju.');
    G('gear', 'Latarnia kierunkowa', 'Lantern, bullseye', '10 sz', 2, 'Stożek jasnego światła 60 stóp i przyćmionego kolejne 60 stóp; 6 godzin na flaszce oleju.');
    G('gear', 'Latarnia z przesłoną', 'Lantern, hooded', '5 sz', 2, 'Jasne światło 30 stóp, przyćmione kolejne 30 stóp; przesłona zmniejsza do przyćmionego 5 stóp.');
    G('gear', 'Zamek', 'Lock', '10 sz', 1, 'Z kluczem. Otwarcie bez klucza: narzędzia złodziejskie, ST 15.');
    G('gear', 'Szkło powiększające', 'Magnifying glass', '100 sz', 0, 'Ułatwienie przy oględzinach drobnych lub misternych rzeczy; rozpala ogień w słońcu.');
    G('gear', 'Kajdany', 'Manacles', '2 sz', 6, 'Dla stworzeń Małych i Średnich. Uwolnienie: Zręczność ST 20, zerwanie: Siła ST 20.');
    G('gear', 'Menażka', 'Mess kit', '2 ss', 1);
    G('gear', 'Lusterko stalowe', 'Mirror, steel', '5 sz', 0.5);
    G('gear', 'Flaszka oleju', 'Oil (flask)', '1 ss', 1, 'Paliwo do lamp. Rozlany i podpalony: 5 obrażeń od ognia w kwadracie 5×5 stóp.');
    G('gear', 'Arkusz papieru', 'Paper', '2 ss', 0);
    G('gear', 'Arkusz pergaminu', 'Parchment', '1 ss', 0);
    G('gear', 'Flakonik perfum', 'Perfume (vial)', '5 sz', 0);
    G('gear', 'Kilof górniczy', "Pick, miner's", '2 sz', 10);
    G('gear', 'Klin żelazny', 'Piton', '5 sm', 0.25);
    G('gear', 'Trucizna (fiolka)', 'Poison, basic', '100 sz', 0, 'Akcja: pokryj broń lub 3 sztuki amunicji na 1 minutę. Trafienie: rzut obronny Kondycji ST 10 albo 1k4 obrażeń od trucizny.');
    G('gear', 'Tyczka (10 stóp)', 'Pole', '5 sm', 7);
    G('gear', 'Żelazny garnek', 'Pot, iron', '2 sz', 10);
    G('gear', 'Sakiewka', 'Pouch', '5 ss', 1, 'Mieści 1/5 stopy sześciennej / 6 lb.');
    G('gear', 'Kołczan', 'Quiver', '1 sz', 1, 'Mieści 20 strzał.');
    G('gear', 'Taran przenośny', 'Ram, portable', '4 sz', 35, '+4 do testu Siły przy wyważaniu drzwi.');
    G('gear', 'Racje żywnościowe (1 dzień)', 'Rations (1 day)', '5 ss', 2, 'Suszone mięso, suchary, owoce i orzechy na jeden dzień.');
    G('gear', 'Lina konopna (50 stóp)', 'Rope, hempen', '1 sz', 10, '2 PW; zerwanie: test Siły ST 17.');
    G('gear', 'Lina jedwabna (50 stóp)', 'Rope, silk', '10 sz', 5, '2 PW; zerwanie: test Siły ST 17.');
    G('gear', 'Worek', 'Sack', '1 sm', 0.5, 'Mieści 1 stopę sześcienną / 30 lb.');
    G('gear', 'Waga kupiecka', "Scale, merchant's", '5 sz', 3);
    G('gear', 'Lak do pieczęci', 'Sealing wax', '5 ss', 0);
    G('gear', 'Łopata', 'Shovel', '2 sz', 5);
    G('gear', 'Gwizdek sygnałowy', 'Signal whistle', '5 sm', 0);
    G('gear', 'Sygnet', 'Signet ring', '5 sz', 0);
    G('gear', 'Mydło', 'Soap', '2 sm', 0);
    G('gear', 'Księga czarów', 'Spellbook', '50 sz', 3, '100 pustych stron na czary czarodzieja.');
    G('gear', 'Żelazne kolce (10)', 'Spikes, iron', '1 sz', 5);
    G('gear', 'Luneta', 'Spyglass', '1000 sz', 1, 'Przybliża dwukrotnie.');
    G('gear', 'Namiot dwuosobowy', 'Tent, two-person', '2 sz', 20);
    G('gear', 'Krzesiwo', 'Tinderbox', '5 ss', 1, 'Rozpalenie pochodni: akcja; innego ognia: minuta.');
    G('gear', 'Pochodnia', 'Torch', '1 sm', 1, 'Płonie 1 godzinę: jasne światło 20 stóp, przyćmione kolejne 20 stóp. Jako broń: 1 obrażenie od ognia.');
    G('gear', 'Fiolka', 'Vial', '1 sz', 0, 'Mieści 4 uncje płynu.');
    G('gear', 'Bukłak', 'Waterskin', '2 ss', 5, 'Waga pełnego; mieści 4 pinty płynu.');
    G('gear', 'Osełka', 'Whetstone', '1 sm', 1);
    G('gear', 'Szkatułka na jałmużnę', 'Alms box', '—', 1);
    G('gear', 'Kadzidło (kostka)', 'Incense', '—', 0);
    G('gear', 'Kadzielnica', 'Censer', '—', 1);
    G('gear', 'Woreczek piasku', 'Little bag of sand', '—', 1);
    G('gear', 'Nożyk', 'Small knife', '—', 0);
    G('gear', 'Sznurek (10 stóp)', 'String', '—', 0);
    // fokusy i symbole
    G('focus', 'Fokus arkanistyczny: kryształ', 'Arcane focus: crystal', '10 sz', 1);
    G('focus', 'Fokus arkanistyczny: kula', 'Arcane focus: orb', '20 sz', 3);
    G('focus', 'Fokus arkanistyczny: różdżka', 'Arcane focus: wand', '10 sz', 1);
    G('focus', 'Fokus arkanistyczny: berło', 'Arcane focus: rod', '10 sz', 2);
    G('focus', 'Fokus arkanistyczny: kostur', 'Arcane focus: staff', '5 sz', 4);
    G('focus', 'Fokus druidyczny: gałązka jemioły', 'Druidic focus: sprig of mistletoe', '1 sz', 0);
    G('focus', 'Fokus druidyczny: totem', 'Druidic focus: totem', '1 sz', 0);
    G('focus', 'Fokus druidyczny: drewniany kostur', 'Druidic focus: wooden staff', '5 sz', 4);
    G('focus', 'Fokus druidyczny: różdżka z cisu', 'Druidic focus: yew wand', '10 sz', 1);
    G('focus', 'Symbol święty: amulet', 'Holy symbol: amulet', '5 sz', 1);
    G('focus', 'Symbol święty: emblemat', 'Holy symbol: emblem', '5 sz', 0);
    G('focus', 'Symbol święty: relikwiarz', 'Holy symbol: reliquary', '5 sz', 2);
    // stroje
    G('clothes', 'Strój zwykły', 'Clothes, common', '5 ss', 3);
    G('clothes', 'Strój kostiumowy', 'Clothes, costume', '5 sz', 4);
    G('clothes', 'Strój wytworny', 'Clothes, fine', '15 sz', 6);
    G('clothes', 'Strój podróżny', "Clothes, traveler's", '2 sz', 4);
    G('clothes', 'Szaty', 'Robes', '1 sz', 4);
    G('clothes', 'Szaty liturgiczne', 'Vestments', '—', 4);
    G('clothes', 'Ciemny strój z kapturem', 'Dark common clothes with hood', '—', 3);
    // narzędzia
    const T = (name, en, cost, w, desc = '') => G('tool', name, en, cost, w, desc);
    T('Narzędzia alchemika', "Alchemist's supplies", '50 sz', 8);
    T('Narzędzia piwowara', "Brewer's supplies", '20 sz', 9);
    T('Narzędzia kaligrafa', "Calligrapher's supplies", '10 sz', 5);
    T('Narzędzia stolarza', "Carpenter's tools", '8 sz', 6);
    T('Narzędzia kartografa', "Cartographer's tools", '15 sz', 6);
    T('Narzędzia szewca', "Cobbler's tools", '5 sz', 5);
    T('Przybory kucharskie', "Cook's utensils", '1 sz', 8);
    T('Narzędzia dmuchacza szkła', "Glassblower's tools", '30 sz', 5);
    T('Narzędzia jubilera', "Jeweler's tools", '25 sz', 2);
    T('Narzędzia kaletnika', "Leatherworker's tools", '5 sz', 5);
    T('Narzędzia murarza', "Mason's tools", '10 sz', 8);
    T('Przybory malarskie', "Painter's supplies", '10 sz', 5);
    T('Narzędzia garncarza', "Potter's tools", '10 sz', 3);
    T('Narzędzia kowala', "Smith's tools", '20 sz', 8);
    T('Narzędzia majsterkowicza', "Tinker's tools", '50 sz', 10);
    T('Narzędzia tkacza', "Weaver's tools", '1 sz', 5);
    T('Narzędzia snycerza', "Woodcarver's tools", '1 sz', 5);
    T('Zestaw do charakteryzacji', 'Disguise kit', '25 sz', 3, 'Kosmetyki, farby do włosów i rekwizyty do przebrań.');
    T('Zestaw fałszerza', 'Forgery kit', '15 sz', 5, 'Do podrabiania dokumentów.');
    T('Zestaw zielarski', 'Herbalism kit', '5 sz', 3, 'Potrzebny do wytwarzania antidotum i mikstur leczenia.');
    T('Przyrządy nawigacyjne', "Navigator's tools", '25 sz', 2);
    T('Zestaw truciciela', "Poisoner's kit", '50 sz', 2);
    T('Narzędzia złodziejskie', "Thieves' tools", '25 sz', 1, 'Wytrychy, pilnik, lusterko na trzonku — otwieranie zamków i rozbrajanie pułapek.');
    // instrumenty
    const I = (name, en, cost, w) => G('instrument', name, en, cost, w);
    I('Dudy', 'Bagpipes', '30 sz', 6); I('Bęben', 'Drum', '6 sz', 3); I('Cymbały', 'Dulcimer', '25 sz', 10); I('Flet', 'Flute', '2 sz', 1);
    I('Lutnia', 'Lute', '35 sz', 2); I('Lira', 'Lyre', '30 sz', 2); I('Róg', 'Horn', '3 sz', 2); I('Fletnia Pana', 'Pan flute', '12 sz', 2);
    I('Szałamaja', 'Shawm', '2 sz', 1); I('Viola', 'Viol', '30 sz', 1);
    // gry
    G('game', 'Kostki do gry', 'Dice set', '1 ss', 0); G('game', 'Szachy smocze', 'Dragonchess set', '1 sz', 0.5);
    G('game', 'Talia kart', 'Playing card set', '5 ss', 0); G('game', 'Gra Trzech Smoków', 'Three-Dragon Ante set', '1 sz', 0);
    // mikstury
    G('potion', 'Mikstura leczenia', 'Potion of healing', '50 sz', 0.5, 'Akcja: wypij — odzyskujesz 2k4+2 PW. Zwykła (pospolita).', 1, { heal: '2k4+2' });
    G('potion', 'Większa mikstura leczenia', 'Potion of greater healing', '150 sz', 0.5, 'Odzyskujesz 4k4+4 PW. Niezwykła.', 1, { heal: '4k4+4' });
    G('potion', 'Wyborna mikstura leczenia', 'Potion of superior healing', '500 sz', 0.5, 'Odzyskujesz 8k4+8 PW. Rzadka.', 1, { heal: '8k4+8' });
    G('potion', 'Najwyższa mikstura leczenia', 'Potion of supreme healing', '5000 sz', 0.5, 'Odzyskujesz 10k4+20 PW. Bardzo rzadka.', 1, { heal: '10k4+20' });
    G('potion', 'Mikstura oddychania pod wodą', 'Potion of water breathing', '180 sz', 0.5, 'Przez 1 godzinę oddychasz pod wodą. Niezwykła.');
    G('potion', 'Mikstura wspinaczki', 'Potion of climbing', '180 sz', 0.5, 'Przez 1 godzinę szybkość wspinaczki równa chodowi i ułatwienie w testach wspinaczki. Pospolita.');
    G('potion', 'Mikstura odporności na ogień', 'Potion of resistance (fire)', '300 sz', 0.5, 'Przez 1 godzinę odporność na obrażenia od ognia. Niezwykła.');
    G('potion', 'Mikstura siły wzgórzowego olbrzyma', 'Potion of hill giant strength', '400 sz', 0.5, 'Przez 1 godzinę Siła 21. Niezwykła.');
    G('potion', 'Mikstura niewidzialności', 'Potion of invisibility', '5000 sz', 0.5, 'Przez 1 godzinę jesteś niewidzialny (kończy się przy ataku lub rzuceniu czaru). Bardzo rzadka.');
    G('potion', 'Zwój czaru (sztuczka)', 'Spell scroll (cantrip)', '25 sz', 0, 'Jednorazowy zwój ze sztuczką z listy twojej klasy. Pospolity.');
    G('potion', 'Zwój czaru (1. krąg)', 'Spell scroll (1st level)', '75 sz', 0, 'Jednorazowy zwój z czarem 1. kręgu. Pospolity.');
    // jedzenie i napoje (ceny z karczmy)
    G('food', 'Piwo (kufel)', 'Ale (mug)', '4 sm', 1); G('food', 'Piwo (galon)', 'Ale (gallon)', '2 ss', 8);
    G('food', 'Chleb (bochenek)', 'Bread (loaf)', '2 sm', 0.5); G('food', 'Ser (kawałek)', 'Cheese (hunk)', '1 ss', 0.5);
    G('food', 'Mięso (kawałek)', 'Meat (chunk)', '3 ss', 1); G('food', 'Wino zwykłe (dzban)', 'Wine, common (pitcher)', '2 ss', 4);
    G('food', 'Wino szlachetne (butelka)', 'Wine, fine (bottle)', '10 sz', 2);
    // uprząż i siodła
    G('tack', 'Siodło jeździeckie', 'Saddle, riding', '10 sz', 25); G('tack', 'Siodło wojskowe', 'Saddle, military', '20 sz', 30, 'Ułatwienie w testach utrzymania się w siodle.');
    G('tack', 'Siodło juczne', 'Saddle, pack', '5 sz', 15); G('tack', 'Siodło egzotyczne', 'Saddle, exotic', '60 sz', 40, 'Dla wierzchowców latających i wodnych.');
    G('tack', 'Juki', 'Saddlebags', '4 sz', 8); G('tack', 'Uzda i wodze', 'Bit and bridle', '2 sz', 1); G('tack', 'Obrok (1 dzień)', 'Feed (per day)', '5 sm', 10);
    G('tack', 'Pancerz dla konia (kolczuga)', 'Barding (chain mail)', '300 sz', 110, 'Kolczuga dla wierzchowca (cena ×4, waga ×2).');
    // wierzchowce i pojazdy (nie do plecaka — waga 0, w opisie udźwig)
    const M = (name, en, cost, desc) => G('mount', name, en, cost, 0, desc, 1, { noPack: true });
    M('Koń pociągowy', 'Draft horse', '50 sz', 'Szybkość 40 stóp, udźwig 540 lb.'); M('Koń wierzchowy', 'Riding horse', '75 sz', 'Szybkość 60 stóp, udźwig 480 lb.');
    M('Koń bojowy', 'Warhorse', '400 sz', 'Szybkość 60 stóp, udźwig 540 lb.'); M('Kucyk', 'Pony', '30 sz', 'Szybkość 40 stóp, udźwig 225 lb.');
    M('Muł', 'Mule', '8 sz', 'Szybkość 40 stóp, udźwig 420 lb.'); M('Osioł', 'Donkey', '8 sz', 'Szybkość 40 stóp, udźwig 420 lb.');
    M('Wielbłąd', 'Camel', '50 sz', 'Szybkość 50 stóp, udźwig 480 lb.'); M('Mastif', 'Mastiff', '25 sz', 'Szybkość 40 stóp, udźwig 195 lb.');
    M('Słoń', 'Elephant', '200 sz', 'Szybkość 40 stóp, udźwig 1320 lb.');
    M('Wóz', 'Wagon', '35 sz', 'Waga 400 lb.'); M('Wózek', 'Cart', '15 sz', 'Waga 200 lb.'); M('Powóz', 'Carriage', '100 sz', 'Waga 600 lb.');
    M('Rydwan', 'Chariot', '250 sz', 'Waga 100 lb.'); M('Sanie', 'Sled', '20 sz', 'Waga 300 lb.'); M('Łódź wiosłowa', 'Rowboat', '50 sz', 'Szybkość 1,5 mili/h.');

    // ---------- zestawy (dodają się jako zawartość) ----------
    const K = (name, en, cost, key) => add({ cat: 'pack', name, en, cost, w: 0, pack: key });
    K('Zestaw włamywacza', "Burglar's pack", '16 sz', 'burglar'); K('Zestaw dyplomaty', "Diplomat's pack", '39 sz', 'diplomat');
    K('Zestaw podróżnika lochów', "Dungeoneer's pack", '12 sz', 'dungeoneer'); K('Zestaw artysty', "Entertainer's pack", '40 sz', 'entertainer');
    K('Zestaw odkrywcy', "Explorer's pack", '10 sz', 'explorer'); K('Zestaw kapłana', "Priest's pack", '19 sz', 'priest');
    K('Zestaw uczonego', "Scholar's pack", '40 sz', 'scholar');

    // ---------- wyszukiwanie po nazwie (polskiej, angielskiej i dawnych nazwach z zestawów) ----------
    const ALIAS = {
        'Fokus arkanistyczny': 'Fokus arkanistyczny: kryształ', 'Fokus druidyczny': 'Fokus druidyczny: gałązka jemioły', 'Symbol święty': 'Symbol święty: amulet',
        'Instrument muzyczny': 'Lutnia', 'Narzędzia rzemieślnicze': 'Narzędzia stolarza', 'Kij podróżny': 'Kostur', 'Strój szlachecki': 'Strój wytworny',
        'Księga wiedzy': 'Księga', 'Modlitewnik': 'Księga', 'Kadzidło': 'Kadzidło (kostka)', 'Tuba na mapy': 'Tuba na mapy i zwoje', 'Pojemnik na zwoje': 'Tuba na mapy i zwoje',
        'Butelka ciemnego atramentu': 'Butelka atramentu', 'Drewniana tarcza': 'Tarcza', 'Leather Armor': 'Zbroja skórzana', 'Studded Leather': 'Zbroja ćwiekowana',
        'Plate Armor': 'Płytówka', 'Light crossbow': 'Kusza lekka', 'Heavy crossbow': 'Kusza ciężka', 'Hand crossbow': 'Kusza ręczna', 'Koszulka kolcza': 'Kaftan kolczy',
        'Strzała': 'Strzały', 'Bełt': 'Bełty', 'Racja żywnościowa': 'Racje żywnościowe (1 dzień)', 'Lina': 'Lina konopna (50 stóp)'
    };
    const norm = (s) => String(s || '').toLowerCase().replace(/\s*\(\d+[^)]*\)\s*$/, '').replace(/\s+/g, ' ').trim();
    const index = new Map();
    list.forEach(it => { [it.name, it.en].forEach(k => { if (k && !index.has(norm(k))) index.set(norm(k), it); }); if (!index.has(it.id)) index.set(it.id, it); });
    Object.entries(ALIAS).forEach(([a, b]) => { const it = index.get(norm(b)); if (it && !index.has(norm(a))) index.set(norm(a), it); });
    function find(nameOrId) {
        if (!nameOrId) return null;
        const k = String(nameOrId);
        return index.get(k) || index.get(norm(k)) || index.get(String(k).toLowerCase().trim()) || null;
    }

    // ---------- opisy ----------
    function propsText(it) {
        if (!it || it.cat !== 'weapon') return '';
        return [...(it.props || '')].map(c => {
            if (c === 'V' && it.vers) return `wszechstronna (${it.vers})`;
            if ((c === 'T' || c === 'A') && it.range) return `${PROP[c]} (${it.range} stóp)`;
            return PROP[c];
        }).filter(Boolean).join(', ');
    }
    function info(it) {
        if (!it) return '';
        if (it.cat === 'weapon') return [it.dmg ? `${it.dmg} ${it.dt}` : '', propsText(it)].filter(Boolean).join(' · ');
        if (it.cat === 'armor') return it.kind === 'S' ? '+2 KP' : [`KP ${it.ac}${it.kind === 'L' ? ' + ZRĘ' : it.kind === 'M' ? ' + ZRĘ (maks. 2)' : ''}`, it.str ? `Sił ${it.str}` : '', it.stealth ? 'skradanie z utrudnieniem' : ''].filter(Boolean).join(' · ');
        if (it.cat === 'pack') return (window.Kits?.PACKS?.[it.pack]?.items || []).map(([nm, q]) => q > 1 ? `${nm} ×${q}` : nm).join(', ');
        if (it.heal) return `leczy ${it.heal} PW`;
        return it.desc || '';
    }
    const fmtW = (w) => !w ? '—' : `${String(+(+w).toFixed(2)).replace('.', ',')} lb`;
    // pozycja do ekwipunku postaci
    function toInv(it, qty) {
        const q = Math.max(1, parseInt(qty, 10) || it.qty || 1);
        return { name: it.name, quantity: q, weight: it.w || 0, cost: it.cost && it.cost !== '—' ? it.cost : '', ref: it.id };
    }
    // zawartość zestawu z wagami
    function packContents(it) {
        const items = window.Kits?.PACKS?.[it.pack]?.items || [];
        return items.map(([nm, q = 1]) => { const x = find(nm); return x ? toInv(x, q) : { name: nm, quantity: q, weight: window.Kits?.weightOf?.(nm) || 0 }; });
    }

    // ---------- broń i pancerze trafiają też do wyliczeń KP i ataków na karcie ----------
    function syncKits() {
        if (!window.Kits) return;
        list.forEach(it => {
            if (it.cat === 'weapon' && it.dmg) {
                const code = (it.props.includes('A') ? 'R' : '') + it.props.replace(/[A]/g, '');
                const rec = [it.dmg, it.dt, code, it.w];
                [it.name, it.en].forEach(k => { if (k && !Kits.WEAPONS[k]) Kits.WEAPONS[k] = rec; });
            }
            if (it.cat === 'armor') {
                const rec = [it.ac, it.kind, it.w];
                [it.name, it.en].forEach(k => { if (k && !Kits.ARMOR[k]) Kits.ARMOR[k] = rec; });
            }
        });
    }
    syncKits();

    return { CATS, PROP, all: list, find, info, propsText, fmtW, toInv, packContents, syncKits, norm };
})();
window.ItemsDB = ItemsDB;
