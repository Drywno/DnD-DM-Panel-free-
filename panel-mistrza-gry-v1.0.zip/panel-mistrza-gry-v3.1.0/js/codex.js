/* ============================================
   Wspólny wygląd otwieranych kart: bestiariusz, magia, ekwipunek
   (ten sam pergamin co karta NPC). Każdy moduł podaje tylko treść.
   ============================================ */
const Codex = (() => {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    /**
     * o.kind: monster | spell | item | magic   o.icon: klasa Font Awesome
     * o.title, o.meta (tekst), o.tags: [{t, cls}], o.actions: HTML przycisków
     * o.tiles: [[etykieta, wartość(HTML), dopisek]], o.abil: HTML, o.lines: [[etykieta, wartość(HTML)]]
     * o.sections: [{title, icon, html}], o.after: HTML pod kartą
     */
    function panel(o) {
        const tiles = (o.tiles || []).filter(t => t && t[1] !== '' && t[1] != null);
        const lines = (o.lines || []).filter(l => l && l[1]);
        return `<div class="cx cx-${o.kind || 'item'}">
            <div class="cx-bar"><div class="cx-actions">${o.actions || ''}</div><button class="detail-close btn-icon cx-close" title="Zamknij">&times;</button></div>
            <article class="cx-page">
                <header class="cx-head">
                    <span class="cx-seal"><i class="fa-solid ${o.icon || 'fa-book'}"></i></span>
                    <div class="cx-title"><h2>${esc(o.title)}</h2>${o.meta ? `<p>${o.meta}</p>` : ''}
                        ${(o.tags || []).length ? `<div class="cx-tags">${o.tags.map(t => `<span class="${t.cls || ''}">${t.t}</span>`).join('')}</div>` : ''}</div>
                </header>
                ${tiles.length ? `<div class="cx-tiles" style="--n:${Math.min(tiles.length, 4)}">${tiles.map(([l, v, sub]) => `<div class="cx-tile"><small>${esc(l)}</small><b>${v}</b>${sub ? `<em>${sub}</em>` : ''}</div>`).join('')}</div>` : ''}
                ${o.abil || ''}
                ${lines.length ? `<div class="cx-lines">${lines.map(([l, v]) => `<div><strong>${esc(l)}</strong> ${v}</div>`).join('')}</div>` : ''}
                ${(o.sections || []).filter(s => s && s.html).map(s => `<section class="cx-sec"><h5>${s.icon ? `<i class="fa-solid ${s.icon}"></i> ` : ''}${esc(s.title)}</h5>${s.html}</section>`).join('')}
            </article>
            ${o.after || ''}
        </div>`;
    }
    // ---------- klikalne rzuty: „+4 to hit”, „+5 do trafienia”, „2d6 + 3”, „8k6” ----------
    const sgn = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);
    const btn = (expr, label, txt, cls = '') => `<button type="button" class="nr ${cls}" data-roll="${esc(expr)}" data-lbl="${esc(label)}" title="Rzuć ${esc(String(expr).replace(/d/g, 'k'))}">${txt}</button>`;
    function rollify(text, label) {
        if (window.I18N && I18N.en) text = I18N.t(String(text ?? ''));
        const RX = /([+−-]\s?\d+)(\s*(?:do trafienia|to hit|na trafienie)\b)|\b(\d{0,2})\s?[dk](\d{1,3})((?:\s?[+−-]\s?\d+)?)(?![\w])/gi;
        return esc(text).replace(RX, (all, hb, rest, n, sd, b) => {
            if (hb) { const v = parseInt(hb.replace(/−/, '-').replace(/\s/g, ''), 10); return isNaN(v) ? all : btn(`1d20${v >= 0 ? '+' : ''}${v}`, label + ': trafienie', sgn(v), 'hit') + rest; }
            const bonus = (b || '').replace(/\s/g, '').replace(/−/g, '-');
            return btn(`${n || 1}d${sd}${bonus}`, label, all.trim(), 'dmg');
        });
    }
    const entries = (list, who) => (list || []).map(e => `<div class="cx-entry">${e.name ? `<b>${esc(e.name)}.</b> ` : ''}${rollify(e.desc || '', `${who} — ${e.name || ''}`)}</div>`).join('');
    const paras = (arr, label = '') => (Array.isArray(arr) ? arr : arr ? [arr] : []).map(p => {
        const t = String(p);
        // tabelki z SRD w opisach (| a | b |) zostawiamy jako tekst stałej szerokości
        return /^\s*\|/.test(t) ? `<pre class="cx-table">${esc(t)}</pre>` : `<p>${rollify(t, label).replace(/\*\*\*?([^*<]+)\*\*\*?/g, '<b>$1</b>')}</p>`;
    }).join('');
    // kliknięcie wartości = rzut (u MG kości panelu, u gracza rzut widoczny dla całego stołu)
    document.addEventListener('click', (e) => {
        const b = e.target.closest('.cx [data-roll]'); if (!b) return;
        e.preventDefault(); e.stopPropagation();
        const expr = b.dataset.roll, label = b.dataset.lbl || '';
        if (window.PANEL_ROLA === 'gracz') { window.DiceRoller?.rollExpression?.(expr, label); return; }
        window.DiceRoller?.rollExpression?.(expr, 'normal', label);
    });
    return { panel, entries, paras, rollify, btn, sgn, esc };
})();
window.Codex = Codex;
