/* ============================================
   Aplikacja gracza — wspólne moduły panelu MG w trybie gracza
   App, StorageManager i DiceRoller podmienione tak, żeby karta postaci,
   bestiariusz i zasady MG działały na danych z serwera (V z player.js),
   a zmiany szły do serwera jako ruchy gracza (bez zapisu do localStorage MG).
   ============================================ */
(function () {
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const clone = (o) => o == null ? o : JSON.parse(JSON.stringify(o));
    // most do player.js (ustawia go Player przy starcie)
    const B = () => window.GraczBridge || {};

    window.App = {
        currentTab: 'postac',
        modules: {},
        esc,
        getActiveCampaignId: () => B().campaignId?.() || null,
        switchTab: (t) => B().switchTab?.(t),
        showModal(title, bodyHtml, footerHtml) {
            const backdrop = document.getElementById('modal-backdrop');
            const titleEl = document.getElementById('modal-title');
            const bodyEl = document.getElementById('modal-body');
            const footerEl = document.getElementById('modal-footer');
            document.getElementById('modal')?.classList.remove('modal-wide');
            if (titleEl) titleEl.textContent = title;
            if (bodyEl) bodyEl.innerHTML = bodyHtml;
            if (footerEl) footerEl.innerHTML = footerHtml || '';
            if (backdrop) backdrop.classList.remove('hidden');
            const close = document.getElementById('modal-close');
            if (close) close.onclick = () => this.closeModal();
            if (backdrop) backdrop.onclick = (e) => { if (e.target === backdrop) this.closeModal(); };
            if (this._esc) document.removeEventListener('keydown', this._esc);
            this._esc = (e) => { if (e.key === 'Escape') this.closeModal(); };
            document.addEventListener('keydown', this._esc);
        },
        closeModal() {
            document.getElementById('modal-backdrop')?.classList.add('hidden');
            if (this._esc) { document.removeEventListener('keydown', this._esc); this._esc = null; }
        },
        showToast(message, type = 'info') {
            const container = document.getElementById('toast-container');
            if (!container) return;
            const icons = { success: 'fa-circle-check', error: 'fa-triangle-exclamation', info: 'fa-circle-info', warning: 'fa-circle-exclamation', turn: 'fa-khanda' };
            const t = document.createElement('div');
            t.className = `toast ${type}`;
            t.setAttribute('role', type === 'error' ? 'alert' : 'status');
            t.innerHTML = `<i class="fa-solid ${icons[type] || icons.info} toast-icon"></i><span class="toast-msg"></span><button class="toast-close" aria-label="Zamknij">&times;</button>`;
            t.querySelector('.toast-msg').textContent = message;
            const remove = () => { t.classList.add('leaving'); setTimeout(() => t.remove(), 250); };
            t.querySelector('.toast-close').onclick = remove;
            container.appendChild(t);
            while (container.children.length > 4) container.firstElementChild.remove();
            setTimeout(remove, type === 'error' ? 5000 : 3200);
        }
    };

    // ---------- dane: tylko własna postać, nic z localStorage Mistrza Gry ----------
    const SM = typeof StorageManager !== "undefined" ? StorageManager : null;   // const z storage.js nie jest na window
    if (SM) {
        // w karcie MG zakładka „Notatki” to prywatne notatki MG — u gracza pokazujemy tam jego własne
        const toSheet = (c) => { if (!c) return c; const x = clone(c); x.notes = x.playerNotes || ''; return x; };
        const fromSheet = (c) => { const x = clone(c); x.playerNotes = x.notes || ''; delete x.notes; return x; };
        Object.assign(SM, {
            getCharacters: () => { const c = B().character?.(); return c ? [toSheet(c)] : []; },
            getCharacter: (cid, id) => { const c = B().character?.(); return c && c.id === id ? toSheet(c) : null; },
            saveCharacter: (cid, ch) => { if (ch) B().saveCharacter?.(fromSheet(ch)); },
            saveCharacters: (cid, list) => { const me = B().character?.(); const c = (list || []).find(x => me && x.id === me.id); if (c) B().saveCharacter?.(fromSheet(c)); },
            deleteCharacter: () => {},
            getNPCs: () => [], getCustomMonsters: () => [], getCustomSpells: () => [], getCustomEquipment: () => [],
            getQuests: () => clone(B().quests?.() || []), saveQuests: () => {},
            getActiveCampaignId: () => B().campaignId?.() || null
        });
    }

    // ---------- rzuty z karty → kości gracza (3D, wynik widzi cały stół) ----------
    window.DiceRoller = {
        // (wyrażenie, opis) albo jak u MG (wyrażenie, tryb, opis)
        rollExpression: (expr, a, b) => B().roll?.(String(expr).replace(/d/gi, 'k'), (a && !['normal', 'advantage', 'disadvantage'].includes(a) ? a : b) || ''),
        roll: async (sides) => Math.floor(Math.random() * (+sides || 20)) + 1,
        addToHistory: () => {}, _updateHistoryAndToast: () => {}
    };
    window.DraggableManager = window.DraggableManager || { makeDraggable() {}, restorePosition() {}, removeItem() {} };
})();
