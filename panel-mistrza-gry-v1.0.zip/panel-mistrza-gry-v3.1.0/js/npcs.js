/* ============================================
   D&D 5e DM Panel — NPC i przeciwnicy
   Jeden kreator dla NPC i wrogów: tożsamość, lokacja z atlasu i pełny
   blok statystyk (KP, PW i kości, prędkości, cechy, rzuty obronne,
   umiejętności, odporności, zmysły, CR, akcje z atakami, reakcje,
   akcje legendarne, czary). Karta ma klikalne rzuty, a „Do walki”
   przenosi do inicjatywy wszystko, czego potrzebuje walka i plansza.
   ============================================ */

const NPCsModule = (function () {
    let npcs = [];
    let currentDetailId = null;

    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const _esc = esc;
    const clone = (o) => JSON.parse(JSON.stringify(o ?? null));
    const cid = () => App.getActiveCampaignId();

    // ---------- słowniki ----------
    const AB = ['str', 'dex', 'con', 'int', 'wis', 'cha'];
    const AB_PL = { str: 'Siła', dex: 'Zręczność', con: 'Kondycja', int: 'Inteligencja', wis: 'Mądrość', cha: 'Charyzma' };
    const AB_GEN = { str: 'Siłę', dex: 'Zręczność', con: 'Kondycję', int: 'Inteligencję', wis: 'Mądrość', cha: 'Charyzmę' };
    const AB_S = { str: 'SIŁ', dex: 'ZRĘ', con: 'KON', int: 'INT', wis: 'MDR', cha: 'CHA' };
    const SIZES = { Tiny: ['Malutki', 1], Small: ['Mały', 1], Medium: ['Średni', 1], Large: ['Duży', 2], Huge: ['Ogromny', 3], Gargantuan: ['Gigantyczny', 4] };
    const TYPES = { humanoid: 'humanoid', beast: 'bestia', monstrosity: 'monstrum', undead: 'nieumarły', fiend: 'bies', celestial: 'niebianin', dragon: 'smok', giant: 'olbrzym', aberration: 'aberracja', construct: 'konstrukt', elemental: 'żywiołak', fey: 'istota baśniowa', ooze: 'szlam', plant: 'roślina', swarm: 'rój' };
    const ALIGN = ['', 'praworządny dobry', 'neutralny dobry', 'chaotyczny dobry', 'praworządny neutralny', 'neutralny', 'chaotyczny neutralny', 'praworządny zły', 'neutralny zły', 'chaotyczny zły', 'bez charakteru', 'dowolny charakter'];
    const ALIGN_EN = { 'lawful good': 1, 'neutral good': 2, 'chaotic good': 3, 'lawful neutral': 4, 'neutral': 5, 'true neutral': 5, 'chaotic neutral': 6, 'lawful evil': 7, 'neutral evil': 8, 'chaotic evil': 9, 'unaligned': 10, 'any alignment': 11 };
    const DMG = {
        slashing: ['cięte', 'ciętych'], piercing: ['kłute', 'kłutych'], bludgeoning: ['obuchowe', 'obuchowych'],
        fire: ['ogień', 'od ognia'], cold: ['zimno', 'od zimna'], lightning: ['błyskawice', 'od błyskawic'], thunder: ['grzmot', 'od grzmotu'],
        acid: ['kwas', 'od kwasu'], poison: ['trucizna', 'od trucizny'], necrotic: ['nekrotyczne', 'nekrotycznych'], radiant: ['promieniste', 'promienistych'],
        force: ['moc', 'od mocy'], psychic: ['psychiczne', 'psychicznych']
    };
    const DMG_DEF = { ...Object.fromEntries(Object.entries(DMG).map(([k, v]) => [k, v[0]])), nonmagical: 'obuchowe, kłute i cięte od niemagicznych ataków' };
    const CONDS = { blinded: 'Oślepienie', charmed: 'Zauroczenie', deafened: 'Głuchota', exhaustion: 'Wyczerpanie', frightened: 'Przerażenie', grappled: 'Pochwycenie', incapacitated: 'Obezwładnienie', paralyzed: 'Paraliż', petrified: 'Spetryfikowanie', poisoned: 'Zatrucie', prone: 'Powalenie', restrained: 'Skrępowanie', stunned: 'Ogłuszenie', unconscious: 'Nieprzytomność' };
    const SENSES = { darkvision: 'widzenie w ciemności', blindsight: 'ślepowidzenie', tremorsense: 'wyczucie drgań', truesight: 'prawdziwe widzenie' };
    const SPEEDS = { walk: 'chód', fly: 'lot', swim: 'pływanie', climb: 'wspinaczka', burrow: 'kopanie' };
    const API = () => (typeof APIClient !== 'undefined' ? APIClient : null);   // const z api.js nie jest na window
    const SKILLS = API()?.SKILLS || {};
    const SKILL_EN = { Acrobatics: 'Akrobatyka', 'Animal Handling': 'Opieka nad zwierzętami', Arcana: 'Wiedza mistyczna', Athletics: 'Atletyka', Deception: 'Oszustwo', History: 'Historia', Insight: 'Wgląd', Intimidation: 'Zastraszanie', Investigation: 'Śledztwo', Medicine: 'Medycyna', Nature: 'Natura', Perception: 'Percepcja', Performance: 'Występy', Persuasion: 'Perswazja', Religion: 'Religia', 'Sleight of Hand': 'Zwinne dłonie', Stealth: 'Skradanie', Survival: 'Sztuka przetrwania' };
    const CRS = ['0', '1/8', '1/4', '1/2', ...Array.from({ length: 30 }, (_, i) => String(i + 1))];
    const KINDS = { text: 'Opis / zdolność', mw: 'Atak bronią wręcz', rw: 'Atak bronią dystansową', ms: 'Atak czarem wręcz', rs: 'Atak czarem dystansowy', save: 'Efekt z rzutem obronnym' };
    const LISTS = { traits: ['Cechy i zdolności specjalne', 'fa-star'], actions: ['Akcje', 'fa-hand-fist'], bonus: ['Akcje dodatkowe', 'fa-bolt'], reactions: ['Reakcje', 'fa-shield-halved'], legendary: ['Akcje legendarne', 'fa-crown'] };
    const DISP = { friendly: ['Przyjazny', 'fa-handshake'], neutral: ['Neutralny', 'fa-scale-balanced'], hostile: ['Wrogi', 'fa-skull'] };

    // ---------- obliczenia ----------
    const crNum = (cr) => { const s = String(cr ?? '').trim(); if (s.includes('/')) { const [a, b] = s.split('/'); return (+a || 0) / (+b || 1); } return parseFloat(s) || 0; };
    const profOf = (st) => st?.prof ? +st.prof : Math.max(2, Math.floor((crNum(st?.cr) - 1) / 4) + 2);
    const mod = (score) => Math.floor(((+score || 10) - 10) / 2);
    const sgn = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);
    const xpOf = (cr) => (API() ? API().crToXP(crNum(cr)) : 0);
    const plDice = (e) => String(e || '').replace(/d/g, 'k');
    // „2k6+3” → { n, s, b }; liczba bez kości → tylko premia
    function parseDice(e) {
        const s = String(e || '').replace(/\s/g, '').replace(/k/gi, 'd').replace(/−/g, '-');
        const m = s.match(/^(\d*)d(\d+)((?:[+-]\d+)*)$/i);
        if (m) return { n: +(m[1] || 1), s: +m[2], b: (m[3].match(/[+-]\d+/g) || []).reduce((a, x) => a + +x, 0) };
        if (/^[+-]?\d+$/.test(s)) return { n: 0, s: 0, b: +s };
        return null;
    }
    const diceStr = (d, pl) => !d ? '' : (d.n ? `${d.n}${pl ? 'k' : 'd'}${d.s}` : '') + (d.b ? (d.n ? (d.b > 0 ? '+' : '−') + Math.abs(d.b) : String(d.b)) : (d.n ? '' : '0'));
    const avg = (d) => d ? Math.max(d.n ? 1 : 0, Math.floor(d.n * (d.s + 1) / 2 + d.b)) : 0;
    const rollExpr = (d) => d ? (d.n ? `${d.n}d${d.s}${d.b ? (d.b > 0 ? '+' : '') + d.b : ''}` : String(d.b)) : '';
    const skillMod = (st, sk) => { const ab = String(SKILLS[sk] || 'WIS').toLowerCase(); return mod(st[ab]) + profOf(st) * (+(st.skills || {})[sk] || 0); };
    const passive = (st) => 10 + skillMod(st, 'Percepcja');
    const tokenSize = (st) => (SIZES[st?.size] || SIZES.Medium)[1];

    // ---------- normalizacja (też starych zapisów: tekstowe akcje, „30 ft.”, „8 (3900 XP)”) ----------
    function parseText(txt) {
        if (Array.isArray(txt)) return txt.map(e => typeof e === 'string' ? { kind: 'text', name: '', desc: e } : { kind: 'text', ...e });
        return String(txt || '').split(/\n+/).map(l => l.trim()).filter(Boolean).map(l => {
            const m = l.match(/^([^.:]{1,70}?(?:\([^)]*\))?)[.:]\s+(.+)$/);
            return m ? { kind: 'text', name: m[1].trim(), desc: m[2].trim() } : { kind: 'text', name: '', desc: l };
        });
    }
    function normStats(s0) {
        const s = { ...(s0 || {}) };
        AB.forEach(k => { s[k] = parseInt(s[k], 10) || 10; });
        s.ac = parseInt(s.ac, 10) || 10;
        s.hp = parseInt(s.hp, 10) || 10;
        s.speeds = { walk: parseInt(s.speeds?.walk ?? s.speed, 10) || 30, ...Object.fromEntries(Object.entries(s.speeds || {}).filter(([k]) => k !== 'walk')) };
        s.speed = s.speeds.walk;
        const crm = String(s.cr ?? '').match(/^\s*(\d+\/\d+|\d+(?:\.\d+)?)/);
        s.cr = crm ? (CRS.includes(crm[1]) ? crm[1] : ({ '0.125': '1/8', '0.25': '1/4', '0.5': '1/2' })[crm[1]] || crm[1]) : (s.cr === 0 ? '0' : '1');
        s.size = SIZES[s.size] ? s.size : 'Medium';
        s.ctype = s.ctype || 'humanoid';
        s.saves = Array.isArray(s.saves) ? s.saves.filter(k => AB.includes(k)) : [];
        s.skills = s.skills && typeof s.skills === 'object' ? s.skills : {};
        ['vuln', 'resist', 'immune', 'condImmune'].forEach(k => { s[k] = Array.isArray(s[k]) ? s[k] : []; });
        s.senses = s.senses && typeof s.senses === 'object' ? s.senses : {};
        s.traits = Array.isArray(s.traits) ? s.traits : parseText(s.special_abilities);
        s.actions = Array.isArray(s.actions) ? s.actions : parseText(s.actions);
        s.legendary = Array.isArray(s.legendary) ? s.legendary : parseText(s.legendary_actions);
        s.bonus = Array.isArray(s.bonus) ? s.bonus : [];
        s.reactions = Array.isArray(s.reactions) ? s.reactions : [];
        s.legendaryCount = parseInt(s.legendaryCount, 10) || 3;
        s.spells = s.spells && typeof s.spells === 'object' ? s.spells : { ab: '', list: '' };
        delete s.special_abilities; delete s.legendary_actions;
        return s;
    }
    function normNPC(n) {
        const x = clone(n) || {};
        x.disposition = DISP[x.disposition] ? x.disposition : 'neutral';
        x.kind = x.kind || (x.race === 'Przeciwnik' && x.role === 'Wróg' ? 'enemy' : 'npc');
        if (x.kind === 'enemy') { if (x.race === 'Przeciwnik') x.race = ''; if (x.role === 'Wróg') x.role = ''; }
        if (x.hasStats || x.kind === 'enemy') { x.hasStats = true; x.stats = normStats(x.stats); }
        else x.stats = x.stats ? normStats(x.stats) : null;
        return x;
    }
    function blankNPC(kind, preset = {}) {
        const enemy = kind === 'enemy';
        return normNPC({ id: null, kind, name: '', race: '', role: '', disposition: enemy ? 'hostile' : 'neutral', location: '', description: '', motivations: '', secrets: '', notes: '', hasStats: enemy, stats: enemy ? {} : null, ...preset });
    }

    // ---------- opis wpisu (atak, efekt) ----------
    function entryCalc(e, st) {
        const ab = e.ab || (e.kind === 'rw' ? 'dex' : e.kind === 'ms' || e.kind === 'rs' || e.kind === 'save' ? (st.spells?.ab || 'wis') : 'str');
        const m = mod(st[ab]), p = profOf(st), mg = parseInt(e.magic, 10) || 0;
        const hit = e.hit !== '' && e.hit != null && !isNaN(+e.hit) ? +e.hit : m + p + mg;
        const weapon = e.kind === 'mw' || e.kind === 'rw';
        const add = (e.addMod ?? weapon) ? m : 0;
        let d1 = parseDice(e.dmg); if (d1) d1 = { ...d1, b: d1.b + add + (weapon ? mg : 0) };
        const d2 = parseDice(e.dmg2);
        const dc = e.dc !== '' && e.dc != null && !isNaN(+e.dc) ? +e.dc : 8 + p + m;
        return { ab, hit, d1, d2, dc };
    }
    const btn = (expr, label, txt, cls = '') => `<button type="button" class="nr ${cls}" data-roll="${esc(expr)}" data-lbl="${esc(label)}" title="Rzuć ${esc(plDice(expr))}">${txt}</button>`;
    const dmgTxt = (d, type, label, roll) => {
        if (!d) return '';
        const ph = DMG[type] ? DMG[type][1] : (type ? esc(type) : '');
        const dice = d.n ? (roll ? btn(rollExpr(d), label + ': obrażenia', `${avg(d)} (${diceStr(d, true)})`, 'dmg') : `${avg(d)} (${diceStr(d, true)})`) : String(avg(d));
        return `${dice} obrażeń${ph ? ' ' + ph : ''}`;
    };
    // tekst w stylu podręcznika; roll=true → wartości są przyciskami rzutów
    function entryHTML(e, st, roll = true, who = '') {
        const name = esc(e.name || '') + (e.recharge ? ` (odnowienie ${esc(e.recharge)})` : '') + (e.cost > 1 ? ` (kosztuje ${e.cost} akcje)` : '');
        const label = (who ? who + ' — ' : '') + (e.name || 'Akcja');
        let body = '';
        if (e.kind && e.kind !== 'text') {
            const c = entryCalc(e, st);
            if (e.kind === 'save') {
                body = `Cel musi wykonać rzut obronny na ${AB_GEN[e.saveAb || 'dex']} <b class="nr-dc">ST ${c.dc}</b>.`
                    + (c.d1 ? ` Porażka: ${dmgTxt(c.d1, e.dt, label, roll)}${c.d2 ? ` plus ${dmgTxt(c.d2, e.dt2, label + ' (dodatkowe)', roll)}` : ''}${e.half ? ', sukces: połowa tych obrażeń' : ''}.` : '');
            } else {
                const kindTxt = ({ mw: 'Atak bronią wręcz', rw: 'Atak bronią dystansową', ms: 'Atak czarem wręcz', rs: 'Atak czarem dystansowy' })[e.kind];
                const reach = e.reach || (e.kind === 'rw' ? '80/320 ft' : e.kind === 'rs' ? '120 ft' : '5 ft');
                const hitB = roll ? btn(`1d20${c.hit >= 0 ? '+' : ''}${c.hit}`, label + ': trafienie', sgn(c.hit), 'hit') : sgn(c.hit);
                body = `<i>${kindTxt}:</i> ${hitB} do trafienia, ${e.kind === 'rw' || e.kind === 'rs' ? 'zasięg' : 'zasięg wręcz'} ${esc(reach)}, ${esc(e.target || 'jeden cel')}.`
                    + (c.d1 ? ` <i>Trafienie:</i> ${dmgTxt(c.d1, e.dt, label, roll)}${c.d2 ? ` plus ${dmgTxt(c.d2, e.dt2, label + ' (dodatkowe)', roll)}` : ''}.` : '');
            }
        }
        const extra = e.desc ? (roll ? rollify(e.desc, label) : esc(e.desc)) : '';
        return `<div class="nb-entry">${name ? `<b class="nb-en">${name}.</b> ` : ''}${body}${body && extra ? ' ' : ''}${extra}</div>`;
    }
    // rzuty ukryte w zwykłym tekście: „+5 do trafienia”, „2k6+3”, „(1d6 + 2)”
    function rollify(text, label) {
        // jeden przebieg — żeby wstawione przyciski nie były ponownie przetwarzane
        const RX = /([+−-]\s?\d+)(\s*(?:do trafienia|to hit|na trafienie|hit)\b)|\b(\d{0,2})\s?[dk](\d{1,3})((?:\s?[+−-]\s?\d+)?)(?![\w])/gi;
        return esc(text).replace(RX, (all, hb, rest, n, sd, b) => {
            if (hb) {
                const v = parseInt(hb.replace(/−/, '-').replace(/\s/g, ''), 10);
                return isNaN(v) ? all : btn(`1d20${v >= 0 ? '+' : ''}${v}`, label + ': trafienie', sgn(v), 'hit') + rest;
            }
            const d = parseDice(`${n || 1}d${sd}${(b || '').replace(/\s/g, '').replace(/−/g, '-')}`);
            return d ? btn(rollExpr(d), label, all.trim(), 'dmg') : all;
        }).replace(/\n/g, '<br>');
    }

    // ---------- blok statystyk ----------
    function statBlockHTML(n, opts = {}) {
        const st = n.stats; if (!st) return '';
        const p = profOf(st), who = n.name;
        const hd = parseDice(st.hitDice);
        const typeTxt = [`${(SIZES[st.size] || SIZES.Medium)[0]} ${TYPES[st.ctype] || st.ctype}`, n.race && n.race.toLowerCase() !== (TYPES[st.ctype] || '').toLowerCase() ? `(${esc(n.race)})` : ''].filter(Boolean).join(' ') + (st.alignment ? `, ${esc(st.alignment)}` : '');
        const speeds = Object.entries(st.speeds || {}).filter(([, v]) => +v).map(([k, v]) => k === 'walk' ? `${v} ft` : `${SPEEDS[k]} ${v} ft`).join(', ') + (st.hover ? ' (unosi się)' : '');
        const saves = st.saves.map(k => btn(`1d20${sgn(mod(st[k]) + p).replace('−', '-')}`, `${who}: rzut obronny (${AB_PL[k]})`, `${AB_S[k]} ${sgn(mod(st[k]) + p)}`)).join(' ');
        const skills = Object.keys(st.skills).filter(k => +st.skills[k] > 0 && SKILLS[k]).sort((a, b) => a.localeCompare(b, 'pl')).map(k => btn(`1d20${sgn(skillMod(st, k)).replace('−', '-')}`, `${who}: ${k}`, `${k} ${sgn(skillMod(st, k))}`)).join(' ');
        const dl = (arr) => arr.map(k => DMG_DEF[k] || k).join('; ');
        const senses = [...Object.entries(st.senses).filter(([, v]) => +v).map(([k, v]) => `${SENSES[k] || k} ${v} ft`), `pasywna Percepcja ${passive(st)}`].join(', ');
        const init = mod(st.dex) + (parseInt(st.initBonus, 10) || 0);
        const list = (key) => (st[key] || []).filter(e => e.name || e.desc || (e.kind && e.kind !== 'text'));
        const sec = (key) => list(key).length ? `<div class="nb-sec"><h5><i class="fa-solid ${LISTS[key][1]}"></i> ${LISTS[key][0]}</h5>
            ${key === 'legendary' ? `<p class="nb-intro">${esc(n.name)} może wykonać ${st.legendaryCount} akcje legendarne, wybierając z poniższych. Naraz tylko jedną, zawsze pod koniec tury innego stworzenia. Wykorzystane akcje odzyskuje na początku swojej tury.</p>` : ''}
            ${list(key).map(e => entryHTML(e, st, true, who)).join('')}</div>` : '';
        const sp = st.spells || {};
        const spellSec = sp.ab && (sp.list || '').trim() ? `<div class="nb-sec"><h5><i class="fa-solid fa-wand-magic-sparkles"></i> Rzucanie czarów</h5>
            <div class="nb-entry">Cechą czarującą jest ${AB_PL[sp.ab]} (<b class="nr-dc">ST ${8 + p + mod(st[sp.ab])}</b>, ${btn(`1d20${sgn(p + mod(st[sp.ab])).replace('−', '-')}`, `${who}: atak czarem`, sgn(p + mod(st[sp.ab])), 'hit')} do trafienia czarem).</div>
            <div class="nb-entry nb-spells">${rollify(sp.list, who + ' — czar')}</div></div>` : '';
        return `<div class="nb ${opts.compact ? 'nb-compact' : ''}">
            <div class="nb-type">${typeTxt}</div>
            <div class="nb-vitals">
                <div class="nb-v"><small>Klasa pancerza</small><b>${st.ac}</b>${st.acNote ? `<em>${esc(st.acNote)}</em>` : ''}</div>
                <div class="nb-v"><small>Punkty wytrzymałości</small><b>${st.hpNow != null ? `${st.hpNow}<small class="nb-of">/${st.hp}</small>` : st.hp}</b>${hd ? `<em>${btn(rollExpr(hd), `${who}: punkty wytrzymałości`, diceStr(hd, true))}</em>` : ''}</div>
                <div class="nb-v"><small>Szybkość</small><b>${st.speeds.walk} ft</b>${speeds.includes(',') ? `<em>${esc(speeds.split(', ').slice(1).join(', '))}</em>` : ''}</div>
                <div class="nb-v"><small>Inicjatywa</small><b>${btn(`1d20${init >= 0 ? '+' : ''}${init}`, `${who}: inicjatywa`, sgn(init))}</b></div>
            </div>
            <div class="nb-abil">${AB.map(k => `<button type="button" class="nb-ab" data-roll="1d20${mod(st[k]) >= 0 ? '+' : ''}${mod(st[k])}" data-lbl="${esc(who)}: test (${AB_PL[k]})" title="Test: ${AB_PL[k]}"><small>${AB_S[k]}</small><b>${st[k]}</b><span>${sgn(mod(st[k]))}</span>${st.saves.includes(k) ? '<i title="Biegłość w rzucie obronnym">●</i>' : ''}</button>`).join('')}</div>
            <div class="nb-lines">
                ${saves ? `<div><strong>Rzuty obronne</strong> ${saves}</div>` : ''}
                ${skills ? `<div><strong>Umiejętności</strong> ${skills}</div>` : ''}
                ${st.vuln.length ? `<div><strong>Podatność</strong> ${esc(dl(st.vuln))}</div>` : ''}
                ${st.resist.length ? `<div><strong>Odporność</strong> ${esc(dl(st.resist))}</div>` : ''}
                ${st.immune.length ? `<div><strong>Niewrażliwość</strong> ${esc(dl(st.immune))}</div>` : ''}
                ${st.condImmune.length ? `<div><strong>Niewrażliwość na stany</strong> ${esc(st.condImmune.map(k => CONDS[k] || k).join(', '))}</div>` : ''}
                <div><strong>Zmysły</strong> ${esc(senses)}</div>
                <div><strong>Języki</strong> ${esc(st.languages || '—')}</div>
                ${opts.pc ? `<div><strong>Poziom</strong> ${esc(opts.pc)} <span class="nb-prof">Premia z biegłości ${sgn(p)}</span></div>` : `<div><strong>Wyzwanie</strong> ${esc(st.cr)} (${xpOf(st.cr).toLocaleString(window.LOC || 'pl-PL')} PD) <span class="nb-prof">Premia z biegłości ${sgn(p)}</span></div>`}
            </div>
            ${sec('traits')}${spellSec}${sec('actions')}${sec('bonus')}${sec('reactions')}${sec('legendary')}
            ${opts.gear === false ? '' : gearSecHTML(n)}
        </div>`;
    }
    // ekwipunek w bloku statystyk (NPC i bohaterowie w walce)
    function gearSecHTML(n) {
        const inv = (n.inventory || []).filter(it => it && it.name), c = n.coins || {};
        const coins = [['gp', 'sz'], ['sp', 'ss'], ['cp', 'sm']].filter(([k]) => +c[k]).map(([k, l]) => `${c[k]} ${l}`).join(', ');
        if (!inv.length && !coins && !n.gear) return '';
        return `<div class="nb-sec nb-gear"><h5><i class="fa-solid fa-sack-xmark"></i> Ekwipunek${inv.length ? ` <small>${fmtLb(invW(inv))}</small>` : ''}</h5>
            ${inv.length ? `<div class="nb-entry">${inv.map(it => `${esc(it.name)}${+it.quantity > 1 ? ` ×${it.quantity}` : ''}`).join(', ')}.</div>` : ''}
            ${coins ? `<div class="nb-entry"><b class="nb-en">Sakiewka.</b> ${coins}.</div>` : ''}
            ${n.gear ? `<div class="nb-entry">${esc(n.gear).replace(/\n/g, '<br>')}</div>` : ''}</div>`;
    }
    /* Bohater gracza w postaci bloku statystyk (jak NPC): cechy, rzuty, umiejętności, ataki z broni,
       zdolności klasy, czary i ekwipunek — do karty tury w walce. */
    function fromCharacter(ch) {
        if (!ch) return null;
        const A = ch.abilityScores || {}, lvl = parseInt(ch.level, 10) || 1, prof = Math.ceil(lvl / 4) + 1;
        const skills = {};
        const plSkill = (k) => SKILLS[k] ? k : SKILL_EN[k] || null;
        (ch.proficiencies || []).forEach(k => { const pl = plSkill(k); if (pl) skills[pl] = 1; });
        (ch.expertise || []).forEach(k => { const pl = plSkill(k); if (pl) skills[pl] = 2; });
        const atk = window.Kits ? Kits.attacks(ch, 8) : [];
        const dtOf = (t) => ({ 'cięte': 'slashing', 'kłute': 'piercing', 'obuchowe': 'bludgeoning' })[String(t || '').toLowerCase()] || '';
        const actions = atk.map(a => ({ kind: a.ranged ? 'rw' : 'mw', name: a.name, hit: a.hit, dmg: String(a.dmg).replace('−', '-'), addMod: false, dt: dtOf(a.type), reach: a.ranged ? (window.ItemsDB?.find(a.name)?.range ? `${ItemsDB.find(a.name).range} ft` : '80/320 ft') : '5 ft' }));
        const feats = [...(ch.classFeatures || []), ...(ch.subclassFeatures || []), ...(ch.feats || [])].filter(f => f && f.name).slice(0, 14).map(f => ({ kind: 'text', name: window.PL ? PL.feat(f.name) : f.name, desc: String(f.desc || f.description || '').slice(0, 400) }));
        const sp = ch.spellcasting?.ability ? String(ch.spellcasting.ability).toLowerCase().slice(0, 3) : '';
        const byLv = {};
        (ch.spells || []).forEach(x => { const l = parseInt(x.level, 10) || 0; (byLv[l] = byLv[l] || []).push(window.PL ? PL.spell(x.name) : x.name); });
        const slots = ch.spellSlots || {};
        const spellList = Object.keys(byLv).sort((a, b) => a - b).map(l => `${+l ? `${l}. krąg${slots[l] ? ` (${Math.max(0, (slots[l].total || 0) - (slots[l].used || 0))}/${slots[l].total} miejsc)` : ''}` : 'Sztuczki'}: ${byLv[l].join(', ')}`).join('\n');
        const cur = ch.currency || {};
        const stats = normStats({
            str: A.str, dex: A.dex, con: A.con, int: A.int, wis: A.wis, cha: A.cha, ac: ch.ac || 10, hp: ch.hp?.max || 1, prof,
            speeds: { walk: parseInt(ch.speed, 10) || 30 }, size: SIZES[ch.size] ? ch.size : 'Medium', ctype: 'humanoid', alignment: ch.alignment || '',
            saves: (ch.savingThrows || []).map(k => String(k).toLowerCase().slice(0, 3)), skills, cr: '1',
            languages: Array.isArray(ch.languages) ? (window.PL ? PL.langs(ch.languages) : ch.languages).join(', ') : (ch.languages || ''),
            traits: feats, actions, spells: AB.includes(sp) && spellList ? { ab: sp, list: spellList } : { ab: '', list: '' }
        });
        stats.hpNow = ch.hp?.current ?? stats.hp;
        return { id: ch.id, name: ch.name, race: ch.race || '', hasStats: true, stats,
            inventory: (ch.inventory || []).map(it => ({ name: it.name, quantity: it.quantity || 1, weight: it.weight || 0 })),
            coins: { gp: cur.gp || 0, sp: cur.sp || 0, cp: cur.cp || 0 }, pcLabel: `${lvl} · ${[ch.race, ch.class].filter(Boolean).join(' ')}` };
    }
    function pcBlockHTML(ch, opts = {}) {
        const n = fromCharacter(ch); if (!n) return '';
        return statBlockHTML(n, { ...opts, pc: n.pcLabel });
    }

    // ---------- init / lista ----------
    function init() {
        document.getElementById('btn-add-npc')?.addEventListener('click', () => openEditor(null, 'npc'));
        document.getElementById('btn-add-enemy')?.addEventListener('click', () => openEditor(null, 'enemy'));
        document.getElementById('npcs-search')?.addEventListener('input', () => renderList());
        document.getElementById('npcs-type-filter')?.addEventListener('change', () => renderList());
        document.getElementById('npcs-location-filter')?.addEventListener('change', () => renderList());
        // rzuty z kart NPC (panel, okno walki, notatki) — jeden nasłuch na cały dokument
        document.addEventListener('click', (e) => {
            const b = e.target.closest('[data-roll]');
            if (!b || !b.closest('.nb, .nb-host')) return;
            e.preventDefault(); e.stopPropagation();
            rollNow(b.dataset.roll, b.dataset.lbl || '');
        });
    }
    function rollNow(expr, label) {
        if (window.DiceRoller?.rollExpression) DiceRoller.rollExpression(expr, 'normal', label);
    }

    function activate() {
        const campaignId = cid();
        if (!campaignId) {
            const list = document.getElementById('npcs-list');
            if (list) list.innerHTML = '<p class="empty-state">Wybierz kampanię, aby zarządzać NPC.</p>';
            return;
        }
        injectMockNPCsIfNeeded(campaignId);
        loadNPCs();
        updateLocationFilter();
        renderList();
        if (currentDetailId && npcs.some(n => n.id === currentDetailId) && !document.getElementById('npc-detail')?.classList.contains('hidden')) showDetail(currentDetailId);
    }

    function injectMockNPCsIfNeeded(cId) {
        // Przykładowe postacie z pakietu kampanii (assets/kampania/pakiet.js) — tylko w jego kampanii.
        const P = window.PANEL_PAKIET;
        if (!P || typeof P.npc !== 'function' || cId !== P.kampania) return;
        const locNPCs = StorageManager.getNPCs(cId) || [];
        if (locNPCs.length > 0 && P.znacznikNpc && locNPCs.find(n => n.name === P.znacznikNpc)) return;
        const currentNames = locNPCs.map(n => n.name);
        P.npc().filter(n => !currentNames.includes(n.name)).forEach(npc => StorageManager.saveNPC(cId, npc));
    }

    function loadNPCs() { npcs = (StorageManager.getNPCs(cid()) || []).map(normNPC); }
    const getNPC = (id) => { const raw = (StorageManager.getNPCs(cid()) || []).find(n => n.id === id); return raw ? normNPC(raw) : null; };

    function updateLocationFilter() {
        const locFilter = document.getElementById('npcs-location-filter');
        if (!locFilter) return;
        const locations = new Set(npcs.map(n => n.location).filter(Boolean));
        const cur = locFilter.value;
        locFilter.innerHTML = '<option value="">Wsz. lokacje</option>' + [...locations].sort((a, b) => a.localeCompare(b, 'pl')).map(l => `<option value="${esc(l)}">${esc(l)}</option>`).join('');
        if (locations.has(cur)) locFilter.value = cur;
    }

    function renderList() {
        const list = document.getElementById('npcs-list');
        if (!list) return;
        if (!npcs.length) { list.innerHTML = '<p class="empty-state">Brak postaci w tej kampanii. Dodaj pierwszego NPC albo przeciwnika.</p>'; return; }
        const search = (document.getElementById('npcs-search')?.value || '').toLowerCase();
        const typeF = document.getElementById('npcs-type-filter')?.value || '';
        const locF = document.getElementById('npcs-location-filter')?.value || '';
        const filtered = npcs.filter(n => {
            if (search && ![n.name, n.role, n.race, n.location].some(v => String(v || '').toLowerCase().includes(search))) return false;
            if (typeF === 'stats') { if (!n.hasStats) return false; }
            else if (typeF === 'enemy') { if (n.kind !== 'enemy') return false; }
            else if (typeF && n.disposition !== typeF) return false;
            if (locF && n.location !== locF) return false;
            return true;
        });
        if (!filtered.length) { list.innerHTML = '<p class="empty-state">Brak wyników spełniających kryteria wyszukiwania.</p>'; return; }
        list.innerHTML = filtered.map(n => {
            const st = n.hasStats ? n.stats : null;
            const sub = [n.role, n.race || (st ? TYPES[st.ctype] : '')].filter(Boolean);
            return `<div class="data-card npc-card d-${n.disposition} ${n.kind === 'enemy' ? 'is-enemy' : ''} ${currentDetailId === n.id ? 'sel' : ''}" data-npc="${esc(n.id)}" tabindex="0">
                <div class="npc-card-head">
                    <span class="npc-seal" title="${DISP[n.disposition][0]}"><i class="fa-solid ${n.kind === 'enemy' ? 'fa-skull' : DISP[n.disposition][1]}"></i></span>
                    <div><div class="card-name">${esc(n.name)}</div>${sub.length ? `<div class="card-subtitle">${esc(sub[0])}${sub[1] ? ` <span>(${esc(sub[1])})</span>` : ''}</div>` : ''}</div>
                </div>
                ${st ? `<div class="npc-vitals"><span title="Klasa pancerza"><i class="fa-solid fa-shield-halved"></i> ${st.ac}</span><span title="Punkty wytrzymałości"><i class="fa-solid fa-heart"></i> ${st.hp}</span><span title="Wyzwanie"><i class="fa-solid fa-skull-crossbones"></i> CR ${esc(st.cr)}</span><span title="Szybkość"><i class="fa-solid fa-shoe-prints"></i> ${st.speeds.walk}</span></div>` : ''}
                <div class="card-tags">
                    <span class="card-tag npc-disp">${n.kind === 'enemy' ? 'Przeciwnik' : DISP[n.disposition][0]}</span>
                    ${n.location ? `<span class="card-tag tag-type"><i class="fa-solid fa-location-dot"></i> ${esc(n.location)}</span>` : ''}
                    ${!st ? '<span class="card-tag tag-nostats">bez statystyk</span>' : ''}
                </div>
            </div>`;
        }).join('');
        list.onclick = (e) => { const c = e.target.closest('[data-npc]'); if (c) showDetail(c.dataset.npc); };
        list.onkeydown = (e) => { const c = e.target.closest('[data-npc]'); if (c && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); showDetail(c.dataset.npc); } };
    }

    // ---------- panel szczegółów ----------
    function placeLink(name) {
        if (!name) return '';
        const l = (StorageManager.getLocations(cid()) || []).find(x => String(x.name || '').toLowerCase() === String(name).toLowerCase());
        return l ? `<button class="npc-loc" onclick="NPCsModule.goPlace('${esc(l.id)}')" title="Pokaż na mapie"><i class="fa-solid fa-location-dot"></i> ${esc(name)}</button>` : `<span class="npc-loc"><i class="fa-solid fa-location-dot"></i> ${esc(name)}</span>`;
    }
    function goPlace(id) { if (window.Atlas?.focus) Atlas.focus(id); }

    function showDetail(npcId) {
        loadNPCs();
        const n = npcs.find(x => x.id === npcId);
        const panel = document.getElementById('npc-detail');
        if (!n || !panel) return;
        currentDetailId = npcId;
        document.querySelectorAll('#npcs-list [data-npc]').forEach(c => c.classList.toggle('sel', c.dataset.npc === npcId));
        const txt = (t) => esc(t).replace(/\n/g, '<br>');
        panel.innerHTML = `
            <button class="btn-icon detail-close" onclick="NPCsModule.closeDetail()" title="Zamknij">✕</button>
            <div class="npc-hero d-${n.disposition}">
                <span class="npc-seal big"><i class="fa-solid ${n.kind === 'enemy' ? 'fa-skull' : DISP[n.disposition][1]}"></i></span>
                <div>
                    <h3>${esc(n.name)}</h3>
                    <p>${esc([n.role, n.race].filter(Boolean).join(' · ')) || (n.kind === 'enemy' ? 'Przeciwnik' : 'NPC')}</p>
                    <div class="npc-chips"><span class="npc-disp-chip">${n.kind === 'enemy' ? 'Przeciwnik' : DISP[n.disposition][0]}</span>${n.party ? `<span class="npc-disp-chip cmp-chip"><i class="fa-solid fa-handshake-angle"></i> w drużynie${n.party.charId ? ` · prowadzi: ${esc(((StorageManager.getCharacters(cid()) || []).find(c => c.id === n.party.charId) || {}).name || '?')}` : ' · osobno'}</span>` : ''}${placeLink(n.location)}</div>
                </div>
            </div>
            <div class="detail-actions detail-actions-row npc-actions">
                ${n.hasStats ? `<button class="btn-primary btn-small" onclick="NPCsModule.addToCombat('${n.id}')"><i class="fa-solid fa-khanda"></i> Do walki</button>` : `<button class="btn-secondary btn-small" onclick="NPCsModule.editNPC('${n.id}', 'stats')" title="Dodaj statystyki, by NPC mógł walczyć"><i class="fa-solid fa-dice-d20"></i> Dodaj statystyki</button>`}
                ${n.kind !== 'enemy' && window.Companions ? `<button class="btn-secondary btn-small ${n.party ? 'is-on' : ''}" onclick="Companions.join('${n.id}')" title="${n.party ? 'Towarzysz drużyny — zmień, kto go prowadzi' : 'Dołącz do drużyny jako towarzysz'}"><i class="fa-solid fa-handshake-angle"></i> ${n.party ? 'W drużynie' : 'Do drużyny'}</button>` : ''}
                <button class="btn-secondary btn-small" onclick="NPCsModule.editNPC('${n.id}')"><i class="fa-solid fa-pen"></i> Edytuj</button>
                <button class="btn-secondary btn-small" onclick="NPCsModule.duplicateNPC('${n.id}')" title="Utwórz kopię (np. kolejny strażnik)"><i class="fa-solid fa-clone"></i></button>
                <button class="btn-secondary btn-small" onclick="NPCsModule.pinNPC('${n.id}')" title="Przypnij jako notatkę"><i class="fa-solid fa-thumbtack"></i></button>
                <button class="btn-danger btn-small" onclick="NPCsModule.deleteNPC('${n.id}')" title="Usuń"><i class="fa-solid fa-trash"></i></button>
            </div>
            ${n.description ? `<div class="detail-section"><div class="detail-section-title">Opis / wygląd</div><div class="npc-text">${txt(n.description)}</div></div>` : ''}
            ${n.motivations ? `<div class="detail-section"><div class="detail-section-title">${n.kind === 'enemy' ? 'Taktyka i cel' : 'Motywacje'}</div><div class="npc-text gold">${txt(n.motivations)}</div></div>` : ''}
            ${n.secrets ? `<div class="detail-section npc-secret"><div class="detail-section-title"><i class="fa-solid fa-user-secret"></i> ${n.kind === 'enemy' ? 'Łup i sekrety' : 'Sekrety'}</div><div class="npc-text">${txt(n.secrets)}</div></div>` : ''}
            ${!n.hasStats && (n.gear || (n.inventory || []).length) ? `<div class="detail-section"><div class="detail-section-title">Ekwipunek</div><div class="nb-host">${gearSecHTML(n)}</div></div>` : ''}
            ${n.notes ? `<div class="detail-section"><div class="detail-section-title">Notatki dla MG</div><div class="npc-text">${txt(n.notes)}</div></div>` : ''}
            ${n.hasStats ? `<div class="detail-section-title npc-sb-title">Statystyki <small>kliknij wartość, by rzucić</small></div>${statBlockHTML(n)}` : ''}`;
        panel.classList.remove('hidden');
    }

    function closeDetail() {
        document.getElementById('npc-detail')?.classList.add('hidden');
        document.querySelectorAll('#npcs-list .sel').forEach(c => c.classList.remove('sel'));
        currentDetailId = null;
    }

    // karta NPC w oknie (z walki, z żetonu na planszy)
    function showSheet(npcId) {
        const n = getNPC(npcId);
        if (!n) { App.showToast('Nie znaleziono tego NPC w kampanii', 'warning'); return; }
        App.showModal(n.name, `<div class="nb-host">${n.description ? `<p class="npc-text nb-desc">${esc(n.description)}</p>` : ''}${n.hasStats ? statBlockHTML(n) : '<p class="ai-muted">Ta postać nie ma statystyk.</p>'}</div>`,
            `<button class="btn-secondary" onclick="NPCsModule.editNPC('${n.id}')"><i class="fa-solid fa-pen"></i> Edytuj</button><button class="btn-primary" onclick="App.closeModal()">Zamknij</button>`);
        document.getElementById('modal')?.classList.add('modal-wide');
    }

    // ================= KREATOR =================
    let ED = null;   // { d: dane, tab, isNew }
    const getPath = (o, p) => p.split('.').reduce((a, k) => a == null ? a : a[k], o);
    const setPath = (o, p, v) => { const ks = p.split('.'); let a = o; ks.slice(0, -1).forEach(k => { if (a[k] == null) a[k] = /^\d+$/.test(k) ? [] : {}; a = a[k]; }); a[ks[ks.length - 1]] = v; };

    function openEditor(id, kind, opts = {}) {
        const campaignId = cid();
        if (!campaignId) { App.showToast('Najpierw wybierz lub utwórz kampanię!', 'error'); return; }
        const src = id ? getNPC(id) : null;
        const d = src || blankNPC(kind || 'npc', opts.preset || {});
        if (opts.tab === 'stats' && !d.hasStats) { d.hasStats = true; d.stats = normStats(d.stats); }
        ED = { d, tab: opts.tab || 'who', isNew: !src };
        const enemy = d.kind === 'enemy';
        const title = src ? `Edycja: ${src.name}` : enemy ? 'Nowy przeciwnik' : 'Nowy NPC';
        App.showModal(title, `<div class="ne" id="ne"></div>`,
            `${src ? `<button class="btn-danger" style="margin-right:auto" onclick="NPCsModule.deleteNPC('${src.id}')"><i class="fa-solid fa-trash"></i> Usuń</button>` : ''}
             <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
             <button class="${enemy ? 'btn-danger' : 'btn-primary'}" id="ne-save"><i class="fa-solid fa-check"></i> ${src ? 'Zapisz zmiany' : enemy ? 'Utwórz przeciwnika' : 'Utwórz NPC'}</button>`);
        document.getElementById('modal')?.classList.add('modal-wide', 'modal-ne');
        renderEditor();
        const root = document.getElementById('ne');
        root.addEventListener('input', onEdInput);
        root.addEventListener('change', onEdInput);
        root.addEventListener('click', onEdClick);
        document.getElementById('ne-save').onclick = saveEditor;
        setTimeout(() => document.getElementById('ne-name')?.focus(), 30);
    }

    function locOptions() {
        const locs = (StorageManager.getLocations(cid()) || []).filter(l => l.type !== 'region' && l.name).map(l => l.name);
        const fromNpcs = (StorageManager.getNPCs(cid()) || []).map(n => n.location).filter(Boolean);
        return [...new Set([...locs, ...fromNpcs])].sort((a, b) => a.localeCompare(b, 'pl'));
    }

    function renderEditor() {
        const root = document.getElementById('ne'); if (!root || !ED) return;
        const d = ED.d, st = d.stats, has = d.hasStats;
        const tabs = [['who', 'fa-user', 'Postać'], ['stats', 'fa-dice-d20', 'Statystyki'], ['acts', 'fa-hand-fist', 'Akcje i zdolności'], ['gear', 'fa-sack-xmark', 'Ekwipunek']];
        if (!has && ED.tab !== 'who' && ED.tab !== 'gear') ED.tab = 'who';
        d.inventory = Array.isArray(d.inventory) ? d.inventory : []; d.coins = d.coins && typeof d.coins === 'object' ? d.coins : {};
        const f = (path, label, attrs = '', cls = '') => `<label class="ne-f ${cls}"><span>${label}</span><input data-f="${path}" value="${esc(getPath(d, path) ?? '')}" ${attrs}></label>`;
        const num = (path, label, attrs = '', cls = '') => f(path, label, `type="number" data-t="num" ${attrs}`, cls);
        const sel = (path, label, opts, cls = '') => `<label class="ne-f ${cls}"><span>${label}</span><select data-f="${path}">${opts.map(([v, t]) => `<option value="${esc(v)}" ${String(getPath(d, path) ?? '') === String(v) ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;
        const area = (path, label, rows = 3, ph = '', cls = '') => `<label class="ne-f ${cls}"><span>${label}</span><textarea data-f="${path}" rows="${rows}" placeholder="${esc(ph)}">${esc(getPath(d, path) ?? '')}</textarea></label>`;

        const who = `
            <div class="ne-kind">
                <button type="button" data-kind="npc" class="${d.kind !== 'enemy' ? 'on' : ''}"><i class="fa-solid fa-user"></i> NPC</button>
                <button type="button" data-kind="enemy" class="${d.kind === 'enemy' ? 'on' : ''}"><i class="fa-solid fa-skull"></i> Przeciwnik</button>
            </div>
            <div class="ne-grid g2">
                <label class="ne-f"><span>${d.kind === 'enemy' ? 'Nazwa (np. Herszt bandytów)' : 'Imię'}</span><input id="ne-name" data-f="name" value="${esc(d.name)}" placeholder="${d.kind === 'enemy' ? 'Herszt bandytów' : 'Grumm'}"></label>
                <div class="ne-f"><span>Nastawienie do drużyny</span><div class="ne-seg">${Object.entries(DISP).map(([k, v]) => `<button type="button" data-disp="${k}" class="d-${k} ${d.disposition === k ? 'on' : ''}"><i class="fa-solid ${v[1]}"></i> ${v[0]}</button>`).join('')}</div></div>
            </div>
            <div class="ne-grid g3">
                ${f('race', 'Rasa / gatunek', 'placeholder="człowiek, goblin…"')}
                ${f('role', 'Rola / zawód', 'placeholder="kowal, strażnik, kultysta…"')}
                <label class="ne-f"><span>Lokacja</span><input data-f="location" list="ne-locs" value="${esc(d.location)}" placeholder="wybierz miejsce z atlasu…"><datalist id="ne-locs">${locOptions().map(l => `<option value="${esc(l)}">`).join('')}</datalist></label>
            </div>
            ${area('description', 'Opis i wygląd', 3, 'Jak wygląda, jak mówi, co go wyróżnia…')}
            ${d.kind === 'enemy' ? area('motivations', 'Taktyka i cel', 2, 'Jak walczy, kiedy ucieka, czego pilnuje…') : `<div class="ne-grid g2">${area('motivations', 'Motywacje (jawne)', 2)}${area('secrets', 'Sekrety (ukryte)', 2)}</div>`}
            ${d.kind === 'enemy' ? area('secrets', 'Łup i sekrety', 2, 'Co ma przy sobie, co wie…') : ''}
            ${area('notes', 'Notatki dla MG', 2)}
            ${d.kind !== 'enemy' ? `<label class="ne-check big"><input type="checkbox" data-hasstats ${has ? 'checked' : ''}> <span><b>Ma statystyki do walki</b><small>Karta z KP, PW, cechami i atakami — można go dodać do walki i na planszę.</small></span></label>` : ''}`;

        let stats = '', acts = '';
        if (has) {
            const p = profOf(st);
            stats = `
            <div class="ne-import">
                <i class="fa-solid fa-dragon"></i>
                <input id="ne-imp" list="ne-mons" placeholder="Wczytaj statystyki z bestiariusza (np. Bandit Captain, Goblin)…">
                <datalist id="ne-mons"></datalist>
                <button type="button" class="btn-secondary btn-small" data-import><i class="fa-solid fa-file-import"></i> Wczytaj</button>
            </div>
            <div class="ne-grid g4">
                ${sel('stats.size', 'Rozmiar', Object.entries(SIZES).map(([k, v]) => [k, v[0]]))}
                ${sel('stats.ctype', 'Typ stworzenia', Object.entries(TYPES).map(([k, v]) => [k, v]))}
                ${sel('stats.alignment', 'Charakter', ALIGN.map(a => [a, a || '—']))}
                ${sel('stats.cr', 'Wyzwanie (CR)', CRS.map(c => [c, `${c} — ${xpOf(c).toLocaleString(window.LOC || 'pl-PL')} PD`]))}
            </div>
            <div class="ne-grid g4">
                ${num('stats.ac', 'Klasa pancerza', 'min="1" max="30"')}
                ${f('stats.acNote', 'Źródło KP', 'placeholder="kolczuga, tarcza"')}
                ${num('stats.hp', 'Punkty wytrzymałości', 'min="1"')}
                <label class="ne-f"><span>Kości wytrzymałości</span><div class="ne-inline"><input data-f="stats.hitDice" value="${esc(st.hitDice || '')}" placeholder="np. 5k8+5"><button type="button" class="ne-mini" data-hpavg title="Ustaw PW na średnią z kości"><i class="fa-solid fa-equals"></i></button></div></label>
            </div>
            <div class="ne-box"><h5><i class="fa-solid fa-shoe-prints"></i> Szybkość (ft)</h5><div class="ne-grid g5">
                ${Object.entries(SPEEDS).map(([k, v]) => num(`stats.speeds.${k}`, v[0].toUpperCase() + v.slice(1), 'min="0" step="5"')).join('')}
            </div><label class="ne-check"><input type="checkbox" data-f="stats.hover" data-t="bool" ${st.hover ? 'checked' : ''}> unosi się w powietrzu (nie spada)</label></div>
            <div class="ne-box"><h5><i class="fa-solid fa-dumbbell"></i> Cechy i rzuty obronne <small>zaznacz biegłość w rzucie obronnym</small></h5>
                <div class="ne-abil">${AB.map(k => `<div class="ne-ab"><small>${AB_PL[k]}</small><input type="number" data-f="stats.${k}" data-t="num" min="1" max="30" value="${st[k]}"><b data-mod="${k}">${sgn(mod(st[k]))}</b>
                    <label class="ne-save" title="Biegłość w rzucie obronnym"><input type="checkbox" data-save="${k}" ${st.saves.includes(k) ? 'checked' : ''}> obrona <i data-sv="${k}">${sgn(mod(st[k]) + (st.saves.includes(k) ? p : 0))}</i></label></div>`).join('')}</div>
            </div>
            <div class="ne-box"><h5><i class="fa-solid fa-list-check"></i> Umiejętności <small>klik: biegłość → ekspertyza → brak</small></h5>
                <div class="ne-skills">${Object.keys(SKILLS).sort((a, b) => a.localeCompare(b, 'pl')).map(k => `<button type="button" class="ne-sk lv${+st.skills[k] || 0}" data-skill="${esc(k)}"><span>${esc(k)}</span><i data-skv="${esc(k)}">${sgn(skillMod(st, k))}</i></button>`).join('')}</div>
            </div>
            <div class="ne-box"><h5><i class="fa-solid fa-shield-virus"></i> Obrażenia i stany</h5>
                ${[['vuln', 'Podatność (×2)'], ['resist', 'Odporność (½)'], ['immune', 'Niewrażliwość (0)']].map(([k, t]) => `<div class="ne-chiprow"><span>${t}</span><div class="ne-chips">${Object.entries(DMG_DEF).map(([dk, dv]) => `<button type="button" class="ne-chip c-${k} ${st[k].includes(dk) ? 'on' : ''}" data-chip="${k}" data-v="${dk}">${dk === 'nonmagical' ? 'niemagiczna broń' : esc(dv)}</button>`).join('')}</div></div>`).join('')}
                <div class="ne-chiprow"><span>Niewrażliwość na stany</span><div class="ne-chips">${Object.entries(CONDS).map(([ck, cv]) => `<button type="button" class="ne-chip c-cond ${st.condImmune.includes(ck) ? 'on' : ''}" data-chip="condImmune" data-v="${ck}">${cv}</button>`).join('')}</div></div>
            </div>
            <div class="ne-box"><h5><i class="fa-solid fa-eye"></i> Zmysły i języki</h5><div class="ne-grid g5">
                ${Object.entries(SENSES).map(([k, v]) => num(`stats.senses.${k}`, v[0].toUpperCase() + v.slice(1) + ' (ft)', 'min="0" step="5"')).join('')}
                <div class="ne-f ne-ro"><span>Pasywna Percepcja</span><b data-pp>${passive(st)}</b></div>
            </div>
            <div class="ne-grid g2">${f('stats.languages', 'Języki', 'placeholder="wspólny, goblini"')}${num('stats.initBonus', 'Dodatkowa premia do inicjatywy', 'placeholder="0"')}</div></div>`;

            const entry = (key, e, i) => {
                const pfx = `stats.${key}.${i}`;
                const k = e.kind || 'text';
                const abSel = (path, val) => `<select data-f="${path}">${AB.map(a => `<option value="${a}" ${val === a ? 'selected' : ''}>${AB_S[a]}</option>`).join('')}</select>`;
                const dtSel = (path, val) => `<select data-f="${path}"><option value="">—</option>${Object.entries(DMG).map(([dk, dv]) => `<option value="${dk}" ${val === dk ? 'selected' : ''}>${dv[0]}</option>`).join('')}</select>`;
                const c = entryCalc(e, st);
                const attack = ['mw', 'rw', 'ms', 'rs'].includes(k);
                return `<div class="ne-entry k-${k}" data-entry="${key}.${i}">
                    <div class="ne-entry-top">
                        <input data-f="${pfx}.name" value="${esc(e.name || '')}" placeholder="Nazwa (np. Długi miecz, Wielokrotny atak)" class="ne-en">
                        <select data-f="${pfx}.kind" data-rerender>${Object.entries(KINDS).map(([kk, kv]) => `<option value="${kk}" ${k === kk ? 'selected' : ''}>${kv}</option>`).join('')}</select>
                        ${key === 'legendary' ? `<select data-f="${pfx}.cost" data-t="num" title="Koszt w akcjach legendarnych">${[1, 2, 3].map(x => `<option value="${x}" ${(+e.cost || 1) === x ? 'selected' : ''}>${x} akc.</option>`).join('')}</select>` : ''}
                        <input data-f="${pfx}.recharge" value="${esc(e.recharge || '')}" placeholder="odnowienie" title="Odnowienie, np. 5–6 albo 1/dzień" class="ne-rc">
                        <button type="button" class="ne-mini" data-move="${key}.${i}.-1" title="W górę"><i class="fa-solid fa-arrow-up"></i></button>
                        <button type="button" class="ne-mini danger" data-del="${key}.${i}" title="Usuń"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    ${attack ? `<div class="ne-entry-row">
                        <label>Cecha ${abSel(`${pfx}.ab`, c.ab)}</label>
                        <label>Premia magiczna <input type="number" data-f="${pfx}.magic" data-t="num" value="${esc(e.magic || '')}" placeholder="0" class="w4"></label>
                        <label title="Puste = cecha + biegłość">Trafienie <input type="number" data-f="${pfx}.hit" value="${esc(e.hit ?? '')}" placeholder="${sgn(c.hit)}" class="w4"></label>
                        <label>Zasięg <input data-f="${pfx}.reach" value="${esc(e.reach || '')}" placeholder="${k === 'rw' ? '80/320 ft' : k === 'rs' ? '120 ft' : '5 ft'}" class="w8"></label>
                        <label>Cel <input data-f="${pfx}.target" value="${esc(e.target || '')}" placeholder="jeden cel" class="w8"></label>
                    </div>` : ''}
                    ${k === 'save' ? `<div class="ne-entry-row">
                        <label>Rzut na ${abSel(`${pfx}.saveAb`, e.saveAb || 'dex')}</label>
                        <label>ST z cechy ${abSel(`${pfx}.ab`, c.ab)}</label>
                        <label title="Puste = 8 + biegłość + cecha">ST <input type="number" data-f="${pfx}.dc" value="${esc(e.dc ?? '')}" placeholder="${c.dc}" class="w4"></label>
                        <label class="ne-check"><input type="checkbox" data-f="${pfx}.half" data-t="bool" ${e.half ? 'checked' : ''}> połowa przy sukcesie</label>
                    </div>` : ''}
                    ${k !== 'text' ? `<div class="ne-entry-row">
                        <label>Obrażenia <input data-f="${pfx}.dmg" value="${esc(e.dmg || '')}" placeholder="1k8" class="w6"></label>
                        ${attack && (k === 'mw' || k === 'rw') ? `<label class="ne-check" title="Dolicz modyfikator cechy do obrażeń"><input type="checkbox" data-f="${pfx}.addMod" data-t="bool" ${(e.addMod ?? true) ? 'checked' : ''}> + cecha</label>` : ''}
                        ${dtSel(`${pfx}.dt`, e.dt)}
                        <label>Dodatkowe <input data-f="${pfx}.dmg2" value="${esc(e.dmg2 || '')}" placeholder="2k6" class="w6"></label>
                        ${dtSel(`${pfx}.dt2`, e.dt2)}
                    </div>` : ''}
                    <textarea data-f="${pfx}.desc" rows="${k === 'text' ? 2 : 1}" placeholder="${k === 'text' ? 'Opis: co robi, ile razy, warunki. Kości (np. 2k6) i „+5 do trafienia” będą klikalne.' : 'Dodatkowy efekt (np. cel zostaje powalony)'}">${esc(e.desc || '')}</textarea>
                    <div class="ne-prev nb-host" data-prev="${key}.${i}">${entryHTML(e, st, false)}</div>
                </div>`;
            };
            acts = Object.entries(LISTS).map(([key, [title, ic]]) => `<div class="ne-box ne-list" data-list="${key}">
                <h5><i class="fa-solid ${ic}"></i> ${title} <small>${({ traits: 'pasywne zdolności, np. Taktyka stada, Odporność na magię', actions: 'ataki i działania w turze — zacznij od „Wielokrotny atak”, jeśli ma kilka', bonus: 'np. Chytra akcja, Ucieczka', reactions: 'np. Parowanie', legendary: '' })[key]}</small>
                ${key === 'legendary' ? `<label class="ne-inline-l">na rundę <input type="number" min="1" max="5" data-f="stats.legendaryCount" data-t="num" value="${st.legendaryCount}" class="w4"></label>` : ''}</h5>
                ${(st[key] || []).map((e, i) => entry(key, e, i)).join('') || ''}
                <div class="ne-add">
                    <button type="button" data-add="${key}" data-k="text"><i class="fa-solid fa-plus"></i> Opis</button>
                    ${key !== 'traits' ? `<button type="button" data-add="${key}" data-k="mw"><i class="fa-solid fa-plus"></i> Atak wręcz</button><button type="button" data-add="${key}" data-k="rw"><i class="fa-solid fa-plus"></i> Atak dystansowy</button><button type="button" data-add="${key}" data-k="save"><i class="fa-solid fa-plus"></i> Rzut obronny</button>` : ''}
                </div>
            </div>`).join('') + `<div class="ne-box"><h5><i class="fa-solid fa-wand-magic-sparkles"></i> Rzucanie czarów</h5>
                <div class="ne-grid g2">${sel('stats.spells.ab', 'Cecha czarująca', [['', '— nie rzuca czarów —'], ...AB.map(a => [a, AB_PL[a]])])}<div class="ne-f ne-ro"><span>ST i atak czarem</span><b data-spell>${st.spells.ab ? `ST ${8 + profOf(st) + mod(st[st.spells.ab])} · ${sgn(profOf(st) + mod(st[st.spells.ab]))}` : '—'}</b></div></div>
                ${area('stats.spells.list', 'Czary', 3, 'Sztuczki (bez limitu): święty płomień, światło\n1. krąg (4 miejsca): leczenie ran, tarcza wiary\n2. krąg (2 miejsca): duchowa broń')}
            </div>`;
        }
        const gear = invEditorHTML(d, has, area);
        const sumBar = has ? `<div class="ne-sum" data-sum>${sumHTML()}</div>` : '';
        root.innerHTML = `
            <div class="ne-tabs">${tabs.map(([k, ic, t]) => `<button type="button" data-tab="${k}" class="${ED.tab === k ? 'on' : ''}" ${!has && k !== 'who' && k !== 'gear' ? 'disabled title="Najpierw zaznacz „Ma statystyki do walki”"' : ''}><i class="fa-solid ${ic}"></i> ${t}</button>`).join('')}</div>
            ${sumBar}
            <div class="ne-pane" ${ED.tab === 'who' ? '' : 'hidden'}>${who}</div>
            <div class="ne-pane" ${ED.tab === 'stats' ? '' : 'hidden'}>${stats}</div>
            <div class="ne-pane" ${ED.tab === 'acts' ? '' : 'hidden'}>${acts}</div>
            <div class="ne-pane" ${ED.tab === 'gear' ? '' : 'hidden'}>${gear}</div>`;
        if (has && ED.tab === 'stats') fillMonsterList();
    }
    // ---------- ekwipunek NPC (przedmioty z bazy z wagą, monety, uwagi) ----------
    const IDB = () => window.ItemsDB || null;
    const DT_PL = { 'cięte': 'slashing', 'kłute': 'piercing', 'obuchowe': 'bludgeoning' };
    const invW = (inv) => (inv || []).reduce((a, it) => a + (+it.weight || 0) * (+it.quantity || 1), 0);
    const fmtLb = (w) => w ? `${String(+(+w).toFixed(2)).replace('.', ',')} lb` : '—';
    function invRows(d, has) {
        const db = IDB();
        return d.inventory.map((it, i) => {
            const x = db && (it.ref ? db.find(it.ref) : db.find(it.name));
            const isW = x && x.cat === 'weapon' && x.dmg, isA = x && x.cat === 'armor';
            return `<div class="ne-inv-row">
                <div class="ne-inv-n"><b>${esc(it.name)}</b>${x ? `<small>${esc(db.info(x))}</small>` : ''}</div>
                <label class="ne-inv-q" title="Ilość"><input type="number" min="1" data-f="inventory.${i}.quantity" data-t="num" value="${+it.quantity || 1}"></label>
                <span class="ne-inv-w">${fmtLb((+it.weight || 0) * (+it.quantity || 1))}</span>
                <div class="ne-inv-a">${has && isW ? `<button type="button" data-invatk="${i}" title="Dodaj atak tą bronią do Akcji"><i class="fa-solid fa-khanda"></i> atak</button>` : ''}${has && isA ? `<button type="button" data-invac="${i}" title="Ustaw KP z tego pancerza"><i class="fa-solid fa-shield-halved"></i> KP</button>` : ''}<button type="button" class="del" data-invdel="${i}" title="Usuń"><i class="fa-solid fa-xmark"></i></button></div>
            </div>`;
        }).join('') || '<p class="ne-muted">Brak przedmiotów — wyszukaj w bazie albo dodaj własny.</p>';
    }
    function invEditorHTML(d, has, area) {
        const c = d.coins || {};
        return `<div class="ne-box ne-inv">
            <h5><i class="fa-solid fa-magnifying-glass"></i> Dodaj z bazy przedmiotów <small>broń, pancerze, wyposażenie — z wagą i ceną</small></h5>
            <input id="ne-inv-q" placeholder="np. miecz, kolczuga, lina, mikstura…" autocomplete="off">
            <div class="ne-inv-res" id="ne-inv-res"></div>
            <div class="ne-inv-own"><input id="ne-inv-own" placeholder="Własny przedmiot (np. list od barona)"><input id="ne-inv-ownw" type="number" min="0" step="0.5" placeholder="lb"><button type="button" data-invown><i class="fa-solid fa-plus"></i> Dodaj</button></div>
        </div>
        <div class="ne-box"><h5><i class="fa-solid fa-sack-xmark"></i> Przy sobie <small data-invw>razem ${fmtLb(invW(d.inventory))}</small></h5><div class="ne-inv-list" data-invlist>${invRows(d, has)}</div></div>
        <div class="ne-box"><h5><i class="fa-solid fa-coins"></i> Sakiewka</h5><div class="ne-grid g3">
            <label class="ne-f"><span>Złoto (sz)</span><input type="number" min="0" data-f="coins.gp" data-t="num" value="${esc(c.gp ?? '')}"></label>
            <label class="ne-f"><span>Srebro (ss)</span><input type="number" min="0" data-f="coins.sp" data-t="num" value="${esc(c.sp ?? '')}"></label>
            <label class="ne-f"><span>Miedź (sm)</span><input type="number" min="0" data-f="coins.cp" data-t="num" value="${esc(c.cp ?? '')}"></label></div>
            ${area('gear', 'Uwagi o ekwipunku', 2, 'np. klucz do lochu w bucie, mapa zaszyta w płaszczu')}</div>`;
    }
    function invSearch(q) {
        const box = document.getElementById('ne-inv-res'); const db = IDB(); if (!box || !db) return;
        const n = db.norm ? db.norm(q) : String(q).toLowerCase();
        if (n.length < 2) { box.innerHTML = ''; return; }
        const hits = db.all.filter(x => (db.norm ? db.norm(x.name + ' ' + (x.en || '')) : (x.name + ' ' + (x.en || '')).toLowerCase()).includes(n)).slice(0, 14);
        box.innerHTML = hits.map(x => `<button type="button" data-invadd="${esc(x.id)}"><i class="fa-solid ${(db.CATS[x.cat] || [])[1] || 'fa-box'}"></i><b>${esc(x.name)}</b><small>${esc(db.info(x) || '')} · ${fmtLb(x.w)}${x.cost && x.cost !== '—' ? ` · ${esc(x.cost)}` : ''}</small></button>`).join('') || '<p class="ne-muted">Nic nie znaleziono.</p>';
    }
    function invRefresh() {
        const root = document.getElementById('ne'); if (!root || !ED) return;
        const l = root.querySelector('[data-invlist]'); if (l) l.innerHTML = invRows(ED.d, ED.d.hasStats);
        const w = root.querySelector('[data-invw]'); if (w) w.textContent = `razem ${fmtLb(invW(ED.d.inventory))}`;
    }
    function weaponAttack(x, st) {
        const ranged = /dystans/i.test(x.sub || '') , fin = (x.props || '').includes('F');
        const ab = ranged ? 'dex' : fin && mod(st.dex) > mod(st.str) ? 'dex' : 'str';
        const reach = ranged || (x.props || '').includes('T') ? (ranged ? `${x.range || '80/320'} ft` : `5 ft lub ${x.range} ft`) : (x.props || '').includes('Z') ? '10 ft' : '5 ft';
        return { kind: ranged ? 'rw' : 'mw', name: x.name, ab, dmg: x.dmg, dt: DT_PL[x.dt] || '', addMod: true, reach, desc: (x.props || '').includes('V') && x.vers ? `Oburącz: ${x.vers} + mod. obrażeń.` : '' };
    }
    function armorAC(x, st) {
        if (x.kind === 'S') return null;
        const dm = mod(st.dex);
        return x.kind === 'L' ? x.ac + dm : x.kind === 'M' ? x.ac + Math.min(2, dm) : x.ac;
    }
    function sumHTML() {
        const st = ED.d.stats; if (!st) return '';
        const p = profOf(st), init = mod(st.dex) + (parseInt(st.initBonus, 10) || 0);
        const hd = parseDice(st.hitDice);
        return `<span><i class="fa-solid fa-shield-halved"></i> KP <b>${st.ac}</b></span><span><i class="fa-solid fa-heart"></i> PW <b>${st.hp}</b>${hd ? ` <small>(${diceStr(hd, true)})</small>` : ''}</span>
            <span><i class="fa-solid fa-shoe-prints"></i> <b>${st.speeds.walk}</b> ft</span><span><i class="fa-solid fa-bolt"></i> Inicjatywa <b>${sgn(init)}</b></span>
            <span><i class="fa-solid fa-skull-crossbones"></i> CR <b>${esc(st.cr)}</b> <small>${xpOf(st.cr).toLocaleString(window.LOC || 'pl-PL')} PD</small></span><span>Biegłość <b>${sgn(p)}</b></span><span>Pas. Percepcja <b>${passive(st)}</b></span>`;
    }
    // odświeżenie wartości wyliczanych bez przebudowy formularza (żeby nie gubić kursora)
    function refreshComputed() {
        const root = document.getElementById('ne'); if (!root || !ED?.d.stats) return;
        const st = ED.d.stats, p = profOf(st);
        root.querySelector('[data-sum]') && (root.querySelector('[data-sum]').innerHTML = sumHTML());
        AB.forEach(k => {
            const m = root.querySelector(`[data-mod="${k}"]`); if (m) m.textContent = sgn(mod(st[k]));
            const s = root.querySelector(`[data-sv="${k}"]`); if (s) s.textContent = sgn(mod(st[k]) + (st.saves.includes(k) ? p : 0));
        });
        root.querySelectorAll('[data-skv]').forEach(el => { el.textContent = sgn(skillMod(st, el.dataset.skv)); });
        const pp = root.querySelector('[data-pp]'); if (pp) pp.textContent = passive(st);
        const spell = root.querySelector('[data-spell]'); if (spell) spell.textContent = st.spells.ab ? `ST ${8 + p + mod(st[st.spells.ab])} · ${sgn(p + mod(st[st.spells.ab]))}` : '—';
        root.querySelectorAll('[data-prev]').forEach(el => {
            const [key, i] = el.dataset.prev.split('.'); const e = st[key]?.[+i]; if (!e) return;
            el.innerHTML = entryHTML(e, st, false);
            const c = entryCalc(e, st), box = el.closest('.ne-entry');
            const hitIn = box?.querySelector(`[data-f="stats.${key}.${i}.hit"]`); if (hitIn) hitIn.placeholder = sgn(c.hit);
            const dcIn = box?.querySelector(`[data-f="stats.${key}.${i}.dc"]`); if (dcIn) dcIn.placeholder = c.dc;
        });
    }
    function onEdInput(e) {
        if (e.target.id === 'ne-inv-q') { if (e.type === 'input') invSearch(e.target.value); return; }
        const t = e.target, path = t.dataset?.f;
        if (!path || !ED) return;
        let v = t.type === 'checkbox' ? t.checked : t.value;
        if (t.dataset.t === 'num') v = t.value === '' ? '' : +t.value;
        setPath(ED.d, path, v);
        if (path.startsWith('inventory.')) { const w = document.querySelector('#ne [data-invw]'); if (w) w.textContent = `razem ${fmtLb(invW(ED.d.inventory))}`; }
        if (path.endsWith('.ab') && /^stats\.(actions|bonus|reactions|legendary|traits)\./.test(path) && e.type === 'change') { /* cecha ataku — tylko przelicz */ }
        if (t.dataset.rerender !== undefined && e.type === 'change') { renderEditor(); return; }
        if (path === 'stats.cr' || path === 'stats.speeds.walk') { /* przeliczy suma */ }
        refreshComputed();
    }
    function onEdClick(e) {
        const b = e.target.closest('button, input[type="checkbox"]'); if (!b || !ED) return;
        const d = ED.d, st = d.stats;
        if (b.dataset.tab) { ED.tab = b.dataset.tab; renderEditor(); return; }
        if (b.dataset.kind) {
            d.kind = b.dataset.kind;
            if (d.kind === 'enemy') { d.hasStats = true; d.stats = normStats(d.stats); if (d.disposition !== 'hostile') d.disposition = 'hostile'; }
            renderEditor(); return;
        }
        if (b.dataset.disp) { d.disposition = b.dataset.disp; b.parentElement.querySelectorAll('[data-disp]').forEach(x => x.classList.toggle('on', x === b)); return; }
        if (b.hasAttribute('data-hasstats')) { d.hasStats = b.checked; if (b.checked) d.stats = normStats(d.stats); renderEditor(); return; }
        if (b.dataset.invadd) {
            const x = IDB()?.find(b.dataset.invadd); if (!x) return;
            const have = d.inventory.find(it => it.ref === x.id || it.name === x.name);
            if (have) have.quantity = (+have.quantity || 1) + 1; else d.inventory.push(IDB().toInv(x, 1));
            invRefresh(); return;
        }
        if (b.hasAttribute('data-invown')) {
            const nm = document.getElementById('ne-inv-own')?.value.trim(); if (!nm) return;
            d.inventory.push({ name: nm.slice(0, 80), quantity: 1, weight: Math.max(0, parseFloat(document.getElementById('ne-inv-ownw')?.value) || 0) });
            document.getElementById('ne-inv-own').value = ''; document.getElementById('ne-inv-ownw').value = '';
            invRefresh(); return;
        }
        if (b.dataset.invdel != null) { d.inventory.splice(+b.dataset.invdel, 1); invRefresh(); return; }
        if (b.dataset.invatk != null && st) {
            const it = d.inventory[+b.dataset.invatk], x = it && IDB() && (it.ref ? IDB().find(it.ref) : IDB().find(it.name)); if (!x) return;
            if ((st.actions || []).some(e => e.name === x.name)) { App.showToast(`Atak „${x.name}” już jest w Akcjach`, 'info'); return; }
            st.actions = [...(st.actions || []), weaponAttack(x, st)];
            App.showToast(`Dodano atak: ${x.name} (zakładka „Akcje i zdolności”)`, 'success'); return;
        }
        if (b.dataset.invac != null && st) {
            const it = d.inventory[+b.dataset.invac], x = it && IDB() && (it.ref ? IDB().find(it.ref) : IDB().find(it.name)); if (!x) return;
            if (x.kind === 'S') { st.ac = (parseInt(st.ac, 10) || 10) + 2; st.acNote = [st.acNote, 'tarcza'].filter(Boolean).join(', '); }
            else { st.ac = armorAC(x, st); st.acNote = x.name.toLowerCase(); }
            App.showToast(`KP ${st.ac} (${st.acNote})`, 'success'); refreshComputed(); return;
        }
        if (!st) return;
        if (b.dataset.save) { const k = b.dataset.save; st.saves = b.checked ? [...new Set([...st.saves, k])] : st.saves.filter(x => x !== k); refreshComputed(); return; }
        if (b.dataset.skill) {
            const k = b.dataset.skill, lv = ((+st.skills[k] || 0) + 1) % 3;
            if (lv) st.skills[k] = lv; else delete st.skills[k];
            b.className = `ne-sk lv${lv}`; refreshComputed(); return;
        }
        if (b.dataset.chip) {
            const k = b.dataset.chip, v = b.dataset.v;
            st[k] = st[k].includes(v) ? st[k].filter(x => x !== v) : [...st[k], v];
            b.classList.toggle('on', st[k].includes(v));
            if (k !== 'condImmune' && st[k].includes(v)) ['vuln', 'resist', 'immune'].filter(o => o !== k && st[o].includes(v)).forEach(o => { st[o] = st[o].filter(x => x !== v); document.querySelector(`#ne [data-chip="${o}"][data-v="${v}"]`)?.classList.remove('on'); });
            return;
        }
        if (b.hasAttribute('data-hpavg')) {
            const hd = parseDice(st.hitDice);
            if (!hd || !hd.n) { App.showToast('Wpisz kości wytrzymałości, np. 5k8+5', 'warning'); return; }
            st.hp = avg(hd); const inp = document.querySelector('#ne [data-f="stats.hp"]'); if (inp) inp.value = st.hp; refreshComputed(); return;
        }
        if (b.dataset.add) {
            const k = b.dataset.k, key = b.dataset.add;
            const e = { kind: k, name: '', desc: '' };
            if (k === 'mw') Object.assign(e, { ab: 'str', dmg: '1k6', dt: 'slashing', addMod: true });
            if (k === 'rw') Object.assign(e, { ab: 'dex', dmg: '1k6', dt: 'piercing', addMod: true });
            if (k === 'save') Object.assign(e, { ab: st.spells?.ab || 'con', saveAb: 'dex', dmg: '2k6', dt: 'fire', half: true });
            if (key === 'legendary') e.cost = 1;
            st[key] = [...(st[key] || []), e];
            renderEditor();
            const list = document.querySelectorAll(`#ne [data-list="${key}"] .ne-entry`); list[list.length - 1]?.querySelector('.ne-en')?.focus();
            return;
        }
        if (b.dataset.del) { const [key, i] = b.dataset.del.split('.'); st[key].splice(+i, 1); renderEditor(); return; }
        if (b.dataset.move) { const [key, i] = b.dataset.move.split('.'); const j = +i; if (j > 0) { const a = st[key]; [a[j - 1], a[j]] = [a[j], a[j - 1]]; renderEditor(); } return; }
        if (b.hasAttribute('data-import')) { importMonster(document.getElementById('ne-imp')?.value || ''); return; }
    }

    // ---------- import z bestiariusza ----------
    let monList = null;
    async function fillMonsterList() {
        const dl = document.getElementById('ne-mons'); if (!dl) return;
        if (!monList) {
            try { monList = [...(StorageManager.getCustomMonsters?.() || []).map(m => ({ ...m, _custom: true, index: m._customId })), ...((await API().getMonsterList()) || [])]; } catch (e) { monList = (StorageManager.getCustomMonsters?.() || []).map(m => ({ ...m, _custom: true, index: m._customId })); }
        }
        const d2 = document.getElementById('ne-mons'); if (!d2) return;
        d2.innerHTML = monList.map(m => `<option value="${esc(m.name)}">${m.challenge_rating != null ? `CR ${API().crDisplay(m.challenge_rating)}` : ''}${m._custom ? ' · własny' : ''}</option>`).join('');
    }
    async function importMonster(name) {
        name = String(name || '').trim();
        if (!name) { App.showToast('Wpisz nazwę potwora z bestiariusza', 'warning'); return; }
        await fillMonsterList();
        const hit = (monList || []).find(m => m.name.toLowerCase() === name.toLowerCase()) || (monList || []).find(m => m.name.toLowerCase().includes(name.toLowerCase()));
        if (!hit) { App.showToast('Nie ma takiego stworzenia w bestiariuszu', 'warning'); return; }
        let m = hit;
        try {
            if (!hit._custom) m = await API().getMonster(hit.index);
            if (window.BestiaryModule?._translateMonster && !m._custom) await Promise.race([BestiaryModule._translateMonster(m), new Promise(r => setTimeout(r, 4000))]);
        } catch (e) { App.showToast('Nie udało się wczytać potwora', 'error'); return; }
        if (!ED) return;
        const keepName = ED.d.name;
        ED.d.stats = fromMonster(m);
        ED.d.hasStats = true;
        if (!keepName) ED.d.name = m.name;
        if (!ED.d.race) ED.d.race = '';
        ED.tab = 'stats';
        renderEditor();
        App.showToast(`Wczytano statystyki: ${m.name} — możesz je dowolnie zmienić`, 'success');
    }
    function fromMonster(m) {
        const s = {};
        s.size = SIZES[m.size] ? m.size : 'Medium';
        const ty = String(typeof m.type === 'string' ? m.type : m.type?.type || 'humanoid').toLowerCase();
        s.ctype = Object.keys(TYPES).find(k => ty.includes(k)) || 'humanoid';
        const al = String(m.alignment || '').toLowerCase();
        s.alignment = ALIGN_EN[al] ? ALIGN[ALIGN_EN[al]] : (ALIGN.includes(al) ? al : '');
        const acs = Array.isArray(m.armor_class) ? m.armor_class : [{ value: m.armor_class ?? m.ac ?? 10 }];
        s.ac = acs[0]?.value ?? 10;
        s.acNote = acs[0]?.type === 'natural' ? 'pancerz naturalny' : (acs[0]?.armor || []).map(a => a.name).join(', ');
        s.hp = m.hit_points ?? m.hp ?? 10;
        s.hitDice = plDice(m.hit_points_roll || m.hit_dice || '');
        const sp = typeof m.speed === 'object' && m.speed ? m.speed : { walk: m.speed };
        s.speeds = {}; Object.keys(SPEEDS).forEach(k => { const v = parseInt(sp[k], 10); if (v) s.speeds[k] = v; });
        if (!s.speeds.walk) s.speeds.walk = sp.walk === undefined ? 30 : 0;
        s.hover = !!sp.hover;
        const full = { str: 'strength', dex: 'dexterity', con: 'constitution', int: 'intelligence', wis: 'wisdom', cha: 'charisma' };
        AB.forEach(k => { s[k] = m[full[k]] ?? m[k] ?? 10; });
        s.cr = m.challenge_rating != null ? API().crDisplay(m.challenge_rating) : String(m.cr || '1');
        const p = profOf(s);
        s.saves = []; s.skills = {};
        (m.proficiencies || []).forEach(x => {
            const nm = x.proficiency?.name || x.name || '';
            if (nm.startsWith('Saving Throw:')) { const k = nm.split(':')[1].trim().toLowerCase(); if (AB.includes(k)) s.saves.push(k); }
            if (nm.startsWith('Skill:')) {
                const pl = SKILL_EN[nm.split(':')[1].trim()]; if (!pl) return;
                const base = mod(s[String(SKILLS[pl] || 'WIS').toLowerCase()]);
                s.skills[pl] = (+x.value || 0) >= base + 2 * p ? 2 : 1;
            }
        });
        const dmgList = (arr) => {
            const out = new Set();
            (arr || []).forEach(t => { const l = String(t).toLowerCase(); if (l.includes('nonmagical')) { out.add('nonmagical'); return; } Object.keys(DMG).forEach(k => { if (l.includes(k)) out.add(k); }); });
            return [...out];
        };
        s.vuln = dmgList(m.damage_vulnerabilities); s.resist = dmgList(m.damage_resistances); s.immune = dmgList(m.damage_immunities);
        s.condImmune = (m.condition_immunities || []).map(c => String(c.index || c.name || c).toLowerCase()).filter(k => CONDS[k]);
        s.senses = {}; Object.keys(SENSES).forEach(k => { const v = parseInt(m.senses?.[k], 10); if (v) s.senses[k] = v; });
        s.languages = m.languages || '';
        const ent = (arr) => (arr || []).map(a => ({ kind: 'text', name: a.name || '', desc: a.desc || '', ...(a.usage?.type === 'recharge on roll' ? { recharge: `${a.usage.min_value}–6` } : {}) }))
            .map(a => a.recharge ? { ...a, name: a.name.replace(/\s*\(recharge[^)]*\)/i, '') } : a);
        s.traits = ent(m.special_abilities); s.actions = ent(m.actions); s.reactions = ent(m.reactions); s.legendary = ent(m.legendary_actions); s.bonus = ent(m.bonus_actions);
        s.legendaryCount = 3;
        const casting = (m.special_abilities || []).find(a => a.spellcasting);
        s.spells = { ab: casting ? String(casting.spellcasting.ability?.index || '').slice(0, 3) : '', list: '' };
        if (!AB.includes(s.spells.ab)) s.spells.ab = '';
        return normStats(s);
    }

    function saveEditor() {
        if (!ED) return;
        const d = ED.d;
        d.name = String(d.name || '').trim();
        if (!d.name) { ED.tab = 'who'; renderEditor(); App.showToast(d.kind === 'enemy' ? 'Podaj nazwę przeciwnika' : 'Imię jest wymagane', 'error'); document.getElementById('ne-name')?.focus(); return; }
        const out = clone(d);
        out.id = out.id || StorageManager.generateId();
        ['race', 'role', 'location', 'description', 'motivations', 'secrets', 'notes', 'gear'].forEach(k => { out[k] = String(out[k] || '').trim(); });
        out.inventory = (out.inventory || []).filter(it => it && it.name).map(it => ({ ...it, quantity: Math.max(1, parseInt(it.quantity, 10) || 1), weight: Math.max(0, +it.weight || 0) }));
        out.coins = Object.fromEntries(Object.entries(out.coins || {}).map(([k, v]) => [k, Math.max(0, parseInt(v, 10) || 0)]).filter(([, v]) => v));
        if (out.hasStats) {
            const st = out.stats;
            AB.forEach(k => { st[k] = Math.max(1, Math.min(30, parseInt(st[k], 10) || 10)); });
            st.ac = Math.max(1, parseInt(st.ac, 10) || 10); st.hp = Math.max(1, parseInt(st.hp, 10) || 1);
            Object.keys(st.speeds).forEach(k => { st.speeds[k] = Math.max(0, parseInt(st.speeds[k], 10) || 0); if (!st.speeds[k] && k !== 'walk') delete st.speeds[k]; });
            st.speed = st.speeds.walk;
            Object.keys(st.senses).forEach(k => { st.senses[k] = parseInt(st.senses[k], 10) || 0; if (!st.senses[k]) delete st.senses[k]; });
            ['traits', 'actions', 'bonus', 'reactions', 'legendary'].forEach(k => { st[k] = (st[k] || []).filter(e => (e.name || '').trim() || (e.desc || '').trim() || (e.kind !== 'text' && e.dmg)); });
            // pola zgodne z resztą panelu (walka, mapa, plansza)
            st.dexMod = mod(st.dex);
        } else out.stats = out.stats || null;
        StorageManager.saveNPC(cid(), out);
        const wasNew = ED.isNew;
        ED = null;
        App.closeModal();
        App.showToast(wasNew ? (out.kind === 'enemy' ? 'Przeciwnik dodany' : 'NPC dodany') : 'Zapisano zmiany', 'success');
        if (document.getElementById('tab-npcs')?.classList.contains('active')) { activate(); showDetail(out.id); }
        else if (window.Atlas && window.CampaignsModule?.getSubtab) { try { CampaignsModule.openSubtab?.(CampaignsModule.getSubtab()); } catch (e) {} }
    }

    // zgodność wstecz
    function showAddNPCModal(preset) { openEditor(null, 'npc', { preset }); }
    function showAddEnemyModal(preset) { openEditor(null, 'enemy', { preset }); }
    function editNPC(npcId, tab) { App.closeModal(); openEditor(npcId, null, { tab }); }
    function createNPC() { saveEditor(); }
    function createEnemy() { saveEditor(); }

    function duplicateNPC(id) {
        const n = getNPC(id); if (!n) return;
        const all = StorageManager.getNPCs(cid()) || [];
        const base = n.name.replace(/\s+\d+$/, '');
        let k = 2; while (all.some(x => x.name === `${base} ${k}`)) k++;
        const copy = { ...clone(n), id: StorageManager.generateId(), name: `${base} ${k}` };
        StorageManager.saveNPC(cid(), copy);
        App.showToast(`Utworzono kopię: ${copy.name}`, 'success');
        activate(); showDetail(copy.id);
    }

    async function deleteNPC(id) {
        const n = getNPC(id);
        if (await Ask.confirm('Postać zniknie z kampanii. Tego nie da się cofnąć.', { title: `Usunąć ${n ? `„${n.name}”` : 'tę postać'}?`, ok: 'Usuń', danger: true })) {
            StorageManager.deleteNPC(cid(), id);
            ED = null; App.closeModal();
            closeDetail();
            activate();
            App.showToast('Postać usunięta', 'info');
        }
    }

    function pinNPC(npcId) {
        const n = getNPC(npcId); if (!n) return;
        if (!window.NotesModule) { App.showToast('Moduł notatek nie jest załadowany', 'error'); return; }
        const lines = [];
        if (n.role || n.location) lines.push([n.role, n.location].filter(Boolean).join(' · '));
        if (n.hasStats) {
            const st = n.stats;
            lines.push(`KP ${st.ac} · PW ${st.hp} · ${st.speeds.walk} ft · CR ${st.cr} · inicj. ${sgn(mod(st.dex))}`);
            lines.push(AB.map(k => `${AB_S[k]} ${st[k]} (${sgn(mod(st[k]))})`).join('  '));
            st.actions.slice(0, 4).forEach(e => { const tmp = document.createElement('div'); tmp.innerHTML = entryHTML(e, st, false); lines.push('• ' + tmp.textContent.trim()); });
        }
        if (n.description) lines.push(n.description);
        const color = n.disposition === 'hostile' ? 'rose' : n.disposition === 'friendly' ? 'green' : 'blue';
        if (NotesModule.newNote) NotesModule.newNote({ title: n.name, content: lines.join('\n'), color, type: 'npc' });
        else if (NotesModule.createNote) NotesModule.createNote({ title: n.name, content: lines.join('\n'), color, type: 'npc' });
        App.showToast('Przypięto NPC jako notatkę', 'success');
    }

    // ---------- walka ----------
    function combatantsFor(n, count = 1, opts = {}) {
        const st = n.stats, hd = parseDice(st.hitDice);
        const d20 = () => Math.floor(Math.random() * 20) + 1;
        const ib = mod(st.dex) + (parseInt(st.initBonus, 10) || 0);
        const group = d20() + ib;
        return Array.from({ length: count }, (_, i) => {
            const hp = opts.rollHp && hd && hd.n ? Math.max(1, Array.from({ length: hd.n }, () => Math.floor(Math.random() * hd.s) + 1).reduce((a, b) => a + b, hd.b)) : st.hp;
            return {
                id: `npc-${n.id}-${Date.now().toString(36)}${i}`,
                name: count > 1 ? `${n.name} ${i + 1}` : n.name,
                type: n.disposition === 'hostile' ? 'monster' : 'npc', disp: n.disposition,
                ac: st.ac, hp, maxHp: hp, initiative: opts.each ? d20() + ib : group,
                dexMod: mod(st.dex), speed: st.speeds.walk, size: tokenSize(st), npcId: n.id, hidden: !!opts.hidden
            };
        });
    }
    function addToCombat(npcId) {
        if (!window.CombatModule) { App.showToast('Moduł walki nie jest dostępny.', 'error'); return; }
        const n = getNPC(npcId);
        if (!n || !n.hasStats) return;
        const hd = parseDice(n.stats.hitDice);
        App.showModal(`Do walki: ${n.name}`, `
            <div class="ne-grid g3">
                <label class="ne-f"><span>Ile sztuk</span><input type="number" id="nc-count" min="1" max="20" value="1"></label>
                <label class="ne-f"><span>Punkty wytrzymałości</span><select id="nc-hp"><option value="avg">Stałe (${n.stats.hp})</option>${hd && hd.n ? `<option value="roll">Losowe (${diceStr(hd, true)})</option>` : ''}</select></label>
                <label class="ne-f"><span>Inicjatywa</span><select id="nc-init"><option value="group">Wspólna dla grupy</option><option value="each">Osobno dla każdego</option></select></label>
            </div>
            <label class="ne-check"><input type="checkbox" id="nc-hid"> ukryci przed graczami (np. zasadzka)</label>
            <p class="modal-hint">KP ${n.stats.ac} · ${n.stats.speeds.walk} ft · inicjatywa 1k20${sgn(mod(n.stats.dex))} · rozmiar żetonu: ${(SIZES[n.stats.size] || SIZES.Medium)[0].toLowerCase()}. W walce przy nazwie pojawi się przycisk karty z atakami.</p>`,
            `<button class="btn-secondary" onclick="App.closeModal()">Anuluj</button><button class="btn-primary" id="nc-go"><i class="fa-solid fa-khanda"></i> Dodaj do walki</button>`);
        document.getElementById('nc-go').onclick = () => {
            const count = Math.max(1, Math.min(20, parseInt(document.getElementById('nc-count').value, 10) || 1));
            const list = combatantsFor(n, count, { rollHp: document.getElementById('nc-hp').value === 'roll', each: document.getElementById('nc-init').value === 'each', hidden: document.getElementById('nc-hid').checked });
            list.forEach(c => CombatModule.addCombatant(c));
            App.closeModal();
            App.showToast(`Dodano do walki: ${n.name}${count > 1 ? ` ×${count}` : ''} (inicjatywa ${list.map(c => c.initiative).filter((v, i, a) => a.indexOf(v) === i).join(', ')})`, 'success');
        };
    }
    // dane dla żetonu na mapie / planszy
    function tokenData(id) {
        const n = getNPC(id); if (!n) return null;
        const st = n.hasStats ? n.stats : null;
        return { kind: 'npc', ref: n.id, name: n.name, disp: n.disposition, hp: st?.hp || 0, max: st?.hp || 0, ac: st?.ac || 10, size: st ? tokenSize(st) : 1, dexMod: st ? mod(st.dex) : 0, speed: st?.speeds.walk || 30 };
    }

    return {
        init, activate, showDetail, closeDetail, showSheet, goPlace,
        openEditor, showAddNPCModal, createNPC, editNPC, showAddEnemyModal, createEnemy, duplicateNPC,
        deleteNPC, pinNPC, addToCombat, tokenData, statBlockHTML, normNPC, fromCharacter, pcBlockHTML,
        profOf, _fromMonster: fromMonster
    };
})();

window.NPCsModule = NPCsModule;
