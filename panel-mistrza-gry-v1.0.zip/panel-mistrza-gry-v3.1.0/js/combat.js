// ============================================================
// CombatModule — Initiative & combat tracker
// ============================================================
const CombatModule = (() => {
    const conditionDescriptions = {
        "Oslepienie": "Istota nic nie widzi i automatycznie oblewa testy oparte na wzroku. Ataki przeciw niej mają ułatwienie, jej ataki — utrudnienie.",
        "Zauroczenie": "Nie może atakować zauroczyciela ani celować w niego szkodliwymi efektami. Zauroczyciel ma ułatwienie w testach Charyzmy wobec niej.",
        "Gluchota": "Nic nie słyszy i automatycznie oblewa testy oparte na słuchu.",
        "Przerazenie": "Utrudnienie w testach cech i atakach, dopóki widzi źródło strachu. Nie może dobrowolnie się do niego zbliżyć.",
        "Pochwycenie": "Szybkość 0. Kończy się, gdy chwytający zostanie obezwładniony albo odsunięty poza zasięg.",
        "Obezwladnienie": "Nie może podejmować akcji ani reakcji.",
        "Niewidzialnosc": "Nie da się jej zobaczyć bez magii. Ataki w nią mają utrudnienie, jej ataki — ułatwienie.",
        "Paraliz": "Obezwładniona, nie rusza się i nie mówi. Oblewa rzuty obronne Siły i Zręczności. Ataki mają ułatwienie, a trafienie z 5 stóp jest krytyczne.",
        "Spetryfikowanie": "Zamieniona w kamień, obezwładniona. Oblewa rzuty obronne Siły i Zręczności, ma odporność na wszystkie obrażenia i nie działa na nią trucizna.",
        "Zatrucie": "Utrudnienie w rzutach na atak i testach cech.",
        "Lezenie": "Może tylko się czołgać (ruch ×2), wstanie kosztuje połowę szybkości. Jej ataki mają utrudnienie. Ataki w nią z 5 stóp — ułatwienie, z dalszej odległości — utrudnienie.",
        "Skrepowanie": "Szybkość 0. Ataki w nią mają ułatwienie, jej ataki — utrudnienie. Utrudnienie w rzutach obronnych Zręczności.",
        "Ogluszenie": "Obezwładniona, nie rusza się, mówi z trudem. Oblewa rzuty obronne Siły i Zręczności. Ataki w nią mają ułatwienie.",
        "Nieprzytomnosc": "Obezwładniona, upuszcza wszystko i pada (leżenie). Oblewa rzuty obronne Siły i Zręczności. Ataki mają ułatwienie, trafienie z 5 stóp jest krytyczne.",
        "Zmeczenie": "Wyczerpanie ma 6 poziomów: 1 — utrudnienie w testach cech, 2 — szybkość o połowę, 3 — utrudnienie w atakach i rzutach obronnych, 4 — maks. PW o połowę, 5 — szybkość 0, 6 — śmierć.",
        "Koncentracja": "Podtrzymuje czar. Po otrzymaniu obrażeń rzut obronny Kondycji ST 10 albo połowa obrażeń (wyższe) — porażka przerywa czar.",
        // English fallbacks
        "Blinded": "Istota nic nie widzi. Oblewa testy oparte na wzroku. Ataki przeciw niej maja ulatwienie.",
        "Charmed": "Nie moze atakowac zauroczyciela. Zauroczyciel ma ulatwienie w testach charyzmy.",
        "Deafened": "Nic nie slyszy. Oblewa testy oparte na sluchu.",
        "Frightened": "Utrudnienie w testach i atakach. Nie moze zblizac sie do zrodla strachu.",
        "Grappled": "Szybkosc rowna 0.",
        "Incapacitated": "Brak mozliwosci podejmowania akcji i reakcji.",
        "Invisible": "Ataki w nia maja utrudnienie, a jej ataki ulatwienie.",
        "Paralyzed": "Obezwładniona, nie rusza się i nie mówi. Oblewa rzuty obronne Siły i Zręczności. Ataki w nią mają ułatwienie, trafienie z 5 stóp jest krytyczne.",
        "Petrified": "Zamieniona w kamień, obezwładniona. Oblewa rzuty obronne Siły i Zręczności, ma odporność na wszystkie obrażenia, ataki w nią mają ułatwienie.",
        "Poisoned": "Utrudnienie w testach ataku i wszystkich testach cech.",
        "Prone": "Może tylko się czołgać. Jej ataki mają utrudnienie. Ataki w nią z 5 stóp — ułatwienie, z dalszej odległości — utrudnienie.",
        "Restrained": "Szybkosc 0. Ataki w nia maja ulatwienie, jej ataki utrudnienie.",
        "Stunned": "Obezwładniona, nie rusza się, mówi z trudem. Oblewa rzuty obronne Siły i Zręczności. Ataki w nią mają ułatwienie.",
        "Unconscious": "Obezwładniona, upuszcza wszystko i pada. Oblewa rzuty obronne Siły i Zręczności. Ataki w nią mają ułatwienie, trafienie z 5 stóp jest krytyczne."
    };
    window.getCondDesc = function(cond) {
        return conditionDescriptions[cond] || '';
    };

    /* ── State ─────────────────────────────────────────────── */
    let state = {
        active: false,
        round: 0,
        currentTurn: 0,   // index into combatants
        combatants: []    // { id, name, initiative, ac, hp, maxHp, type, conditions, defeated }
    };

    /* ── Public API ────────────────────────────────────────── */

    function init() {
        if (window.VTTModule) window.VTTModule.init();
        _bind('btn-start-combat', 'click', startCombat);
        _bind('btn-end-combat',   'click', endCombat);
        _bind('btn-loot',         'click', () => window.Loot && Loot.open(state.combatants));
        _bind('btn-next-turn',    'click', nextTurn);
        _bind('btn-add-combatant','click', showAddCombatantModal);

        // Restore persisted state
        const saved = StorageManager.getCombatState();
        if (saved && (saved.active || (saved.combatants || []).length)) {
            state = { active: false, round: 0, currentTurn: 0, combatants: [], ...saved };
            _showCombatUI(!!state.active);
        }

    }

    function activate() {
        if (window.VTTModule && VTTModule.activate) VTTModule.activate();
        renderInitiativeList();
    }

    /* ── Combat lifecycle ──────────────────────────────────── */

    function startCombat() {
        if (state.combatants.length === 0) {
            App.showToast('Najpierw dodaj uczestników walki', 'warning');
            return;
        }

        // Sort by initiative descending
        state.combatants.sort((a, b) => b.initiative - a.initiative);
        state.active = true;
        state.round = 1;
        state.currentTurn = 0;
        // Reset defeated flags
        state.combatants.forEach(c => { c.defeated = c.hp <= 0; });

        _showCombatUI(true);
        _persist();
        renderInitiativeList();
        App.showToast('Walka rozpoczęta — Runda 1', 'success');
    }

    function endCombat() {
        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-danger" id="btn-confirm-end-combat">Zakończ Walkę</button>`;

        const fallen = state.combatants.filter(c => (c.defeated || c.hp <= 0) && !['pc', 'player'].includes(c.type) && !String(c.id).startsWith('char-') && !String(c.id).endsWith('-druzyna') && c.disp !== 'friendly');
        App.showModal('Zakończyć walkę?', `<p>Czy na pewno chcesz zakończyć obecną walkę? Wszyscy uczestnicy zostaną wyczyszczeni z trackera.</p>
            ${window.Loot ? `<label class="lt-ann"><input type="checkbox" id="end-loot" ${fallen.length ? 'checked' : ''}> Rozdaj łupy${fallen.length ? ` z pokonanych (${fallen.length})` : ''}</label>` : ''}`, footer);

        setTimeout(() => {
            const btn = document.getElementById('btn-confirm-end-combat');
            if (btn) btn.addEventListener('click', () => {
                const wantLoot = document.getElementById('end-loot')?.checked, snap = JSON.parse(JSON.stringify(state.combatants));
                state = { active: false, round: 0, currentTurn: 0, combatants: [] };
                StorageManager.clearCombatState();
                _showCombatUI(false);
                renderInitiativeList();
                App.closeModal();
                App.showToast('Walka zakończona', 'info');
                if (wantLoot && window.Loot) setTimeout(() => Loot.open(snap), 250);
            });
        }, 50);
    }

    function nextTurn() {
        if (!state.active || state.combatants.length === 0) return;

        // Advance — skip defeated
        let loopGuard = state.combatants.length;
        do {
            state.currentTurn++;
            if (state.currentTurn >= state.combatants.length) {
                state.currentTurn = 0;
                state.round++;
                _updateRoundDisplay();
            }
            loopGuard--;
        } while (state.combatants[state.currentTurn].defeated && loopGuard > 0);

        if (window.VTTModule) window.VTTModule.resetTurnMovement();
        _persist();
        renderInitiativeList();
    }

    /* ── Combatant management ──────────────────────────────── */

    function addCombatant(options = {}) {
        const combatant = {
            ...options,
            id:         options.id || StorageManager.generateId(),
            name:       options.name       || 'Unknown',
            initiative: options.initiative ?? 0,
            ac:         options.ac         ?? 10,
            hp:         options.hp         ?? 10,
            maxHp:      options.maxHp      ?? options.hp ?? 10,
            type:       options.type       || 'monster',  // 'pc' | 'npc' | 'monster'
            conditions: [...(options.conditions || [])],
            defeated:   (options.hp ?? 10) <= 0
        };

        state.combatants.push(combatant);

        // Re-sort if combat is active
        if (state.active) {
            state.combatants.sort((a, b) => b.initiative - a.initiative);
        }

        _persist();
        renderInitiativeList();
        return combatant;
    }

    let _pick = null;
    function showAddCombatantModal() {
        _pick = null;
        const cId = App.getActiveCampaignId();
        let quickSelects = '<div class="form-group" style="flex:1"><label>Bohaterowie (Brak aktywnych)</label><select disabled><option>—</option></select></div>';

        // Build quick-select options from characters, NPCs
        if (cId) {
            const characters = StorageManager.getCharacters(cId) || [];
            const npcs       = StorageManager.getNPCs(cId)       || [];

            if (characters.length || npcs.length) {
                quickSelects = `
                    <div class="form-group" style="flex:1">
                        <label for="modal-comb-quick">PC i NPC</label>
                        <select id="modal-comb-quick">
                            <option value="">— Wybierz —</option>
                            ${characters.map(ch => `<option value="char-${ch.id}" data-name="${_esc(ch.name)}" data-ac="${ch.ac || 10}" data-hp="${ch.hp?.max || ch.hp || 10}" data-dex="${ch.abilityScores?.dex || 10}" data-type="pc">${_esc(ch.name)} (PC)</option>`).join('')}
                            ${npcs.map(n => `<option value="npc-${n.id}" data-name="${_esc(n.name)}" data-ac="${n.stats?.ac || n.ac || 10}" data-hp="${n.stats?.hp || n.hp || 10}" data-dex="${n.stats?.dex || 10}" data-type="npc">${_esc(n.name)} (NPC)</option>`).join('')}
                        </select>
                    </div>`;
            }
        }

        const body = `
            <div class="form-row">
                ${quickSelects}
                <div class="form-group" style="flex:1">
                    <label for="modal-comb-bestiary">Bestiariusz</label>
                    <select id="modal-comb-bestiary">
                        <option value="">— Ładowanie —</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group" style="flex:2">
                    <label for="modal-comb-name">Nazwa Uczestnika</label>
                    <input type="text" id="modal-comb-name" placeholder="Nazwa">
                </div>
                <div class="form-group" style="flex:1">
                    <label for="modal-comb-type">Typ</label>
                    <select id="modal-comb-type">
                        <option value="monster">Potwór (Monster)</option>
                        <option value="npc">NPC</option>
                        <option value="pc">Gracz (PC)</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="modal-comb-init">Inicjatywa</label>
                    <div style="display:flex;gap:.25rem;align-items:center;">
                        <input type="number" id="modal-comb-init" value="10" style="width:5rem">
                        <button class="btn-secondary btn-small" id="btn-roll-init" title="Rzuć Inicjatywę">🎲</button>
                    </div>
                </div>
                <div class="form-group">
                    <label for="modal-comb-ac">KP (AC)</label>
                    <input type="number" id="modal-comb-ac" value="10" style="width:5rem">
                </div>
                <div class="form-group">
                    <label for="modal-comb-hp">HP (PW)</label>
                    <input type="number" id="modal-comb-hp" value="10" style="width:5rem">
                </div>
            </div>
            <input type="hidden" id="modal-comb-dex" value="10">
        `;

        const footer = `
            <button class="btn-secondary" onclick="App.closeModal()">Anuluj</button>
            <button class="btn-primary" id="btn-confirm-add-combatant">Dodaj</button>`;

        App.showModal('Dodaj do walki', body, footer);

        // Async load Bestiary
        APIClient.getMonsterList().then(monsters => {
            const select = document.getElementById('modal-comb-bestiary');
            if (select) {
                const custom = StorageManager.getCustomMonsters() || [];
                const all = [...monsters, ...custom.map(m => ({ ...m, index: m._customId, _custom: true }))];
                select.innerHTML = '<option value="">— Wybierz Potwora —</option>' + 
                    all.map(m => `<option value="${m.index}" data-custom="${m._custom ? '1' : ''}">${_esc(m.name)}</option>`).join('');
            }
        });

        setTimeout(() => {
            // Roll initiative button
            const rollBtn = document.getElementById('btn-roll-init');
            if (rollBtn) {
                rollBtn.addEventListener('click', async () => {
                    const dex = parseInt(document.getElementById('modal-comb-dex').value, 10) || 10;
                    const mod = APIClient.abilityModifier(dex);
                    const result = await rollInitiative(mod, document.getElementById('modal-comb-name')?.value);
                    document.getElementById('modal-comb-init').value = result;
                    App.showToast(`Rzut na Inicjatywę: ${result}`, 'info');
                });
            }

            // Quick-select auto-fill (PC/NPC)
            const quickSel = document.getElementById('modal-comb-quick');
            if (quickSel) {
                quickSel.addEventListener('change', async () => {
                    const opt = quickSel.selectedOptions[0];
                    _pick = opt && opt.value ? opt.value : null;
                    if (opt && opt.value) {
                        document.getElementById('modal-comb-name').value = opt.dataset.name || '';
                        document.getElementById('modal-comb-ac').value   = opt.dataset.ac   || 10;
                        document.getElementById('modal-comb-hp').value   = opt.dataset.hp   || 10;
                        document.getElementById('modal-comb-type').value = opt.dataset.type || 'monster';
                        const dex = parseInt(opt.dataset.dex, 10) || 10;
                        document.getElementById('modal-comb-dex').value = dex;
                        
                        // Auto-roll initiative on select
                        document.getElementById('modal-comb-init').value = await rollInitiative(APIClient.abilityModifier(dex), document.getElementById('modal-comb-name')?.value);
                        
                        // Reset bestiary
                        const bSel = document.getElementById('modal-comb-bestiary');
                        if (bSel) bSel.value = "";
                    }
                });
            }
            
            // Bestiary auto-fill
            const bSel = document.getElementById('modal-comb-bestiary');
            if (bSel) {
                bSel.addEventListener('change', async () => {
                    const opt = bSel.selectedOptions[0];
                    if (!opt || !opt.value) return;
                    _pick = null;
                    
                    const isCustom = opt.dataset.custom === '1';
                    const index = opt.value;
                    _pick = isCustom ? `mon-custom:${index}` : `mon-${index}`;
                    let m;
                    if (isCustom) {
                        const customs = StorageManager.getCustomMonsters() || [];
                        m = customs.find(c => c._customId === index);
                    } else {
                        m = await APIClient.getMonster(index);
                    }
                    if (!m) return;
                    
                    document.getElementById('modal-comb-name').value = m.name;
                    document.getElementById('modal-comb-type').value = 'monster';
                    
                    // extract ac/hp/dex
                    let ac = 10;
                    if (m.armor_class != null) {
                        if (typeof m.armor_class === 'number') ac = m.armor_class;
                        else if (Array.isArray(m.armor_class) && m.armor_class[0]) ac = m.armor_class[0].value || 10;
                    }
                    let hp = m.hit_points || 10;
                    let dex = m.dexterity || m.dex || 10;
                    
                    document.getElementById('modal-comb-ac').value = ac;
                    document.getElementById('modal-comb-hp').value = hp;
                    document.getElementById('modal-comb-dex').value = dex;
                    
                    document.getElementById('modal-comb-init').value = await rollInitiative(APIClient.abilityModifier(dex), document.getElementById('modal-comb-name')?.value);
                    
                    // Reset pc/npc select
                    const qSel = document.getElementById('modal-comb-quick');
                    if (qSel) qSel.value = "";
                });
            }

            // Confirm
            const confirmBtn = document.getElementById('btn-confirm-add-combatant');
            if (confirmBtn) confirmBtn.addEventListener('click', _handleAddCombatant);
        }, 50);
    }

    function _handleAddCombatant() {
        const name = document.getElementById('modal-comb-name').value.trim();
        if (!name) { App.showToast('Nazwa uczestnika jest wymagana', 'error'); return; }

        const initiative = parseInt(document.getElementById('modal-comb-init').value, 10) || 0;
        const ac         = parseInt(document.getElementById('modal-comb-ac').value, 10)   || 10;
        const hp         = parseInt(document.getElementById('modal-comb-hp').value, 10)   || 10;
        const type       = document.getElementById('modal-comb-type').value;

        // NPC z kampanii: prędkość, rozmiar żetonu, nastawienie i karta z atakami
        let extra = {};
        if (_pick && _pick.startsWith('npc-') && window.NPCsModule?.tokenData) {
            const t = NPCsModule.tokenData(_pick.slice(4));
            if (t) extra = { npcId: t.ref, speed: t.speed, dexMod: t.dexMod, size: t.size, disp: t.disp };
        } else if (_pick && _pick.startsWith('mon-')) {
            extra = { ref: _pick.slice(4) };
        } else if (_pick && _pick.startsWith('char-')) {
            const ch = (StorageManager.getCharacters(App.getActiveCampaignId()) || []).find(x => x.id === _pick.slice(5));
            if (ch && !state.combatants.some(x => x.id === _pick)) extra = { id: _pick, charId: ch.id, speed: parseInt(ch.speed, 10) || 30 };
        }
        _pick = null;
        addCombatant({ ...extra, name, initiative, ac, hp, maxHp: hp, type });
        App.closeModal();
        App.showToast(`${name} dodany do walki`, 'success');
    }

    /* ── HP ─────────────────────────────────────────────────── */

    // PW bohatera w walce = PW na jego karcie (widzi to też gracz na swoim urządzeniu)
    function syncCharacterHp(c) {
        if (!c || !String(c.id).startsWith('char-')) return;
        const cid = App.getActiveCampaignId(); if (!cid) return;
        const chId = c.charId || String(c.id).slice(5);
        const list = StorageManager.getCharacters(cid) || [];
        const ch = list.find(x => x.id === chId);
        if (!ch || !ch.hp || ch.hp.current === c.hp) return;
        ch.hp.current = c.hp;
        if (c.hp > 0 && ch.deathSaves) ch.deathSaves = { successes: 0, failures: 0 };
        StorageManager.saveCharacters(cid, list);
    }

    function reloadFromStorage() {
        const saved = StorageManager.getCombatState();
        state = { active: false, round: 0, currentTurn: 0, combatants: [], ...(saved || {}) };
        _showCombatUI(!!state.active);
        renderInitiativeList();
    }

    function modifyHP(combatantId, amount) {
        const c = state.combatants.find(x => x.id === combatantId);
        if (!c) return;

        const before = c.hp;
        // bohater: obrażenia najpierw zdejmują tymczasowe PW (PHB), a przy 0 PW — rzuty przeciw śmierci
        let pcNote = '';
        const pc = String(c.id).startsWith('char-') ? (() => { const cid = App.getActiveCampaignId(), list = StorageManager.getCharacters(cid) || [], ch = list.find(x => x.id === (c.charId || String(c.id).slice(5))); return ch ? { cid, list, ch } : null; })() : null;
        if (pc && amount < 0 && (pc.ch.hp?.temp || 0) > 0) {
            const soak = Math.min(pc.ch.hp.temp, -amount);
            pc.ch.hp.temp -= soak; amount += soak;
            StorageManager.saveCharacters(pc.cid, pc.list);
            pcNote = `tymczasowe PW pochłonęły ${soak}`;
        }
        if (pc && amount < 0 && before <= 0) {
            const ds = pc.ch.deathSaves = pc.ch.deathSaves || { successes: 0, failures: 0 };
            if (-amount >= c.maxHp) { ds.failures = 3; pcNote = 'obrażenia przy 0 PW ≥ maks. PW — natychmiastowa śmierć'; }
            else { ds.failures = Math.min(3, ds.failures + 1); pcNote = `obrażenia przy 0 PW — porażka w rzucie przeciw śmierci (${ds.failures}/3; trafienie krytyczne liczy się podwójnie)`; }
            StorageManager.saveCharacters(pc.cid, pc.list);
        } else if (pc && amount < 0 && before > 0 && before + amount <= 0 && -(before + amount) >= c.maxHp) {
            pc.ch.deathSaves = { successes: 0, failures: 3 };
            StorageManager.saveCharacters(pc.cid, pc.list);
            pcNote = 'nadwyżka obrażeń ≥ maks. PW — natychmiastowa śmierć';
        }
        c.hp = Math.max(0, Math.min(c.maxHp, c.hp + amount));
        c.defeated = c.hp <= 0;
        syncCharacterHp(c);
        if (pcNote) App.showToast(`${c.name}: ${pcNote}`, 'warning');
        window.Companions?.syncHp?.(c);

        _persist();
        renderInitiativeList();
        if (amount < 0 && before > 0 && (c.conditions || []).includes('Koncentracja')) concentrationCheck(c, Math.min(before, -amount));
    }

    /* ── Koncentracja: obrażenia → rzut obronny Kondycji ───── */
    const mod_ = (v) => Math.floor(((parseInt(v, 10) || 10) - 10) / 2);
    async function conSaveOf(c) {
        const cid = App.getActiveCampaignId();
        const charId = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null);
        if (charId) {
            const ch = (StorageManager.getCharacters(cid) || []).find(x => x.id === charId);
            if (ch) return { bonus: mod_(ch.abilityScores?.con) + ((ch.savingThrows || []).includes('CON') ? APIClient.proficiencyBonus(ch.level || 1) : 0), pc: true };
        }
        if (c.npcId) {
            const n = (StorageManager.getNPCs(cid) || []).find(x => x.id === c.npcId), st = n?.stats;
            if (st) { const crP = window.NPCsModule?.profOf ? NPCsModule.profOf(st) : 2; return { bonus: mod_(st.con) + ((st.saves || []).includes('con') ? crP : 0) }; }
        }
        if (c.ref) {
            try {
                const m = await APIClient.getMonster(c.ref);
                const sv = (m?.proficiencies || []).find(p => /Saving Throw: CON/i.test(p.proficiency?.name || ''));
                if (m) return { bonus: sv ? sv.value : mod_(m.constitution) };
            } catch (e) {}
        }
        return { bonus: null };
    }
    async function concentrationCheck(c, dmg) {
        if (c.hp <= 0) {
            removeCondition(c.id, 'Koncentracja');
            App.showToast(`${c.name} pada — koncentracja przerwana, czar się kończy`, 'warning');
            return;
        }
        const dc = Math.max(10, Math.floor(dmg / 2));
        const { bonus, pc } = await conSaveOf(c);
        const sgn = (n) => (n >= 0 ? `+${n}` : `${n}`);
        // gracze widzą prośbę o rzut w dzienniku stołu
        if (pc && window.OnlineModule?.available?.()) { try { await fetch('api/dziennik', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Panel': '1' }, body: JSON.stringify({ typ: 'wiad', tekst: `🧠 ${c.name}: rzut obronny Kondycji ST ${dc}, żeby utrzymać koncentrację (${dmg} obrażeń).` }) }); } catch (e) {} }
        App.showModal(`Koncentracja: ${c.name}`, `
            <p>${_esc(c.name)} dostaje <b>${dmg}</b> obrażeń, a utrzymuje czar. Potrzebny rzut obronny <b>Kondycji ST ${dc}</b>${bonus != null ? ` (premia ${sgn(bonus)})` : ''}.</p>
            ${pc ? '<p class="modal-hint">To bohater gracza — gracz może rzucić sam (prośba poszła do dziennika stołu) albo rzuć za niego tutaj.</p>' : ''}
            <div id="conc-res" class="conc-res"></div>`,
            `<button class="btn-danger" id="conc-fail"><i class="fa-solid fa-heart-crack"></i> Nieudany — przerwij czar</button><button class="btn-secondary" id="conc-ok">Udany</button>${bonus != null ? `<button class="btn-primary" id="conc-roll"><i class="fa-solid fa-dice-d20"></i> Rzuć k20${sgn(bonus)}</button>` : ''}`);
        const done = (ok) => {
            if (!ok) { removeCondition(c.id, 'Koncentracja'); App.showToast(`${c.name} traci koncentrację — czar się kończy`, 'warning'); }
            else App.showToast(`${c.name} utrzymuje koncentrację`, 'success');
            App.closeModal();
        };
        document.getElementById('conc-fail').onclick = () => done(false);
        document.getElementById('conc-ok').onclick = () => done(true);
        const rb = document.getElementById('conc-roll');
        if (rb) rb.onclick = async () => {
            rb.disabled = true;
            let total;
            try { const r = await DiceRoller.rollExpression(`1d20${sgn(bonus)}`, 'normal', `${c.name}: koncentracja (ST ${dc})`); total = r?.total; } catch (e) {}
            if (typeof total !== 'number') total = Math.floor(Math.random() * 20) + 1 + bonus;
            const ok = total >= dc;
            const box = document.getElementById('conc-res');
            if (box) box.innerHTML = `<b class="${ok ? 'ok' : 'bad'}">${total}</b> — ${ok ? 'udany, czar trwa' : 'nieudany, czar się kończy'}`;
            setTimeout(() => done(ok), 1400);
        };
    }

    /* ── Conditions ────────────────────────────────────────── */

    function addCondition(combatantId, condition) {
        const c = state.combatants.find(x => x.id === combatantId);
        if (!c) return;
        if (!c.conditions.includes(condition)) {
            c.conditions.push(condition);
            _persist();
            renderInitiativeList();
        }
    }

    function removeCondition(combatantId, condition) {
        const c = state.combatants.find(x => x.id === combatantId);
        if (!c) return;
        c.conditions = c.conditions.filter(cond => cond !== condition);
        _persist();
        renderInitiativeList();
    }

    /* ── Initiative ────────────────────────────────────────── */

    async function rollInitiative(modifier, who) {
        const mod = parseInt(modifier) || 0;
        const modStr = mod >= 0 ? `+${mod}` : `${mod}`;
        const result = await DiceRoller.rollExpression(`1d20${modStr}`, 'normal', `${who ? who + ': ' : ''}inicjatywa`);
        return result ? result.total : 0;
    }

    /* ── Render ─────────────────────────────────────────────── */

    
    // Custom Tooltip Logic
    /* ── Karta tury: kto teraz, ile ma ruchu, czym atakuje, kto dalej ── */
    const eco = { tag: '', a: false, b: false, r: false };
    const sheetCache = {};
    let sheetOpen = (() => { try { return localStorage.getItem('dnd5e_cf_sheet') !== '0'; } catch (e) { return true; } })();
    // szybkość 0 wg zasad: pochwycenie, skrępowanie oraz stany, które obezwładniają ciało (samo „obezwładnienie” nie zatrzymuje ruchu)
    const STOP_CONDS = ['Pochwycenie', 'Skrepowanie', 'Paraliz', 'Ogluszenie', 'Nieprzytomnosc', 'Spetryfikowanie'];
    const CPL = { Oslepienie: 'Oślepienie', Gluchota: 'Głuchota', Przerazenie: 'Przerażenie', Obezwladnienie: 'Obezwładnienie', Niewidzialnosc: 'Niewidzialność', Paraliz: 'Paraliż', Lezenie: 'Leżenie', Skrepowanie: 'Skrępowanie', Ogluszenie: 'Ogłuszenie', Nieprzytomnosc: 'Nieprzytomność', Zmeczenie: 'Zmęczenie', Spetryfikowanie: 'Spetryfikowanie' };
    const vttScene = () => window.VTTModule?.state?.scene || null;
    function distFt(a, b) {
        const V = vttScene(); if (!V || !V.tokens) return null;
        const ta = V.tokens[a.id], tb = V.tokens[b.id]; if (!ta || !tb) return null;
        if (V.kind === 'atlas' && (ta.lv || V.levelId) !== (tb.lv || V.levelId)) return null;   // inne piętro
        const na = Math.max(1, +a.size || 1), nb = Math.max(1, +b.size || 1);
        const dx = Math.max(0, tb.x - (ta.x + na - 1), ta.x - (tb.x + nb - 1)), dy = Math.max(0, tb.y - (ta.y + na - 1), ta.y - (tb.y + nb - 1));
        const mx = Math.max(dx, dy), mn = Math.min(dx, dy);
        return (V.diag === 'alt' ? mx + Math.floor(mn / 2) : mx) * 5;
    }
    function moveOf(c) {
        const t = vttScene()?.tokens?.[c.id], tag = `${state.round}:${c.id}`;
        const total = (c.conditions || []).some(k => STOP_CONDS.includes(k)) ? 0 : (parseInt(c.speed, 10) || 30) * (t && t.dash === tag ? 2 : 1);
        const moved = t && t.tt === tag ? (t.moved || 0) : 0;
        return { total, left: Math.max(0, total - moved), dash: !!(t && t.dash === tag) };
    }
    const sgn = (n) => (n >= 0 ? '+' : '−') + Math.abs(n);
    const rb = (expr, lbl, txt, cls = '') => `<button type="button" class="nr ${cls}" data-roll="${_esc(expr)}" data-lbl="${_esc(lbl)}">${txt}</button>`;
    function sheetHTML(c) {
        const cidv = App.getActiveCampaignId();
        const charId = c.charId || (String(c.id).startsWith('char-') ? String(c.id).slice(5) : null);
        if (charId) {
            const ch = (StorageManager.getCharacters(cidv) || []).find(x => x.id === charId); if (!ch) return '';
            return window.NPCsModule?.pcBlockHTML ? NPCsModule.pcBlockHTML(ch, { compact: true }) : '';
        }
        if (!window.NPCsModule) return '';
        const withNow = (n) => { const x = { ...n, name: c.name, stats: { ...n.stats, hpNow: c.hp, hp: c.maxHp || n.stats.hp } }; return NPCsModule.statBlockHTML(x, { compact: true }); };
        if (c.npcId) {
            const raw = (StorageManager.getNPCs(cidv) || []).find(n => n.id === c.npcId);
            if (raw) { const n = NPCsModule.normNPC(raw); if (n.hasStats) return withNow(n); }
        }
        // potwór: z bestiariusza (indeks), z własnych potworów, a gdy brak powiązania — po nazwie
        const base = String(c.name || '').replace(/\s+\d+$/, '').trim();
        const key = c.ref ? `ref:${c.ref}` : `name:${base.toLowerCase()}`;
        const hit = sheetCache[key];
        if (hit) return withNow(hit);
        if (hit === undefined) {
            sheetCache[key] = null;
            (async () => {
                const custom = () => (StorageManager.getCustomMonsters?.() || []);
                let m = null;
                if (c.ref && String(c.ref).startsWith('custom:')) m = custom().find(x => x._customId === String(c.ref).slice(7)) || null;
                else if (c.ref) m = await APIClient.getMonster(c.ref).catch(() => null);
                if (!m || !m.name) {
                    // NPC kampanii o tej nazwie
                    const npc = (StorageManager.getNPCs(cidv) || []).map(NPCsModule.normNPC).find(n => n.hasStats && n.name.toLowerCase() === base.toLowerCase());
                    if (npc) { sheetCache[key] = npc; renderFocus(); return; }
                    m = custom().find(x => String(x.name || '').toLowerCase() === base.toLowerCase()) || null;
                    if (!m) {
                        const slug = base.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/ł/g, 'l').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
                        if (slug) m = await APIClient.getMonster(slug).catch(() => null);
                        if ((!m || !m.name) && APIClient.getMonsterList) {
                            const L = await APIClient.getMonsterList().catch(() => []);
                            const f = (L || []).find(x => String(x.name || '').toLowerCase() === base.toLowerCase() || String(x.namePl || '').toLowerCase() === base.toLowerCase());
                            if (f) m = await APIClient.getMonster(f.index).catch(() => null);
                        }
                    }
                }
                if (m && m.name) { sheetCache[key] = { name: base, hasStats: true, stats: NPCsModule._fromMonster(m) }; renderFocus(); }
                else { sheetCache[key] = false; renderFocus(); }
            })();
            return '<p class="cf-muted"><i class="fa-solid fa-spinner fa-spin"></i> Wczytuję kartę z bestiariusza…</p>';
        }
        // nic nie znaleziono — skrócona karta z tego, co wiadomo z walki
        return `<div class="nb nb-compact"><div class="nb-type">${_esc(c.type === 'monster' ? 'Przeciwnik' : c.type === 'npc' ? 'NPC' : 'Uczestnik walki')}</div>
            <div class="nb-vitals">
                <div class="nb-v"><small>Klasa pancerza</small><b>${c.ac}</b></div>
                <div class="nb-v"><small>Punkty wytrzymałości</small><b>${c.hp}<small class="nb-of">/${c.maxHp}</small></b></div>
                <div class="nb-v"><small>Szybkość</small><b>${parseInt(c.speed, 10) || 30} ft</b></div>
                <div class="nb-v"><small>Inicjatywa</small><b>${c.initiative}</b></div>
            </div>
            <p class="nb-intro">Brak pełnej karty: ten uczestnik nie jest powiązany z bestiariuszem ani z NPC kampanii. Dodawaj przeciwników z Bestiariusza („Do walki”), z NPC i wrogów albo z Atlasu — wtedy pojawią się tu ich ataki i cechy.</p></div>`;
    }
    function renderFocus() {
        const list = document.getElementById('initiative-list'); if (!list) return;
        let box = document.getElementById('combat-focus');
        if (!box) { box = document.createElement('div'); box.id = 'combat-focus'; box.className = 'nb-host'; list.parentNode.insertBefore(box, list); }
        const c = state.active ? state.combatants[state.currentTurn] : null;
        if (!c) { box.innerHTML = ''; box.hidden = true; return; }
        box.hidden = false;
        const tag = `${state.round}:${c.id}`; if (eco.tag !== tag) Object.assign(eco, { tag, a: false, b: false, r: false });
        const pct = c.maxHp > 0 ? Math.max(0, Math.min(100, c.hp / c.maxHp * 100)) : 0;
        const mv = moveOf(c);
        const typeTxt = c.type === 'pc' || c.type === 'player' ? 'Bohater' : c.type === 'npc' ? (c.disp === 'friendly' ? 'Sojusznik' : 'NPC') : 'Przeciwnik';
        // kto dalej (pomija pokonanych)
        const next = []; for (let k = 1; k < state.combatants.length && next.length < 3; k++) { const o = state.combatants[(state.currentTurn + k) % state.combatants.length]; if (!o.defeated && o.hp > 0) next.push(o); }
        // kto jest blisko (w zasięgu wręcz) — z planszy
        const near = state.combatants.filter(o => o.id !== c.id && o.hp > 0).map(o => ({ o, d: distFt(c, o) })).filter(x => x.d != null).sort((a, b) => a.d - b.d);
        const melee = near.filter(x => x.d <= 5);
        const sheet = sheetHTML(c);
        box.innerHTML = `<div class="cf t-${_esc(c.type)}">
            <div class="cf-h"><span class="cf-now">Teraz</span><b>${_esc(c.name)}</b><em>${typeTxt}${(() => { const L = window.VTTModule?.levelOf?.(c.id); return L && L.many ? ` · <i class="fa-solid fa-stairs"></i> ${_esc(L.name)}` : ''; })()}</em></div>
            <div class="cf-stats">
                <span><small>KP</small><b>${c.ac}</b></span>
                <span class="cf-hp"><small>PW</small><b>${c.hp}<i>/${c.maxHp}</i></b><u><s style="width:${pct}%"></s></u></span>
                <span><small>Ruch</small><b>${mv.left}<i>/${mv.total} ft</i></b>${mv.dash ? '<em>sprint</em>' : ''}</span>
                <span><small>Inicjatywa</small><b>${c.initiative}</b></span>
            </div>
            <div class="cf-eco">${[['a', 'fa-hand-fist', 'Akcja'], ['b', 'fa-bolt', 'Akcja dodatkowa'], ['r', 'fa-rotate-left', 'Reakcja']].map(([k, ic, l]) => `<button type="button" data-eco="${k}" class="${eco[k] ? 'used' : ''}" title="${eco[k] ? 'Wykorzystana — kliknij, by cofnąć' : 'Kliknij, gdy wykorzysta'}"><i class="fa-solid ${ic}"></i> ${l}</button>`).join('')}</div>
            ${(c.conditions || []).length ? `<div class="cf-conds">${c.conditions.map(k => `<div><b>${_esc(CPL[k] || k)}</b> ${_esc(window.getCondDesc ? getCondDesc(k) : '')}</div>`).join('')}</div>` : ''}
            ${near.length ? `<div class="cf-near"><i class="fa-solid fa-location-crosshairs"></i> ${melee.length ? `W zasięgu wręcz: ${melee.map(x => `<b>${_esc(x.o.name)}</b>`).join(', ')}` : `Najbliżej: <b>${_esc(near[0].o.name)}</b> (${near[0].d} ft)`}</div>` : ''}
            ${sheet ? `<details class="cf-sheet" ${sheetOpen ? 'open' : ''}><summary>Karta i ataki</summary><div class="cf-scroll">${sheet}</div></details>` : ''}
            ${next.length ? `<div class="cf-next"><span>Dalej:</span>${next.map((o, i) => `<b class="${i ? '' : 'first'}">${_esc(o.name)}</b>`).join('<i>›</i>')}</div>` : ''}
        </div>`;
        if (!box._bound) {
            box._bound = true;
            box.addEventListener('click', (e) => { const b = e.target.closest('[data-eco]'); if (!b) return; eco[b.dataset.eco] = !eco[b.dataset.eco]; b.classList.toggle('used', eco[b.dataset.eco]); });
            box.addEventListener('toggle', (e) => { if (e.target.matches('.cf-sheet')) { sheetOpen = e.target.open; try { localStorage.setItem('dnd5e_cf_sheet', sheetOpen ? '1' : '0'); } catch (er) {} } }, true);
        }
    }

    // po ruchu żetonu: odśwież kartę tury i odległości bez przebudowy listy (nie gubi wpisywanych PW)
    function refreshFocus() {
        renderFocus();
        const cur = state.active ? state.combatants[state.currentTurn] : null;
        document.querySelectorAll('#initiative-list [data-combatant-id]').forEach(card => {
            const c = state.combatants.find(x => x.id === card.dataset.combatantId); if (!c) return;
            const d = cur && cur.id !== c.id ? distFt(cur, c) : null;
            let el = card.querySelector('.cb-dist');
            if (d == null) { el?.remove(); return; }
            if (!el) { el = document.createElement('div'); el.className = 'cb-dist'; card.querySelector('.cb-ac')?.before(el); }
            el.classList.toggle('melee', d <= 5); el.title = `Odległość od: ${cur.name}`; el.innerHTML = `<i class="fa-solid fa-ruler"></i> ${d} ft`;
        });
    }
    function renderInitiativeList() {
        if (window.VTTModule) window.VTTModule.syncTokens();
        const container = document.getElementById('initiative-list');
        if (!container) return;

        if (state.combatants.length === 0) {
            container.innerHTML = '<div class="empty-state">Brak uczestników walki. Dodaj przeciwników i graczy z odpowiednich zakładek by zacząć.</div>';
            renderFocus();
            return;
        }

        container.innerHTML = state.combatants.map((c, i) => {
            const isActive = state.active && state.currentTurn === i;
            const isDefeated = c.hp <= 0 && c.type !== 'player';
            const hpPercent = Math.max(0, Math.min(100, (c.hp / c.maxHp) * 100));
            let hpClass = 'hp-high';
            if (hpPercent <= 25) hpClass = 'hp-low';
            else if (hpPercent <= 50) hpClass = 'hp-mid';

            return `
            <div class="combatant-card block-layout ${isActive ? 'active-turn' : ''} ${isDefeated ? 'defeated' : ''}" data-id="${c.id}" data-combatant-id="${c.id}">
                
                <div class="cb-header">
                    <div class="cb-header-left">
                        ${!state.active ? `
                            <input type="number" class="init-input" data-id="${c.id}" value="${c.initiative}" title="Inicjatywa">
                        ` : `
                            <div class="cb-initiative">${c.initiative}</div>
                        `}
                        <div class="cb-name">${_esc(c.name)}${window.VTTModule?.state?.scene?.fog && !c.seen && c.type !== 'pc' && c.type !== 'player' && !String(c.id).endsWith('-druzyna') && c.disp !== 'friendly' ? '<small class="cb-undisc" title="Gracze jeszcze go nie zobaczyli — nie ma go u nich nawet w kolejce"><i class="fa-solid fa-eye-slash"></i> nieodkryty</small>' : ''}${(() => { if (!c.npcId || !String(c.id).endsWith('-druzyna') || !window.Companions) return ''; const n = Companions.list().find(x => x.id === c.npcId); if (!n) return ''; const ow = n.party.charId ? (StorageManager.getCharacters(App.getActiveCampaignId()) || []).find(x => x.id === n.party.charId) : null; return `<small class="cb-ctrl" title="Towarzysz drużyny"><i class="fa-solid fa-handshake-angle"></i> ${ow ? `prowadzi: ${_esc(ow.name)}` : 'MG'}</small>`; })()}</div>
                    </div>
                    <div class="cb-header-right">
                        ${c.npcId ? `<button class="btn-icon cb-sheet" onclick="NPCsModule.showSheet('${_esc(c.npcId)}')" title="Karta: ataki, cechy, rzuty"><i class="fa-solid fa-scroll"></i></button>` : ''}
                        ${(() => { const cur = state.active ? state.combatants[state.currentTurn] : null; const d = cur && cur.id !== c.id ? distFt(cur, c) : null; return d != null ? `<div class="cb-dist ${d <= 5 ? 'melee' : ''}" title="Odległość od: ${_esc(cur.name)}"><i class="fa-solid fa-ruler"></i> ${d} ft</div>` : ''; })()}
                        <div class="cb-ac">KP ${c.ac}</div>
                        <button class="btn-icon btn-danger btn-remove-combatant" data-id="${c.id}" title="Usuń"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                </div>
                
                <div class="cb-health">
                    <div class="hp-bar">
                        <div class="hp-bar-fill ${hpClass}" style="width:${hpPercent}%"></div>
                    </div>
                </div>
                
                <div class="cb-controls">
                    <div class="cb-hp-actions">
                        <button class="hp-adjust-btn damage" data-id="${c.id}" data-amount="-5">-5</button>
                        <button class="hp-adjust-btn damage" data-id="${c.id}" data-amount="-1">-1</button>
                        
                        <div class="cb-hp-manual">
                            <input type="number" class="hp-manual-input" data-id="${c.id}" value="${c.hp}">
                            <span>/ ${c.maxHp} HP</span>
                        </div>
                        
                        <button class="hp-adjust-btn heal" data-id="${c.id}" data-amount="1">+1</button>
                        <button class="hp-adjust-btn heal" data-id="${c.id}" data-amount="5">+5</button>
                    </div>
                    
                    <div class="cb-conditions">
                        ${(c.conditions || []).map(cond => {
                            const desc = window.getCondDesc ? window.getCondDesc(cond) : '';
                            const safeDesc = desc.replace(/"/g, "'");
                            return `<span class="condition-badge condition-${_esc(cond).toLowerCase()}" data-id="${c.id}" data-condition="${_esc(cond)}" data-tooltip="${safeDesc}">${getConditionIcon(cond)} ${_esc(cond)}</span>`;
                        }).join('')}
                        <button class="btn-icon btn-add-condition" data-id="${c.id}" title="Dodaj status"><i class="fa-solid fa-plus"></i></button>
                    </div>
                </div>
                
            </div>`;
        }).join('');
        renderFocus();

        // Bind condition tooltips
        let tip = document.getElementById('cond-tip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'cond-tip';
            tip.style.cssText = 'position:fixed;z-index:99999;pointer-events:none;display:none;background:rgba(10,6,2,.97);color:#f0e6c8;border:1px solid #d4a017;border-radius:8px;padding:10px 14px;font-size:.82rem;line-height:1.6;max-width:280px;box-shadow:0 6px 24px rgba(0,0,0,.95);white-space:normal;';
            document.body.appendChild(tip);
        }
        container.querySelectorAll('.condition-badge').forEach(badge => {
            badge.addEventListener('mouseenter', () => {
                const desc = badge.dataset.tooltip || '';
                const name = badge.dataset.condition || '';
                if (!desc && !name) return;
                tip.innerHTML = '<strong style="color:#d4a017;display:block;margin-bottom:4px">' + name + '</strong>' + (desc ? '<span>' + desc + '</span>' : '');
                tip.style.display = 'block';
            });
            badge.addEventListener('mousemove', (e) => {
                if (tip.style.display === 'none') return;
                let top = e.clientY - tip.offsetHeight - 12;
                let left = e.clientX - tip.offsetWidth / 2;
                if (top < 4) top = e.clientY + 16;
                if (left < 4) left = 4;
                if (left + tip.offsetWidth > window.innerWidth - 4) left = window.innerWidth - tip.offsetWidth - 4;
                tip.style.top = top + 'px';
                tip.style.left = left + 'px';
            });
            badge.addEventListener('mouseleave', () => { tip.style.display = 'none'; });
        });

        // Bind manual HP input
        container.querySelectorAll('.hp-manual-input').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = input.dataset.id;
                const newHp = parseInt(input.value, 10);
                if(!isNaN(newHp)) {
                    const c = state.combatants.find(x => x.id === id);
                    if(c) {
                        modifyHP(id, newHp - c.hp);
                    }
                }
            });
            input.addEventListener('click', (e) => e.stopPropagation());
        });

        // Bind init input
        container.querySelectorAll('.init-input').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = input.dataset.id;
                const newInit = parseInt(input.value, 10) || 0;
                const c = state.combatants.find(x => x.id === id);
                if (c) {
                    c.initiative = newInit;
                    _persist();
                }
            });
            input.addEventListener('click', (e) => e.stopPropagation());
        });

        // Bind HP buttons
        container.querySelectorAll('.hp-adjust-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id  = btn.dataset.id;
                const amt = parseInt(btn.dataset.amount, 10);
                modifyHP(id, amt);
            });
        });

        // Bind condition badge removal
        container.querySelectorAll('.condition-badge').forEach(badge => {
            badge.addEventListener('click', (e) => {
                e.stopPropagation();
                removeCondition(badge.dataset.id, badge.dataset.condition);
            });
        });

        // Bind add-condition buttons
        container.querySelectorAll('.btn-add-condition').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                _showConditionPicker(btn.dataset.id);
            });
        });

        // Bind remove combatant
        container.querySelectorAll('.btn-remove-combatant').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                removeCombatant(btn.dataset.id);
            });
        });
        
        // Bind selection highlighting
        container.querySelectorAll('.combatant-card').forEach(card => {
            card.addEventListener('click', () => {
                highlightCombatant(card.dataset.combatantId);
                if (window.VTTModule && window.VTTModule.focusCombatant) window.VTTModule.focusCombatant(card.dataset.combatantId);
            });
        });
    }

    function highlightCombatant(combatantId) {
        document.querySelectorAll('.combatant-card').forEach(card => {
            if (card.dataset.combatantId === combatantId) {
                card.style.borderLeft = '6px solid var(--gold)';
                card.style.backgroundColor = 'var(--surface-dark)';
                card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                card.style.borderLeft = '';
                card.style.backgroundColor = '';
            }
        });
    }

    /* ── Condition picker modal ────────────────────────────── */

    function _showConditionPicker(combatantId) {
        const conditions = APIClient.CONDITIONS || [
            'Oslepienie', 'Zauroczenie', 'Gluchota', 'Przerazenie', 'Pochwycenie',
            'Obezwladnienie', 'Niewidzialnosc', 'Paraliz', 'Spetryfikowanie',
            'Zatrucie', 'Lezenie', 'Skrepowanie', 'Ogluszenie', 'Nieprzytomnosc',
            'Zmeczenie', 'Koncentracja'
        ];

        const c = state.combatants.find(x => x.id === combatantId);
        if (!c) return;

        const body = `
            <div style="display:flex;flex-wrap:wrap;gap:.5rem;">
                ${conditions.map(cond => {
                    const active = c.conditions.includes(cond);
                    return `
                        <button class="btn-${active ? 'primary' : 'secondary'} condition-pick-btn" data-condition="${cond}">
                            ${getConditionIcon(cond)} ${cond}
                        </button>
                    `;
                }).join('')}
            </div>`;

        const footer = `<button class="btn-secondary" onclick="App.closeModal()">Zamknij</button>`;

        App.showModal(`Statusy — ${_esc(c.name)}`, body, footer);

        setTimeout(() => {
            document.querySelectorAll('.condition-pick-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const cond = btn.dataset.condition;
                    if (c.conditions.includes(cond)) {
                        removeCondition(combatantId, cond);
                        btn.classList.remove('btn-primary');
                        btn.classList.add('btn-secondary');
                    } else {
                        addCondition(combatantId, cond);
                        btn.classList.remove('btn-secondary');
                        btn.classList.add('btn-primary');
                    }
                });
            });
        }, 50);
    }

    /* ── UI helpers ─────────────────────────────────────────── */

    function _showCombatUI(active) {
        const roundEl   = document.getElementById('combat-round');
        const startBtn  = document.getElementById('btn-start-combat');
        const endBtn    = document.getElementById('btn-end-combat');

        if (roundEl)  roundEl.classList.toggle('hidden', !active);
        if (startBtn) startBtn.classList.toggle('hidden', active);
        if (endBtn)   endBtn.classList.toggle('hidden', !active);

        _updateRoundDisplay();
    }

    function _updateRoundDisplay() {
        const roundEl = document.getElementById('round-number');
        if (roundEl) roundEl.textContent = state.round;
    }

    function _persist() {
        StorageManager.saveCombatState({
            active:      state.active,
            round:       state.round,
            currentTurn: state.currentTurn,
            combatants:  state.combatants
        });
    }

    function _bind(id, event, fn) {
        const el = document.getElementById(id);
        if (el) el.addEventListener(event, fn);
    }

    



    function getConditionIcon(cond) {
        const map = {
            'Oslepienie': '<i class="fa-solid fa-eye-slash"></i> ',
            'Zauroczenie': '<i class="fa-solid fa-heart"></i> ',
            'Gluchota': '<i class="fa-solid fa-ear-deaf"></i> ',
            'Przerazenie': '<i class="fa-solid fa-ghost"></i> ',
            'Pochwycenie': '<i class="fa-solid fa-hand-fist"></i> ',
            'Obezwladnienie': '<i class="fa-solid fa-ban"></i> ',
            'Niewidzialnosc': '<i class="fa-solid fa-user-ninja"></i> ',
            'Paraliz': '<i class="fa-solid fa-bolt"></i> ',
            'Spetryfikowanie': '<i class="fa-solid fa-gem"></i> ',
            'Zatrucie': '<i class="fa-solid fa-skull-crossbones"></i> ',
            'Lezenie': '<i class="fa-solid fa-bed"></i> ',
            'Skrepowanie': '<i class="fa-solid fa-link"></i> ',
            'Ogluszenie': '<i class="fa-solid fa-star"></i> ',
            'Nieprzytomnosc': '<i class="fa-solid fa-moon"></i> ',
            'Zmeczenie': '<i class="fa-solid fa-battery-empty"></i> ',
            'Koncentracja': '<i class="fa-solid fa-brain"></i> ',
            // English fallbacks
            'Blinded': '<i class="fa-solid fa-eye-slash"></i> ',
            'Charmed': '<i class="fa-solid fa-heart"></i> ',
            'Deafened': '<i class="fa-solid fa-ear-deaf"></i> ',
            'Frightened': '<i class="fa-solid fa-ghost"></i> ',
            'Grappled': '<i class="fa-solid fa-hand-fist"></i> ',
            'Incapacitated': '<i class="fa-solid fa-ban"></i> ',
            'Invisible': '<i class="fa-solid fa-user-ninja"></i> ',
            'Paralyzed': '<i class="fa-solid fa-bolt"></i> ',
            'Petrified': '<i class="fa-solid fa-gem"></i> ',
            'Poisoned': '<i class="fa-solid fa-skull-crossbones"></i> ',
            'Prone': '<i class="fa-solid fa-bed"></i> ',
            'Restrained': '<i class="fa-solid fa-link"></i> ',
            'Stunned': '<i class="fa-solid fa-star"></i> ',
            'Unconscious': '<i class="fa-solid fa-moon"></i> '
        };
        return map[cond] || '<i class="fa-solid fa-circle-exclamation"></i> ';
    }

    function _esc(str) {
        const div = document.createElement('div');
        div.textContent = String(str);
        return div.innerHTML;
    }

    /* ── Expose ── */
    
    function addCombatants(list) {
        (list || []).forEach(o => {
            const c = { ...o, id: o.id || StorageManager.generateId(), name: o.name || 'Unknown', initiative: o.initiative ?? 0,
                ac: o.ac ?? 10, hp: o.hp ?? 10, maxHp: o.maxHp ?? o.hp ?? 10, type: o.type || 'monster', conditions: [...(o.conditions || [])] };
            c.defeated = c.hp <= 0;
            const i = state.combatants.findIndex(x => x.id === c.id);
            if (i >= 0) state.combatants[i] = { ...state.combatants[i], ...c, conditions: state.combatants[i].conditions };
            else state.combatants.push(c);
        });
        if (state.active) {
            const cur = state.combatants[state.currentTurn]?.id;
            state.combatants.sort((a, b) => b.initiative - a.initiative);
            state.currentTurn = Math.max(0, state.combatants.findIndex(x => x.id === cur));
        }
        _persist();
        renderInitiativeList();
    }

    function updateCombatant(id, patch) {
        const c = state.combatants.find(x => x.id === id);
        if (!c) return;
        const before = c.hp;
        Object.assign(c, patch);
        if ('hp' in patch) { c.hp = Math.max(0, Math.min(c.maxHp, c.hp)); c.defeated = c.hp <= 0; syncCharacterHp(c); }
        _persist();
        renderInitiativeList();
        if ('hp' in patch && c.hp < before && before > 0 && (c.conditions || []).includes('Koncentracja')) concentrationCheck(c, before - c.hp);
    }

    function removeCombatant(id) {
        const idx = state.combatants.findIndex(c => c.id === id);
        if (idx < 0) return;
        state.combatants.splice(idx, 1);
        if (idx < state.currentTurn) state.currentTurn--;
        if (state.currentTurn >= state.combatants.length) state.currentTurn = 0;
        if (!state.combatants.length) { state.active = false; _showCombatUI(false); }
        _persist();
        renderInitiativeList();
    }

    function clearCombatants() {
        state = { active: false, round: 0, currentTurn: 0, combatants: [] };
        StorageManager.clearCombatState();
        _showCombatUI(false);
        renderInitiativeList();
    }

    function getRound() { return state.round; }

    function getCombatants() { return state.combatants; }
    function isActive() { return state.active; }
    function getActiveCombatant() {
        if (!state.active || state.combatants.length === 0) return null;
        return state.combatants[state.currentTurn];
    }
    
    return {
        init,
        activate,
        startCombat,
        endCombat,
        addCombatant,
        showAddCombatantModal,
        nextTurn,
        renderInitiativeList,
        modifyHP,
        addCondition,
        removeCondition,
        rollInitiative,
        getCombatants,
        isActive,
        getActiveCombatant,
        highlightCombatant,
        addCombatants,
        updateCombatant,
        removeCombatant,
        clearCombatants,
        getRound,
        reloadFromStorage,
        refreshFocus,
        selectCombatant: (id) => { highlightCombatant(id); if (window.VTTModule?.focusCombatant) VTTModule.focusCombatant(id); }
    };
})();

window.CombatModule = CombatModule;

