/* ============================================
   D&D 5e DM Panel — API Client (dnd5eapi.co)
   ============================================ */

const APIClient = {
    BASE_URL: 'https://www.dnd5eapi.co/api/2014',
    cache: {},
    translationCache: new Map(),

    // ---------- tłumaczenia ----------
    // 1) pamięć w tej karcie, 2) pamięć przeglądarki (zostaje po odświeżeniu), 3) wspólna pamięć serwera panelu
    //    (każdy tekst tłumaczony raz dla MG i wszystkich graczy), 4) dopiero potem Google — równolegle, nie po kolei.
    _trLoaded: false,
    _trLoad() {
        if (this._trLoaded) return; this._trLoaded = true;
        try { const o = JSON.parse(localStorage.getItem('dnd5e_tr1') || '{}'); Object.entries(o).forEach(([k, v]) => this.translationCache.set(k, v)); } catch (e) {}
    },
    _trSave() {
        clearTimeout(this._trT);
        this._trT = setTimeout(() => {
            try {
                let entries = [...this.translationCache.entries()];
                if (entries.length > 4000) entries = entries.slice(-4000);
                localStorage.setItem('dnd5e_tr1', JSON.stringify(Object.fromEntries(entries)));
            } catch (e) { try { localStorage.removeItem('dnd5e_tr1'); } catch (er) {} }
        }, 800);
    },
    async _trGoogle(text) {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=pl&dt=t&q=${encodeURIComponent(text)}`;
        const res = await fetch(url);
        const json = await res.json();
        return json[0].map(x => x[0]).join('');
    },
    async translateMany(texts) {
        if (window.LANG === 'en') return (texts || []).map(t => (typeof t === 'string' ? t : ''));
        this._trLoad();
        const list = (texts || []).map(t => (typeof t === 'string' ? t : ''));
        const need = [...new Set(list.filter(t => t.trim() && !this.translationCache.has(t)))];
        if (need.length) {
            let viaServer = false;
            if (/^https?:$/.test(location.protocol)) {
                try {
                    for (let i = 0; i < need.length; i += 40) {
                        const part = need.slice(i, i + 40);
                        const r = await fetch('/api/tlumacz', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Panel': '1' }, body: JSON.stringify({ teksty: part }) });
                        if (!r.ok) throw new Error('HTTP ' + r.status);
                        const j = await r.json();
                        part.forEach((t, k) => { if (j.wyniki?.[k]) this.translationCache.set(t, j.wyniki[k]); });
                    }
                    viaServer = true;
                } catch (e) { viaServer = false; }
            }
            // bez serwera panelu (albo gdy nie odpowiada): tłumacz bezpośrednio, kilka naraz
            const left = need.filter(t => !this.translationCache.has(t));
            if (left.length && !viaServer) {
                let i = 0;
                const worker = async () => { while (i < left.length) { const t = left[i++]; try { this.translationCache.set(t, await this._trGoogle(t)); } catch (e) {} } };
                await Promise.all(Array.from({ length: Math.min(6, left.length) }, worker));
            }
            this._trSave();
        }
        return list.map(t => this.translationCache.get(t) ?? t);
    },
    isTranslated(text) { if (window.LANG === 'en') return true; this._trLoad(); return !text || typeof text !== 'string' || !text.trim() || this.translationCache.has(text); },
    // pojedyncze teksty z tej samej chwili lecą jednym zapytaniem
    translateText(text) {
        if (!text || typeof text !== 'string' || text.trim() === '') return Promise.resolve(text);
        if (window.LANG === 'en') return Promise.resolve(text);
        this._trLoad();
        if (this.translationCache.has(text)) return Promise.resolve(this.translationCache.get(text));
        if (!this._trQ) {
            this._trQ = new Map();
            setTimeout(() => {
                const q = this._trQ; this._trQ = null;
                const keys = [...q.keys()];
                this.translateMany(keys).then(out => keys.forEach((k, i) => q.get(k).forEach(r => r(out[i])))).catch(() => keys.forEach(k => q.get(k).forEach(r => r(k))));
            }, 0);
        }
        return new Promise(r => { const a = this._trQ.get(text) || []; a.push(r); this._trQ.set(text, a); });
    },

    async fetch(endpoint) {
        // Check memory cache
        if (this.cache[endpoint]) return this.cache[endpoint];

        // Check localStorage cache
        const cacheKey = endpoint.replace(/\//g, '_');
        if (StorageManager.isSRDCacheValid(cacheKey)) {
            const cached = StorageManager.getSRDCache(cacheKey);
            this.cache[endpoint] = cached.data;
            return cached.data;
        }

        try {
            const res = await fetch(this.BASE_URL + endpoint);
            if (!res.ok) throw new Error(`API Error: ${res.status}`);
            const data = await res.json();

            // Cache in memory and localStorage
            this.cache[endpoint] = data;
            StorageManager.setSRDCache(cacheKey, data);
            return data;
        } catch (err) {
            console.error('API fetch error:', endpoint, err);
            // Try returning stale cache
            const stale = StorageManager.getSRDCache(cacheKey);
            if (stale && stale.data) return stale.data;
            throw err;
        }
    },

    async fetchGraphQL(query) {
        const cacheKey = 'graphql_' + this._hash(query);
        if (StorageManager.isSRDCacheValid(cacheKey)) {
            return StorageManager.getSRDCache(cacheKey).data;
        }
        
        try {
            const res = await fetch('https://www.dnd5eapi.co/graphql', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query })
            });
            const json = await res.json();
            StorageManager.setSRDCache(cacheKey, json.data);
            return json.data;
        } catch (e) {
            console.error('GraphQL err:', e);
            return null;
        }
    },

    _hash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) hash = ((hash << 5) - hash) + str.charCodeAt(i);
        return hash;
    },

    // ---- Monsters ----
    async getMonsterList() {
        const query = `query { monsters(limit: 500) { index name size type challenge_rating armor_class { ... on ArmorClassArmor { value } ... on ArmorClassNatural { value } ... on ArmorClassDex { value } ... on ArmorClassSpell { value } ... on ArmorClassCondition { value } } hit_points } }`;
        const data = await this.fetchGraphQL(query);
        if (data && data.monsters) return data.monsters;
        
        // Fallback to REST
        const fallback = await this.fetch('/monsters');
        return fallback.results || [];
    },

    async getMonster(index) {
        return await this.fetch(`/monsters/${index}`);
    },

    // ---- Spells ----
    async getSpellList() {
        const query = `query { spells(limit: 500) { index name level school { name } ritual concentration classes { name } } }`;
        const data = await this.fetchGraphQL(query);
        if (data && data.spells) return data.spells;
        
        // Fallback to REST
        const fallback = await this.fetch('/spells');
        return fallback.results || [];
    },

    async getSpell(index) {
        return await this.fetch(`/spells/${index}`);
    },

    // ---- Equipment ----
    async getEquipmentList() {
        const query = `query {
          equipments(limit: 500) {
            ... on IEquipment {
              index
              name
              cost { quantity unit }
              weight
            }
            ... on Armor { equipment_category { name } }
            ... on Weapon { equipment_category { name } }
            ... on Tool { equipment_category { name } }
            ... on Gear { equipment_category { name } }
            ... on Pack { equipment_category { name } }
            ... on Ammunition { equipment_category { name } }
            ... on Vehicle { equipment_category { name } }
          }
        }`;
        const data = await this.fetchGraphQL(query);
        if (data && data.equipments) return data.equipments;

        const fallback = await this.fetch('/equipment');
        return fallback.results || [];
    },

    async getEquipment(index) {
        return await this.fetch(`/equipment/${index}`);
    },

    async getEquipmentCategories() {
        const data = await this.fetch('/equipment-categories');
        return data.results || [];
    },

    // ---- Magic Items ----
    async getMagicItemList() {
        const query = `query {
          magicItems(limit: 500) {
            index
            name
            equipment_category { name }
            rarity { name }
          }
        }`;
        const data = await this.fetchGraphQL(query);
        if (data && data.magicItems) return data.magicItems;

        const fallback = await this.fetch('/magic-items');
        return fallback.results || [];
    },

    async getMagicItem(index) {
        return await this.fetch(`/magic-items/${index}`);
    },

    // ---- Classes & Races ----
    async getClassList() {
        const data = await this.fetch('/classes');
        return data.results || [];
    },

    async getClass(index) {
        return await this.fetch(`/classes/${index}`);
    },

    async getClassLevel(index, level) {
        return await this.fetch(`/classes/${index}/levels/${level}`);
    },

    async getFeature(index) {
        return await this.fetch(`/features/${index}`);
    },

    async getClassFeatures(index) {
        const data = await this.fetch(`/classes/${index}/features`);
        return data.results || [];
    },

    async getRaceList() {
        const data = await this.fetch('/races');
        return data.results || [];
    },

    async getRace(index) {
        return await this.fetch(`/races/${index}`);
    },

    async getSubraceList(raceIndex) {
        const raceData = await this.getRace(raceIndex);
        return raceData.subraces || [];
    },

    async getSubrace(index) {
        return await this.fetch(`/subraces/${index}`);
    },

    async getBackground(index) {
        return await this.fetch(`/backgrounds/${index}`);
    },

    async getBackgroundList() {
        const data = await this.fetch('/backgrounds');
        return data.results || [];
    },

    async getClassLevels(classIndex) {
        const data = await this.fetch(`/classes/${classIndex}/levels`);
        return Array.isArray(data) ? data : (data.results || []);
    },

    async getClassSpells(classIndex) {
        const data = await this.fetch(`/classes/${classIndex}/spells`);
        return data.results || [];
    },

    async getLanguageList() {
        const data = await this.fetch('/languages');
        return data.results || [];
    },

    // ---- Utils ----
    _indexify(name) {
        if (!name) return '';
        return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
    },

    // ---- Conditions ----
    async getConditions() {
        const data = await this.fetch('/conditions');
        return data.results || [];
    },

    async getCondition(index) {
        return await this.fetch(`/conditions/${index}`);
    },

    // ---- Skills ----
    async getSkills() {
        const data = await this.fetch('/skills');
        return data.results || [];
    },

    // ---- Ability Scores ----
    async getAbilityScores() {
        const data = await this.fetch('/ability-scores');
        return data.results || [];
    },

    // ---- Proficiencies ----
    async getProficiencies() {
        const data = await this.fetch('/proficiencies');
        return data.results || [];
    },

    // ---- Traits ----
    async getTraits() {
        const data = await this.fetch('/traits');
        return data.results || [];
    },

    async getTrait(index) {
        return await this.fetch(`/traits/${index}`);
    },

    // ---- Features ----
    async getFeatures() {
        const data = await this.fetch('/features');
        return data.results || [];
    },

    // ---- Languages ----
    async getLanguages() {
        const data = await this.fetch('/languages');
        return data.results || [];
    },

    // ---- Damage Types ----
    async getDamageTypes() {
        const data = await this.fetch('/damage-types');
        return data.results || [];
    },

    // ---- Weapon Properties ----
    async getWeaponProperties() {
        const data = await this.fetch('/weapon-properties');
        return data.results || [];
    },

    // ---- Magic Schools ----
    async getMagicSchools() {
        const data = await this.fetch('/magic-schools');
        return data.results || [];
    },

    // ---- Utility ----
    abilityModifier(score) {
        return Math.floor((score - 10) / 2);
    },

    modifierString(score) {
        const mod = this.abilityModifier(score);
        return mod >= 0 ? `+${mod}` : `${mod}`;
    },

    proficiencyBonus(level) {
        return Math.ceil(level / 4) + 1;
    },

    crToXP(cr) {
        const table = {
            0: 10, 0.125: 25, 0.25: 50, 0.5: 100,
            1: 200, 2: 450, 3: 700, 4: 1100, 5: 1800,
            6: 2300, 7: 2900, 8: 3900, 9: 5000, 10: 5900,
            11: 7200, 12: 8400, 13: 10000, 14: 11500, 15: 13000,
            16: 15000, 17: 18000, 18: 20000, 19: 22000, 20: 25000,
            21: 33000, 22: 41000, 23: 50000, 24: 62000, 25: 75000,
            26: 90000, 27: 105000, 28: 120000, 29: 135000, 30: 155000
        };
        return table[cr] || 0;
    },

    crDisplay(cr) {
        if (cr === 0.125) return '1/8';
        if (cr === 0.25) return '1/4';
        if (cr === 0.5) return '1/2';
        return String(cr);
    },

    // D&D 5e conditions list
    CONDITIONS: [
        'Oslepienie', 'Zauroczenie', 'Gluchota', 'Przerazenie', 'Pochwycenie',
        'Obezwladnienie', 'Niewidzialnosc', 'Paraliz', 'Spetryfikowanie',
        'Zatrucie', 'Lezenie', 'Skrepowanie', 'Ogluszenie', 'Nieprzytomnosc',
        'Zmeczenie', 'Koncentracja'
    ],

    // D&D 5e skills with abilities
    SKILLS: {
        'Akrobatyka': 'DEX', 'Opieka nad zwierzętami': 'WIS', 'Wiedza mistyczna': 'INT',
        'Atletyka': 'STR', 'Oszustwo': 'CHA', 'Historia': 'INT',
        'Wgląd': 'WIS', 'Zastraszanie': 'CHA', 'Śledztwo': 'INT',
        'Medycyna': 'WIS', 'Natura': 'INT', 'Percepcja': 'WIS',
        'Występy': 'CHA', 'Perswazja': 'CHA', 'Religia': 'INT',
        'Zwinne dłonie': 'DEX', 'Skradanie': 'DEX', 'Sztuka przetrwania': 'WIS'
    },

    ABILITY_NAMES: ['STR', 'DEX', 'CON', 'INT', 'WIS', 'CHA'],
    ABILITY_NAMES_PL: ['SIŁ', 'ZRĘ', 'KON', 'INT', 'MĄD', 'CHA'],
    ABILITY_FULL: {
        'STR': 'Strength', 'DEX': 'Dexterity', 'CON': 'Constitution',
        'INT': 'Intelligence', 'WIS': 'Wisdom', 'CHA': 'Charisma'
    },
    ABILITY_FULL_PL: {
        'STR': 'Siła', 'DEX': 'Zręczność', 'CON': 'Kondycja',
        'INT': 'Inteligencja', 'WIS': 'Mądrość', 'CHA': 'Charyzma'
    },

    // Static Translation Dictionaries
    DICT: {
        sizes: {
            'Tiny': 'Malutki', 'Small': 'Mały', 'Medium': 'Średni',
            'Large': 'Duży', 'Huge': 'Ogromny', 'Gargantuan': 'Gigantyczny'
        },
        types: {
            'aberration': 'Aberracja', 'beast': 'Bestia', 'celestial': 'Niebiański',
            'construct': 'Konstrukt', 'dragon': 'Smok', 'elemental': 'Żywiołak',
            'fey': 'Baśniowy', 'fiend': 'Bies', 'giant': 'Gigant',
            'humanoid': 'Humanoid', 'monstrosity': 'Monstrum', 'ooze': 'Szlam',
            'plant': 'Roślina', 'undead': 'Nieumarły', 'swarm': 'Rój'
        },
        schools: {
            'Abjuration': 'Odrzucanie', 'Conjuration': 'Przywoływanie',
            'Divination': 'Poznanie', 'Enchantment': 'Zaczarowania',
            'Evocation': 'Wywoływanie', 'Illusion': 'Iluzje',
            'Necromancy': 'Nekromancja', 'Transmutation': 'Transmutacja'
        },
        categories: {
            'Weapon': 'Broń', 'Armor': 'Pancerz', 'Adventuring Gear': 'Sprzęt',
            'Tool': 'Narzędzie', 'Mount': 'Wierzchowiec', 'Vehicle': 'Pojazd',
            'Trade Good': 'Towar', 'Wondrous Item': 'Cudowny Przedmiot',
            'Potion': 'Mikstura', 'Ring': 'Pierścień', 'Rod': 'Berło',
            'Scroll': 'Zwój', 'Staff': 'Kostur', 'Wand': 'Różdżka', 'Other': 'Inne'
        }
    },

    translateStatic(category, key) {
        if (!key) return '';
        if (this.DICT[category] && this.DICT[category][key]) {
            return this.DICT[category][key];
        }
        return key;
    }
};
