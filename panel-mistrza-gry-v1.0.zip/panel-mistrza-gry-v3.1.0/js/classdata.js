/**
 * ClassData — Centralny rejestr danych klasowych D&D 5e
 * Zawiera: progi XP, kości wytrzymałości, podklasy, zasoby klasowe, atuty, sztuczki/zaklęcia znane
 */
const ClassData = (function () {

    /* =====================================================
       PROGI DOŚWIADCZENIA (XP → Poziom)
       ===================================================== */
    const XP_THRESHOLDS = {
        1: 0, 2: 300, 3: 900, 4: 2700, 5: 6500,
        6: 14000, 7: 23000, 8: 34000, 9: 48000, 10: 64000,
        11: 85000, 12: 100000, 13: 120000, 14: 140000, 15: 165000,
        16: 195000, 17: 225000, 18: 265000, 19: 305000, 20: 355000
    };

    function getLevelForXP(xp) {
        let lvl = 1;
        for (let l = 20; l >= 1; l--) {
            if (xp >= XP_THRESHOLDS[l]) { lvl = l; break; }
        }
        return lvl;
    }

    function getXPForNextLevel(currentLevel) {
        if (currentLevel >= 20) return null;
        return XP_THRESHOLDS[currentLevel + 1];
    }

    /* =====================================================
       KOŚCI WYTRZYMAŁOŚCI per klasa
       ===================================================== */
    const HIT_DIE = {
        barbarian: 12, bard: 8, cleric: 8, druid: 8,
        fighter: 10, monk: 8, paladin: 10, ranger: 10,
        rogue: 8, sorcerer: 6, warlock: 8, wizard: 6
    };

    /* =====================================================
       POZIOM WYBORU PODKLASY per klasa
       ===================================================== */
    const SUBCLASS_LEVEL = {
        barbarian: 3, bard: 3, cleric: 1, druid: 2,
        fighter: 3, monk: 3, paladin: 3, ranger: 3,
        rogue: 3, sorcerer: 1, warlock: 1, wizard: 2
    };

    /* =====================================================
       PODKLASY — Nazwa, opis, cechy per poziom
       ===================================================== */
    const SUBCLASSES = {
        barbarian: [
            {
                key: 'berserker', name: 'Ścieżka Berserka',
                desc: 'Berserk oddaje się czystej furii bitewnej, nie znając strachu ani litości.',
                features: {
                    3: [{ name: 'Szaleństwo', desc: 'Będąc w Szale, możesz wykonać jeden dodatkowy atak bronią białą jako akcję dodatkową. Po zakończeniu Szału otrzymujesz 1 poziom wyczerpania.' }],
                    6: [{ name: 'Bezmyślny Szał', desc: 'Nie możesz być oszołomiony ani przestraszony w Szale. Efekt kończy się razem z Szałem.' }],
                    10: [{ name: 'Zastraszająca Obecność', desc: 'Jako akcję możesz przerazić istotę w promieniu 30 stóp. Cel musi zdać rzut obronny na Mądrość (ST 8 + bonus biegłości + mod. CHA) lub jest przestraszony do końca twojej następnej tury.' }],
                    14: [{ name: 'Odwet', desc: 'Gdy otrzymujesz obrażenia od stworzenia w zasięgu 5 stóp, możesz użyć reakcji, by wykonać atak bronią białą przeciwko niemu.' }]
                }
            },
            {
                key: 'totem-warrior', name: 'Ścieżka Totemicznego Wojownika',
                desc: 'Duchowy przewodnik, zwierzęcy totem, prowadzi wojownika i nadaje mu nadprzyrodzoną moc.',
                features: {
                    3: [{ name: 'Duch Totemu (Niedźwiedź)', desc: 'Będąc w Szale, masz odporność na wszystkie typy obrażeń oprócz psychicznych.' }],
                    6: [{ name: 'Aspekt Bestii', desc: 'Zyskujesz nadprzyrodzoną zdolność opartą na wybranym zwierzęciu totemicznym.' }],
                    10: [{ name: 'Duchowy Wędrowiec', desc: 'Możesz rzucić zaklęcie Rozmowa ze Zwierzętami jako rytuał.' }],
                    14: [{ name: 'Totemiczne Urzeczenie', desc: 'Zyskujesz potężną zdolność końcową swojego totemu.' }]
                }
            }
        ],
        bard: [
            {
                key: 'lore', name: 'Kolegium Wiedzy',
                desc: 'Bardowie Wiedzy gromadzą fragmenty wiedzy ze wszelkich źródeł — od akademickich traktatów po pieśni uliczne.',
                features: {
                    3: [
                        { name: 'Dodatkowe Biegłości', desc: 'Zyskujesz biegłość w 3 dowolnych umiejętnościach.' },
                        { name: 'Cięte Słowa', desc: 'Gdy stworzenie w zasięgu 60 stóp wykonuje rzut na atak, test cechy lub rzut na obrażenia, możesz użyć reakcji i wydać kość Inspiracji Bardowskiej, by odjąć wynik od rzutu stworzenia.' }
                    ],
                    6: [{ name: 'Dodatkowe Tajemnice Magiczne', desc: 'Poznaj 2 zaklęcia z listy dowolnej klasy. Muszą być na poziomie, który możesz rzucać.' }],
                    14: [{ name: 'Niezrównana Umiejętność', desc: 'Gdy wykonujesz test cechy, możesz wydać kość Inspiracji Bardowskiej i dodać ją do wyniku.' }]
                }
            },
            {
                key: 'valor', name: 'Kolegium Waleczności',
                desc: 'Bardowie Waleczności gromadzą się w halach mead, by opiewać czyny wielkich bohaterów — i sami nimi się stać.',
                features: {
                    3: [
                        { name: 'Dodatkowe Biegłości', desc: 'Zyskujesz biegłość w średnich pancerzach, tarczach i broniach wojennych.' },
                        { name: 'Inspiracja Bojowa', desc: 'Stworzenie, które użyje twojej Inspiracji Bardowskiej, może dodać kość do rzutu na obrażenia broni lub do KP.' }
                    ],
                    6: [{ name: 'Dodatkowy Atak', desc: 'Gdy podejmujesz akcję Ataku, możesz zaatakować dwa razy.' }],
                    14: [{ name: 'Wezwanie Bitwy', desc: 'Gdy używasz akcji do rzucenia zaklęcia barda, możesz wykonać jeden atak bronią jako akcję dodatkową.' }]
                }
            }
        ],
        cleric: [
            {
                key: 'life', name: 'Domena Życia',
                desc: 'Domena Życia skupia się na pozytywnej energii — jednej z fundamentalnych sił wszechświata — która podtrzymuje wszelkie życie.',
                features: {
                    1: [
                        { name: 'Dodatkowa Biegłość', desc: 'Zyskujesz biegłość w ciężkich pancerzach.' },
                        { name: 'Uczeń Życia', desc: 'Twoje zaklęcia leczące są potężniejsze. Gdy użyjesz zaklęcia 1. poziomu lub wyższego, by przywrócić punkty wytrzymałości, cel odzyskuje dodatkowe 2 + poziom zaklęcia PW.' }
                    ],
                    2: [{ name: 'Boski Kanał: Zachowanie Życia', desc: 'Jako akcję przywracasz liczbę PW równą 5 × twój poziom kleryka, rozdzielonych dowolnie między stworzenia w promieniu 30 stóp (max do połowy PW celu). Nie działa na nieumarłych i konstrukty.' }],
                    6: [{ name: 'Błogosławiony Uzdrowiciel', desc: 'Zaklęcia leczące 1. poziomu lub wyższe, które rzucasz na inne istoty, leczą też ciebie za 2 + poziom zaklęcia PW.' }],
                    8: [{ name: 'Boski Cios', desc: 'Raz na turę, gdy trafisz atakiem bronią, zadajesz dodatkowe 1k8 obrażeń od energii promieniowania.' }],
                    17: [{ name: 'Najwyższe Leczenie', desc: 'Gdy normalnie rzuciłbyś jedną lub więcej kości, by przywrócić PW zaklęciem, użyj zamiast tego maksymalnej liczby na każdej kości.' }]
                }
            },
            {
                key: 'war', name: 'Domena Wojny',
                desc: 'Bogowie wojny obserwują wojowników i nagradzają wielkie czyny w boju.',
                features: {
                    1: [
                        { name: 'Dodatkowa Biegłość', desc: 'Zyskujesz biegłość w ciężkich pancerzach i broniach wojennych.' },
                        { name: 'Kapłan Wojny', desc: 'Gdy użyjesz akcji Ataku, możesz wykonać jeden atak bronią jako akcję dodatkową (ilość użyć = mod. WIS / długi odpoczynek).' }
                    ],
                    2: [{ name: 'Boski Kanał: Kierowana Uderzenie', desc: 'Gdy wykonujesz rzut na atak, możesz użyć Boskiego Kanału, by uzyskać +10 do rzutu. Decydujesz po zobaczeniu wyniku, ale przed ogłoszeniem trafienia.' }],
                    6: [{ name: 'Boski Kanał: Błogosławieństwo Boga Wojny', desc: 'Gdy istota w promieniu 30 stóp wykonuje rzut na atak, możesz użyć reakcji i Boskiego Kanału, by dać jej +10 do rzutu.' }],
                    8: [{ name: 'Boski Cios', desc: 'Raz na turę, gdy trafisz atakiem bronią, zadajesz dodatkowe 1k8 obrażeń tego samego typu co broń.' }],
                    17: [{ name: 'Awatar Bitwy', desc: 'Zyskujesz odporność na obrażenia od niemagicznych broni obuchowych, kłutych i siecznych.' }]
                }
            },
            {
                key: 'light', name: 'Domena Światła',
                desc: 'Bogowie światła promują ideały odrodzenia, prawdy, czujności i piękna.',
                features: {
                    1: [
                        { name: 'Dodatkowa Sztuczka', desc: 'Zyskujesz sztuczkę Światło (Light), jeśli jej jeszcze nie znasz.' },
                        { name: 'Opiekuńczy Blask', desc: 'Gdy jesteś atakowany, możesz użyć reakcji, by narzucić atakującemu Utrudnienie. Nie wymaga wydania slotu.' }
                    ],
                    2: [{ name: 'Boski Kanał: Promieniowanie Świtu', desc: 'Jako akcję unosisz swój symbol i wypuszczasz falę światła. Każda wroga istota w promieniu 30 stóp musi zdać rzut obronny na Kondycję lub otrzymuje 2k10 + poziom kleryka obrażeń od promieniowania.' }],
                    6: [{ name: 'Udoskonalone Migotanie', desc: 'Możesz dodać modyfikator Mądrości do obrażeń od zaklęć sztuczek z Odrzucania.' }],
                    8: [{ name: 'Silne Zaklęcia', desc: 'Dodajesz modyfikator Mądrości do obrażeń od zaklęć sztuczek z Odrzucania.' }],
                    17: [{ name: 'Korona Światła', desc: 'Możesz użyć akcji, by aktywować aurę światła słonecznego na 1 minutę. Emitujesz jasne światło w promieniu 60 stóp i przyćmione światło dalsze 30 stóp.' }]
                }
            },
            {
                key: 'tempest', name: 'Domena Burzy',
                desc: 'Bogowie, których domeny obejmują burze, trzęsienia ziemi, tornada, często domagają się strachu i szacunku.',
                features: {
                    1: [{ name: 'Biegłość', desc: 'Ciężkie pancerze i bronie wojenne.' }, { name: 'Gniew Burzy', desc: 'Reakcja na atak z 5 stóp: atakujący musi zdać rzut ZR lub otrzymuje 2k8 obrażeń od błyskawic/grzmotu.' }],
                    2: [{ name: 'Boski Kanał: Niszczycielski Gniew', desc: 'Maksymalizujesz obrażenia od błyskawic lub grzmotu.' }],
                    6: [{ name: 'Uderzenie Gromu', desc: 'Obrażenia od błyskawic odpychają wroga o 10 stóp.' }],
                    8: [{ name: 'Boski Cios', desc: 'Raz na turę +1k8 obrażeń od błyskawic/grzmotu.' }],
                    17: [{ name: 'Dziecię Burzy', desc: 'Prędkość latania równa chodzenia na świeżym powietrzu.' }]
                }
            }
        ],
        druid: [
            {
                key: 'land', name: 'Krąg Krainy',
                desc: 'Druidzi Krainy czerpią dodatkową moc z wyjątkowych terenów, na których zostali wtajemniczeni.',
                features: {
                    2: [
                        { name: 'Dodatkowa Sztuczka', desc: 'Poznaj jedną dodatkową sztuczkę druidowską.' },
                        { name: 'Naturalne Odrodzenie', desc: 'Odzyskujesz wydane sloty zaklęć podczas krótkiego odpoczynku. Łączny poziom slotów nie może przekraczać połowy twojego poziomu druida (zaokr. w górę), a żaden slot nie może być 6. poziomu lub wyższy.' }
                    ],
                    3: [{ name: 'Zaklęcia Kręgu', desc: 'Zyskujesz dostęp do zaklęć zależnych od wybranego terenu (Arktyka, Wybrzeże, Pustynia, Las, Łąka, Góry, Bagno, Podziemia).' }],
                    6: [{ name: 'Krok po Krainie', desc: 'Poruszanie się przez niemagiczny trudny teren nie kosztuje cię dodatkowego ruchu.' }],
                    10: [{ name: 'Strażnik Natury', desc: 'Nie możesz być oszołomiony ani przestraszony przez elementale lub fey, i jesteś odporny na trucizny i choroby.' }],
                    14: [{ name: 'Sanktuarium Natury', desc: 'Stworzenia ze świata natury instynktownie wahają się przed atakowaniem ciebie.' }]
                }
            },
            {
                key: 'moon', name: 'Krąg Księżyca',
                desc: 'Druidzi Księżyca to mistrzowie zmiennokształtności, strażnicy dziczy.',
                features: {
                    2: [
                        { name: 'Bojowa Dzika Postać', desc: 'Możesz użyć Dzikiej Postaci jako akcji dodatkowej (zamiast akcji). W Dzikiej Postaci możesz wydać slot zaklęcia, by odzyskać 1k8 PW za poziom slotu.' },
                        { name: 'Formy Kręgu', desc: 'Możesz przekształcić się w bestie o WP do 1 (bez limitu ruchu). Na 6. poziomie WP rośnie do poziomu druida / 3.' }
                    ],
                    6: [{ name: 'Pierwotne Uderzenie', desc: 'Twoje ataki w Dzikiej Postaci liczone są jako magiczne.' }],
                    10: [{ name: 'Żywiołowa Dzika Postać', desc: 'Możesz wydać 2 użycia Dzikiej Postaci, by przekształcić się w żywiołaka (powietrza, ziemi, ognia lub wody).' }],
                    14: [{ name: 'Tysiąc Twarzy', desc: 'Możesz rzucać zaklęcie Zmień Siebie (Alter Self) do woli.' }]
                }
            }
        ],
        fighter: [
            {
                key: 'champion', name: 'Czempion',
                desc: 'Czempion skupia się na surowej, fizycznej doskonałości i śmiertelnych ciosach.',
                features: {
                    3: [{ name: 'Ulepszone Trafienie Krytyczne', desc: 'Twoje ataki bronią trafiają krytycznie na wynik 19 lub 20.' }],
                    7: [{ name: 'Niezwykły Atleta', desc: 'Dodajesz połowę bonusu biegłości (zaokr. w górę) do testów Siły, Zręczności i Kondycji, w których nie masz biegłości. Dystans skoku w dal rośnie o liczbę stóp = mod. Siły.' }],
                    10: [{ name: 'Dodatkowy Styl Walki', desc: 'Wybierz drugi Styl Walki.' }],
                    15: [{ name: 'Doskonałe Trafienie Krytyczne', desc: 'Twoje ataki bronią trafiają krytycznie na wynik 18, 19 lub 20.' }],
                    18: [{ name: 'Ocaleniec', desc: 'Na początku twojej tury, jeśli masz mniej niż połowę PW i nie masz 0 PW, odzyskujesz 5 + mod. Kondycji PW.' }]
                }
            },
            {
                key: 'battle-master', name: 'Mistrz Bitewny',
                desc: 'Mistrzowie Bitewni używają technik bojowych zwanych manewrami, które dają im przewagę w walce.',
                features: {
                    3: [
                        { name: 'Manewry Bojowe', desc: 'Poznaj 3 manewry. Zyskujesz 4 kości wyższości (k8). Kość wyższości służy do zasilania manewrów i odzyskiwana jest po krótkim lub długim odpoczynku.' },
                        { name: 'Ocena Bojowa', desc: 'Możesz poświęcić 1 minutę na obserwację stworzenia, by poznać 2 z następujących: Siłę, Zręczność, Kondycję, KP, aktualne PW, poziomy klas, poziomy wojownika.' }
                    ],
                    7: [{ name: 'Dodatkowe Manewry i Kości', desc: 'Poznaj 2 dodatkowe manewry. Zyskujesz 5. kość wyższości.' }],
                    10: [{ name: 'Ulepszone Manewry', desc: 'Poznaj 2 dodatkowe manewry. Kość wyższości rośnie do k10.' }],
                    15: [{ name: 'Nieustępliwy', desc: 'Gdy nie masz kości wyższości na początku walki, odzyskujesz jedną.' }],
                    18: [{ name: 'Ulepszone Kości', desc: 'Kość wyższości rośnie do k12.' }]
                }
            },
            {
                key: 'eldritch-knight', name: 'Mistyczny Rycerz',
                desc: 'Mistyczny Rycerz łączy mistrzostwo z bronią z podstawową magią ze szkoły Odrzucania i Wywoływania.',
                features: {
                    3: [{ name: 'Rzucanie Zaklęć', desc: 'Zyskujesz możliwość rzucania zaklęć (Inteligencja).' }, { name: 'Więź z Bronią', desc: 'Możesz przywołać broń do ręki z dowolnego miejsca.' }],
                    7: [{ name: 'Magia Bojowa', desc: 'Gdy rzucasz sztuczkę jako akcję, możesz zaatakować bronią jako akcję dodatkową.' }],
                    10: [{ name: 'Uderzenie Mistycznego Rycerza', desc: 'Trafienie wroga narzuca mu Utrudnienie na rzut obronny przeciw twojemu następnemu zaklęciu.' }],
                    15: [{ name: 'Magiczna Szarża', desc: 'Gdy używasz Zrywu Akcji, możesz się teleportować do 30 stóp.' }],
                    18: [{ name: 'Ulepszona Magia Bojowa', desc: 'Gdy rzucasz zaklęcie jako akcję, możesz zaatakować bronią jako akcję dodatkową.' }]
                }
            }
        ],
        monk: [
            {
                key: 'open-hand', name: 'Droga Otwartej Dłoni',
                desc: 'Mistrzowie Otwartej Dłoni to najznakomitsi artyści sztuk walki.',
                features: {
                    3: [{ name: 'Technika Otwartej Dłoni', desc: 'Gdy trafisz Serią Ciosów, możesz narzucić jeden efekt: cel musi zdać rzut ZR lub zostaje powalony; cel musi zdać rzut SI lub jest odepchnięty 15 stóp; cel nie może używać reakcji do końca twojej następnej tury.' }],
                    6: [{ name: 'Pełnia Ciała', desc: 'Zyskujesz zdolność leczenia się. Jako akcję, odzyskujesz PW równe trzykrotności twojego poziomu mnicha. Używasz tego raz na długi odpoczynek.' }],
                    11: [{ name: 'Spokój Umysłu', desc: 'Możesz użyć akcji, by zakończyć na sobie jeden efekt oszołomienia lub przestraszenia.' }],
                    17: [{ name: 'Drżąca Dłoń', desc: 'Gdy trafisz stworzenie Serią Ciosów, możesz ustawić niewidzialne wibracje w jego ciele na liczbę dni = twój poziom mnicha. Jako akcję możesz zakończyć wibracje: cel musi zdać rzut obronny na Kondycję lub spada do 0 PW, a przy sukcesie otrzymuje 10k10 obrażeń od energii nekrotycznej.' }]
                }
            },
            {
                key: 'shadow', name: 'Droga Cienia',
                desc: 'Mnisi Cienia podążają tradycją, która ceni skrycie i podstęp ponad otwartą konfrontację.',
                features: {
                    3: [{ name: 'Sztuki Cienia', desc: 'Możesz wydać 2 punkty Ki, by rzucić Ciemność, Przejście bez Śladu, Cichy Obraz lub Widzenie w Ciemnościach.' }],
                    6: [{ name: 'Krok Cienia', desc: 'Gdy jesteś w przyćmionym świetle lub ciemności, jako akcję dodatkową możesz teleportować się do 60 stóp w miejsce, które widzisz, w przyćmionym świetle lub ciemności. Masz Ułatwienie na pierwszy atak w tej turze.' }],
                    11: [{ name: 'Płaszcz Cieni', desc: 'Możesz stać się niewidzialny w przyćmionym świetle lub ciemności. Niewidzialność kończy się, gdy zaatakujesz lub rzucisz zaklęcie.' }],
                    17: [{ name: 'Mistrz Cieni', desc: 'Możesz użyć reakcji, gdy otrzymujesz obrażenia, by zmniejszyć je o 5 × twój mod. Zręczności i teleportować się do 60 stóp.' }]
                }
            },
            {
                key: 'four-elements', name: 'Droga Czterech Żywiołów',
                desc: 'Uczysz się manipulować żywiołami za pomocą Ki.',
                features: {
                    3: [{ name: 'Uczeń Żywiolów', desc: 'Znasz dyscypliny żywiołów zasilane Ki.' }],
                    6: [{ name: 'Dyscyplina', desc: 'Nowa dyscyplina.' }],
                    11: [{ name: 'Dyscyplina', desc: 'Nowa dyscyplina.' }],
                    17: [{ name: 'Dyscyplina', desc: 'Nowa dyscyplina.' }]
                }
            }
        ],
        paladin: [
            {
                key: 'devotion', name: 'Przysięga Oddania',
                desc: 'Paladyni Oddania trzymają się najwyższych ideałów sprawiedliwości, cnoty i porządku.',
                features: {
                    3: [
                        { name: 'Boski Kanał: Święta Broń', desc: 'Jako akcję nasycasz broń świętą energią na 1 minutę. Broń emituje jasne światło w promieniu 20 stóp. Dodajesz mod. CHA do rzutów na atak. Broń liczy się jako magiczna. Fiends i undead trafieni muszą zdać rzut ZR lub są przestraszone.' },
                        { name: 'Boski Kanał: Odwrócenie Plugastwa', desc: 'Jako akcję, każdy fiend i undead w promieniu 30 stóp musi zdać rzut ZR lub jest odwrócony na 1 minutę.' }
                    ],
                    7: [{ name: 'Aura Oddania', desc: 'Ty i sojusznicy w promieniu 10 stóp nie możecie być oszołomieni (wymaga przytomności). Na 18. poziomie promień rośnie do 30 stóp.' }],
                    15: [{ name: 'Czystość Ducha', desc: 'Jesteś zawsze pod wpływem zaklęcia Ochrona przed Złem i Dobrem.' }],
                    20: [{ name: 'Święta Nimba', desc: 'Jako akcję na 1 minutę emanujesz aurę światła słonecznego. Jasne światło 30 stóp, przyćmione 30 stóp dalej. Na początku tury wroga istota w jasnym świetle otrzymuje 10 obrażeń od promieniowania. Zyskujesz Ułatwienie na rzuty obr. przeciw zaklęciom fiends i undead.' }]
                }
            },
            {
                key: 'vengeance', name: 'Przysięga Zemsty',
                desc: 'Paladyni Zemsty poświęcają się karaniu tych, którzy popełnili śmiertelne grzechy.',
                features: {
                    3: [
                        { name: 'Boski Kanał: Ślub Wrogości', desc: 'Jako akcję dodatkową wskażesz stworzenie w promieniu 10 stóp. Masz Ułatwienie na rzuty na atak przeciwko niemu na 1 minutę.' },
                        { name: 'Boski Kanał: Odpychająca Kara', desc: 'Gdy trafisz atakiem bronią białą, możesz użyć Boskiego Kanału, by zadać dodatkowe 2k8 + poziom paladyna obrażeń. Cel Duży lub mniejszy musi zdać rzut obr. SI lub jest odepchnięty 20 stóp i powalony.' }
                    ],
                    7: [{ name: 'Nieustępliwy Prześladowca', desc: 'Gdy wroga istota w promieniu 30 stóp się teleportuje, możesz użyć reakcji, by teleportować się do 30 stóp od niej.' }],
                    15: [{ name: 'Dusza Zemsty', desc: 'Gdy jesteś sprowadzony do 0 PW i nie giniesz natychmiast, możesz natychmiast użyć reakcji, by wykonać atak bronią lub zaklęcie.' }],
                    20: [{ name: 'Anioł Zemsty', desc: 'Jako akcję na 1 godzinę zyskujesz skrzydła (prędkość latania 60 stóp) i aurę grozy (wrogowie w 30 stópach muszą zdawać rzuty ZR lub są przestraszone).' }]
                }
            },
            {
                key: 'ancients', name: 'Przysięga Starożytnych',
                desc: 'Przysięga tak stara jak elfy czy rytuały druidów.',
                features: {
                    3: [{ name: 'Kanał: Pęta Natury', desc: 'Pnącza oplatają wroga.' }, { name: 'Kanał: Zwrócenie Niewiernych', desc: 'Fey i Fiends uciekają.' }],
                    7: [{ name: 'Aura Ochrony', desc: 'Ty i sojusznicy macie odporność na obrażenia od zaklęć (10 stóp).' }],
                    15: [{ name: 'Nieśmiertelny', desc: 'Kiedy spadasz do 0 PW, spadasz do 1 PW raz na długi odpoczynek. Starzejesz się wolniej.' }],
                    20: [{ name: 'Starszy Czempion', desc: 'Transformacja na 1 minutę (regeneracja 10 PW, zaklęcia jako akcja dodatkowa).' }]
                }
            }
        ],
        ranger: [
            {
                key: 'hunter', name: 'Łowca',
                desc: 'Archetyp Łowcy oznacza akceptację roli jako bulwar między cywilizacją a groźbami ze strony dziczy.',
                features: {
                    3: [{ name: 'Łowiecka Zdobycz', desc: 'Wybierz jeden: Pogromca Hord (+1k8 obrażeń jeśli cel ma pełne PW), Zabójca Olbrzymów (+1k8 obrażeń celom Dużym+), lub Łamacz Kolossów (dodatkowe 1k8 obrażeń raz na turę).' }],
                    7: [{ name: 'Taktyka Obronna', desc: 'Wybierz jeden: Unik w Wieloosobowym Ataku (Utrudnienie na ataki jeśli sojusznik obok), Stalowa Wola (Ułatwienie na rzuty obr. przeciw przestraszeniu), lub Ucieczka przed Hordą (ataki okazyjne mają Utrudnienie przeciw tobie).' }],
                    11: [{ name: 'Wielokrotny Atak', desc: 'Wybierz jeden: Salwa (atakujesz wiele celów w zasięgu 10 stóp), lub Atak Wichrowy (jeśli chybisz, możesz powtórzyć atak na inny cel).' }],
                    15: [{ name: 'Doskonała Obrona', desc: 'Wybierz jeden: Uchylenie (połowa obrażeń na udanym rzucie ZR), Stanie Przeciwko Pływowi (gdy stworzenie chybi cię atakiem, możesz kontratakować jako reakcję), lub Niezwykłe Uniki (nie musisz rzucać, ataki mają Utrudnienie gdy nie widzisz atakującego).' }]
                }
            },
            {
                key: 'beast-master', name: 'Władca Bestii',
                desc: 'Tworzysz unikalną więź ze zwierzęcym towarzyszem.',
                features: {
                    3: [{ name: 'Towarzysz', desc: 'Zyskujesz zwierzęcego towarzysza (max CR 1/4). Dodajesz PB do jego AC, ataku i obrażeń.' }],
                    7: [{ name: 'Wyjątkowy Trening', desc: 'Towarzysz może użyć Dash, Disengage, Dodge jako akcja dodatkowa.' }],
                    11: [{ name: 'Furia Bestii', desc: 'Towarzysz może atakować dwa razy, gdy rozkażesz mu Atak.' }],
                    15: [{ name: 'Współdzielenie Zaklęć', desc: 'Zaklęcia rzucane na ciebie wpływają też na towarzysza w zasięgu 30 stóp.' }]
                }
            }
        ],
        rogue: [
            {
                key: 'thief', name: 'Złodziej',
                desc: 'Doskonalisz umiejętności w sztukach złodziejskich — włamaniach, unikaniu pułapek i otwieraniu zamków.',
                features: {
                    3: [
                        { name: 'Szybkie Dłonie', desc: 'Możesz użyć akcji dodatkowej Chytrego Działania, by wykonać test Zręczności (Zwinne Dłonie), użyć narzędzi złodziejskich, lub użyć akcji Użycie Przedmiotu.' },
                        { name: 'Wspinacz Drugiego Piętra', desc: 'Wspinanie nie kosztuje cię dodatkowego ruchu. Dystans skoku rośnie o liczbę stóp = mod. Zręczności.' }
                    ],
                    9: [{ name: 'Doskonały Bezruch', desc: 'Masz Ułatwienie na testy Zręczności (Skradanie), jeśli poruszyłeś się nie więcej niż połowę swojej prędkości w tej turze.' }],
                    13: [{ name: 'Użyj Magicznego Urządzenia', desc: 'Możesz używać magicznych przedmiotów niezależnie od wymagań klasy, rasy czy poziomu.' }],
                    17: [{ name: 'Złodziejskie Odruchy', desc: 'Możesz wykonać dwie tury podczas pierwszej rundy walki (jedną o normalnej inicjatywie, drugą o inicjatywie minus 10).' }]
                }
            },
            {
                key: 'assassin', name: 'Zabójca',
                desc: 'Skupiasz się na sztuce eliminacji celów z chirurgiczną precyzją.',
                features: {
                    3: [
                        { name: 'Biegłość w Dodatkowych Narzędziach', desc: 'Zyskujesz biegłość w zestawie do charakteryzacji i zestawie trucicielskim.' },
                        { name: 'Zabójstwo', desc: 'Masz Ułatwienie na ataki przeciw istotom, które jeszcze nie działały w walce. Każde trafienie na zaskoczoną istotę to automatyczny trafienie krytyczne.' }
                    ],
                    9: [{ name: 'Mistrz Infiltracji', desc: 'Możesz stworzyć fałszywą tożsamość (7 dni, 25 gp) ze szczegółową historią, wyglądem i zachowaniem.' }],
                    13: [{ name: 'Oszust', desc: 'Zyskujesz zdolność perfekcyjnego naśladowania głosu, pisma i zachowania innej osoby po 3 godzinach obserwacji.' }],
                    17: [{ name: 'Śmiertelny Cios', desc: 'Gdy trafisz zaskoczoną istotę, musi zdać rzut obronny na Kondycję (ST 8 + mod. ZR + bonus biegłości) lub otrzymuje podwójne obrażenia z ataku.' }]
                }
            },
            {
                key: 'arcane-trickster', name: 'Mistyczny Oszust',
                desc: 'Łączysz sztukę iluzji i oczarowania ze złodziejskimi zdolnościami.',
                features: {
                    3: [{ name: 'Rzucanie Zaklęć', desc: 'Zaklęcia (Inteligencja).' }, { name: 'Magiczna Dłoń', desc: 'Niewidzialna dłoń do otwierania zamków i kradzieży na odległość.' }],
                    9: [{ name: 'Zasadzka Magiczna', desc: 'Utrudnienie dla celów na rzuty obronne przeciw zaklęciom, jeśli cel cię nie widzi.' }],
                    13: [{ name: 'Mylący Cień', desc: 'Dłoń daje ci Ułatwienie na ataki przeciw wrogowi.' }],
                    17: [{ name: 'Złodziej Zaklęć', desc: 'Kiedy wróg rzuca zaklęcie, możesz spróbować je ukraść.' }]
                }
            }
        ],
        sorcerer: [
            {
                key: 'draconic', name: 'Smocza Linia Krwi',
                desc: 'Twoja wrodzona magia pochodzi od smoczego przodka, którego krew płynie w twoich żyłach.',
                features: {
                    1: [
                        { name: 'Smocza Odporność', desc: 'Twoje PW maksymalne zwiększają się o 1 za każdy poziom czarodzieja. Zyskujesz naturalną KP = 13 + mod. Zręczności (bez pancerza).' },
                        { name: 'Smocza Linia', desc: 'Wybierz typ smoka przodka, który określa typ obrażeń twojej linii krwi.' }
                    ],
                    6: [{ name: 'Żywiołowe Powinowactwo', desc: 'Gdy rzucasz zaklęcie, które zadaje obrażenia wybranego typu, dodajesz mod. CHA do obrażeń.' }],
                    14: [{ name: 'Skrzydła Smoka', desc: 'Zyskujesz zdolność wyrastania smoczyich skrzydeł (prędkość latania = twoja prędkość chodzenia).' }],
                    18: [{ name: 'Smocza Obecność', desc: 'Jako akcję możesz emanować aurą zachwytu lub strachu na 60 stóp na 1 minutę. Wrogowie muszą zdać rzut ZR lub są oszołomieni/przestraszone.' }]
                }
            },
            {
                key: 'wild-magic', name: 'Dzika Magia',
                desc: 'Twoja magia pochodzi z chaotycznych sił chaosu.',
                features: {
                    1: [{ name: 'Wypływ Dzikiej Magii', desc: 'Mistrz Gry może poprosić o rzut k20 przy rzucaniu zaklęcia 1+ poz. Na 1 wywołujesz efekt Dzikiej Magii.' }, { name: 'Fale Chaosu', desc: 'Ułatwienie na rzut k20.' }],
                    6: [{ name: 'Zagięcie Prawdopodobieństwa', desc: 'Możesz wydać 2 Punkty Sorcery by obniżyć lub podnieść wynik cudzego rzutu k20 o 1k4.' }],
                    14: [{ name: 'Kontrola Chaosu', desc: 'Rzucasz dwa razy w tabeli Dzikiej Magii i wybierasz efekt.' }],
                    18: [{ name: 'Zniszczenie Zaklęcia', desc: 'Zadajesz obrażenia wrogom wokół siebie po wywołaniu Dzikiej Magii.' }]
                }
            }
        ],
        warlock: [
            {
                key: 'fiend', name: 'Patron: Arcydiabł',
                desc: 'Zawarłeś pakt z istotą z niższych planów egzystencji — diabłem lub demonem o kosmicznej mocy.',
                features: {
                    1: [{ name: 'Błogosławieństwo Mrocznego', desc: 'Gdy sprowadzisz wrogą istotę do 0 PW, zyskujesz tymczasowe PW = mod. CHA + twój poziom czarownika (min. 1).' }],
                    6: [{ name: 'Szczęście Mrocznego', desc: 'Gdy wykonujesz test cechy lub rzut obronny, możesz dodać 1k10 do wyniku. Używasz tego po zobaczeniu wyniku, ale przed ogłoszeniem. Raz na krótki lub długi odpoczynek.' }],
                    10: [{ name: 'Piekielna Odporność', desc: 'Wybierz jeden typ obrażeń: zyskujesz odporność na ten typ. Przy krótkim lub długim odpoczynku możesz zmienić typ.' }],
                    14: [{ name: 'Przerzucenie przez Piekło', desc: 'Gdy trafisz stworzenie atakiem, możesz natychmiast przetransportować cel do niższych planów (znika do końca twojej następnej tury, otrzymując 10k10 obrażeń psychicznych przy powrocie). Raz na długi odpoczynek.' }]
                }
            },
            {
                key: 'archfey', name: 'Patron: Arcydworzanin',
                desc: 'Twój patron to lord lub pani ze świata Fey.',
                features: {
                    1: [{ name: 'Fey Obecność', desc: 'Możesz oczarować lub przestraszyć istoty wokół siebie w promieniu 10 stóp.' }],
                    6: [{ name: 'Mglista Ucieczka', desc: 'Po otrzymaniu obrażeń możesz zniknąć i teleportować się na 60 stóp.' }],
                    10: [{ name: 'Czarująca Obrona', desc: 'Odporność na oczarowanie. Odbijanie oczarowania na nadawcę.' }],
                    14: [{ name: 'Mroczne Majaki', desc: 'Wysyłasz wroga do iluzorycznego królestwa na 1 minutę.' }]
                }
            }
        ],
        wizard: [
            {
                key: 'evocation', name: 'Szkoła Odrzucania (Evoker)',
                desc: 'Skupiasz się na zaklęciach, które tworzą potężne efekty żywiołowe.',
                features: {
                    2: [
                        { name: 'Rzeźba Zaklęć', desc: 'Gdy rzucasz zaklęcie odrzucające, które wpływa na inne stworzenia, możesz wybrać liczbę istot = 1 + poziom zaklęcia. Te istoty automatycznie zdają rzuty obr. i nie otrzymują obrażeń (jeśli normalnie otrzymałyby połowę).' },
                        { name: 'Uczony Odrzucania', desc: 'Złoto i czas na skopiowanie zaklęcia odrzucającego do księgi zaklęć to połowa normalnej ceny.' }
                    ],
                    6: [{ name: 'Wzmocniony Żywioł', desc: 'Dodajesz mod. INT do rzutu na obrażenia jednego zaklęcia odrzucającego za rzut.' }],
                    10: [{ name: 'Wzmocniona Sztuczka', desc: 'Dodajesz mod. INT do obrażeń od sztuczek maga.' }],
                    14: [{ name: 'Przesycenie', desc: 'Możesz zwiększyć moc jednego zaklęcia odrzucającego 5. poziomu lub niższego. Cel otrzymuje maksymalne obrażenia (zamiast rzutu kośćmi) od tego zaklęcia.' }]
                }
            },
            {
                key: 'abjuration', name: 'Szkoła Odgradzania (Abjurer)',
                desc: 'Specjalizujesz się w magii ochronnej, odgradzając zło i bannicję wrogów.',
                features: {
                    2: [
                        { name: 'Arcane Ward', desc: 'Gdy rzucasz zaklęcie odgradzające 1. poz. lub wyższe, tworzysz magiczną barierę. Ma PW = 2 × poziom maga + mod. INT. Gdy otrzymujesz obrażenia, bariera traci PW zamiast ciebie.' },
                        { name: 'Uczony Odgradzania', desc: 'Złoto i czas na skopiowanie zaklęcia odgradzającego do księgi zaklęć to połowa normalnej ceny.' }
                    ],
                    6: [{ name: 'Rzucona Bariera', desc: 'Gdy stworzenie w promieniu 30 stóp otrzymuje obrażenia, możesz użyć reakcji, by twoja Arcane Ward absorbowała obrażenia zamiast celu.' }],
                    10: [{ name: 'Ulepszona Odgroda', desc: 'Gdy rzucasz zaklęcie odgradzające, odzyskujesz PW bariery = 2 × poziom zaklęcia.' }],
                    14: [{ name: 'Odporność na Zaklęcia', desc: 'Masz Ułatwienie na rzuty obr. przeciw zaklęciom. Masz odporność na obrażenia od zaklęć.' }]
                }
            },
            {
                key: 'necromancy', name: 'Szkoła Nekromancji',
                desc: 'Odkrywasz sekrety życia, śmierci i nieumarłych.',
                features: {
                    2: [{ name: 'Ponure Żniwa', desc: 'Odzyskujesz PW kiedy zabijasz wroga zaklęciem.' }],
                    6: [{ name: 'Nieumarły Sługa', desc: 'Zyskujesz zaklęcie Ożywienie Trupa. Możesz celować w więcej ciał. Szkielety/Zombie zadają więcej obrażeń.' }],
                    10: [{ name: 'Przyzwyczajenie do Śmierci', desc: 'Odporność na obrażenia nekrotyczne, maksymalne PW nie mogą być obniżone.' }],
                    14: [{ name: 'Kontrola nad Nieumarłym', desc: 'Przejmowanie kontroli nad cudzymi nieumarłymi.' }]
                }
            }
        ]
    };

    /* =====================================================
       ZASOBY KLASOWE per klasa per poziom
       Struktura: className -> Array of { name, namePL, key, getMax(level, char) }
       ===================================================== */
    const CLASS_RESOURCES = {
        barbarian: [
            {
                key: 'rage', namePL: 'Szał', icon: '🔥',
                getMax: (lvl) => lvl >= 20 ? 999 : lvl >= 17 ? 6 : lvl >= 12 ? 5 : lvl >= 6 ? 4 : lvl >= 3 ? 3 : 2,
                unlockLevel: 1, restType: 'long',
                extra: (lvl) => ({ rageDamage: lvl >= 16 ? 4 : lvl >= 9 ? 3 : 2 })
            },
            {
                key: 'rageDamage', namePL: 'Bonus Obrażeń Szału', icon: '⚔️',
                getMax: (lvl) => lvl >= 16 ? 4 : lvl >= 9 ? 3 : 2,
                unlockLevel: 1, restType: 'none', isPassive: true
            }
        ],
        bard: [
            {
                key: 'bardicInspiration', namePL: 'Inspiracja Bardowska', icon: '🎵',
                getMax: (lvl, char) => Math.max(1, Math.floor(((char?.abilityScores?.cha || 10) - 10) / 2)),
                unlockLevel: 1, restType: (lvl) => lvl >= 5 ? 'short' : 'long',   // od 5. poz. Źródło inspiracji
                extra: (lvl) => ({ dieName: lvl >= 15 ? 'k12' : lvl >= 10 ? 'k10' : lvl >= 5 ? 'k8' : 'k6' })
            },
            {
                key: 'songOfRest', namePL: 'Pieśń Odpoczynku', icon: '🎶',
                getMax: (lvl) => lvl >= 17 ? 12 : lvl >= 13 ? 10 : lvl >= 9 ? 8 : 6,
                unlockLevel: 2, restType: 'none', isPassive: true, suffix: (lvl) => `k${lvl >= 17 ? 12 : lvl >= 13 ? 10 : lvl >= 9 ? 8 : 6}`
            }
        ],
        cleric: [
            {
                key: 'channelDivinity', namePL: 'Boski Kanał', icon: '✝️',
                getMax: (lvl) => lvl >= 18 ? 3 : lvl >= 6 ? 2 : 1,
                unlockLevel: 2, restType: 'short'
            }
        ],
        druid: [
            {
                key: 'wildShape', namePL: 'Dzika Postać', icon: '🐻',
                getMax: () => 2,
                unlockLevel: 2, restType: 'short',
                extra: (lvl) => ({ maxCR: lvl >= 8 ? 1 : lvl >= 4 ? 0.5 : 0.25 })
            }
        ],
        fighter: [
            {
                key: 'secondWind', namePL: 'Drugi Oddech', icon: '💨',
                getMax: () => 1,
                unlockLevel: 1, restType: 'short'
            },
            {
                key: 'actionSurge', namePL: 'Zryw Akcji', icon: '⚡',
                getMax: (lvl) => lvl >= 17 ? 2 : 1,
                unlockLevel: 2, restType: 'short'
            },
            {
                key: 'indomitable', namePL: 'Niezłomność', icon: '🛡️',
                getMax: (lvl) => lvl >= 17 ? 3 : lvl >= 13 ? 2 : 1,
                unlockLevel: 9, restType: 'long'
            }
        ],
        monk: [
            {
                key: 'ki', namePL: 'Punkty Ki', icon: '☯️',
                getMax: (lvl) => lvl,
                unlockLevel: 2, restType: 'short'
            },
            {
                key: 'martialArts', namePL: 'Sztuki Walki', icon: '👊',
                getMax: (lvl) => lvl >= 17 ? 10 : lvl >= 11 ? 8 : lvl >= 5 ? 6 : 4,
                unlockLevel: 1, restType: 'none', isPassive: true, suffix: (lvl) => `k${lvl >= 17 ? 10 : lvl >= 11 ? 8 : lvl >= 5 ? 6 : 4}`
            },
            {
                key: 'unarmoredMovement', namePL: 'Ruch bez Pancerza', icon: '🏃',
                getMax: (lvl) => lvl >= 18 ? 30 : lvl >= 14 ? 25 : lvl >= 10 ? 20 : lvl >= 6 ? 15 : lvl >= 2 ? 10 : 0,
                unlockLevel: 2, restType: 'none', isPassive: true, suffix: () => 'stóp'
            }
        ],
        paladin: [
            {
                key: 'layOnHands', namePL: 'Nałożenie Rąk', icon: '🤲',
                getMax: (lvl) => lvl * 5,
                unlockLevel: 1, restType: 'long'
            },
            {
                key: 'divineSense', namePL: 'Boskie Zmysły', icon: '👁️',
                getMax: (lvl, char) => 1 + Math.max(0, Math.floor(((char?.abilityScores?.cha || 10) - 10) / 2)),
                unlockLevel: 1, restType: 'long'
            },
            {
                key: 'channelDivinity', namePL: 'Boski Kanał', icon: '✝️',
                getMax: () => 1,
                unlockLevel: 3, restType: 'short'
            }
        ],
        ranger: [
            {
                key: 'favoredEnemies', namePL: 'Ulubieni Wrogowie', icon: '🎯',
                getMax: (lvl) => lvl >= 14 ? 3 : lvl >= 6 ? 2 : 1,
                unlockLevel: 1, restType: 'none', isPassive: true
            },
            {
                key: 'naturalExplorer', namePL: 'Naturalny Odkrywca', icon: '🌲',
                getMax: (lvl) => lvl >= 10 ? 3 : lvl >= 6 ? 2 : 1,
                unlockLevel: 1, restType: 'none', isPassive: true
            }
        ],
        rogue: [
            {
                key: 'sneakAttack', namePL: 'Podstępny Atak', icon: '🗡️',
                getMax: (lvl) => Math.ceil(lvl / 2),
                unlockLevel: 1, restType: 'none', isPassive: true, suffix: () => 'k6'
            }
        ],
        sorcerer: [
            {
                key: 'sorceryPoints', namePL: 'Punkty Czarów', icon: '✨',
                getMax: (lvl) => lvl,
                unlockLevel: 2, restType: 'long'
            }
        ],
        warlock: [
            {
                key: 'pactSlots', namePL: 'Sloty Paktu', icon: '🌙',
                getMax: (lvl) => lvl >= 17 ? 4 : lvl >= 11 ? 3 : lvl >= 2 ? 2 : 1,
                unlockLevel: 1, restType: 'short',
                extra: (lvl) => ({ slotLevel: Math.min(5, Math.ceil(lvl / 2)) })
            },
            {
                key: 'invocations', namePL: 'Inwokacje', icon: '📜',
                getMax: (lvl) => lvl >= 18 ? 8 : lvl >= 15 ? 7 : lvl >= 12 ? 6 : lvl >= 9 ? 5 : lvl >= 7 ? 4 : lvl >= 5 ? 3 : 2,
                unlockLevel: 2, restType: 'none', isPassive: true
            }
        ],
        wizard: [
            {
                key: 'arcaneRecovery', namePL: 'Odzyskiwanie Czarów', icon: '📖',
                getMax: (lvl) => Math.ceil(lvl / 2),
                unlockLevel: 1, restType: 'long', suffix: () => 'poz. slotów'
            }
        ]
    };

    /* =====================================================
       DODATKOWY ATAK
       ===================================================== */
    const EXTRA_ATTACK = {
        barbarian: [5],
        bard: [],  // Kolegium Waleczności daje na 6
        cleric: [],
        druid: [],
        fighter: [5, 11, 20],  // 2 ataki na 5, 3 na 11, 4 na 20
        monk: [5],
        paladin: [5],
        ranger: [5],
        rogue: [],
        sorcerer: [],
        warlock: [],  // Pact of the Blade na 5 via inwokację
        wizard: []
    };

    /* =====================================================
       SZTUCZKI ZNANE per klasa per poziom
       ===================================================== */
    const CANTRIPS_KNOWN = {
        bard:     { 1:2, 4:3, 10:4 },
        cleric:   { 1:3, 4:4, 10:5 },
        druid:    { 1:2, 4:3, 10:4 },
        sorcerer: { 1:4, 4:5, 10:6 },
        warlock:  { 1:2, 4:3, 10:4 },
        wizard:   { 1:3, 4:4, 10:5 }
    };

    function getCantripsKnown(className, level) {
        const table = CANTRIPS_KNOWN[className];
        if (!table) return 0;
        let known = 0;
        for (const [lvl, count] of Object.entries(table)) {
            if (level >= parseInt(lvl)) known = count;
        }
        return known;
    }

    /* =====================================================
       ZAKLĘCIA ZNANE per klasa per poziom
       (Tylko dla klas ze "spells known" — Bard, Ranger, Sorcerer, Warlock)
       ===================================================== */
    const SPELLS_KNOWN = {
        bard:     { 1:4, 2:5, 3:6, 4:7, 5:8, 6:9, 7:10, 8:11, 9:12, 10:14, 11:15, 13:16, 14:18, 15:19, 17:20, 18:22 },
        ranger:   { 2:2, 3:3, 5:4, 7:5, 9:6, 11:7, 13:8, 15:9, 17:10, 19:11 },
        sorcerer: { 1:2, 2:3, 3:4, 4:5, 5:6, 6:7, 7:8, 8:9, 9:10, 10:11, 11:12, 13:13, 15:14, 17:15 },
        warlock:  { 1:2, 2:3, 3:4, 4:5, 5:6, 6:7, 7:8, 8:9, 9:10, 11:11, 13:12, 15:13, 17:14, 19:15 }
    };

    function getSpellsKnown(className, level) {
        const table = SPELLS_KNOWN[className];
        if (!table) return null; // Klasa przygotowuje zaklęcia, nie "zna"
        let known = 0;
        for (const [lvl, count] of Object.entries(table)) {
            if (level >= parseInt(lvl)) known = count;
        }
        return known;
    }

    /* =====================================================
       ATUTY (FEATS) — SRD + popularne
       ===================================================== */
    const FEATS = [
        {
            key: 'alert', name: 'Czujny (Alert)',
            desc: '+5 do inicjatywy. Nie możesz być zaskoczony gdy jesteś przytomny. Ukryte stworzenia nie mają Ułatwienia na ataki przeciwko tobie.',
            effects: { initiativeBonus: 5 }
        },
        {
            key: 'athlete', name: 'Atleta (Athlete)',
            desc: '+1 do Siły lub Zręczności. Wstawanie z pozycji leżącej kosztuje 5 stóp ruchu. Wspinanie nie spowalnia. Skok z biegu wymaga tylko 5 stóp rozbiegu.',
            effects: { abilityChoice: ['str', 'dex'], abilityBonus: 1 }
        },
        {
            key: 'durable', name: 'Wytrzymały (Durable)',
            desc: '+1 do Kondycji. Gdy rzucasz Kość Wytrzymałości na leczenie, minimalna wartość = 2 × mod. Kondycji.',
            effects: { abilityIncrease: { con: 1 } }
        },
        {
            key: 'grappler', name: 'Zapaśnik (Grappler)',
            desc: 'Masz Ułatwienie na ataki przeciw stworzeniom, które chwyciłeś. Możesz użyć akcji, by unieruchomić chwyconego (oba stworzenia są unieruchomione).',
            prerequisite: 'Siła 13+',
            effects: {}
        },
        {
            key: 'great-weapon-master', name: 'Mistrz Wielkiej Broni',
            desc: 'Przy krytycznym trafieniu lub powaleniu wroga do 0 PW, możesz wykonać dodatkowy atak bronią jako akcję dodatkową. Przed atakiem bronią ciężką możesz przyjąć -5 do ataku za +10 do obrażeń.',
            effects: {}
        },
        {
            key: 'healer', name: 'Uzdrowiciel (Healer)',
            desc: 'Używając zestawu medyka, możesz przywrócić istotie 1k6 + 4 + jej max HD PW. Raz per istotę na krótki/długi odpoczynek. Stabilizacja przywraca 1 PW.',
            effects: {}
        },
        {
            key: 'heavily-armored', name: 'Ciężko Opancerzony',
            desc: '+1 do Siły. Zyskujesz biegłość w ciężkich pancerzach.',
            prerequisite: 'Biegłość w średnich pancerzach',
            effects: { abilityIncrease: { str: 1 } }
        },
        {
            key: 'inspiring-leader', name: 'Inspirujący Przywódca',
            desc: 'Po 10 minutach przemowy, do 6 przyjaznych istot (w tym ty) zyskuje tymczasowe PW = twój poziom + mod. CHA.',
            prerequisite: 'Charyzma 13+',
            effects: {}
        },
        {
            key: 'lucky', name: 'Szczęściarz (Lucky)',
            desc: 'Masz 3 punkty szczęścia. Gdy wykonujesz rzut na atak, test cechy lub rzut obronny, możesz wydać punkt, by rzucić dodatkową k20 i wybrać którą użyć. Możesz też wydać punkt, gdy jesteś atakowany. Punkty odnawiają się po długim odpoczynku.',
            effects: { luckyPoints: 3 }
        },
        {
            key: 'mage-slayer', name: 'Pogromca Magów',
            desc: 'Gdy stworzenie w zasięgu 5 stóp rzuca zaklęcie, możesz użyć reakcji, by je zaatakować. Gdy zranisz rzucającego, ma Utrudnienie na koncentrację. Masz Ułatwienie na rzuty obr. przeciw zaklęciom z zasięgu 5 stóp.',
            effects: {}
        },
        {
            key: 'mobile', name: 'Ruchliwy (Mobile)',
            desc: '+10 stóp prędkości. Gdy używasz akcji Biegu (Dash), trudny teren nie spowalnia. Gdy atakujesz stworzenie, nie prowokuje ono ataku okazyjnego od ciebie do końca tury (niezależnie od trafienia).',
            effects: { speedBonus: 10 }
        },
        {
            key: 'observant', name: 'Spostrzegawczy (Observant)',
            desc: '+1 do Inteligencji lub Mądrości. +5 do pasywnej Percepcji i pasywnego Dochodzenia. Potrafisz czytać z ruchu warg.',
            effects: { abilityChoice: ['int', 'wis'], abilityBonus: 1 }
        },
        {
            key: 'resilient', name: 'Odporny (Resilient)',
            desc: '+1 do wybranej cechy. Zyskujesz biegłość w rzutach obronnych tej cechy.',
            effects: { abilityChoiceAny: true, abilityBonus: 1, savingThrowProficiency: true }
        },
        {
            key: 'sentinel', name: 'Strażnik (Sentinel)',
            desc: 'Gdy trafisz atakiem okazyjnym, prędkość celu spada do 0 na resztę tury. Stworzenia prowokują u ciebie atak okazyjny, nawet jeśli użyły Odłączenia. Gdy stworzenie w zasięgu 5 stóp atakuje inny cel niż ty, możesz użyć reakcji, by je zaatakować.',
            effects: {}
        },
        {
            key: 'sharpshooter', name: 'Ostry Strzelec (Sharpshooter)',
            desc: 'Ataki bronią dystansową ignorują połowę i trzy czwarte osłony. Daleki zasięg broni dystansowej nie narzuca Utrudnienia. Przed atakiem bronią dystansową możesz przyjąć -5 do ataku za +10 do obrażeń.',
            effects: {}
        },
        {
            key: 'shield-master', name: 'Mistrz Tarczy',
            desc: 'Po ataku możesz użyć akcji dodatkowej, by odepchnąć stworzenie tarczą. Możesz dodać bonus KP z tarczy do rzutów obr. na ZR przeciw efektom celującym tylko w ciebie. Jeśli zdasz rzut ZR na połowę obrażeń, możesz użyć reakcji, by nie otrzymać żadnych.',
            effects: {}
        },
        {
            key: 'tough', name: 'Twardziel (Tough)',
            desc: 'Twoje PW maksymalne zwiększają się o 2 za każdy posiadany poziom.',
            effects: { hpPerLevel: 2 }
        },
        {
            key: 'war-caster', name: 'Wojenny Mag (War Caster)',
            desc: 'Masz Ułatwienie na rzuty na Kondycję dla utrzymania Koncentracji. Możesz wykonywać gesty somatyczne zaklęć, mając broń lub tarczę w rękach. Jako atak okazyjny możesz rzucić zaklęcie (zamiast ataku bronią).',
            prerequisite: 'Zdolność rzucania zaklęć',
            effects: {}
        }
    ];

    /* =====================================================
       ZDOLNOŚCI AUTOMATYCZNE per klasa per poziom
       (cechy, które nie są w API ale są kluczowe)
       ===================================================== */
    const AUTO_FEATURES = {
        barbarian: {
            1: ['Szał', 'Obrona bez Pancerza (Barbarzyńca)'],
            2: ['Bezmyślny Atak', 'Wyczucie Zagrożenia'],
            3: ['Ścieżka Pierwotna'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Dodatkowy Atak', 'Szybki Ruch (+10 stóp)'],
            6: ['Cecha Ścieżki'],
            7: ['Zwierzęcy Instynkt'],
            8: ['Zwiększenie Wartości Cechy'],
            9: ['Brutalny Krytyk (1 dodatkowa kość)'],
            10: ['Cecha Ścieżki'],
            11: ['Nieustanny Szał'],
            12: ['Zwiększenie Wartości Cechy'],
            13: ['Brutalny Krytyk (2 dodatkowe kości)'],
            14: ['Cecha Ścieżki'],
            15: ['Uporczywy Szał'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Brutalny Krytyk (3 dodatkowe kości)'],
            18: ['Nieugięta Moc'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Pierwotny Czempion (+4 SI, +4 KON)']
        },
        bard: {
            1: ['Rzucanie Zaklęć', 'Inspiracja Bardowska (k6)'],
            2: ['Wszechstronność', 'Pieśń Odpoczynku (k6)'],
            3: ['Kolegium Bardów', 'Ekspertyza'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Inspiracja Bardowska (k8)', 'Źródło Inspiracji'],
            6: ['Kontrugrok', 'Cecha Kolegium'],
            8: ['Zwiększenie Wartości Cechy'],
            9: ['Pieśń Odpoczynku (k8)'],
            10: ['Inspiracja Bardowska (k10)', 'Ekspertyza', 'Tajemnice Magiczne'],
            12: ['Zwiększenie Wartości Cechy'],
            13: ['Pieśń Odpoczynku (k10)'],
            14: ['Tajemnice Magiczne', 'Cecha Kolegium'],
            15: ['Inspiracja Bardowska (k12)'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Pieśń Odpoczynku (k12)'],
            18: ['Tajemnice Magiczne'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Najwyższa Inspiracja']
        },
        cleric: {
            1: ['Rzucanie Zaklęć', 'Boska Domena'],
            2: ['Boski Kanał (1/odpoczynek)', 'Cecha Domeny'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Zniszczenie Nieumarłych (CR 1/2)'],
            6: ['Boski Kanał (2/odpoczynek)', 'Cecha Domeny'],
            8: ['Zwiększenie Wartości Cechy', 'Zniszczenie Nieumarłych (CR 1)', 'Cecha Domeny'],
            10: ['Boska Interwencja'],
            11: ['Zniszczenie Nieumarłych (CR 2)'],
            12: ['Zwiększenie Wartości Cechy'],
            14: ['Zniszczenie Nieumarłych (CR 3)'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Zniszczenie Nieumarłych (CR 4)', 'Cecha Domeny'],
            18: ['Boski Kanał (3/odpoczynek)'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Ulepszona Boska Interwencja']
        },
        druid: {
            1: ['Język Druidów', 'Rzucanie Zaklęć'],
            2: ['Dzika Postać', 'Krąg Druidów'],
            4: ['Ulepszenie Dzikiej Postaci', 'Zwiększenie Wartości Cechy'],
            6: ['Cecha Kręgu'],
            8: ['Ulepszenie Dzikiej Postaci', 'Zwiększenie Wartości Cechy'],
            10: ['Cecha Kręgu'],
            12: ['Zwiększenie Wartości Cechy'],
            14: ['Cecha Kręgu'],
            16: ['Zwiększenie Wartości Cechy'],
            18: ['Ponadczasowe Ciało', 'Zaklęcia Bestii'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Arcydruid']
        },
        fighter: {
            1: ['Styl Walki', 'Drugi Oddech'],
            2: ['Zryw Akcji (1 użycie)'],
            3: ['Archetyp Bojowy'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Dodatkowy Atak (2 ataki)'],
            6: ['Zwiększenie Wartości Cechy'],
            7: ['Cecha Archetypu'],
            8: ['Zwiększenie Wartości Cechy'],
            9: ['Niezłomność (1 użycie)'],
            10: ['Cecha Archetypu'],
            11: ['Dodatkowy Atak (3 ataki)'],
            12: ['Zwiększenie Wartości Cechy'],
            13: ['Niezłomność (2 użycia)'],
            14: ['Zwiększenie Wartości Cechy'],
            15: ['Cecha Archetypu'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Zryw Akcji (2 użycia)', 'Niezłomność (3 użycia)'],
            18: ['Cecha Archetypu'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Dodatkowy Atak (4 ataki)']
        },
        monk: {
            1: ['Obrona bez Pancerza (Mnich)', 'Sztuki Walki'],
            2: ['Ki', 'Ruch bez Pancerza (+10 stóp)'],
            3: ['Odbijanie Pocisków', 'Tradycja Klasztorna'],
            4: ['Powolne Spadanie', 'Zwiększenie Wartości Cechy'],
            5: ['Dodatkowy Atak', 'Ogłuszające Uderzenie'],
            6: ['Uderzenia Ki są Magiczne', 'Ruch +15 stóp', 'Cecha Tradycji'],
            7: ['Spokój Umysłu', 'Pustka Umysłu'],
            8: ['Zwiększenie Wartości Cechy'],
            9: ['Ruch po Ścianach'],
            10: ['Czystość Ciała', 'Ruch +20 stóp'],
            11: ['Cecha Tradycji'],
            12: ['Zwiększenie Wartości Cechy'],
            13: ['Język Słońca i Księżyca'],
            14: ['Diamentowa Dusza', 'Ruch +25 stóp'],
            15: ['Wieczna Młodość'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Cecha Tradycji'],
            18: ['Puste Ciało', 'Ruch +30 stóp'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Idealne Ja']
        },
        paladin: {
            1: ['Boskie Zmysły', 'Nałożenie Rąk'],
            2: ['Styl Walki', 'Rzucanie Zaklęć', 'Boski Cios'],
            3: ['Boskie Zdrowie', 'Święta Przysięga'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Dodatkowy Atak'],
            6: ['Aura Ochrony'],
            7: ['Cecha Przysięgi'],
            8: ['Zwiększenie Wartości Cechy'],
            10: ['Aura Odwagi'],
            11: ['Ulepszony Boski Cios'],
            12: ['Zwiększenie Wartości Cechy'],
            14: ['Oczyszczający Dotyk'],
            15: ['Cecha Przysięgi'],
            16: ['Zwiększenie Wartości Cechy'],
            18: ['Rozszerzenie Aur (30 stóp)'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Cecha Przysięgi']
        },
        ranger: {
            1: ['Ulubiony Wróg', 'Naturalny Odkrywca'],
            2: ['Styl Walki', 'Rzucanie Zaklęć'],
            3: ['Archetyp Łowcy', 'Pierwotna Świadomość'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Dodatkowy Atak'],
            6: ['Ulepszony Ulubiony Wróg', 'Ulepszony Naturalny Odkrywca'],
            7: ['Cecha Archetypu'],
            8: ['Zwiększenie Wartości Cechy', 'Krok Natury'],
            10: ['Ulepszony Naturalny Odkrywca', 'Ukrycie na Widoku'],
            11: ['Cecha Archetypu'],
            12: ['Zwiększenie Wartości Cechy'],
            14: ['Ulepszony Ulubiony Wróg', 'Zniknięcie'],
            15: ['Cecha Archetypu'],
            16: ['Zwiększenie Wartości Cechy'],
            18: ['Dzikie Zmysły'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Pogromca Wrogów']
        },
        rogue: {
            1: ['Ekspertyza (2 umiejętności)', 'Podstępny Atak (1k6)', 'Żargon Złodziei'],
            2: ['Chytre Działanie'],
            3: ['Archetyp Łotra', 'Podstępny Atak (2k6)'],
            4: ['Zwiększenie Wartości Cechy'],
            5: ['Niezwykłe Uniki', 'Podstępny Atak (3k6)'],
            6: ['Ekspertyza (2 dodatkowe)'],
            7: ['Uchylenie', 'Podstępny Atak (4k6)'],
            8: ['Zwiększenie Wartości Cechy'],
            9: ['Cecha Archetypu', 'Podstępny Atak (5k6)'],
            10: ['Zwiększenie Wartości Cechy'],
            11: ['Niezawodny Talent', 'Podstępny Atak (6k6)'],
            12: ['Zwiększenie Wartości Cechy'],
            13: ['Cecha Archetypu', 'Podstępny Atak (7k6)'],
            14: ['Zmysł Niewidzialności'],
            15: ['Śliski Umysł', 'Podstępny Atak (8k6)'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Cecha Archetypu', 'Podstępny Atak (9k6)'],
            18: ['Nieuchwytny'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Cios Szczęścia', 'Podstępny Atak (10k6)']
        },
        sorcerer: {
            1: ['Rzucanie Zaklęć', 'Magiczne Pochodzenie'],
            2: ['Źródło Magii'],
            3: ['Metamagia'],
            4: ['Zwiększenie Wartości Cechy'],
            6: ['Cecha Pochodzenia'],
            8: ['Zwiększenie Wartości Cechy'],
            10: ['Metamagia'],
            12: ['Zwiększenie Wartości Cechy'],
            14: ['Cecha Pochodzenia'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Metamagia'],
            18: ['Cecha Pochodzenia'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Magiczna Odnowa']
        },
        warlock: {
            1: ['Pakt z Nieziemskim Patronem', 'Magia Paktu'],
            2: ['Inwokacje'],
            3: ['Dar Paktu'],
            4: ['Zwiększenie Wartości Cechy'],
            6: ['Cecha Patrona'],
            8: ['Zwiększenie Wartości Cechy'],
            10: ['Cecha Patrona'],
            11: ['Mistyczne Arcanum (6 poziom)'],
            12: ['Zwiększenie Wartości Cechy'],
            13: ['Mistyczne Arcanum (7 poziom)'],
            14: ['Cecha Patrona'],
            15: ['Mistyczne Arcanum (8 poziom)'],
            16: ['Zwiększenie Wartości Cechy'],
            17: ['Mistyczne Arcanum (9 poziom)'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Mistyczny Mistrz']
        },
        wizard: {
            1: ['Rzucanie Zaklęć', 'Tajemna Odnowa'],
            2: ['Tradycja Magiczna'],
            4: ['Zwiększenie Wartości Cechy'],
            6: ['Cecha Tradycji'],
            8: ['Zwiększenie Wartości Cechy'],
            10: ['Cecha Tradycji'],
            12: ['Zwiększenie Wartości Cechy'],
            14: ['Cecha Tradycji'],
            16: ['Zwiększenie Wartości Cechy'],
            18: ['Mistrzostwo w Zaklęciach'],
            19: ['Zwiększenie Wartości Cechy'],
            20: ['Zaklęcia Charakterystyczne']
        }
    };

    /* =====================================================
       HELPER: Zwraca zasoby klasowe na danym poziomie
       ===================================================== */
    function getResourcesForLevel(className, level, char) {
        const classKey = className.toLowerCase();
        const resources = CLASS_RESOURCES[classKey];
        if (!resources) return [];
        return resources
            .filter(r => level >= r.unlockLevel)
            .map(r => ({
                key: r.key,
                namePL: r.namePL,
                icon: r.icon,
                max: r.getMax(level, char),
                isPassive: r.isPassive || false,
                restType: r.restType,
                suffix: r.suffix ? r.suffix(level) : null,
                extra: r.extra ? r.extra(level) : null
            }));
    }

    /* =====================================================
       HELPER: Zwraca podklasy dla klasy
       ===================================================== */
    function getSubclassesForClass(className) {
        return SUBCLASSES[className.toLowerCase()] || [];
    }

    function getSubclassFeatures(className, subclassKey, level) {
        const subclasses = SUBCLASSES[className.toLowerCase()];
        if (!subclasses) return [];
        const sub = subclasses.find(s => s.key === subclassKey);
        if (!sub) return [];
        let features = [];
        for (const [lvl, feats] of Object.entries(sub.features)) {
            if (parseInt(lvl) <= level) {
                features = features.concat(feats);
            }
        }
        return features;
    }

    function getNewSubclassFeatures(className, subclassKey, level) {
        const subclasses = SUBCLASSES[className.toLowerCase()];
        if (!subclasses) return [];
        const sub = subclasses.find(s => s.key === subclassKey);
        if (!sub || !sub.features[level]) return [];
        return sub.features[level];
    }

    /* =====================================================
       HELPER: Sprawdza czy na danym poziomie jest ASI
       ===================================================== */
    function isASILevel(className, level) {
        // Standardowe ASI: 4, 8, 12, 16, 19
        // Fighter: dodatkowe na 6, 14
        // Rogue: dodatkowe na 10
        const base = [4, 8, 12, 16, 19];
        const classKey = className.toLowerCase();
        if (classKey === 'fighter') return [...base, 6, 14].includes(level);
        if (classKey === 'rogue') return [...base, 10].includes(level);
        return base.includes(level);
    }

    /* =====================================================
       HELPER: Sprawdza czy na danym poziomie jest wybór podklasy
       ===================================================== */
    function isSubclassLevel(className, level) {
        const classKey = className.toLowerCase();
        return SUBCLASS_LEVEL[classKey] === level;
    }

    /* =====================================================
       PUBLIC API
       ===================================================== */
    return {
        XP_THRESHOLDS,
        HIT_DIE,
        SUBCLASS_LEVEL,
        SUBCLASSES,
        CLASS_RESOURCES,
        EXTRA_ATTACK,
        CANTRIPS_KNOWN,
        SPELLS_KNOWN,
        FEATS,
        AUTO_FEATURES,

        getLevelForXP,
        getXPForNextLevel,
        getCantripsKnown,
        getSpellsKnown,
        getResourcesForLevel,
        getSubclassesForClass,
        getSubclassFeatures,
        getNewSubclassFeatures,
        isASILevel,
        isSubclassLevel
    };
})();

window.ClassData = ClassData;
