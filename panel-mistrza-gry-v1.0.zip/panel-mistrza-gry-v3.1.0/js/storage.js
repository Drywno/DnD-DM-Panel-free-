/* ============================================
   D&D 5e DM Panel — LocalStorage Manager
   ============================================ */

const StorageManager = {
    PREFIX: 'dnd5e_dm_',

    // ---- Generic CRUD ----
    get(key) {
        try {
            const raw = localStorage.getItem(this.PREFIX + key);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            console.error('StorageManager.get error:', key, e);
            return null;
        }
    },

    set(key, value) {
        const raw = JSON.stringify(value);
        try {
            localStorage.setItem(this.PREFIX + key, raw);
        } catch (e) {
            // Storage full: drop the re-downloadable SRD cache first, then retry once.
            if (this._isQuotaError(e) && this.clearSRDCache() > 0) {
                try {
                    localStorage.setItem(this.PREFIX + key, raw);
                } catch (e2) {
                    this._reportStorageError(key, e2);
                    return;
                }
            } else {
                this._reportStorageError(key, e);
                return;
            }
        }
        this.syncToServer(key);
    },

    _isQuotaError(e) {
        return e && (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED' || e.code === 22 || e.code === 1014);
    },

    _reportStorageError(key, e) {
        console.error('StorageManager.set error:', key, e);
        if (key.startsWith('srd_cache_')) return; // cache is optional, stay silent
        if (window.App && App.showToast) {
            App.showToast('Nie udało się zapisać danych — pamięć przeglądarki jest pełna. Zrób eksport kopii!', 'error');
        }
    },

    clearSRDCache() {
        const keys = [];
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith(this.PREFIX + 'srd_cache_')) keys.push(k);
        }
        keys.forEach(k => localStorage.removeItem(k));
        return keys.length;
    },

    getStorageUsageKB() {
        let total = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && k.startsWith(this.PREFIX)) total += (k.length + (localStorage.getItem(k) || '').length) * 2;
        }
        return Math.round(total / 1024);
    },

    remove(key) {
        localStorage.removeItem(this.PREFIX + key);
        this.syncToServer(key);
    },

    // ---- Network Sync ----
    getSyncUrl() {
        // Jeśli DM odpala plik z dysku (file://), musimy uderzać na localhost:8080
        if (window.location.protocol === 'file:') {
            return 'http://localhost:8080/api/sync';
        }
        return '/api/sync';
    },

    // Automatyczna kopia na dysk (serwer.js zapisuje ją w folderze „kopie”).
    // Wysyłka startuje dopiero po sprawdzeniu przy starcie, czy na dysku nie ma więcej danych
    // niż w przeglądarce — dzięki temu pusta przeglądarka nigdy nie nadpisze dobrej kopii.
    _sync: {
        dirty: new Set((() => { try { return JSON.parse(localStorage.getItem('dnd5e_meta_dirty') || '[]'); } catch (e) { return []; } })()),
        version: +(localStorage.getItem('dnd5e_meta_version') || 0), proto: 0,
        klient: Math.random().toString(36).slice(2, 10),
        hold: true, locked: false, pending: false, timer: null, inflight: false, again: false, last: null, ok: null, error: null, retry: 0, guard: null
    },

    syncAvailable() {
        return location.protocol !== 'file:' && !location.pathname.includes('player.html') && window.PANEL_ROLA !== 'gracz';
    },
    _saveDirty() {
        try { localStorage.setItem('dnd5e_meta_dirty', JSON.stringify([...this._sync.dirty])); } catch (e) {}
    },
    setSyncVersion(v) {
        this._sync.version = +v || 0;
        try { localStorage.setItem('dnd5e_meta_version', String(this._sync.version)); } catch (e) {}
    },
    _headers() { return { 'Content-Type': 'application/json', 'X-Panel': '1', 'X-Klient': this._sync.klient }; },

    syncToServer(key) {
        if (!this.syncAvailable()) return;
        if (key && String(key).startsWith('srd_cache_')) return;
        const S = this._sync;
        S.pending = true;
        if (key) S.dirty.add(this.PREFIX + key); else S.dirty.add('*');
        this._saveDirty();
        if (S.hold) return;
        clearTimeout(S.timer);
        S.timer = setTimeout(() => this.flushSync(), 600);
    },

    _payload(keys) {
        const S = this._sync;
        if (S.proto < 3) return this.exportAll();
        if (keys.has('*')) return JSON.stringify({ base: S.version, full: JSON.parse(this.exportAll()) });
        const set = {}, del = [];
        keys.forEach(k => { const v = localStorage.getItem(k); if (v === null) del.push(k); else set[k] = v; });
        return JSON.stringify({ base: S.version, set, del });
    },

    async flushSync(opts = {}) {
        const S = this._sync;
        if (!this.syncAvailable() || S.hold || !S.pending) return S.ok !== false;
        if (opts.unload && this.sendPatch()) { clearTimeout(S.timer); return true; }
        if (S.inflight) { S.again = true; return true; }
        clearTimeout(S.timer);
        S.pending = false; S.inflight = true;
        const sent = new Set(S.dirty); S.dirty.clear();
        const body = this._payload(sent);
        try {
            const r = await fetch(this.getSyncUrl(), {
                method: 'POST', headers: this._headers(), body, cache: 'no-store',
                keepalive: !!opts.unload && body.length < 60000
            });
            const j = await r.json().catch(() => ({}));
            if (r.status === 401) { S.error = 'sesja wygasła — zaloguj się ponownie'; location.href = '/logowanie'; throw new Error(S.error); }
            if (!r.ok || j.ok === false) throw new Error(j.error || `serwer odpowiedział ${r.status}`);
            S.ok = true; S.error = null; S.retry = 0; S.last = j.t || Date.now();
            if (j.guard) S.guard = Date.now();
            if (j.version) this.setSyncVersion(j.version);
            if (j.merged && Object.keys(j.merged).length) this.applyRemote(j.merged, j.version, { fromPush: true });
            this._saveDirty();
            try { localStorage.setItem('dnd5e_meta_last_autosync', String(S.last)); } catch (e) {}
        } catch (e) {
            S.ok = false; S.error = S.error || e.message || 'brak połączenia z serwerem';
            if (e.message) S.error = e.message;
            S.pending = true;
            sent.forEach(k => S.dirty.add(k));
            this._saveDirty();
            const wait = [3000, 10000, 30000, 60000][Math.min(S.retry++, 3)];
            S.timer = setTimeout(() => this.flushSync(), wait);
        } finally {
            S.inflight = false;
            try { window.dispatchEvent(new CustomEvent('panel-sync')); } catch (e) {}
            if (S.again) { S.again = false; if (S.pending && S.ok) this.flushSync(); }
        }
        return S.ok;
    },

    // zmiany z serwera (gracze, drugi komputer MG) — zapis bez odsyłania z powrotem
    applyRemote(map, version, opts = {}) {
        const S = this._sync, changed = [];
        for (const [k, v] of Object.entries(map || {})) {
            if (!k.startsWith(this.PREFIX)) continue;
            if (!opts.fromPush && S.dirty.has(k)) continue;   // nasza nowsza zmiana i tak pójdzie na serwer
            try {
                if (v === null) localStorage.removeItem(k); else if (localStorage.getItem(k) !== v) localStorage.setItem(k, v); else continue;
                changed.push(k);
            } catch (e) {}
        }
        if (version && version > S.version && !S.dirty.size && !S.inflight) this.setSyncVersion(version);
        if (changed.length) { try { window.dispatchEvent(new CustomEvent('panel-remote', { detail: { keys: changed } })); } catch (e) {} }
        return changed;
    },

    // przy zamykaniu karty: wyślij tylko zmienione wpisy (mała paczka przeżywa zamknięcie karty)
    sendPatch() {
        const S = this._sync;
        if (!S.dirty.size || S.dirty.has('*')) return false;
        const patch = { set: {}, del: [] };
        S.dirty.forEach(k => { const v = localStorage.getItem(k); if (v === null) patch.del.push(k); else patch.set[k] = v; });
        const body = JSON.stringify(patch);
        if (body.length > 60000) return false;
        try {
            fetch(this.getSyncUrl() + '/patch', { method: 'POST', headers: this._headers(), body, keepalive: true, cache: 'no-store' }).catch(() => {});
            S.dirty.clear(); S.pending = false; this._saveDirty();
            return true;
        } catch (e) { return false; }
    },

    holdSync() { this._sync.hold = true; this._sync.locked = true; },
    releaseSync() {
        const S = this._sync;
        S.hold = false; S.locked = false;
        if (S.dirty.size) S.pending = true;
        if (S.pending) this.flushSync();
        try { window.dispatchEvent(new CustomEvent('panel-sync-ready')); } catch (e) {}
    },
    syncState() { return { ...this._sync, timer: undefined, dirty: [...this._sync.dirty] }; },

    // liczba wpisów, które naprawdę są danymi Mistrza Gry (kampanie, bohaterowie, notatki…)
    statsOf(map) {
        const s = { kampanie: 0, bohaterowie: 0, npc: 0, sesje: 0, zadania: 0, notatki: 0, lokacje: 0, wlasne: 0 };
        const len = (v) => { try { const a = JSON.parse(v); return Array.isArray(a) ? a.length : 0; } catch (e) { return 0; } };
        for (const [k, v] of Object.entries(map || {})) {
            if (!k.startsWith(this.PREFIX) || typeof v !== 'string') continue;
            const key = k.slice(this.PREFIX.length);
            if (key === 'campaigns') s.kampanie += len(v);
            else if (key.startsWith('characters_')) s.bohaterowie += len(v);
            else if (key.startsWith('npcs_')) s.npc += len(v);
            else if (key.startsWith('sessions_')) s.sesje += len(v);
            else if (key.startsWith('quests_')) s.zadania += len(v);
            else if (key.startsWith('notes_')) s.notatki += len(v);
            else if (key.startsWith('locations_')) s.lokacje += len(v);
            else if (/^custom_(monsters|spells|equipment)$/.test(key)) s.wlasne += len(v);
        }
        return s;
    },
    score(stats) { return Object.values(stats || {}).reduce((a, b) => a + b, 0); },
    localMap() {
        const m = {};
        for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(this.PREFIX)) m[k] = localStorage.getItem(k); }
        return m;
    },

    // sprawdza plik kopii; zwraca { data, stats } albo rzuca błąd z czytelnym opisem
    parseBackup(input) {
        let data = input;
        if (typeof input === 'string') {
            try { data = JSON.parse(input); } catch (e) { throw new Error('Plik nie jest poprawnym plikiem JSON.'); }
        }
        if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('To nie jest kopia panelu.');
        const clean = {};
        for (const [k, v] of Object.entries(data)) {
            if (!k.startsWith(this.PREFIX)) continue;
            clean[k] = typeof v === 'string' ? v : JSON.stringify(v);
        }
        if (!Object.keys(clean).length) throw new Error('W pliku nie ma danych panelu (kampanii, bohaterów…).');
        return { data: clean, stats: this.statsOf(clean) };
    },

    // kampanie zapisane w kopii: [{ id, name, here: czy taka już jest w panelu }]
    campaignsInBackup(data) {
        let list = [];
        try { list = JSON.parse(data[this.PREFIX + 'campaigns'] || '[]') || []; } catch (e) { list = []; }
        const mine = new Set((this.get('campaigns') || []).map(c => c.id));
        return list.filter(c => c && c.id).map(c => ({ id: c.id, name: c.name || 'Kampania', here: mine.has(c.id) }));
    },
    // dołącza wybrane kampanie z kopii do obecnych danych (reszta panelu zostaje nietknięta)
    mergeCampaigns(data, ids) {
        const want = new Set(ids || []);
        let src = [];
        try { src = JSON.parse(data[this.PREFIX + 'campaigns'] || '[]') || []; } catch (e) { src = []; }
        const list = this.get('campaigns') || [];
        let n = 0;
        src.filter(c => want.has(c.id)).forEach(c => {
            const i = list.findIndex(x => x.id === c.id);
            if (i >= 0) list[i] = c; else list.push(c);
            Object.entries(data).forEach(([k, v]) => {
                if (!k.startsWith(this.PREFIX) || !k.endsWith('_' + c.id) || k.startsWith(this.PREFIX + 'srd_cache_')) return;
                localStorage.setItem(k, v);
                this.syncToServer(k.slice(this.PREFIX.length));
            });
            n++;
        });
        this.set('campaigns', list);
        return n;
    },

    // zastępuje wszystkie dane panelu danymi z kopii; przy braku miejsca cofa zmiany
    restoreAll(input) {
        const { data } = this.parseBackup(input);
        const keep = (k) => k.startsWith(this.PREFIX + 'srd_cache_') || k.startsWith(this.PREFIX + 'ui_');
        const old = this.localMap();
        const wipe = () => Object.keys(this.localMap()).forEach(k => { if (!keep(k)) localStorage.removeItem(k); });
        try {
            wipe();
            for (const [k, v] of Object.entries(data)) { if (!k.startsWith(this.PREFIX + 'srd_cache_')) localStorage.setItem(k, v); }
        } catch (e) {
            if (this._isQuotaError(e) && this.clearSRDCache() > 0) {
                try { for (const [k, v] of Object.entries(data)) localStorage.setItem(k, v); this.syncToServer(); return true; } catch (e2) { e = e2; }
            }
            wipe();
            for (const [k, v] of Object.entries(old)) { try { localStorage.setItem(k, v); } catch (e3) {} }
            throw new Error(this._isQuotaError(e) ? 'Za mało miejsca w przeglądarce, aby wczytać tę kopię — przywrócono poprzedni stan.' : 'Nie udało się wczytać kopii — przywrócono poprzedni stan.');
        }
        this.syncToServer();
        return true;
    },

    async pullFromServer() {
        try {
            const res = await fetch(this.getSyncUrl());
            if (!res.ok) return false;
            const data = await res.json();
            let changed = false;
            for (const [key, value] of Object.entries(data)) {
                if (localStorage.getItem(key) !== value) {
                    localStorage.setItem(key, value);
                    changed = true;
                }
            }
            return changed;
        } catch (e) {
            return false;
        }
    },

    // ---- Campaigns ----
    getCampaigns() {
        return this.get('campaigns') || [];
    },

    saveCampaigns(campaigns) {
        this.set('campaigns', campaigns);
    },

    getCampaign(id) {
        const campaigns = this.getCampaigns();
        return campaigns.find(c => c.id === id) || null;
    },

    saveCampaign(campaign) {
        const campaigns = this.getCampaigns();
        const idx = campaigns.findIndex(c => c.id === campaign.id);
        if (idx >= 0) campaigns[idx] = campaign;
        else campaigns.push(campaign);
        this.saveCampaigns(campaigns);
    },

    deleteCampaign(id) {
        const campaigns = this.getCampaigns().filter(c => c.id !== id);
        this.saveCampaigns(campaigns);
    },

    getActiveCampaignId() {
        return this.get('activeCampaignId');
    },

    setActiveCampaignId(id) {
        this.set('activeCampaignId', id);
    },

    // ---- Characters (PC) ----
    getCharacters(campaignId) {
        return this.get(`characters_${campaignId}`) || [];
    },

    saveCharacters(campaignId, characters) {
        this.set(`characters_${campaignId}`, characters);
    },

    getCharacter(campaignId, charId) {
        return this.getCharacters(campaignId).find(c => c.id === charId) || null;
    },

    saveCharacter(campaignId, character) {
        const chars = this.getCharacters(campaignId);
        const idx = chars.findIndex(c => c.id === character.id);
        if (idx >= 0) chars[idx] = character;
        else chars.push(character);
        this.saveCharacters(campaignId, chars);
    },

    deleteCharacter(campaignId, charId) {
        const chars = this.getCharacters(campaignId).filter(c => c.id !== charId);
        this.saveCharacters(campaignId, chars);
    },

    // ---- NPCs ----
    getNPCs(campaignId) {
        return this.get(`npcs_${campaignId}`) || [];
    },

    saveNPCs(campaignId, npcs) {
        this.set(`npcs_${campaignId}`, npcs);
    },

    saveNPC(campaignId, npc) {
        const npcs = this.getNPCs(campaignId);
        const idx = npcs.findIndex(n => n.id === npc.id);
        if (idx >= 0) npcs[idx] = npc;
        else npcs.push(npc);
        this.saveNPCs(campaignId, npcs);
    },

    deleteNPC(campaignId, npcId) {
        const npcs = this.getNPCs(campaignId).filter(n => n.id !== npcId);
        this.saveNPCs(campaignId, npcs);
    },

    // ---- Notes ----
    getNotes(campaignId) {
        return this.get(`notes_${campaignId}`) || [];
    },

    saveNotes(campaignId, notes) {
        this.set(`notes_${campaignId}`, notes);
    },

    saveNote(campaignId, note) {
        const notes = this.getNotes(campaignId);
        const idx = notes.findIndex(n => n.id === note.id);
        if (idx >= 0) notes[idx] = note;
        else notes.push(note);
        this.saveNotes(campaignId, notes);
    },

    deleteNote(campaignId, noteId) {
        const notes = this.getNotes(campaignId).filter(n => n.id !== noteId);
        this.saveNotes(campaignId, notes);
    },

    // ---- Sessions ----
    getSessions(campaignId) {
        return this.get(`sessions_${campaignId}`) || [];
    },

    saveSessions(campaignId, sessions) {
        this.set(`sessions_${campaignId}`, sessions);
    },

    saveSession(campaignId, session) {
        const sessions = this.getSessions(campaignId);
        const idx = sessions.findIndex(s => s.id === session.id);
        if (idx >= 0) sessions[idx] = session;
        else sessions.push(session);
        this.saveSessions(campaignId, sessions);
    },

    // ---- Locations ----
    getLocations(campaignId) {
        return this.get(`locations_${campaignId}`) || [];
    },

    saveLocations(campaignId, locations) {
        this.set(`locations_${campaignId}`, locations);
    },

    saveLocation(campaignId, location) {
        const locs = this.getLocations(campaignId);
        const idx = locs.findIndex(l => l.id === location.id);
        if (idx >= 0) locs[idx] = location;
        else locs.push(location);
        this.saveLocations(campaignId, locs);
    },

    // ---- Quests ----
    getQuests(campaignId) {
        return this.get(`quests_${campaignId}`) || [];
    },

    saveQuests(campaignId, quests) {
        this.set(`quests_${campaignId}`, quests);
    },

    saveQuest(campaignId, quest) {
        const quests = this.getQuests(campaignId);
        const idx = quests.findIndex(q => q.id === quest.id);
        if (idx >= 0) quests[idx] = quest;
        else quests.push(quest);
        this.saveQuests(campaignId, quests);
    },

    deleteQuest(campaignId, questId) {
        const quests = this.getQuests(campaignId).filter(q => q.id !== questId);
        this.saveQuests(campaignId, quests);
    },

    // ---- Custom Data (monsters, spells, equipment) ----
    getCustomMonsters() {
        return this.get('custom_monsters') || [];
    },

    saveCustomMonsters(monsters) {
        this.set('custom_monsters', monsters);
    },

    saveCustomMonster(monster) {
        const list = this.getCustomMonsters();
        const idx = list.findIndex(m => m.index === monster.index);
        if (idx >= 0) list[idx] = monster;
        else list.push(monster);
        this.saveCustomMonsters(list);
    },

    deleteCustomMonster(index) {
        this.saveCustomMonsters(this.getCustomMonsters().filter(m => m.index !== index));
    },

    getCustomSpells() {
        return this.get('custom_spells') || [];
    },

    saveCustomSpells(spells) {
        this.set('custom_spells', spells);
    },

    saveCustomSpell(spell) {
        const list = this.getCustomSpells();
        const idx = list.findIndex(s => s.index === spell.index);
        if (idx >= 0) list[idx] = spell;
        else list.push(spell);
        this.saveCustomSpells(list);
    },

    deleteCustomSpell(index) {
        this.saveCustomSpells(this.getCustomSpells().filter(s => s.index !== index));
    },

    getCustomEquipment() {
        return this.get('custom_equipment') || [];
    },

    saveCustomEquipment(items) {
        this.set('custom_equipment', items);
    },

    saveCustomEquipmentItem(item) {
        const list = this.getCustomEquipment();
        const idx = list.findIndex(e => e.index === item.index);
        if (idx >= 0) list[idx] = item;
        else list.push(item);
        this.saveCustomEquipment(list);
    },

    deleteCustomEquipmentItem(index) {
        this.saveCustomEquipment(this.getCustomEquipment().filter(e => e.index !== index));
    },

    // ---- SRD Cache ----
    getSRDCache(type) {
        return this.get(`srd_cache_${type}`);
    },

    setSRDCache(type, data) {
        this.set(`srd_cache_${type}`, { data, timestamp: Date.now() });
    },

    isSRDCacheValid(type, maxAgeMs = 24 * 60 * 60 * 1000) {
        const cached = this.getSRDCache(type);
        if (!cached || !cached.timestamp) return false;
        return (Date.now() - cached.timestamp) < maxAgeMs;
    },

    // ---- Combat State ----
    getCombatState() {
        return this.get('combat_state');
    },

    saveCombatState(state) {
        this.set('combat_state', state);
    },

    clearCombatState() {
        this.remove('combat_state');
    },

    // ---- VTT State ----
    getVTTState() {
        return this.get('vtt_state');
    },

    saveVTTState(state) {
        this.set('vtt_state', state);
    },

    // ---- Pinned Items (positions) ----
    getPinnedItems() {
        return this.get('pinned_items') || [];
    },

    savePinnedItems(items) {
        this.set('pinned_items', items);
    },

    // ---- Dice History ----
    getDiceHistory() {
        return this.get('dice_history') || [];
    },

    saveDiceHistory(history) {
        // Keep last 50 rolls
        this.set('dice_history', history.slice(-50));
    },

    // ---- Export / Import ----
    exportAll({ includeCache = false } = {}) {
        const data = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (!includeCache && key.startsWith(this.PREFIX + 'srd_cache_')) continue; // re-downloadable, keeps backups small
            if (key.startsWith(this.PREFIX)) {
                data[key] = localStorage.getItem(key);
            }
        }
        return JSON.stringify(data, null, 2);
    },

    importAll(jsonStr) {
        try {
            this.restoreAll(jsonStr);
            return true;
        } catch (e) {
            console.error('Import error:', e);
            return false;
        }
    },

    // ---- Utility ----
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    }
};

// wyślij zaległe zmiany, zanim karta zostanie schowana lub zamknięta
(function () {
    const flush = () => { if (StorageManager._sync.pending && !StorageManager._sync.hold) StorageManager.flushSync({ unload: true }); };
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
    window.addEventListener('pagehide', flush);
    // zabezpieczenie: gdyby sprawdzenie przy starcie się nie odbyło, autokopia i tak ruszy
    setTimeout(() => { if (StorageManager._sync.hold && !StorageManager._sync.locked) StorageManager.releaseSync(); }, 10000);
})();
