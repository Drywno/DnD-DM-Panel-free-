/* ============================================
   D&D 5e DM Panel — Wybierak zaklęć
   Wspólny dla kreatora postaci i księgi zaklęć:
   wyszukiwanie, filtry, limity sztuczek/czarów na poziom,
   rozwijany opis czaru (tłumaczony, zapamiętywany).
   ============================================ */

const SpellPicker = (() => {
    const EN = { bard: 'Bard', cleric: 'Cleric', druid: 'Druid', paladin: 'Paladin', ranger: 'Ranger', sorcerer: 'Sorcerer', warlock: 'Warlock', wizard: 'Wizard' };
    const SCHOOLS = { Abjuration: 'Odpychanie', Conjuration: 'Przywoływanie', Divination: 'Wieszczenie', Enchantment: 'Zauroczenie', Evocation: 'Wywoływanie', Illusion: 'Iluzja', Necromancy: 'Nekromancja', Transmutation: 'Przemiany' };
    const FULL = ['bard', 'cleric', 'druid', 'sorcerer', 'wizard'];
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const mod = (s) => Math.floor(((s ?? 10) - 10) / 2);

    let listCache = null;
    async function allSpells() {
        if (listCache) return listCache;
        try { listCache = (await APIClient.getSpellList()) || []; } catch (e) { listCache = []; }
        return listCache;
    }

    /** Najwyższy krąg czarów dostępny na danym poziomie klasy. */
    function maxSpellLevel(ck, level) {
        if (FULL.includes(ck)) return Math.min(9, Math.ceil(level / 2));
        if (ck === 'warlock') return Math.min(5, Math.ceil(level / 2));
        if (ck === 'paladin' || ck === 'ranger') return level >= 17 ? 5 : level >= 13 ? 4 : level >= 9 ? 3 : level >= 5 ? 2 : level >= 2 ? 1 : 0;
        return 0;
    }

    /** Ile sztuczek i czarów (znanych / przygotowanych / w księdze) przysługuje. */
    function limits(ck, level, scores = {}) {
        const cantrips = window.ClassData ? ClassData.getCantripsKnown(ck, level) : 0;
        let spells = 0, kind = 'znane';
        const known = window.ClassData ? ClassData.getSpellsKnown(ck, level) : null;
        if (known !== null && known !== undefined) spells = known;
        else if (ck === 'wizard') { spells = 6 + 2 * (level - 1); kind = 'w księdze'; }
        else if (ck === 'cleric' || ck === 'druid') { spells = Math.max(1, mod(scores.wis) + level); kind = 'przygotowane'; }
        else if (ck === 'paladin') { spells = level >= 2 ? Math.max(1, Math.floor(level / 2) + mod(scores.cha)) : 0; kind = 'przygotowane'; }
        return { cantrips, spells, kind, maxLevel: maxSpellLevel(ck, level) };
    }

    // ---------- opis czaru ----------
    const descCache = new Map();
    async function details(index) {
        if (descCache.has(index)) return descCache.get(index);
        const d = await APIClient.getSpell(index);
        if (!d || !d.name) throw new Error('brak danych');
        const tr = async (arr) => {
            const out = [];
            out.push(...await APIClient.translateMany(Array.isArray(arr) ? arr : arr ? [arr] : []));
            return out;
        };
        const info = {
            name: d.name, level: d.level || 0,
            school: SCHOOLS[d.school?.name] || d.school?.name || '',
            time: d.casting_time || '', range: d.range || '', duration: d.duration || '',
            components: (d.components || []).join(', ') + (d.material ? ` (${d.material})` : ''),
            ritual: !!d.ritual, concentration: !!d.concentration,
            desc: await tr(d.desc), higher: await tr(d.higher_level)
        };
        descCache.set(index, info);
        return info;
    }
    function detailsHTML(info) {
        const facts = [['Czas rzucania', info.time], ['Zasięg', info.range], ['Komponenty', info.components], ['Czas trwania', info.duration]]
            .filter(([, v]) => v).map(([k, v]) => `<div><span>${k}</span><b>${esc(v)}</b></div>`).join('');
        return `
            <div class="sp-facts">${facts}</div>
            <div class="sp-desc">${info.desc.map(p => `<p>${esc(p)}</p>`).join('')}
            ${info.higher.length ? `<p class="sp-higher"><b>Na wyższych kręgach:</b> ${info.higher.map(esc).join(' ')}</p>` : ''}</div>`;
    }
    async function fillDetails(el, index) {
        el.innerHTML = '<div class="sp-loading">Wczytywanie opisu…</div>';
        try { el.innerHTML = detailsHTML(await details(index)); }
        catch (e) { el.innerHTML = '<div class="sp-loading">Nie udało się pobrać opisu (brak połączenia z bazą SRD).</div>'; }
    }
    const tags = (s) => `${s.ritual ? '<i class="sp-tag" title="Rytuał">R</i>' : ''}${s.concentration ? '<i class="sp-tag" title="Koncentracja">K</i>' : ''}`;

    // ---------- wybierak ----------
    /**
     * opts: { cls, level, scores, selected:[{index,name,level}], strict, onChange }
     */
    async function mount(el, opts) {
        const ck = window.Kits ? Kits.classKey(opts.cls) : String(opts.cls || '').toLowerCase();
        const lim = limits(ck, opts.level || 1, opts.scores || {});
        const st = { q: '', lvl: 'all', onlyClass: !!EN[ck], open: new Set(), sel: new Map((opts.selected || []).filter(s => s.index).map(s => [s.index, s])) };
        el.innerHTML = '<div class="sp-loading">Wczytywanie listy zaklęć…</div>';
        const spells = (await allSpells()).slice().sort((a, b) => (a.level - b.level) || a.name.localeCompare(b.name));
        const maxLvl = Math.max(lim.maxLevel, 0);

        const counts = () => {
            let c = 0, s = 0;
            st.sel.forEach(v => { if ((v.level || 0) === 0) c++; else s++; });
            return { c, s };
        };
        const full = (lvl) => {
            if (!opts.strict) return false;
            const { c, s } = counts();
            return lvl === 0 ? c >= lim.cantrips : s >= lim.spells;
        };
        const emit = () => opts.onChange && opts.onChange([...st.sel.values()]);

        function visible() {
            const q = st.q.trim().toLowerCase();
            return spells.filter(s => {
                if (st.onlyClass && EN[ck] && !(s.classes || []).some(c => c.name === EN[ck])) return false;
                if (opts.strict && s.level > maxLvl) return false;
                if (opts.strict && s.level === 0 && lim.cantrips === 0) return false;
                if (opts.strict && s.level > 0 && lim.spells === 0) return false;
                if (st.lvl !== 'all' && String(s.level) !== st.lvl) return false;
                if (q && !s.name.toLowerCase().includes(q) && !(window.PL ? PL.spell(s.name) : '').toLowerCase().includes(q)) return false;
                return true;
            });
        }

        function head() {
            const { c, s } = counts();
            const chip = (label, n, max) => `<span class="sp-count ${max && n > max ? 'over' : max && n === max ? 'done' : ''}">${label} <b>${n}${max || max === 0 ? ` / ${max}` : ''}</b></span>`;
            return `${lim.cantrips || !opts.strict ? chip('Sztuczki', c, lim.cantrips) : ''}
                    ${lim.spells || !opts.strict ? chip(`Czary ${lim.kind}`, s, lim.spells) : ''}
                    ${maxLvl ? `<span class="sp-note">do ${maxLvl}. kręgu</span>` : ''}`;
        }

        function chosen() {
            const all = [...st.sel.values()].sort((a, b) => (a.level - b.level) || a.name.localeCompare(b.name));
            const group = (title, list, max) => `
                <div class="sp-chosen-group">
                    <div class="sp-chosen-head"><span>${title}</span><b>${list.length}${max ? ` / ${max}` : ''}</b></div>
                    ${list.length ? list.map(x => `<div class="sp-chip" data-i="${esc(x.index)}"><span>${esc(window.PL ? PL.spell(x.name) : x.name)}</span>${x.level ? `<small>${x.level}</small>` : ''}<button data-act="unpick" title="Usuń">✕</button></div>`).join('')
                        : `<div class="sp-chosen-empty">${max ? `Wybierz jeszcze ${max}` : 'Nic nie wybrano'}</div>`}
                    ${list.length && max && list.length < max ? `<div class="sp-chosen-empty">Zostało: ${max - list.length}</div>` : ''}
                </div>`;
            const c = all.filter(x => !x.level), sp = all.filter(x => x.level);
            return `${(lim.cantrips || !opts.strict) ? group('Sztuczki', c, opts.strict ? lim.cantrips : 0) : ''}
                    ${(lim.spells || !opts.strict) ? group(opts.strict ? `Czary (${lim.kind})` : 'Czary', sp, opts.strict ? lim.spells : 0) : ''}`;
        }

        function rows() {
            const list = visible();
            if (!list.length) return '<div class="sp-empty">Brak zaklęć dla tych filtrów.</div>';
            let lastLvl = null;
            return list.map(s => {
                const on = st.sel.has(s.index), blocked = !on && full(s.level), open = st.open.has(s.index);
                const sep = s.level !== lastLvl ? `<div class="sp-sep">${s.level === 0 ? 'Sztuczki' : `${s.level}. krąg`}</div>` : '';
                lastLvl = s.level;
                return `${sep}<div class="sp-row ${on ? 'on' : ''} ${blocked ? 'blocked' : ''} ${open ? 'open' : ''}" data-i="${esc(s.index)}">
                    <button class="sp-check" data-act="pick" title="${blocked ? 'Limit osiągnięty' : on ? 'Usuń' : 'Wybierz'}" ${blocked ? 'disabled' : ''}></button>
                    <button class="sp-name" data-act="open"><b title="${esc(s.name)}">${esc(window.PL ? PL.spell(s.name) : s.name)}</b><small>${esc(SCHOOLS[s.school?.name] || s.school?.name || '')}</small>${tags(s)}<span class="sp-caret">▾</span></button>
                    <div class="sp-body" ${open ? '' : 'hidden'}></div>
                </div>`;
            }).join('');
        }

        el.innerHTML = `
            <div class="sp">
                <div class="sp-head">${head()}</div>
                <div class="sp-tools">
                    <input type="search" class="sp-search" placeholder="Szukaj zaklęcia…" aria-label="Szukaj zaklęcia">
                    <div class="sp-lvls">${['all', ...Array.from({ length: (opts.strict ? maxLvl : 9) + 1 }, (_, i) => String(i))]
                        .filter(l => !(opts.strict && ((l === '0' && !lim.cantrips) || (l !== '0' && l !== 'all' && !lim.spells))))
                        .map(l => `<button data-lvl="${l}" class="${l === 'all' ? 'on' : ''}">${l === 'all' ? 'Wszystkie' : l === '0' ? 'Sztuczki' : l}</button>`).join('')}</div>
                    ${EN[ck] ? `<label class="sp-only"><input type="checkbox" ${st.onlyClass ? 'checked' : ''}> tylko lista klasy</label>` : ''}
                </div>
                <div class="sp-split">
                    <div class="sp-list"></div>
                    <aside class="sp-chosen"></aside>
                </div>
            </div>`;
        const listEl = el.querySelector('.sp-list'), headEl = el.querySelector('.sp-head'), chosenEl = el.querySelector('.sp-chosen');
        const redraw = () => { listEl.innerHTML = rows(); headEl.innerHTML = head(); chosenEl.innerHTML = chosen(); listEl.querySelectorAll('.sp-row.open .sp-body').forEach(b => fillDetails(b, b.parentElement.dataset.i)); };
        redraw();

        el.querySelector('.sp-search').addEventListener('input', (e) => { st.q = e.target.value; redraw(); });
        el.querySelectorAll('.sp-lvls button').forEach(b => b.addEventListener('click', () => {
            st.lvl = b.dataset.lvl;
            el.querySelectorAll('.sp-lvls button').forEach(x => x.classList.toggle('on', x === b));
            redraw();
        }));
        el.querySelector('.sp-only input')?.addEventListener('change', (e) => { st.onlyClass = e.target.checked; redraw(); });
        chosenEl.addEventListener('click', (e) => {
            const b = e.target.closest('[data-act="unpick"]');
            if (!b) return;
            st.sel.delete(b.closest('.sp-chip').dataset.i);
            const y = listEl.scrollTop;
            redraw();
            listEl.scrollTop = y;
            emit();
        });
        listEl.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-act]');
            if (!btn) return;
            const row = btn.closest('.sp-row'), idx = row.dataset.i;
            const s = spells.find(x => x.index === idx);
            if (btn.dataset.act === 'open') {
                const body = row.querySelector('.sp-body');
                if (st.open.has(idx)) { st.open.delete(idx); row.classList.remove('open'); body.hidden = true; }
                else { st.open.add(idx); row.classList.add('open'); body.hidden = false; fillDetails(body, idx); }
                return;
            }
            if (st.sel.has(idx)) st.sel.delete(idx);
            else if (!full(s.level)) st.sel.set(idx, { index: s.index, name: s.name, level: s.level || 0, school: SCHOOLS[s.school?.name] || s.school?.name || '', ritual: !!s.ritual, concentration: !!s.concentration, isCustom: false });
            const y = listEl.scrollTop;
            redraw();
            listEl.scrollTop = y;
            emit();
        });
        return { get: () => [...st.sel.values()], limits: lim };
    }

    return { mount, limits, maxSpellLevel, details, detailsHTML, fillDetails, tags, SCHOOLS, EN };
})();

window.SpellPicker = SpellPicker;
