@echo off
chcp 65001 >nul
title Panel Mistrza Gry
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Nie znaleziono Node.js. Zainstaluj go ze strony https://nodejs.org ^(wersja LTS^),
  echo  a potem uruchom ten plik ponownie.
  echo.
  pause
  exit /b
)
rem zamknij starą wersję serwera, jeśli jeszcze działa w tle
for /f "tokens=5" %%a in ('netstat -ano ^| findstr /C:":8080 " ^| findstr LISTENING') do taskkill /F /PID %%a >nul 2>nul
node serwer.js
pause
