# Panel Mistrza Gry · Game Master Panel (D&D 5e)

**[English](#english) · [Polski](#polski)**

A self-hosted table for Dungeons & Dragons 5th edition: one Game Master, up to 8 players, a shared map, combat tracker, character sheets, quest board and dice — in Polish or English.

Samodzielnie hostowany stół do D&D 5. edycji: jeden Mistrz Gry, do 8 graczy, wspólna mapa, walka, karty postaci, tablica zleceń i kości — po polsku albo po angielsku.

> Unofficial fan project. Not affiliated with, endorsed or sponsored by Wizards of the Coast. See [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).

---

## English

### What it does

- **Game Master panel** — campaigns, heroes, NPCs and enemies, bestiary, spells, equipment (SRD), session notes, quest board, atlas with your own maps, battle map with fog of war, initiative tracker, loot, rests, tavern games, music and mood.
- **Player view** — every player gets a personal link or an 8‑character code and sees only their character, the party, the map the GM shows, combat and quests. The server strips GM secrets before sending anything to players.
- **Live** — changes reach all screens immediately; dice are rolled by the server and everyone sees the result.
- **Installable app** — the player view can be added to a phone's home screen (PWA).
- **Language** — Polish or English. Every user picks their own language (PL/EN switch on the login page, in the GM sidebar and in the player's sidebar / "More" menu). On the first visit it follows the browser language (Polish for Polish browsers or the Polish time zone).
- **Backups** — automatic backup after every change, hourly and daily snapshots, manual backups and restore.

### Requirements

- [Node.js](https://nodejs.org) **18 or newer** (LTS recommended). No database, no `npm install` needed to run it.
- A modern browser (Chrome, Edge, Firefox, Safari).

### Install and run

1. Download the ZIP (green **Code → Download ZIP** button, or the latest file from **Releases**) and unpack it anywhere.
2. Start it:
   - **Windows:** double-click `Zainstaluj aplikację.vbs` once — it creates a desktop icon “Panel Mistrza Gry”. Next time just use the icon. (`Uruchom panel.bat` starts it with a console window instead.)
   - **macOS / Linux:** run `./start.sh` (or `node serwer.js`) in the unpacked folder.
3. Open `http://localhost:8080/`. On the computer running the panel the GM needs no password.

### Playing with others

- **Same Wi‑Fi:** GM panel → **Players** → **Set the GM password** → **Share on the home network**. Then add players and send them their links or QR codes.
- **On the internet:** run it on a server (Docker or plain Node.js) behind HTTPS. Step-by-step guide (in Polish, with copy‑paste configs): [SERWER.md](SERWER.md).

### Configuration (environment variables)

| Variable | Meaning |
|---|---|
| `PANEL_PORT` | port (default `8080`) |
| `PANEL_TRYB=serwer` | server mode: no password‑less GM login, trusts reverse‑proxy headers |
| `PANEL_HASLO_MG` | Game Master password set at start‑up |
| `PANEL_URL` | public address used in player links, e.g. `https://dnd.example.com` |
| `PANEL_HOST` | listen address (`127.0.0.1` behind a proxy, `0.0.0.0` without one) |
| `PANEL_DANE` | folder for data (`dane/`) and backups (`kopie/`) |
| `PANEL_LANG` | language of console messages: `pl` or `en` (default: system language) |
| `PANEL_HTTPS=0` | turns off the secure local address for phones (see *Privacy*) |

### Your data and privacy

- Campaign data stays on your computer/server: in the browser of the GM and in the `dane/` and `kopie/` folders next to the panel. Neither folder is ever served over HTTP and neither is part of this repository.
- The panel contacts these external services: `www.dnd5eapi.co` (SRD rules data), `cdnjs.cloudflare.com` (icons, QR codes), `fonts.googleapis.com` (fonts). In Polish mode, English SRD descriptions are machine-translated via `translate.googleapis.com`. To let phones install the app on a home network, the server downloads a certificate for `*.local-ip.sh` (disable with `PANEL_HTTPS=0`).
- Player accounts: one device per account — a new login logs the previous device out. GM logins are rate‑limited and locked after repeated wrong passwords.

### Your own maps and campaign pack (optional)

The release ships with a blank parchment world map. You can upload your own world map in the Atlas (per campaign). To bundle maps, sample locations and NPCs with your copy of the panel, see [assets/kampania/README.md](assets/kampania/README.md).

### Development

Plain JavaScript, no build step for the app itself. `js/dice-box.bundle.js` (3D dice) is prebuilt; `npm install` is only needed to rebuild it.
UI strings are written in Polish; the English interface comes from the dictionary in `js/i18n-en.js` applied by `js/i18n.js`.

### License

Code: [MIT](LICENSE). Rules content: SRD 5.1, CC BY 4.0. Third-party libraries and fonts: see [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).

---

## Polski

### Co potrafi

- **Panel Mistrza Gry** — kampanie, bohaterowie, NPC i przeciwnicy, bestiariusz, czary i ekwipunek (SRD), sesje i notatki, tablica zleceń, atlas z własnymi mapami, plansza walki z mgłą wojny, kolejka inicjatywy, łupy, odpoczynki, gry w karczmie, muzyka i nastrój.
- **Widok gracza** — każdy gracz dostaje własny link albo 8‑znakowy kod i widzi tylko swoją postać, drużynę, mapę pokazaną przez MG, walkę i zlecenia. Serwer wycina sekrety MG, zanim cokolwiek wyśle graczom.
- **Na żywo** — zmiany od razu trafiają na wszystkie ekrany, kośćmi rzuca serwer.
- **Aplikacja** — widok gracza można dodać do ekranu głównego telefonu.
- **Język** — polski albo angielski; każdy wybiera sam (przełącznik PL/EN na stronie logowania, w pasku bocznym MG i u gracza w menu „Więcej”).
- **Kopie zapasowe** — autokopia po każdej zmianie, kopie godzinowe i dzienne, kopie ręczne i przywracanie.

### Wymagania

[Node.js](https://nodejs.org) **18 lub nowszy** (wersja LTS). Bez bazy danych i bez `npm install`.

### Instalacja

1. Pobierz ZIP (zielony przycisk **Code → Download ZIP** albo plik z zakładki **Releases**) i rozpakuj w dowolnym miejscu.
2. **Windows:** kliknij dwa razy `Zainstaluj aplikację.vbs` — na pulpicie pojawi się ikona „Panel Mistrza Gry”. Potem uruchamiasz panel tą ikoną.
   **macOS / Linux:** `./start.sh` (albo `node serwer.js`).
3. Panel otwiera się pod `http://localhost:8080/`. Na tym komputerze MG wchodzi bez hasła.

Gra z innymi: **Gracze → Ustaw hasło MG → Udostępnij w sieci domowej**. Serwer w internecie (Docker, Caddy, nginx): [SERWER.md](SERWER.md).

### Dane i prywatność

Dane kampanii zostają u Ciebie — w przeglądarce MG oraz w folderach `dane/` i `kopie/` obok panelu (serwer nigdy ich nie udostępnia, nie ma ich też w repozytorium). Z zewnętrznych usług panel korzysta z: dnd5eapi.co (dane SRD), cdnjs (ikony, kody QR), Google Fonts, Google Translate (tłumaczenie opisów SRD w wersji polskiej) i local-ip.sh (certyfikat do instalacji aplikacji na telefonach; wyłączysz go `PANEL_HTTPS=0`).

### Własne mapy i pakiet kampanii

Wydanie zawiera pustą mapę świata (pergamin). Własną mapę wgrasz w Atlasie dla każdej kampanii osobno. Jak dołączyć do panelu własne mapy, lokacje i NPC — [assets/kampania/README.md](assets/kampania/README.md).
