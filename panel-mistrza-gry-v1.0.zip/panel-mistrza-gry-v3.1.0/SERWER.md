# Panel Mistrza Gry — gracze przy stole i własny serwer

Panel działa w trzech trybach. We wszystkich jest jeden Mistrz Gry i do 8 graczy (domyślnie 4 miejsca).
Każdy gracz ma własny widok: swoją kartę postaci, drużynę, mapę, pole walki, zadania, dziennik stołu i kości.

| Tryb | Kto się łączy | Co zrobić |
|---|---|---|
| **Tylko ten komputer** | MG | Uruchom ikonę „Panel Mistrza Gry”. Nic więcej. |
| **Sieć domowa** | MG + gracze w tym samym Wi‑Fi | Panel → **Gracze** → ustaw hasło MG → **Udostępnij w sieci domowej**. |
| **Własny serwer** | MG + gracze z dowolnego miejsca | Ten dokument, sekcja „Serwer w internecie”. |

---

## Jak dołączają gracze

1. W panelu MG otwórz zakładkę **Gracze**.
2. Kliknij **Dodaj gracza**, wpisz imię i wybierz postać z drużyny.
3. Wyślij graczowi jego **link** (przycisk „Kopiuj”) albo pokaż **kod QR**.
   Gracz może też wejść na `/logowanie` i wpisać 8‑znakowy kod.
4. Logowanie zostaje zapamiętane na urządzeniu gracza. **Nowy kod** unieważnia stary link.

Co gracz może sam zmieniać: swoje PW (obrażenia, leczenie, tymczasowe), rzuty przeciw śmierci,
kości wytrzymałości, zużycie komórek zaklęć i zdolności klasowych, ekwipunek, sakiewkę i własne notatki.
Na polu walki może przesuwać tylko swój żeton i tylko w swojej turze (MG może to wyłączyć w „Siatka”).
Rzuty kośćmi losuje serwer — wynik widzi cały stół i MG.

Czego gracz **nie widzi**: sekretów lokacji i zadań, nieodkrytych miejsc i zleceń, ukrytych stworzeń,
sekretnych przejść i elementów „tylko dla MG” na mapach, dokładnych PW przeciwników (tylko „ranny”, „ciężko ranny”…),
notatek MG, bestiariusza i reszty panelu MG. Serwer wycina te dane, zanim cokolwiek wyśle do gracza.

MG może **pokazać graczom** tekst (np. opis lokacji z Atlasu), obraz albo mapę — pojawią się na wszystkich ekranach.

---

## Sieć domowa (najprostsze granie przy jednym stole)

1. Panel → **Gracze** → **Ustaw hasło MG** (min. 6 znaków).
2. Kliknij **Udostępnij w sieci domowej**.
   Przy pierwszym razie Windows zapyta o zaporę dla „Node.js” — zaznacz *sieci prywatne* i kliknij *Zezwól*.
3. Linki dla graczy mają teraz adres komputera, np. `http://192.168.1.23:8080/gracz?kod=…`.

Komputer z panelem musi być włączony podczas gry. Na tym komputerze MG wchodzi bez hasła.

---

## Serwer w internecie

Wymagania: dowolny serwer z **Node.js 18+** (VPS, Raspberry Pi, NAS) albo Docker, i domena wskazująca na serwer.
Panel nie potrzebuje bazy danych ani pakietów npm.

### Ustawienia (zmienne środowiskowe)

| Zmienna | Znaczenie | Przykład |
|---|---|---|
| `PANEL_TRYB` | `serwer` — wyłącza wchodzenie bez hasła z tego samego komputera i ufa nagłówkom proxy | `serwer` |
| `PANEL_HASLO_MG` | hasło Mistrza Gry (ustawiane przy starcie) | `dlugie-tajne-haslo` |
| `PANEL_URL` | publiczny adres — używany w linkach dla graczy | `https://dnd.twojadomena.pl` |
| `PANEL_PORT` | port serwera | `8080` |
| `PANEL_HOST` | adres nasłuchu; `127.0.0.1` za proxy, `0.0.0.0` bez proxy | `127.0.0.1` |
| `PANEL_DANE` | folder na dane (`dane/`) i kopie (`kopie/`) | `/srv/panel-dane` |
| `PANEL_LANG` | język komunikatów w konsoli serwera: `pl` albo `en` (domyślnie wg systemu) | `pl` |
| `PANEL_HTTPS` | `0` wyłącza bezpieczny adres dla telefonów w sieci domowej (certyfikat z local-ip.sh) | `0` |

### Wariant A: Docker (zalecany)

```bash
# w folderze panelu, po ustawieniu hasła i adresu w docker-compose.yml
docker compose up -d
```

Dane i kopie trafią do `./dane-panelu`. Jeśli Docker nie może tam pisać:
`sudo chown -R 1000:1000 dane-panelu`.

### Wariant B: zwykły Node.js + systemd

```bash
sudo mkdir -p /opt/panel && sudo cp -r . /opt/panel && sudo chown -R www-data /opt/panel
```

`/etc/systemd/system/panel.service`:

```ini
[Unit]
Description=Panel Mistrza Gry
After=network.target

[Service]
WorkingDirectory=/opt/panel
ExecStart=/usr/bin/node serwer.js
Environment=PANEL_TRYB=serwer
Environment=PANEL_HOST=127.0.0.1
Environment=PANEL_PORT=8080
Environment=PANEL_URL=https://dnd.twojadomena.pl
Environment=PANEL_HASLO_MG=dlugie-tajne-haslo
User=www-data
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now panel
```

### HTTPS: Caddy (najprościej — sam pobiera certyfikat)

`/etc/caddy/Caddyfile`:

```
dnd.twojadomena.pl {
    reverse_proxy 127.0.0.1:8080
}
```

### HTTPS: nginx

```nginx
server {
    server_name dnd.twojadomena.pl;
    client_max_body_size 60m;

    location /api/events {               # połączenia na żywo — bez buforowania
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Connection '';
        proxy_buffering off;
        proxy_read_timeout 1h;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    # certyfikat: sudo certbot --nginx -d dnd.twojadomena.pl
}
```

### Przeniesienie kampanii na serwer

Skopiuj na serwer foldery `kopie` i `dane` z komputera (albo w panelu: **Kopie zapasowe → Pobierz plik kopii**,
a na serwerze **Wczytaj z pliku…**). Przy pierwszym wejściu MG na serwer panel sam zaproponuje wczytanie danych.

---

## Bezpieczeństwo

- Ustaw długie hasło MG. Po 12 błędnych próbach logowania adres jest blokowany na 15 minut.
- Na serwerze w internecie używaj HTTPS (Caddy/nginx) — wtedy ciasteczka logowania są szyfrowane.
- Kody graczy można w każdej chwili wymienić („Nowy kod”) albo usunąć miejsce.
- Serwer nie udostępnia folderów `dane`, `kopie` ani plików serwera — tylko wygląd panelu i dane po zalogowaniu.

## Kopie zapasowe

Bez zmian: `kopie/autokopia.json` po każdej zmianie, stan z każdej godziny, z końca dnia (30 dni),
kopia przed dużą zmianą i kopie ręczne. Zarządzasz nimi w panelu: kliknij plakietkę „Autokopia” w pasku bocznym.
