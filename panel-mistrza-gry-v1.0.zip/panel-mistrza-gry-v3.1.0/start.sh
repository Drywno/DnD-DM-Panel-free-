#!/bin/sh
# Panel Mistrza Gry — uruchomienie na macOS / Linux · start on macOS / Linux
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
    echo "Nie znaleziono Node.js — zainstaluj wersję LTS: https://nodejs.org"
    echo "Node.js not found — install the LTS version: https://nodejs.org"
    exit 1
fi
exec node serwer.js "$@"
